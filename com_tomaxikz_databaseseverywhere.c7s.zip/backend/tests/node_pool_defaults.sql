-- Run with psql -v ON_ERROR_STOP=1 -f tests/node_pool_defaults.sql on a disposable DB.
BEGIN;
CREATE SCHEMA dbev_node_defaults_test;
SET LOCAL search_path TO dbev_node_defaults_test;

CREATE TABLE com_tomaxikz_databaseseverywhere_nodes (
    name text PRIMARY KEY,
    default_cpu_cores double precision NOT NULL DEFAULT 0.5,
    default_memory_mib bigint NOT NULL DEFAULT 512,
    default_disk_mib bigint NOT NULL DEFAULT 1024
);
CREATE TABLE servers (
    name text PRIMARY KEY,
    dbev_pool_cpu_cores double precision NOT NULL DEFAULT 1,
    dbev_pool_memory_mib bigint NOT NULL DEFAULT 1024,
    dbev_pool_disk_mib bigint NOT NULL DEFAULT 16384,
    dbev_pool_max_databases integer NOT NULL DEFAULT 8
);
CREATE TABLE com_tomaxikz_databaseseverywhere_shared_pools (
    runtime_id text PRIMARY KEY,
    cpu_cores double precision,
    memory_mib bigint,
    disk_mib bigint,
    max_databases integer
);
INSERT INTO com_tomaxikz_databaseseverywhere_nodes (name) VALUES ('existing');
INSERT INTO servers VALUES ('existing', 3, 3072, 32768, 12);
INSERT INTO com_tomaxikz_databaseseverywhere_shared_pools VALUES ('pool-1', 2, 2048, 8192, 8);
CREATE TEMP TABLE original_pool AS TABLE com_tomaxikz_databaseseverywhere_shared_pools;

\ir ../migrations/20260911130000_node_pool_defaults/up.sql

INSERT INTO servers (name) VALUES ('new');
INSERT INTO com_tomaxikz_databaseseverywhere_nodes (name) VALUES ('new');
DO $$
BEGIN
    IF (SELECT dbev_pool_use_node_defaults FROM servers WHERE name = 'existing') THEN
        RAISE EXCEPTION 'Migration changed existing server allocation policy';
    END IF;
    IF NOT (SELECT dbev_pool_use_node_defaults FROM servers WHERE name = 'new') THEN
        RAISE EXCEPTION 'New servers do not inherit';
    END IF;
    IF EXISTS (
        SELECT FROM com_tomaxikz_databaseseverywhere_nodes
        WHERE (default_pool_cpu_cores, default_pool_memory_mib, default_pool_disk_mib,
               default_pool_max_databases) <> (1, 1024, 16384, 8)
    ) THEN
        RAISE EXCEPTION 'Incorrect node defaults';
    END IF;
    BEGIN
        UPDATE com_tomaxikz_databaseseverywhere_nodes SET default_pool_cpu_cores = 'NaN';
        RAISE EXCEPTION 'NaN CPU accepted';
    EXCEPTION WHEN check_violation THEN NULL;
    END;
    BEGIN
        UPDATE com_tomaxikz_databaseseverywhere_nodes SET default_pool_memory_mib = 0;
        RAISE EXCEPTION 'Invalid memory accepted';
    EXCEPTION WHEN check_violation THEN NULL;
    END;
    BEGIN
        UPDATE com_tomaxikz_databaseseverywhere_nodes SET default_pool_disk_mib = 9007199254740992;
        RAISE EXCEPTION 'Unsafe disk accepted';
    EXCEPTION WHEN check_violation THEN NULL;
    END;
    BEGIN
        UPDATE com_tomaxikz_databaseseverywhere_nodes SET default_pool_max_databases = 1025;
        RAISE EXCEPTION 'Invalid tenant capacity accepted';
    EXCEPTION WHEN check_violation THEN NULL;
    END;
END $$;

UPDATE com_tomaxikz_databaseseverywhere_nodes SET
    default_pool_cpu_cores = 4, default_pool_memory_mib = 4096,
    default_pool_disk_mib = 65536, default_pool_max_databases = 32;
DO $$
BEGIN
    IF EXISTS (
        SELECT FROM servers WHERE name = 'existing' AND
        (dbev_pool_cpu_cores, dbev_pool_memory_mib, dbev_pool_disk_mib, dbev_pool_max_databases)
          <> (3, 3072, 32768, 12)
    ) THEN
        RAISE EXCEPTION 'Existing override changed';
    END IF;
    IF EXISTS (
        SELECT FROM com_tomaxikz_databaseseverywhere_nodes WHERE
        (default_cpu_cores, default_memory_mib, default_disk_mib) <> (0.5, 512, 1024)
    ) THEN
        RAISE EXCEPTION 'Child defaults changed';
    END IF;
END $$;

\ir ../migrations/20260911130000_node_pool_defaults/down.sql

DO $$
BEGIN
    IF EXISTS (
        (TABLE com_tomaxikz_databaseseverywhere_shared_pools EXCEPT TABLE original_pool)
        UNION ALL
        (TABLE original_pool EXCEPT TABLE com_tomaxikz_databaseseverywhere_shared_pools)
    ) THEN
        RAISE EXCEPTION 'Existing pool allocation changed';
    END IF;
    IF EXISTS (
        SELECT FROM information_schema.columns WHERE table_schema = 'dbev_node_defaults_test'
          AND (column_name LIKE 'default_pool_%' OR column_name = 'dbev_pool_use_node_defaults')
    ) THEN
        RAISE EXCEPTION 'Down migration left columns behind';
    END IF;
END $$;
ROLLBACK;
