# DBEV 0.17 persistent pools

The contract reference for this update is DBEV binary **0.8.0**, API **0.17.0**, fixed source commit [b679f09ffbaeb631ac08d85f2bc44e64bfb8c950](https://github.com/Tomaxikz/DatabasesEverywhere/tree/b679f09ffbaeb631ac08d85f2bc44e64bfb8c950). It includes batch-backup failure reporting after the original 0.8.0 tag.

This addon requires DBEV API **0.17.0 or newer**. Every placement decision starts with a fresh, authenticated `GET /api/system`; Axios consumers and the Rust client read the raw response body directly. Shared placement additionally requires the selected protocol to be enabled with `shared` mode, `server_private_pools: true`, and `shared_pool_scope: "server"`.

Dedicated placement retains the existing instance flow. Shared placement is supported only for PostgreSQL, MySQL, MariaDB, MongoDB, and ClickHouse. Redis, Valkey, and Qdrant are dedicated-only.

## Persistent ownership

- The panel derives `server_id` from the authorized immutable game-server UUID. Browsers cannot select it.
- A durable `(server UUID, engine) -> (node UUID, runtime_id)` mapping is stored before any child operation is allowed.
- Node UUID and token_id must match the fresh root system response. token_id is a stable ownership namespace; rotating the token secret must not change it.
- Pool reports use `owner.server_id` and `owner.panel_id`, with root `cpu`, `memory`, and `disk` samples. Pool resize returns `PoolConfig` (owner/runtime/limits), not a resource report.
- Every parent operation refreshes `/api/system`, loads the exact `/api/pools/{runtime_id}` object, and verifies server, engine, node, and runtime ownership.
- One persistent engine pool exists per server and engine. Capacity exhaustion fails; it never creates an overflow pool or silently changes node.
- Deleting the last child keeps the pool. Explicit pool deletion requires an empty local and remote inventory, confirmation, a reason, and its own permission.

## Shared pool defaults

Set defaults under **Admin → DatabasesEverywhere → create/edit node → Containers & capacity → Shared pool defaults**.
CPU cores, memory (MiB), total disk (MiB), and maximum databases apply to each new engine pool on that DBEV node.
They are panel-side allocation settings, not daemon configuration keys. Initial defaults are 1 CPU, 1024 MiB memory,
16384 MiB disk, and 8 databases.

New game servers use **Use DBEV node defaults** under their DatabasesEverywhere feature limits. Turn it off to
set explicit per-server pool allocations. The actual selected/pinned DBEV node supplies inherited defaults;
another node's values are never substituted. Dedicated CPU/RAM and child disk allowances remain separate.

Apply `20260911130000_node_pool_defaults` with the updated backend/frontend. Existing servers retain their
explicit allocations (inheritance starts disabled); administrators can opt them in. Existing pool mappings
retain their saved limits. Editing defaults does not resize engines or enqueue child limit synchronization.
Explicit pool resize requests still use the current administrator-approved allocation as their ceiling,
which comes from the mapped node when inheritance is enabled. No pool is automatically resized.

## Creation and migration

The parent is accepted by `POST /api/pools` with the complete administrator-approved `PoolLimits`. The panel persists `runtime_id` and `status_url`, polls the operation, then creates the child at `POST /api/pools/{runtime_id}/instances`. Child creation sends only its identity, credentials, database endpoint, and disk allowance. CPU and memory belong to the parent.

Dedicated-to-shared migration requires the user to select an existing compatible `pool_id`. Pool image changes are explicit parent operations; the panel creates child backups before forwarding a confirmed same-release-line update. Pending or quarantined updates are left for operator attention.

## Dashboard and WebSockets

The server dashboard lists authorized persistent pools, including empty pools. Parent start/stop/restart/kill controls are distinct from child Enable/Disable database-access controls. CPU, memory, and disk charts are labeled as whole-engine metrics and preserve null/stale samples.

Monitoring and logs mint a new single-use JWT on every connection and reconnect. Pool grants contain only the authorized runtime in `pools` and exactly one of `pools:monitor` or `pools:logs`; database-only subusers are not granted these permissions. Monitoring reconnects after sequence gaps and applies progress reset, removals, and runtime-keyed updates. Logs consume reset/append/end events verbatim in bounded text buffers.

## API type generation

The stale 0.16 generated client was removed so removed `/api/admin/shared-pools` contracts cannot be used accidentally. Regenerate it only from the coordinated 0.17 schema:

```sh
DBEV_OPENAPI_SOURCE=/path/to/dbev-0.17/docs/api/openapi.yml bash scripts/generate-dbev-api-types.sh
```

The generator rejects any schema whose declared version is not exactly 0.17.0. Coordinate addon deployment with the updated daemon; older daemons fail closed and must not receive this addon build.

## Upgrade and failure handling

Apply the new `20260911120000_pool_contract` migration before starting the updated backend. It changes validation constraints, not saved allocation values. DBEV remains responsible for engine-specific startup floors. Its down migration refuses allocations below the former floors rather than silently increasing them.

The migration adds a durable creation claim: only one worker can POST a new pool. Existing unbound mappings and ambiguous POSTs require operator reconciliation on the originally pinned node. Do not clear a claim merely to retry: first verify whether the original pool exists and bind its verified runtime/status identity. Never adopt another owner's pool. Legacy automatic cleanup requests caused by invalid creation acceptance are retained but no longer executed; operator review is required.

Creating/failed pools with a persisted runtime are read via their durable status URL even before a metrics report is published. Missing reports never become zero metrics. Missing accepted child creation state retains the child's identity and quota instead of scheduling deletion or releasing it speculatively.

Temporary uploads use root arrays and root catalog inspection. An expired upload's 404 does not permanently disable the upload UI. Operator-staged imports remain supported and their files are untouched.

A batch-backup HTTP 200 means the pass finished, not that all databases succeeded. The report requires `backups`, `skipped`, and `failed`; it displays failures and support IDs separately. Pool backup lists remain per-child archives, never atomic engine snapshots.

Deployment must coordinate the fixed daemon build, the extension migration/backend, and the frontend build. No live daemon, production database, or credentials were modified during implementation. Before production rollout, run an authenticated GET /api/system smoke test on each assigned node, exercise pool ownership denial, concurrent first-child creation, pending/failed creation, nullable/stale monitoring, socket reconnects, and mixed-result backup runs against disposable databases. A production daemon round-trip and migration up/down test still require an approved disposable environment.
