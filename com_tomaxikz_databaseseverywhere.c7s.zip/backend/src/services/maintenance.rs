use super::lifecycle::{deletion_response_confirms_purge, refresh_deployment_migration};
use crate::{
    dbev::{DbevClient, validate_system_response},
    domain::{ResourceLimits, ServerDatabaseConfigurationExtension},
    persistence::{
        DatabaseRecord, DeleteInstanceOperation, NodeRecord, remote_operation_completed,
        remote_runtime_id, remote_status,
    },
    settings::{ExtensionSettingsData, normalize_node_health_interval},
};
use shared::{
    State,
    models::{BaseModel, ByUuid, server::Server},
    response::extract_readable_error,
};
use std::time::Duration;

pub async fn run_maintenance_loop(state: State) {
    let mut next_health_refresh = tokio::time::Instant::now();
    let mut next_limit_sync = tokio::time::Instant::now();
    loop {
        let (enabled, health_interval) = match maintenance_settings(&state).await {
            Ok(settings) => settings,
            Err(error) => {
                tracing::error!(error = ?error, "failed to read DatabasesEverywhere settings");
                (true, 300)
            }
        };

        if enabled {
            let now = tokio::time::Instant::now();
            if now >= next_health_refresh {
                if let Err(error) = refresh_node_health(&state).await {
                    tracing::warn!(error = ?error, "DatabasesEverywhere node health refresh failed");
                }
                next_health_refresh = now + Duration::from_secs(health_interval);
            }
            if let Err(error) = process_deletion_operations(&state).await {
                tracing::warn!(error = ?error, "DatabasesEverywhere deletion outbox processing failed");
            }
            if let Err(error) = refresh_pending_lifecycle(&state).await {
                tracing::warn!(error = ?error, "DatabasesEverywhere lifecycle refresh failed");
            }
            if now >= next_limit_sync {
                if let Err(error) = synchronize_database_limits(&state).await {
                    tracing::warn!(error = ?error, "DatabasesEverywhere resource synchronization failed");
                }
                next_limit_sync = now + Duration::from_secs(60);
            }
        } else {
            next_health_refresh = tokio::time::Instant::now();
            next_limit_sync = tokio::time::Instant::now();
        }

        tokio::time::sleep(Duration::from_secs(5)).await;
    }
}

async fn refresh_pending_lifecycle(state: &State) -> Result<(), anyhow::Error> {
    for database in DatabaseRecord::pending_lifecycle_refresh(state).await? {
        let result = async {
            if database.migration_active() {
                refresh_deployment_migration(state, &database).await?;
                return Ok::<_, anyhow::Error>(());
            }

            let node = NodeRecord::by_uuid(state, database.dbev_node_uuid)
                .await?
                .ok_or_else(|| anyhow::anyhow!("DatabasesEverywhere node no longer exists"))?;
            let client = DbevClient::for_mutation(state, &node).await?;
            let remote = match client
                .get::<serde_json::Value>(&database.status_url())
                .await
            {
                Ok(remote) => remote,
                Err(status_error)
                    if database.creation_pending()
                        && error_has_status(&status_error, axum::http::StatusCode::NOT_FOUND) =>
                {
                    let instance_path = format!(
                        "/api/instances/{}",
                        urlencoding::encode(&database.instance_id())
                    );
                    match client.get::<serde_json::Value>(&instance_path).await {
                        Ok(instance) => instance,
                        Err(instance_error)
                            if error_has_status(
                                &instance_error,
                                axum::http::StatusCode::NOT_FOUND,
                            ) =>
                        {
                            database
                                .store_error(
                                    state,
                                    "DBEV no longer reports the accepted creation; identity and quota retained for operator reconciliation",
                                )
                                .await?;
                            return Ok::<_, anyhow::Error>(());
                        }
                        Err(instance_error) => return Err(instance_error),
                    }
                }
                Err(error) => return Err(error),
            };
            database.update_remote_state(state, &remote).await?;

            let terminal_without_runtime = remote_status(&remote)
                .is_some_and(|status| !matches!(status, "creating" | "booting" | "failed"))
                && remote_runtime_id(&remote).is_none();
            if terminal_without_runtime || remote_operation_completed(&remote) {
                let instance = client
                    .get::<serde_json::Value>(&format!(
                        "/api/instances/{}",
                        urlencoding::encode(&database.instance_id())
                    ))
                    .await?;
                database.update_remote_state(state, &instance).await?;
            }
            Ok(())
        }
        .await;
        if let Err(error) = result {
            database.store_error(state, &error.to_string()).await?;
            tracing::warn!(database = %database.uuid, error = ?error, "failed to refresh DatabasesEverywhere lifecycle state");
        }
    }
    Ok(())
}

fn error_has_status(error: &anyhow::Error, expected: axum::http::StatusCode) -> bool {
    extract_readable_error(error).is_some_and(|(_, status)| status == expected)
}

pub async fn synchronize_database_limits(state: &State) -> Result<(), anyhow::Error> {
    for database in DatabaseRecord::pending_limit_sync(state).await? {
        let result = synchronize_one(state, &database).await;
        if let Err(error) = result {
            database.store_error(state, &error.to_string()).await?;
            tracing::warn!(database = %database.uuid, error = ?error, "failed to synchronize DatabasesEverywhere limits");
        }
    }
    Ok(())
}

async fn synchronize_one(state: &State, database: &DatabaseRecord) -> Result<(), anyhow::Error> {
    if database.migration_active() {
        return Ok(());
    }
    let server = Server::by_uuid_optional(&state.database, database.server_uuid)
        .await?
        .ok_or_else(|| anyhow::anyhow!("server no longer exists"))?;
    let configuration = server.parse_model_extension::<ServerDatabaseConfigurationExtension>()?;
    let node = NodeRecord::by_uuid(state, database.dbev_node_uuid)
        .await?
        .ok_or_else(|| anyhow::anyhow!("DatabasesEverywhere node no longer exists"))?;
    let mut requested = ResourceLimits {
        cpu_cores: configuration.cpu_cores.unwrap_or(node.default_cpu_cores),
        memory_mib: configuration.memory_mib.unwrap_or(node.default_memory_mib),
        disk_mib: configuration.disk_mib.unwrap_or(node.default_disk_mib),
    };
    if database.deployment_mode == crate::domain::DeploymentMode::Shared {
        let current = database.limits();
        requested.cpu_cores = current.cpu_cores;
        requested.memory_mib = current.memory_mib;
        // A product ceiling can reduce an allowance, but never silently expand
        // a tenant or change the administrator's physical pool budget.
        requested.disk_mib = requested.disk_mib.min(current.disk_mib);
    } else {
        requested = requested.with_protocol_floors(database.protocol);
    }
    let client = DbevClient::for_mutation(state, &node).await?;
    let path = format!(
        "/api/instances/{}/limits",
        urlencoding::encode(&database.instance_id())
    );
    let limits = if database.deployment_mode == crate::domain::DeploymentMode::Shared {
        let pool_id = database
            .metadata
            .get("pool_id")
            .and_then(serde_json::Value::as_str)
            .ok_or_else(|| anyhow::anyhow!("shared database has no verified parent mapping"))?;
        let pool = super::pools::load_owned_pool(state, database.server_uuid, pool_id).await?;
        if pool.mapping.node_uuid != database.dbev_node_uuid
            || pool.mapping.protocol != database.protocol
        {
            return Err(anyhow::anyhow!(
                "shared database parent mapping does not match"
            ));
        }
        serde_json::json!({"disk_mib": requested.disk_mib})
    } else {
        serde_json::to_value(requested)?
    };
    client.patch::<serde_json::Value, _>(&path, &limits).await?;
    database.update_limits(state, requested, true).await
}

async fn refresh_node_health(state: &State) -> Result<(), anyhow::Error> {
    for node in NodeRecord::all(state)
        .await?
        .into_iter()
        .filter(|node| node.enabled)
    {
        let client = match DbevClient::for_node(state, &node).await {
            Ok(client) => client,
            Err(error) => {
                node.store_health(state, None, None, Some(&error.to_string()))
                    .await?;
                continue;
            }
        };
        let health = async {
            let heartbeat = client.get::<serde_json::Value>("/api/heartbeat").await?;
            if heartbeat.get("status").and_then(serde_json::Value::as_str) != Some("ok") {
                return Err(anyhow::anyhow!("node heartbeat is not ready"));
            }
            let system = client.system().await?;
            Ok::<_, anyhow::Error>(system)
        }
        .await;
        match health {
            Ok(system) => {
                let contract_error = validate_system_response(&system)
                    .err()
                    .map(|error| error.to_string());
                node.store_health(state, Some(&system), None, contract_error.as_deref())
                    .await?;
            }
            Err(error) => {
                node.store_health(state, None, None, Some(&error.to_string()))
                    .await?;
            }
        }
    }
    Ok(())
}

async fn process_deletion_operations(state: &State) -> Result<(), anyhow::Error> {
    for operation in DeleteInstanceOperation::due(state).await? {
        let result = async {
            let node = NodeRecord::by_uuid(state, operation.dbev_node_uuid)
                .await?
                .ok_or_else(|| anyhow::anyhow!("DatabasesEverywhere node no longer exists"))?;
            let client = DbevClient::for_mutation(state, &node).await?;
            let path = format!(
                "/api/instances/{}?confirm=true&reason={}",
                urlencoding::encode(&operation.instance_id),
                urlencoding::encode(&operation.reason),
            );
            if let Some(response) = client.delete_allow_not_found(&path).await?
                && !deletion_response_confirms_purge(&response)
            {
                return Err(anyhow::anyhow!(
                    "DatabasesEverywhere did not confirm permanent deletion and purge"
                ));
            }
            Ok::<_, anyhow::Error>(())
        }
        .await;
        match result {
            Ok(()) => operation.complete(state).await?,
            Err(error) => operation.fail(state, &error.to_string()).await?,
        }
    }
    Ok(())
}

async fn maintenance_settings(state: &State) -> Result<(bool, u64), anyhow::Error> {
    let settings = state.settings.get().await?;
    let extension = settings
        .get_extension_settings::<ExtensionSettingsData>("com.tomaxikz.databaseseverywhere")?;
    Ok((
        extension.enabled,
        normalize_node_health_interval(extension.node_health_interval_seconds),
    ))
}
