use crate::{
    dbev::{DbevCapabilities, DbevClient},
    domain::{DatabaseProtocol, DeploymentMode, NodeDeploymentPolicy, ResourceLimits},
    persistence::{
        DatabaseRecord, migration_status, remote_instance, remote_runtime_id, remote_status,
    },
    services::scheduler::select_node,
};
use rand::distr::SampleString;
use regex::Regex;
use serde::{Deserialize, Serialize};
use shared::{
    State,
    models::server::Server,
    response::{DisplayError, extract_readable_error},
};
use std::sync::LazyLock;
use utoipa::ToSchema;

static DATABASE_IDENTIFIER: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"^[A-Za-z][A-Za-z0-9_-]{0,62}$").unwrap());

#[derive(Debug, Clone, Deserialize, ToSchema)]
pub struct CreateDatabaseInput {
    pub protocol: DatabaseProtocol,
    pub deployment_mode: Option<DeploymentMode>,
    pub display_name: String,
    pub database_name: Option<String>,
    pub username: Option<String>,
    pub image: Option<String>,
    pub limits: Option<ResourceLimits>,
}

#[derive(Debug, Clone, Serialize, ToSchema)]
pub struct DeleteDatabaseOutcome {
    pub deferred: bool,
}

#[derive(Debug, Clone, Serialize, ToSchema)]
pub struct ResetPasswordOutcome {
    pub restarted: bool,
}

#[derive(Debug, Clone, Deserialize, ToSchema)]
pub struct StartDeploymentMigrationInput {
    pub target_mode: DeploymentMode,
    pub pool_id: Option<String>,
}

#[derive(Debug, Clone, Serialize, ToSchema)]
pub struct DeploymentMigrationOutcome {
    pub migration: serde_json::Value,
    pub location: Option<String>,
}

pub async fn create_database(
    state: &State,
    server: &Server,
    input: CreateDatabaseInput,
) -> Result<DatabaseRecord, anyhow::Error> {
    ensure_extension_enabled(state).await?;
    validate_create_input(&input)?;

    let deployment_mode = input.deployment_mode.unwrap_or_default();
    let scheduled = select_node(
        state,
        server,
        input.protocol,
        deployment_mode,
        input.image.as_deref(),
        input.limits,
    )
    .await?;
    let uuid = uuid::Uuid::new_v4();
    let compact_uuid = uuid.simple().to_string();
    let database_name = input
        .database_name
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(str::to_owned)
        .unwrap_or_else(|| format!("c7s_{}", &compact_uuid[..20]));
    let username = input
        .username
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(str::to_owned)
        .unwrap_or_else(|| format!("u_{}", &compact_uuid[..20]));
    validate_identifier("database name", &database_name)?;
    validate_identifier("username", &username)?;
    let password = rand::distr::Alphanumeric.sample_string(&mut rand::rng(), 40);
    let instance_id = uuid.to_string();
    let public_port = i32::from(scheduled.node.gateway_port(input.protocol));
    let tls = scheduled.node.protocol_tls(input.protocol);

    let record = DatabaseRecord::create(
        state,
        uuid,
        server.uuid,
        scheduled.node.uuid,
        input.protocol,
        deployment_mode,
        input.display_name.trim(),
        &database_name,
        &username,
        &password,
        &scheduled.node.public_host,
        public_port,
        tls,
        "creating",
        input.image.as_deref(),
        scheduled.limits,
        serde_json::json!({
            "api_version": scheduled.system.get("api_version"),
            "daemon_version": scheduled.system.get("version"),
            "node_uuid": scheduled.node.daemon_uuid.clone(),
            "panel_creation_pending": true,
        }),
    )
    .await?;

    let prepared = async {
        if deployment_mode == DeploymentMode::Shared {
            let pool = crate::services::pools::ensure_pool_ready(
                state,
                server,
                input.protocol,
                &scheduled.node,
                input.image.as_deref(),
            )
            .await?;
            crate::services::pools::ensure_pool_capacity(
                state,
                &pool,
                Some((&instance_id, scheduled.limits.disk_mib)),
            )
            .await?;
            let runtime_id = pool.mapping.require_runtime()?.to_owned();
            record
                .update_remote_state(state, &serde_json::json!({"pool_id": runtime_id}))
                .await?;
            Ok::<_, anyhow::Error>((
                pool.client,
                format!("/api/pools/{}/instances", urlencoding::encode(&runtime_id)),
                serde_json::json!({
                    "instance_id": instance_id,
                    "database": database_name,
                    "username": username,
                    "password": password,
                    "public_host": scheduled.node.public_host.clone(),
                    "public_port": public_port,
                    "disk_mib": scheduled.limits.disk_mib,
                }),
                Some(runtime_id),
            ))
        } else {
            let client = DbevClient::for_mutation(state, &scheduled.node).await?;
            let mut payload = serde_json::json!({
                "instance_id": instance_id,
                "protocol": input.protocol,
                "deployment_mode": deployment_mode,
                "database": database_name,
                "username": username,
                "password": password,
                "public_host": scheduled.node.public_host.clone(),
                "public_port": public_port,
                "project_id": server.uuid.to_string(),
                "limits": scheduled.limits,
            });
            if let Some(image) = input.image.as_deref() {
                payload["image"] = serde_json::Value::String(image.to_owned());
            }
            Ok((client, "/api/instances".to_owned(), payload, None))
        }
    }
    .await;
    let (client, creation_path, payload, pool_runtime_id) = match prepared {
        Ok(prepared) => prepared,
        Err(error) => {
            if let Err(store_error) = record
                .release_quota_with_error(state, &error.to_string())
                .await
            {
                tracing::error!(database = %record.uuid, error = ?store_error, "failed to release a creation reservation after DBEV contract validation failed");
            }
            return Err(error);
        }
    };
    let accepted = client
        .post_accepted_with_location::<serde_json::Value, _>(&creation_path, &payload)
        .await;
    let accepted = match accepted {
        Ok(accepted) => accepted,
        Err(error) => {
            let ambiguous = mutation_outcome_is_ambiguous(&error);
            let store = if ambiguous {
                record.store_error(state, &error.to_string()).await
            } else {
                record
                    .release_quota_with_error(state, &error.to_string())
                    .await
            };
            if let Err(store_error) = store {
                tracing::error!(database = %record.uuid, error = ?store_error, "failed to persist rejected DatabasesEverywhere creation state");
            }
            return Err(error);
        }
    };

    let accepted_value = accepted.value;
    let status_location = if deployment_mode == DeploymentMode::Shared {
        shared_child_status_location(&accepted_value, &instance_id)
    } else {
        creation_status_location(accepted.location.as_deref(), &accepted_value, &instance_id)
    };
    let response_compatible = if deployment_mode == DeploymentMode::Shared {
        shared_child_response_is_compatible(&accepted_value, &instance_id)
    } else {
        creation_response_is_compatible(&accepted_value, &instance_id)
    };
    if !response_compatible || status_location.is_err() {
        // The POST may have succeeded. Keep identity and quota until an operator
        // reconciles that exact instance; malformed acceptance is not permission to delete it.
        record
            .store_error(
                state,
                "DBEV creation acceptance was invalid; operator reconciliation is required",
            )
            .await?;
        return Err(DisplayError::new(
            "DBEV creation acceptance was invalid; operator reconciliation is required",
        )
        .with_status(axum::http::StatusCode::BAD_GATEWAY)
        .into());
    }

    let mut accepted_object = accepted_value.as_object().cloned().unwrap_or_default();
    accepted_object.insert(
        "status_url".to_owned(),
        serde_json::Value::String(status_location.unwrap()),
    );
    if let Some(pool_id) = pool_runtime_id {
        accepted_object.insert("pool_id".to_owned(), serde_json::Value::String(pool_id));
    }
    let accepted_value = serde_json::Value::Object(accepted_object);
    record.update_remote_state(state, &accepted_value).await?;
    DatabaseRecord::by_server_uuid(state, server.uuid, uuid)
        .await?
        .ok_or_else(|| anyhow::anyhow!("created database record disappeared"))
}

async fn ensure_extension_enabled(state: &State) -> Result<(), anyhow::Error> {
    if !extension_provisioning_enabled(state).await? {
        return Err(
            DisplayError::new("the DatabasesEverywhere extension is disabled")
                .with_status(axum::http::StatusCode::SERVICE_UNAVAILABLE)
                .into(),
        );
    }
    Ok(())
}

pub async fn extension_provisioning_enabled(state: &State) -> Result<bool, anyhow::Error> {
    let settings = state.settings.get().await?;
    let extension = settings.get_extension_settings::<crate::settings::ExtensionSettingsData>(
        "com.tomaxikz.databaseseverywhere",
    )?;
    Ok(extension.enabled)
}

pub async fn delete_database(
    state: &State,
    database: &DatabaseRecord,
    reason: &str,
) -> Result<DeleteDatabaseOutcome, anyhow::Error> {
    ensure_database_mutable(database)?;
    let reason = reason.trim();
    if reason.is_empty() {
        return Err(DisplayError::new("a deletion reason is required").into());
    }
    let node = crate::persistence::NodeRecord::by_uuid(state, database.dbev_node_uuid)
        .await?
        .ok_or_else(|| anyhow::anyhow!("DatabasesEverywhere node no longer exists"))?;
    let client = DbevClient::for_mutation(state, &node).await?;
    let path = format!(
        "/api/instances/{}?confirm=true&reason={}",
        urlencoding::encode(&database.instance_id()),
        urlencoding::encode(reason),
    );

    match client.delete_allow_not_found(&path).await {
        Ok(Some(response)) => {
            if !deletion_response_confirms_purge(&response) {
                return Err(DisplayError::new(
                    "DatabasesEverywhere did not confirm permanent deletion and purge",
                )
                .with_status(axum::http::StatusCode::BAD_GATEWAY)
                .into());
            }
            database.delete_local(state).await?;
            Ok(DeleteDatabaseOutcome { deferred: false })
        }
        Ok(None) => {
            database.delete_local(state).await?;
            Ok(DeleteDatabaseOutcome { deferred: false })
        }
        // Never replay a delete after an ambiguous response.
        Err(error) => Err(error),
    }
}

pub(crate) fn deletion_response_confirms_purge(response: &serde_json::Value) -> bool {
    response.get("deleted").and_then(serde_json::Value::as_bool) == Some(true)
        && response.get("purged").and_then(serde_json::Value::as_bool) == Some(true)
}

pub async fn set_database_power(
    state: &State,
    database: &DatabaseRecord,
    action: &str,
) -> Result<serde_json::Value, anyhow::Error> {
    ensure_database_mutable(database)?;
    validate_database_power_action(database.deployment_mode, action)?;
    if database.status == "quarantined" {
        return Err(DisplayError::new(
            "this database is quarantined; inspect or reconcile it before using normal power actions",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    }
    let (node, client) = client_for_database(state, database).await?;
    let response = client
        .post::<serde_json::Value, _>(
            &format!(
                "/api/instances/{}/power",
                urlencoding::encode(&database.instance_id())
            ),
            &serde_json::json!({ "action": action }),
        )
        .await?;
    database.update_remote_state(state, &response).await?;
    drop(node);
    Ok(response)
}

fn validate_database_power_action(
    deployment_mode: DeploymentMode,
    action: &str,
) -> Result<(), anyhow::Error> {
    if !matches!(action, "start" | "stop" | "restart" | "kill") {
        return Err(DisplayError::new("unsupported DatabasesEverywhere power action").into());
    }
    if deployment_mode == DeploymentMode::Shared && !matches!(action, "start" | "stop") {
        return Err(DisplayError::new(
            "shared child controls only enable or disable database access; restart and kill belong to the parent pool",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    }
    Ok(())
}

pub async fn set_database_image(
    state: &State,
    database: &DatabaseRecord,
    image: &str,
    major_upgrade: bool,
    legacy_password: Option<&str>,
) -> Result<serde_json::Value, anyhow::Error> {
    ensure_database_mutable(database)?;
    if database.deployment_mode == DeploymentMode::Shared {
        return Err(DisplayError::new(
            "shared databases use their pool image and cannot be updated individually",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    }
    validate_image(image)?;
    if database.status == "quarantined" {
        return Err(DisplayError::new(
            "this database is quarantined; inspect or reconcile it before replacing its image",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    }
    if major_upgrade
        && matches!(
            database.protocol,
            DatabaseProtocol::Redis | DatabaseProtocol::Valkey | DatabaseProtocol::Qdrant
        )
    {
        return Err(DisplayError::new(
            "major upgrades are not supported for Redis, Valkey, or Qdrant",
        )
        .into());
    }
    let (node, client) = client_for_database(state, database).await?;
    let system = client.system().await?;
    let capabilities = DbevCapabilities::from_system(&system);
    node.store_health(state, Some(&system), None, None).await?;

    let explicitly_supplied = legacy_password.filter(|password| !password.is_empty());
    let password = if capabilities.stored_tenant_credentials {
        explicitly_supplied.map(str::to_owned)
    } else {
        Some(match explicitly_supplied {
            Some(password) => password.to_owned(),
            None => database.decrypted_password(state).await?,
        })
    };
    if let Some(password) = password.as_deref() {
        validate_password(password)?;
    }
    let payload = image_update_payload(image, major_upgrade, password.as_deref());
    let response = client
        .patch::<serde_json::Value, _>(
            &format!(
                "/api/instances/{}/image",
                urlencoding::encode(&database.instance_id())
            ),
            &payload,
        )
        .await;
    let response = match response {
        Ok(response) => response,
        Err(error) => {
            if extract_readable_error(&error)
                .is_some_and(|(_, status)| status == axum::http::StatusCode::INTERNAL_SERVER_ERROR)
                && let Ok(refreshed) = client
                    .get::<serde_json::Value>(&format!(
                        "/api/instances/{}",
                        urlencoding::encode(&database.instance_id())
                    ))
                    .await
                && let Err(refresh_error) = database.update_remote_state(state, &refreshed).await
            {
                tracing::warn!(database = %database.uuid, error = ?refresh_error, "failed to refresh database state after an internal image update failure");
            }
            return Err(error);
        }
    };
    database.update_remote_state(state, &response).await?;
    Ok(response)
}

pub async fn reconcile_database(
    state: &State,
    database: &DatabaseRecord,
) -> Result<serde_json::Value, anyhow::Error> {
    ensure_database_mutable(database)?;
    let (_node, client) = client_for_database(state, database).await?;
    let path = format!(
        "/api/instances/{}/reconcile",
        urlencoding::encode(&database.instance_id())
    );
    let response = client
        .post::<serde_json::Value, _>(&path, &serde_json::json!({}))
        .await?;
    database.update_remote_state(state, &response).await?;
    Ok(response)
}

pub async fn reset_database_password(
    state: &State,
    database: &DatabaseRecord,
    password: &str,
) -> Result<ResetPasswordOutcome, anyhow::Error> {
    ensure_database_mutable(database)?;
    validate_password(password)?;
    let (_node, client) = client_for_database(state, database).await?;
    let instance_path = format!(
        "/api/instances/{}",
        urlencoding::encode(&database.instance_id())
    );
    let current = client.get::<serde_json::Value>(&instance_path).await?;
    database.update_remote_state(state, &current).await?;
    if remote_instance(&current)
        .get("status")
        .and_then(serde_json::Value::as_str)
        != Some("running")
    {
        return Err(DisplayError::new(
            "the database must be running before its credential can be reset",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    }

    let path = format!("{instance_path}/password");
    let response = client
        .patch::<serde_json::Value, _>(&path, &serde_json::json!({ "password": password }))
        .await;
    let response = match response {
        Ok(response) => response,
        Err(error) => {
            if let Ok(refreshed) = client.get::<serde_json::Value>(&instance_path).await
                && let Err(refresh_error) = database.update_remote_state(state, &refreshed).await
            {
                tracing::warn!(database = %database.uuid, error = ?refresh_error, "failed to refresh database state after a rejected credential reset");
            }
            return Err(error);
        }
    };
    if contains_plaintext_credential(&response) {
        return Err(anyhow::Error::new(
            DisplayError::new("DatabasesEverywhere returned an unsafe password reset response")
                .with_status(axum::http::StatusCode::BAD_GATEWAY),
        ));
    }

    let (instance, restarted) = parse_password_reset_response(&response)?;
    database.update_remote_state(state, instance).await?;
    database.update_password(state, password).await?;
    Ok(ResetPasswordOutcome { restarted })
}

pub async fn start_deployment_migration(
    state: &State,
    database: &DatabaseRecord,
    input: StartDeploymentMigrationInput,
) -> Result<DeploymentMigrationOutcome, anyhow::Error> {
    ensure_database_mutable(database)?;
    if input.target_mode == database.deployment_mode {
        return Err(
            DisplayError::new("the database already uses the requested placement")
                .with_status(axum::http::StatusCode::CONFLICT)
                .into(),
        );
    }

    let node = crate::persistence::NodeRecord::by_uuid(state, database.dbev_node_uuid)
        .await?
        .ok_or_else(|| anyhow::anyhow!("DatabasesEverywhere node no longer exists"))?;
    if node.deployment_policy != NodeDeploymentPolicy::Hybrid {
        return Err(DisplayError::new(
            "dedicated/shared migrations are available only while this node uses hybrid policy",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    }
    let (client, system) = DbevClient::for_mutation_with_system(state, &node).await?;
    if !DbevCapabilities::from_system(&system)
        .supports_deployment(database.protocol, input.target_mode)
    {
        return Err(DisplayError::new(format!(
            "{} does not support {} placement on this DatabasesEverywhere node",
            database.protocol.label(),
            input.target_mode.as_str(),
        ))
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    }

    let mut request = serde_json::json!({ "target_mode": input.target_mode });
    let destination_pool_id = if input.target_mode == DeploymentMode::Shared {
        if !DbevCapabilities::from_system(&system).supports_private_shared(database.protocol) {
            return Err(DisplayError::new(crate::dbev::private_shared_block_reason(
                &system,
                database.protocol,
                &node.api_url,
            ))
            .with_status(axum::http::StatusCode::CONFLICT)
            .into());
        }
        let pool_id = input
            .pool_id
            .as_deref()
            .filter(|value| !value.trim().is_empty())
            .ok_or_else(|| {
                DisplayError::new(
                    "dedicated-to-shared migration requires an existing destination pool_id",
                )
                .with_status(axum::http::StatusCode::BAD_REQUEST)
            })?;
        let pool =
            crate::services::pools::load_owned_pool(state, database.server_uuid, pool_id).await?;
        if pool.mapping.node_uuid != database.dbev_node_uuid
            || pool.mapping.protocol != database.protocol
        {
            return Err(DisplayError::new(
                "the destination pool must use this database's authorized node and engine",
            )
            .with_status(axum::http::StatusCode::FORBIDDEN)
            .into());
        }
        crate::services::pools::ensure_pool_capacity(
            state,
            &pool,
            Some((&database.instance_id(), database.disk_mib)),
        )
        .await?;
        request["pool_id"] = serde_json::Value::String(pool_id.to_owned());
        Some(pool_id.to_owned())
    } else {
        if input.pool_id.is_some() {
            return Err(
                DisplayError::new("pool_id is only valid for a shared migration target")
                    .with_status(axum::http::StatusCode::BAD_REQUEST)
                    .into(),
            );
        }
        None
    };
    let placeholder = serde_json::json!({
        "status": "submitting",
        "stage": "reserving_quota",
        "target_mode": input.target_mode,
        "pool_id": destination_pool_id,
    });
    database
        .reserve_migration_target(state, input.target_mode, &placeholder)
        .await?;

    let path = format!(
        "/api/instances/{}/deployment-migrations",
        urlencoding::encode(&database.instance_id())
    );
    let accepted = client
        .post_accepted_with_location::<serde_json::Value, _>(&path, &request)
        .await;
    let accepted = match accepted {
        Ok(accepted) => accepted,
        Err(error) => {
            let ambiguous = mutation_outcome_is_ambiguous(&error);
            let migration = serde_json::json!({
                "status": if ambiguous { "submitting" } else { "failed" },
                "stage": if ambiguous { "submission_outcome_unknown" } else { "submission" },
                "target_mode": input.target_mode,
                "pool_id": destination_pool_id,
                "diagnostic": {
                    "message": if ambiguous {
                        "The migration request outcome is unknown. The target quota remains reserved and database mutations remain locked until an administrator reconciles the operation."
                    } else {
                        "DatabasesEverywhere rejected the migration request before accepting it."
                    }
                },
            });
            if ambiguous {
                database
                    .store_deployment_migration(state, &migration)
                    .await?;
            } else {
                database
                    .finish_deployment_migration(state, &migration)
                    .await?;
            }
            return Err(error);
        }
    };

    let location = match migration_location(accepted.location.as_deref(), &accepted.value) {
        Ok(location) => location,
        Err(error) => {
            database
                .store_deployment_migration(
                    state,
                    &serde_json::json!({
                        "status": "submitting",
                        "stage": "status_location_unavailable",
                        "target_mode": input.target_mode,
                        "diagnostic": {
                            "message": "DBEV accepted the placement migration but did not return a safe status location. Administrator reconciliation is required."
                        }
                    }),
                )
                .await?;
            return Err(error);
        }
    };
    let migration = migration_record(
        accepted.value,
        input.target_mode,
        &location,
        destination_pool_id.as_deref(),
    );
    let migration = persist_deployment_migration(state, database, &client, migration).await?;
    Ok(DeploymentMigrationOutcome {
        migration,
        location: Some(location),
    })
}

pub async fn refresh_deployment_migration(
    state: &State,
    database: &DatabaseRecord,
) -> Result<DeploymentMigrationOutcome, anyhow::Error> {
    let stored = database.deployment_migration.as_ref().ok_or_else(|| {
        DisplayError::new("this database has no deployment migration record")
            .with_status(axum::http::StatusCode::NOT_FOUND)
    })?;
    if !database.migration_active() {
        return Ok(DeploymentMigrationOutcome {
            migration: stored.clone(),
            location: migration_location_from_record(stored),
        });
    }
    let Some(location) = migration_location_from_record(stored) else {
        if migration_requires_reconciliation(stored) {
            return Ok(DeploymentMigrationOutcome {
                migration: stored.clone(),
                location: None,
            });
        }
        return Err(DisplayError::new(
            "the active deployment migration has no safe status location; administrator reconciliation is required",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    };
    let node = crate::persistence::NodeRecord::by_uuid(state, database.dbev_node_uuid)
        .await?
        .ok_or_else(|| anyhow::anyhow!("DatabasesEverywhere node no longer exists"))?;
    let client = DbevClient::for_node(state, &node).await?;
    let remote = client.get::<serde_json::Value>(&location).await?;
    let target = database.migration_target_mode.unwrap_or_else(|| {
        if database.deployment_mode == DeploymentMode::Dedicated {
            DeploymentMode::Shared
        } else {
            DeploymentMode::Dedicated
        }
    });
    let migration = migration_record(
        remote,
        target,
        &location,
        stored.get("pool_id").and_then(serde_json::Value::as_str),
    );
    let migration = persist_deployment_migration(state, database, &client, migration).await?;
    Ok(DeploymentMigrationOutcome {
        migration,
        location: Some(location),
    })
}

fn migration_location(
    header: Option<&str>,
    response: &serde_json::Value,
) -> Result<String, anyhow::Error> {
    let location = header
        .or_else(|| {
            response
                .get("status_url")
                .and_then(serde_json::Value::as_str)
        })
        .or_else(|| response.get("location").and_then(serde_json::Value::as_str))
        .or_else(|| {
            response
                .pointer("/migration/status_url")
                .and_then(serde_json::Value::as_str)
        })
        .or_else(|| {
            response
                .pointer("/result/status_url")
                .and_then(serde_json::Value::as_str)
        })
        .or_else(|| {
            response
                .pointer("/result/migration/status_url")
                .and_then(serde_json::Value::as_str)
        })
        .ok_or_else(|| {
            DisplayError::new("DatabasesEverywhere did not return a migration status location")
                .with_status(axum::http::StatusCode::BAD_GATEWAY)
        })?;
    if !location.starts_with("/api/") || location.starts_with("//") {
        return Err(DisplayError::new(
            "DatabasesEverywhere returned an invalid migration status location",
        )
        .with_status(axum::http::StatusCode::BAD_GATEWAY)
        .into());
    }
    Ok(location.to_owned())
}

fn creation_status_location(
    header: Option<&str>,
    response: &serde_json::Value,
    instance_id: &str,
) -> Result<String, anyhow::Error> {
    let fallback = format!("/api/instances/{instance_id}/status");
    let location = header
        .or_else(|| {
            response
                .get("status_url")
                .and_then(serde_json::Value::as_str)
        })
        .or_else(|| {
            response
                .pointer("/instance/status_url")
                .and_then(serde_json::Value::as_str)
        })
        .or_else(|| {
            response
                .pointer("/result/status_url")
                .and_then(serde_json::Value::as_str)
        })
        .or_else(|| {
            response
                .pointer("/result/instance/status_url")
                .and_then(serde_json::Value::as_str)
        })
        .unwrap_or(&fallback);
    if !location.starts_with("/api/") || location.starts_with("//") {
        return Err(DisplayError::new(
            "DatabasesEverywhere returned an invalid instance creation status location",
        )
        .with_status(axum::http::StatusCode::BAD_GATEWAY)
        .into());
    }
    Ok(location.to_owned())
}

fn creation_response_is_compatible(response: &serde_json::Value, instance_id: &str) -> bool {
    let mismatched_instance = remote_instance(response)
        .get("instance_id")
        .and_then(serde_json::Value::as_str)
        .is_some_and(|returned| returned != instance_id);
    let invalid_status =
        remote_status(response).is_some_and(|status| !matches!(status, "creating" | "booting"));
    !mismatched_instance && !invalid_status
}

fn shared_child_status_location(
    response: &serde_json::Value,
    instance_id: &str,
) -> Result<String, anyhow::Error> {
    if response
        .get("instance_id")
        .and_then(serde_json::Value::as_str)
        != Some(instance_id)
    {
        return Err(DisplayError::new(
            "DBEV shared-child acceptance returned a mismatched root instance_id",
        )
        .with_status(axum::http::StatusCode::BAD_GATEWAY)
        .into());
    }
    let location = response
        .get("status_url")
        .and_then(serde_json::Value::as_str)
        .ok_or_else(|| {
            DisplayError::new("DBEV shared-child acceptance is missing the root status_url")
                .with_status(axum::http::StatusCode::BAD_GATEWAY)
        })?;
    if location != format!("/api/instances/{}/status", urlencoding::encode(instance_id)) {
        return Err(DisplayError::new(
            "DBEV shared-child acceptance returned an invalid status_url",
        )
        .with_status(axum::http::StatusCode::BAD_GATEWAY)
        .into());
    }
    Ok(location.to_owned())
}

fn shared_child_response_is_compatible(response: &serde_json::Value, instance_id: &str) -> bool {
    response.is_object()
        && response
            .get("instance_id")
            .and_then(serde_json::Value::as_str)
            == Some(instance_id)
        && response
            .get("status_url")
            .and_then(serde_json::Value::as_str)
            .is_some()
        && response.get("data").is_none()
        && response.get("instance").is_none()
        && response.get("pool_limits").is_none()
        && response.get("shared_pool").is_none()
}

fn mutation_outcome_is_ambiguous(error: &anyhow::Error) -> bool {
    extract_readable_error(error).is_none_or(|(_, status)| {
        status == axum::http::StatusCode::REQUEST_TIMEOUT || status.is_server_error()
    })
}

fn migration_record(
    response: serde_json::Value,
    target: DeploymentMode,
    location: &str,
    pool_id: Option<&str>,
) -> serde_json::Value {
    let mut object = response.as_object().cloned().unwrap_or_default();
    object
        .entry("target_mode".to_owned())
        .or_insert_with(|| serde_json::json!(target));
    object.insert(
        "status_url".to_owned(),
        serde_json::Value::String(location.to_owned()),
    );
    if let Some(pool_id) = pool_id {
        object.insert(
            "pool_id".to_owned(),
            serde_json::Value::String(pool_id.to_owned()),
        );
    }
    serde_json::Value::Object(object)
}

fn migration_location_from_record(migration: &serde_json::Value) -> Option<String> {
    migration
        .get("status_url")
        .and_then(serde_json::Value::as_str)
        .filter(|location| location.starts_with("/api/") && !location.starts_with("//"))
        .map(str::to_owned)
}

fn migration_terminal(migration: &serde_json::Value) -> bool {
    matches!(
        migration_status(migration),
        Some("completed" | "failed" | "cancelled" | "manual_intervention")
    )
}

fn migration_requires_reconciliation(migration: &serde_json::Value) -> bool {
    matches!(
        migration.get("stage").and_then(serde_json::Value::as_str),
        Some("submission_outcome_unknown" | "status_location_unavailable")
    )
}

async fn persist_deployment_migration(
    state: &State,
    database: &DatabaseRecord,
    client: &DbevClient,
    mut migration: serde_json::Value,
) -> Result<serde_json::Value, anyhow::Error> {
    if migration_status(&migration) == Some("completed") && remote_runtime_id(&migration).is_none()
    {
        let instance = client
            .get::<serde_json::Value>(&format!(
                "/api/instances/{}",
                urlencoding::encode(&database.instance_id())
            ))
            .await?;
        let instance = remote_instance(&instance).clone();
        migration
            .as_object_mut()
            .ok_or_else(|| {
                DisplayError::new(
                    "DatabasesEverywhere returned an invalid deployment migration response",
                )
                .with_status(axum::http::StatusCode::BAD_GATEWAY)
            })?
            .insert("instance".to_owned(), instance);
    }

    if migration_terminal(&migration) {
        database
            .finish_deployment_migration(state, &migration)
            .await?;
    } else {
        database
            .store_deployment_migration(state, &migration)
            .await?;
    }
    Ok(migration)
}

fn ensure_database_mutable(database: &DatabaseRecord) -> Result<(), anyhow::Error> {
    if database.migration_active() {
        return Err(DisplayError::new(
            "a dedicated/shared migration is active; wait for it to finish before changing this database",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    }
    if database.status == "deleting" {
        return Err(DisplayError::new("this database is being deleted")
            .with_status(axum::http::StatusCode::CONFLICT)
            .into());
    }
    Ok(())
}

fn image_update_payload(
    image: &str,
    major_upgrade: bool,
    password: Option<&str>,
) -> serde_json::Value {
    let mut payload = serde_json::json!({
        "image": image,
        "major_upgrade": major_upgrade,
    });
    if let Some(password) = password {
        payload["password"] = serde_json::Value::String(password.to_owned());
    }
    payload
}

fn parse_password_reset_response(
    response: &serde_json::Value,
) -> Result<(&serde_json::Value, bool), anyhow::Error> {
    let restarted = response
        .get("restarted")
        .and_then(serde_json::Value::as_bool)
        .ok_or_else(invalid_password_reset_response)?;
    let instance = response
        .get("instance")
        .filter(|instance| instance.is_object())
        .ok_or_else(invalid_password_reset_response)?;
    Ok((instance, restarted))
}

fn invalid_password_reset_response() -> anyhow::Error {
    anyhow::Error::new(
        DisplayError::new("DatabasesEverywhere returned an invalid password reset response")
            .with_status(axum::http::StatusCode::BAD_GATEWAY),
    )
}

async fn client_for_database(
    state: &State,
    database: &DatabaseRecord,
) -> Result<(crate::persistence::NodeRecord, DbevClient), anyhow::Error> {
    let node = crate::persistence::NodeRecord::by_uuid(state, database.dbev_node_uuid)
        .await?
        .ok_or_else(|| anyhow::anyhow!("DatabasesEverywhere node no longer exists"))?;
    let client = DbevClient::for_mutation(state, &node).await?;
    Ok((node, client))
}

fn validate_create_input(input: &CreateDatabaseInput) -> Result<(), anyhow::Error> {
    let display_name = input.display_name.trim();
    if display_name.is_empty() || display_name.chars().count() > 191 {
        return Err(
            DisplayError::new("database display name must contain 1 to 191 characters").into(),
        );
    }
    if let Some(database_name) = input.database_name.as_deref().map(str::trim)
        && !database_name.is_empty()
    {
        validate_identifier("database name", database_name)?;
    }
    if let Some(username) = input.username.as_deref().map(str::trim)
        && !username.is_empty()
    {
        validate_identifier("username", username)?;
    }
    if let Some(image) = input.image.as_deref() {
        validate_image(image)?;
    }
    Ok(())
}

fn validate_identifier(label: &str, value: &str) -> Result<(), anyhow::Error> {
    if !DATABASE_IDENTIFIER.is_match(value) {
        return Err(DisplayError::new(format!(
            "{label} must start with an ASCII letter and contain at most 63 letters, digits, underscores, or dashes"
        ))
        .into());
    }
    const RESERVED: &[&str] = &[
        "postgres",
        "mysql",
        "admin",
        "root",
        "default",
        "dbe_admin",
        "dbe_health",
    ];
    if RESERVED
        .iter()
        .any(|reserved| value.eq_ignore_ascii_case(reserved))
    {
        return Err(DisplayError::new(format!("{label} is reserved")).into());
    }
    Ok(())
}

fn validate_image(image: &str) -> Result<(), anyhow::Error> {
    let image = image.trim();
    if image.is_empty() || image.len() > 255 || image.chars().any(char::is_whitespace) {
        return Err(DisplayError::new("enter a valid pinned container image reference").into());
    }
    let last_segment = image.rsplit('/').next().unwrap_or(image);
    let pinned = image.contains("@sha256:")
        || last_segment
            .rsplit_once(':')
            .is_some_and(|(_, tag)| !tag.is_empty() && tag != "latest");
    if !pinned {
        return Err(DisplayError::new(
            "container images must use a non-latest tag or sha256 digest",
        )
        .into());
    }
    Ok(())
}

fn validate_password(password: &str) -> Result<(), anyhow::Error> {
    let characters = password.chars().count();
    if !(1..=4096).contains(&characters) {
        return Err(
            DisplayError::new("password must contain between 1 and 4096 characters").into(),
        );
    }
    if password
        .chars()
        .any(|character| matches!(character, '\0' | '\r' | '\n'))
    {
        return Err(DisplayError::new(
            "password cannot contain NUL, carriage return, or line feed characters",
        )
        .into());
    }
    Ok(())
}

fn contains_plaintext_credential(value: &serde_json::Value) -> bool {
    match value {
        serde_json::Value::Object(object) => object.iter().any(|(key, value)| {
            matches!(key.to_ascii_lowercase().as_str(), "password" | "api_key")
                || contains_plaintext_credential(value)
        }),
        serde_json::Value::Array(values) => values.iter().any(contains_plaintext_credential),
        _ => false,
    }
}

#[cfg(test)]
mod tests {
    use super::{
        contains_plaintext_credential, creation_response_is_compatible, creation_status_location,
        deletion_response_confirms_purge, image_update_payload, migration_location,
        migration_requires_reconciliation, mutation_outcome_is_ambiguous,
        parse_password_reset_response, shared_child_response_is_compatible,
        shared_child_status_location, validate_database_power_action, validate_password,
    };
    use crate::domain::DeploymentMode;
    use shared::response::DisplayError;

    #[test]
    fn validates_password_contract_without_normalizing_the_secret() {
        assert!(validate_password(" a valid password ").is_ok());
        assert!(validate_password("").is_err());
        assert!(validate_password("line\nbreak").is_err());
        assert!(validate_password(&"x".repeat(4097)).is_err());
    }

    #[test]
    fn parent_and_child_power_controls_remain_distinct() {
        for action in ["start", "stop"] {
            assert!(validate_database_power_action(DeploymentMode::Shared, action).is_ok());
        }
        for action in ["restart", "kill"] {
            assert!(validate_database_power_action(DeploymentMode::Shared, action).is_err());
            assert!(validate_database_power_action(DeploymentMode::Dedicated, action).is_ok());
        }
    }

    #[test]
    fn rejects_passwords_in_daemon_response_models() {
        assert!(contains_plaintext_credential(&serde_json::json!({
            "instance": { "password": "must-not-be-returned" },
            "restarted": true
        })));
        assert!(!contains_plaintext_credential(&serde_json::json!({
            "instance": { "status": "running" },
            "restarted": true
        })));
    }

    #[test]
    fn quota_is_released_only_after_deletion_and_purge_are_both_confirmed() {
        assert!(deletion_response_confirms_purge(&serde_json::json!({
            "deleted": true,
            "purged": true
        })));
        assert!(!deletion_response_confirms_purge(&serde_json::json!({
            "deleted": true,
            "purged": false
        })));
        assert!(!deletion_response_confirms_purge(&serde_json::json!({
            "status": "deleting"
        })));
    }

    #[test]
    fn accepts_live_and_recreated_password_rotation_responses() {
        for restarted in [false, true] {
            let response = serde_json::json!({
                "instance": { "instance_id": "example", "status": "running" },
                "restarted": restarted
            });
            let (instance, actual) = parse_password_reset_response(&response).unwrap();
            assert_eq!(actual, restarted);
            assert_eq!(
                instance.get("status").and_then(serde_json::Value::as_str),
                Some("running")
            );
        }
    }

    #[test]
    fn modern_image_update_omits_password_and_legacy_update_keeps_it() {
        let modern = image_update_payload("postgres:17.5", false, None);
        assert_eq!(
            modern.get("image").and_then(serde_json::Value::as_str),
            Some("postgres:17.5")
        );
        assert!(!modern.as_object().unwrap().contains_key("password"));

        let legacy = image_update_payload("postgres:17.5", false, Some("legacy-secret"));
        assert_eq!(
            legacy.get("password").and_then(serde_json::Value::as_str),
            Some("legacy-secret")
        );
    }

    #[test]
    fn deployment_migrations_follow_any_safe_daemon_status_location() {
        assert_eq!(
            migration_location(
                Some("/api/deployment-migrations/job-1"),
                &serde_json::Value::Null,
            )
            .unwrap(),
            "/api/deployment-migrations/job-1"
        );
        assert!(
            migration_location(Some("//other-host.example/job-1"), &serde_json::Value::Null)
                .is_err()
        );
        assert_eq!(
            migration_location(
                None,
                &serde_json::json!({
                    "result": {
                        "migration": { "status_url": "/api/deployment-migrations/job-2" }
                    }
                }),
            )
            .unwrap(),
            "/api/deployment-migrations/job-2"
        );
    }

    #[test]
    fn creation_uses_returned_safe_status_location_with_legacy_fallback() {
        assert_eq!(
            creation_status_location(
                Some("/api/operations/create-1"),
                &serde_json::Value::Null,
                "instance-1",
            )
            .unwrap(),
            "/api/operations/create-1"
        );
        assert_eq!(
            creation_status_location(None, &serde_json::Value::Null, "instance-1").unwrap(),
            "/api/instances/instance-1/status"
        );
        assert_eq!(
            creation_status_location(
                None,
                &serde_json::json!({
                    "result": {
                        "instance": { "status_url": "/api/operations/create-2" }
                    }
                }),
                "instance-1",
            )
            .unwrap(),
            "/api/operations/create-2"
        );
        assert!(
            creation_status_location(
                Some("https://other.example/api/operations/create-1"),
                &serde_json::Value::Null,
                "instance-1",
            )
            .is_err()
        );
    }

    #[test]
    fn shared_child_creation_requires_direct_root_identity_and_status() {
        let response = serde_json::json!({
            "instance_id": "instance-1",
            "status_url": "/api/instances/instance-1/status"
        });
        assert!(shared_child_response_is_compatible(&response, "instance-1"));
        assert_eq!(
            shared_child_status_location(&response, "instance-1").unwrap(),
            "/api/instances/instance-1/status"
        );
        assert!(!shared_child_response_is_compatible(
            &serde_json::json!({ "data": response }),
            "instance-1"
        ));
        assert!(
            shared_child_status_location(
                &serde_json::json!({
                    "instance_id": "instance-2", "status_url": "/api/instances/instance-1/status"
                }),
                "instance-1"
            )
            .is_err()
        );
    }

    #[test]
    fn creation_accepts_sparse_jobs_but_rejects_conflicting_instance_state() {
        assert!(creation_response_is_compatible(
            &serde_json::json!({ "status_url": "/api/operations/create-1" }),
            "instance-1",
        ));
        assert!(creation_response_is_compatible(
            &serde_json::Value::Null,
            "instance-1",
        ));
        assert!(!creation_response_is_compatible(
            &serde_json::json!({
                "instance": { "instance_id": "different", "status": "creating" }
            }),
            "instance-1",
        ));
        assert!(!creation_response_is_compatible(
            &serde_json::json!({
                "instance": { "instance_id": "instance-1", "status": "running" }
            }),
            "instance-1",
        ));
    }

    #[test]
    fn ambiguous_mutation_failures_do_not_release_reserved_quota() {
        for status in [
            axum::http::StatusCode::REQUEST_TIMEOUT,
            axum::http::StatusCode::INTERNAL_SERVER_ERROR,
            axum::http::StatusCode::BAD_GATEWAY,
            axum::http::StatusCode::GATEWAY_TIMEOUT,
        ] {
            let error: anyhow::Error = DisplayError::new("ambiguous mutation outcome")
                .with_status(status)
                .into();
            assert!(mutation_outcome_is_ambiguous(&error));
        }

        let rejected: anyhow::Error = DisplayError::new("capacity exhausted")
            .with_status(axum::http::StatusCode::SERVICE_UNAVAILABLE)
            .into();
        assert!(mutation_outcome_is_ambiguous(&rejected));
    }

    #[test]
    fn uncertain_migration_submissions_require_manual_reconciliation() {
        for stage in ["submission_outcome_unknown", "status_location_unavailable"] {
            assert!(migration_requires_reconciliation(&serde_json::json!({
                "status": "submitting",
                "stage": stage,
            })));
        }
        assert!(!migration_requires_reconciliation(&serde_json::json!({
            "status": "running",
            "stage": "copying_data",
        })));
    }
}
