use crate::{
    dbev::{DbevClient, validate_system_response},
    domain::{DatabaseProtocol, DeploymentMode},
    persistence::{DatabaseRecord, NodeRecord, SharedPool, validate_runtime_id},
};
use axum::http::StatusCode;
use serde_json::Value;
use shared::{
    State,
    response::{DisplayError, extract_readable_error},
};
use std::{
    collections::{BTreeMap, BTreeSet},
    time::Duration,
};

#[derive(Clone)]
pub struct OwnedPool {
    pub mapping: SharedPool,
    pub panel_id: String,
    pub client: DbevClient,
    pub remote: Value,
    pub status: Value,
}

pub async fn load_owned_pool(
    state: &State,
    server_id: uuid::Uuid,
    runtime_id: &str,
) -> Result<OwnedPool, anyhow::Error> {
    validate_runtime_id(runtime_id)?;
    let mapping = SharedPool::by_runtime(state, server_id, runtime_id)
        .await?
        .ok_or_else(|| {
            DisplayError::new("pool not found for this server").with_status(StatusCode::NOT_FOUND)
        })?;
    load_verified_mapping(state, mapping).await
}

pub async fn list_owned_pools(
    state: &State,
    server_id: uuid::Uuid,
) -> Result<Vec<OwnedPool>, anyhow::Error> {
    let mappings = SharedPool::list(state, server_id)
        .await?
        .into_iter()
        .filter(|mapping| mapping.runtime_id.is_some())
        .collect::<Vec<_>>();
    let mut snapshots =
        std::collections::BTreeMap::<uuid::Uuid, (DbevClient, String, Vec<Value>)>::new();
    for mapping in &mappings {
        if snapshots.contains_key(&mapping.node_uuid) {
            continue;
        }
        let node = NodeRecord::by_uuid(state, mapping.node_uuid)
            .await?
            .ok_or_else(|| anyhow::anyhow!("a mapped DBEV node no longer exists"))?;
        let (client, system) = DbevClient::for_mutation_with_system(state, &node).await?;
        validate_system_response(&system)?;
        let reports = client.get::<Vec<Value>>("/api/pools").await?;
        snapshots.insert(mapping.node_uuid, (client, node.token_id, reports));
    }

    let mut result = Vec::with_capacity(mappings.len());
    for mapping in mappings {
        let runtime_id = mapping.require_runtime()?;
        let (client, panel_id, reports) = snapshots
            .get(&mapping.node_uuid)
            .ok_or_else(|| anyhow::anyhow!("pool node snapshot disappeared"))?;
        let report = reports
            .iter()
            .find(|report| report.get("runtime_id").and_then(Value::as_str) == Some(runtime_id))
            .cloned();
        let (remote, status) = pool_state(client, &mapping, panel_id, report).await?;
        result.push(OwnedPool {
            mapping,
            panel_id: panel_id.clone(),
            client: client.clone(),
            remote,
            status,
        });
    }
    Ok(result)
}

pub async fn load_owned_pool_on_node(
    state: &State,
    node_id: uuid::Uuid,
    runtime_id: &str,
) -> Result<OwnedPool, anyhow::Error> {
    validate_runtime_id(runtime_id)?;
    let mapping = SharedPool::by_node_runtime(state, node_id, runtime_id)
        .await?
        .ok_or_else(|| {
            DisplayError::new("pool is not mapped to this panel node")
                .with_status(StatusCode::NOT_FOUND)
        })?;
    load_verified_mapping(state, mapping).await
}

async fn load_verified_mapping(
    state: &State,
    mapping: SharedPool,
) -> Result<OwnedPool, anyhow::Error> {
    let node = NodeRecord::by_uuid(state, mapping.node_uuid)
        .await?
        .ok_or_else(|| anyhow::anyhow!("the pool's DBEV node no longer exists"))?;
    let (client, system) = DbevClient::for_mutation_with_system(state, &node).await?;
    validate_system_response(&system)?;
    let runtime_id = mapping.require_runtime()?;
    let report = match client
        .get::<Value>(&format!("/api/pools/{}", urlencoding::encode(runtime_id)))
        .await
    {
        Ok(report) => Some(report),
        Err(error) if has_status(&error, StatusCode::NOT_FOUND) => None,
        Err(error) => return Err(error),
    };
    let (remote, status) = pool_state(&client, &mapping, &node.token_id, report).await?;
    Ok(OwnedPool {
        mapping,
        panel_id: node.token_id,
        client,
        remote,
        status,
    })
}

async fn pool_state(
    client: &DbevClient,
    mapping: &SharedPool,
    panel_id: &str,
    report: Option<Value>,
) -> Result<(Value, Value), anyhow::Error> {
    if let Some(report) = report {
        mapping.verify_remote(&report, panel_id)?;
        let status = serde_json::json!({"runtime_id": mapping.require_runtime()?, "status": report["status"]});
        return Ok((report, status));
    }
    // Pending/failed creation can have durable status without a published runtime.
    let path = format!(
        "/api/pools/{}/status",
        urlencoding::encode(mapping.require_runtime()?)
    );
    let status = client.get::<Value>(&path).await?;
    if status.get("runtime_id").and_then(Value::as_str) != Some(mapping.require_runtime()?)
        || !matches!(
            status.get("status").and_then(Value::as_str),
            Some("creating" | "booting" | "failed" | "quarantined" | "deleting")
        )
    {
        return Err(DisplayError::new(
            "the mapped pool has no verifiable runtime; operator reconciliation is required",
        )
        .with_status(StatusCode::CONFLICT)
        .into());
    }
    Ok((Value::Null, status))
}

pub async fn ensure_pool_ready(
    state: &State,
    server: &shared::models::server::Server,
    protocol: DatabaseProtocol,
    node: &NodeRecord,
    image: Option<&str>,
) -> Result<OwnedPool, anyhow::Error> {
    let mut mapping = SharedPool::pin(state, server, protocol, node).await?;
    let (client, system) = DbevClient::for_mutation_with_system(state, node).await?;
    validate_system_response(&system)?;
    if !crate::dbev::DbevCapabilities::from_system(&system).supports_private_shared(protocol) {
        return Err(DisplayError::new(crate::dbev::private_shared_block_reason(
            &system,
            protocol,
            &node.api_url,
        ))
        .with_status(StatusCode::CONFLICT)
        .into());
    }

    if let Some(runtime_id) = mapping.runtime_id.as_deref() {
        if image.is_some() {
            return Err(DisplayError::new(
                "this engine already has a persistent pool; change its image from the pool controls",
            )
            .with_status(StatusCode::CONFLICT)
            .into());
        }
        let remote = match client
            .get::<Value>(&format!("/api/pools/{}", urlencoding::encode(runtime_id)))
            .await
        {
            Ok(remote) => remote,
            Err(error) if has_status(&error, StatusCode::NOT_FOUND) => {
                poll_pool_ready(&client, &mapping).await?
            }
            Err(error) => return Err(error),
        };
        mapping.verify_remote(&remote, &node.token_id)?;
        ensure_pool_usable(&remote)?;
        return Ok(OwnedPool {
            status: serde_json::json!({"runtime_id": runtime_id, "status": remote["status"]}),
            mapping,
            panel_id: node.token_id.clone(),
            client,
            remote,
        });
    }

    mapping.claim_creation(state).await?;
    let accepted = client
        .post_accepted_with_location::<Value, _>("/api/pools", &mapping.create_payload(image))
        .await?;
    let (runtime_id, status_url) = parse_pool_acceptance(&accepted.value)?;
    if accepted
        .location
        .as_deref()
        .is_some_and(|value| value != status_url)
    {
        return Err(DisplayError::new(
            "DBEV returned conflicting pool status locations; operator reconciliation is required",
        )
        .with_status(StatusCode::BAD_GATEWAY)
        .into());
    }
    // An ambiguous mapping is never permission to delete a remote engine.
    mapping.bind_runtime(state, runtime_id, status_url).await?;
    let remote = poll_pool_ready(&client, &mapping).await?;
    mapping.verify_remote(&remote, &node.token_id)?;
    ensure_pool_usable(&remote)?;
    Ok(OwnedPool {
        status: serde_json::json!({"runtime_id": mapping.require_runtime()?, "status": remote["status"]}),
        mapping,
        panel_id: node.token_id.clone(),
        client,
        remote,
    })
}

pub async fn poll_pool_ready(
    client: &DbevClient,
    mapping: &SharedPool,
) -> Result<Value, anyhow::Error> {
    let status_url = mapping.status_url.as_deref().ok_or_else(|| {
        DisplayError::new("pool creation has no persisted status URL")
            .with_status(StatusCode::CONFLICT)
    })?;
    for _ in 0..180 {
        let status = client.get::<Value>(status_url).await?;
        if status.get("runtime_id").and_then(Value::as_str) != Some(mapping.require_runtime()?) {
            return Err(DisplayError::new("DBEV returned a status for another pool")
                .with_status(StatusCode::BAD_GATEWAY)
                .into());
        }
        match operation_status(&status) {
            Some("running") => {
                let runtime_id = mapping.require_runtime()?;
                return client
                    .get::<Value>(&format!("/api/pools/{}", urlencoding::encode(runtime_id)))
                    .await;
            }
            Some("failed" | "quarantined" | "stopped" | "deleting") => {
                return Err(DisplayError::new(
                    operation_error(&status)
                        .unwrap_or("DBEV failed to prepare the persistent pool")
                        .to_owned(),
                )
                .with_status(StatusCode::CONFLICT)
                .into());
            }
            _ => tokio::time::sleep(Duration::from_secs(2)).await,
        }
    }
    Err(DisplayError::new(
        "pool creation is still pending; check its status before creating a child database",
    )
    .with_status(StatusCode::GATEWAY_TIMEOUT)
    .into())
}

pub async fn owned_pool_instances(
    state: &State,
    pool: &OwnedPool,
) -> Result<Vec<Value>, anyhow::Error> {
    let remote = raw_pool_instances(pool).await?;
    let allowed = local_pool_databases(state, &pool.mapping)
        .await?
        .into_iter()
        .map(|database| database.instance_id())
        .collect::<std::collections::HashSet<_>>();
    Ok(remote
        .into_iter()
        .filter(|instance| {
            instance
                .get("instance_id")
                .and_then(Value::as_str)
                .is_some_and(|instance_id| allowed.contains(instance_id))
        })
        .collect())
}

/// Fetches the complete DBEV child inventory for an already ownership-verified pool.
/// Callers performing capacity or destructive checks must use this unfiltered view.
pub async fn raw_pool_instances(pool: &OwnedPool) -> Result<Vec<Value>, anyhow::Error> {
    if pool.remote.is_null() {
        return Err(
            DisplayError::new("pool creation has not published an engine inventory yet")
                .with_status(StatusCode::CONFLICT)
                .into(),
        );
    }
    let runtime_id = pool.mapping.require_runtime()?;
    pool.client
        .get::<Vec<Value>>(&format!(
            "/api/pools/{}/instances",
            urlencoding::encode(runtime_id)
        ))
        .await
}

pub async fn local_pool_databases(
    state: &State,
    mapping: &SharedPool,
) -> Result<Vec<DatabaseRecord>, anyhow::Error> {
    Ok(DatabaseRecord::all_for_server(state, mapping.server_id)
        .await?
        .into_iter()
        .filter(|database| {
            database.deployment_mode == DeploymentMode::Shared
                && database.protocol == mapping.protocol
                && database.dbev_node_uuid == mapping.node_uuid
                && database.metadata.get("pool_id").and_then(Value::as_str)
                    == mapping.runtime_id.as_deref()
        })
        .collect())
}

pub async fn ensure_pool_capacity(
    state: &State,
    pool: &OwnedPool,
    pending: Option<(&str, i64)>,
) -> Result<(), anyhow::Error> {
    let (tenant_count, reserved_disk_mib) = pool_capacity_usage(state, pool, pending).await?;
    if let Some(message) = pool.mapping.capacity_error(tenant_count, reserved_disk_mib) {
        return Err(DisplayError::new(message)
            .with_status(StatusCode::CONFLICT)
            .into());
    }
    Ok(())
}

pub async fn pool_capacity_usage(
    state: &State,
    pool: &OwnedPool,
    pending: Option<(&str, i64)>,
) -> Result<(i64, i64), anyhow::Error> {
    let databases = local_pool_databases(state, &pool.mapping).await?;
    let remote = raw_pool_instances(pool).await?;
    let local_reservations = databases
        .iter()
        .map(|database| (database.instance_id(), database.disk_mib))
        .collect();
    let (count, disk) = reconcile_pool_reservations(
        local_reservations,
        &remote,
        pending.map(|(instance_id, disk_mib)| (instance_id.to_owned(), disk_mib)),
    )?;
    // The report also counts provisional daemon reservations absent from /instances.
    let reported_count = pool
        .remote
        .get("tenant_count")
        .and_then(Value::as_i64)
        .filter(|value| *value >= 0)
        .ok_or_else(|| anyhow::anyhow!("pool tenant reservations are unavailable"))?;
    let reported_disk = pool
        .remote
        .pointer("/disk/reserved_bytes")
        .and_then(Value::as_u64)
        .ok_or_else(|| anyhow::anyhow!("pool disk reservations are unavailable"))?;
    let reported_disk = i64::try_from(reported_disk.div_ceil(1_048_576))?;
    Ok((count.max(reported_count), disk.max(reported_disk)))
}

pub async fn reconciled_pool_databases(
    state: &State,
    pool: &OwnedPool,
) -> Result<Vec<DatabaseRecord>, anyhow::Error> {
    let local = local_pool_databases(state, &pool.mapping).await?;
    let local_ids = local
        .iter()
        .map(DatabaseRecord::instance_id)
        .collect::<BTreeSet<_>>();
    let mut remote_ids = BTreeSet::new();
    for instance in raw_pool_instances(pool).await? {
        let instance_id = remote_instance_id(&instance)?;
        if !remote_ids.insert(instance_id.to_owned()) {
            return Err(DisplayError::new(
                "DBEV returned duplicate pool child identities; operator reconciliation is required",
            )
            .with_status(StatusCode::BAD_GATEWAY)
            .into());
        }
    }
    if local_ids != remote_ids {
        return Err(DisplayError::new(
            "panel and DBEV pool child inventories differ; reconcile ownership before updating the pool",
        )
        .with_status(StatusCode::CONFLICT)
        .into());
    }
    Ok(local)
}

fn reconcile_pool_reservations(
    mut reservations: BTreeMap<String, i64>,
    remote: &[Value],
    pending: Option<(String, i64)>,
) -> Result<(i64, i64), anyhow::Error> {
    for instance in remote {
        let instance_id = remote_instance_id(instance)?;
        let disk_mib = instance.pointer("/limits/disk_mib").and_then(Value::as_i64);
        if disk_mib.is_some_and(|value| value < 0) {
            return Err(DisplayError::new(
                "DBEV returned a pool child with invalid limits.disk_mib; capacity cannot be verified",
            )
            .with_status(StatusCode::BAD_GATEWAY)
            .into());
        }
        match (reservations.get_mut(instance_id), disk_mib) {
            (Some(local_disk_mib), Some(remote_disk_mib)) => {
                *local_disk_mib = (*local_disk_mib).max(remote_disk_mib);
            }
            (Some(_), None) => {}
            (None, Some(remote_disk_mib)) if remote_disk_mib >= 0 => {
                reservations.insert(instance_id.to_owned(), remote_disk_mib);
            }
            (None, _) => {
                return Err(DisplayError::new(
                    "DBEV returned an untracked pool child without valid limits.disk_mib; capacity cannot be verified",
                )
                .with_status(StatusCode::BAD_GATEWAY)
                .into());
            }
        }
    }

    if let Some((instance_id, disk_mib)) = pending {
        if disk_mib < 0 {
            return Err(DisplayError::new("pending pool disk allowance cannot be negative").into());
        }
        reservations
            .entry(instance_id)
            .and_modify(|current| *current = (*current).max(disk_mib))
            .or_insert(disk_mib);
    }

    let tenant_count = i64::try_from(reservations.len()).unwrap_or(i64::MAX);
    let reserved_disk_mib = reservations
        .into_values()
        .try_fold(0_i64, i64::checked_add)
        .ok_or_else(|| DisplayError::new("pool disk reservations exceed the supported range"))?;
    Ok((tenant_count, reserved_disk_mib))
}

fn remote_instance_id(instance: &Value) -> Result<&str, anyhow::Error> {
    instance
        .get("instance_id")
        .and_then(Value::as_str)
        .filter(|value| !value.trim().is_empty())
        .ok_or_else(|| {
            DisplayError::new(
                "DBEV returned a pool child without a valid root instance_id; ownership and capacity cannot be verified",
            )
            .with_status(StatusCode::BAD_GATEWAY)
            .into()
        })
}

pub fn parse_pool_acceptance(response: &Value) -> Result<(&str, &str), anyhow::Error> {
    let runtime_id = response
        .get("runtime_id")
        .and_then(Value::as_str)
        .filter(|value| !value.trim().is_empty())
        .ok_or_else(|| invalid_acceptance("runtime_id"))?;
    validate_runtime_id(runtime_id)?;
    let status_url = response
        .get("status_url")
        .and_then(Value::as_str)
        .ok_or_else(|| invalid_acceptance("status_url"))?;
    crate::persistence::validate_status_url(status_url)?;
    if response.get("status").and_then(Value::as_str) != Some("creating")
        || status_url != format!("/api/pools/{}/status", urlencoding::encode(runtime_id))
    {
        return Err(invalid_acceptance("status/status_url"));
    }
    Ok((runtime_id, status_url))
}

fn invalid_acceptance(field: &str) -> anyhow::Error {
    DisplayError::new(format!(
        "DBEV pool acceptance response is missing a valid root {field}"
    ))
    .with_status(StatusCode::BAD_GATEWAY)
    .into()
}

fn operation_status(response: &Value) -> Option<&str> {
    response.get("status").and_then(Value::as_str)
}

fn operation_error(response: &Value) -> Option<&str> {
    response
        .get("error")
        .and_then(Value::as_str)
        .or_else(|| response.pointer("/error/message").and_then(Value::as_str))
        .or_else(|| {
            response
                .pointer("/progress/message")
                .and_then(Value::as_str)
        })
}

fn ensure_pool_usable(remote: &Value) -> Result<(), anyhow::Error> {
    match remote.get("status").and_then(Value::as_str) {
        Some("running") if remote.get("pending_image").is_none_or(Value::is_null) => Ok(()),
        Some("creating" | "booting") => Err(DisplayError::new(
            "the persistent pool is still being prepared",
        )
        .with_status(StatusCode::CONFLICT)
        .into()),
        Some("quarantined" | "failed") => Err(DisplayError::new(
            "the persistent pool requires operator attention",
        )
        .with_status(StatusCode::CONFLICT)
        .into()),
        _ => Err(DisplayError::new(
            "the persistent pool is stopped, unavailable or updating; inspect its parent controls",
        )
        .with_status(StatusCode::CONFLICT)
        .into()),
    }
}

fn has_status(error: &anyhow::Error, status: StatusCode) -> bool {
    extract_readable_error(error).is_some_and(|(_, actual)| actual == status)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn accepts_only_direct_pool_acceptance_fields() {
        let response = serde_json::json!({
            "runtime_id": "pool-1",
            "status": "creating",
            "status_url": "/api/pools/pool-1/status"
        });
        assert_eq!(
            parse_pool_acceptance(&response).unwrap(),
            ("pool-1", "/api/pools/pool-1/status")
        );
        assert!(parse_pool_acceptance(&serde_json::json!({ "data": response })).is_err());
        assert!(
            parse_pool_acceptance(&serde_json::json!({
                "runtime_id": "pool-1",
                "status_url": "https://attacker.invalid/status"
            }))
            .is_err()
        );
    }

    #[test]
    fn pending_and_quarantined_pools_are_not_usable() {
        assert!(ensure_pool_usable(&serde_json::json!({ "status": "running" })).is_ok());
        assert!(ensure_pool_usable(&serde_json::json!({ "status": "pending" })).is_err());
        assert!(ensure_pool_usable(&serde_json::json!({ "status": "quarantined" })).is_err());
    }

    #[test]
    fn capacity_includes_untracked_remote_children_without_double_counting() {
        let local = BTreeMap::from([("local-child".to_owned(), 512)]);
        let remote = vec![
            serde_json::json!({ "instance_id": "local-child", "limits": { "disk_mib": 512 } }),
            serde_json::json!({ "instance_id": "remote-child", "limits": { "disk_mib": 1024 } }),
        ];
        assert_eq!(
            reconcile_pool_reservations(local, &remote, None).unwrap(),
            (2, 1536)
        );
    }

    #[test]
    fn capacity_counts_pending_migrations_and_fails_closed_on_unknown_remote_disk() {
        assert_eq!(
            reconcile_pool_reservations(
                BTreeMap::new(),
                &[],
                Some(("migrating-child".to_owned(), 256)),
            )
            .unwrap(),
            (1, 256)
        );
        assert!(
            reconcile_pool_reservations(
                BTreeMap::new(),
                &[serde_json::json!({ "instance_id": "untracked-child" })],
                None,
            )
            .is_err()
        );
    }
}
