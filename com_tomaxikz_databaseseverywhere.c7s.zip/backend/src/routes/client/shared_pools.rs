use crate::{
    persistence::{DatabaseRecordApi, NodeRecord, PoolLimits},
    services::pools::{
        OwnedPool, list_owned_pools, load_owned_pool, local_pool_databases, owned_pool_instances,
        pool_capacity_usage, raw_pool_instances, reconciled_pool_databases,
    },
};
use axum::extract::{Path, Query};
use serde::{Deserialize, Serialize};
use shared::{
    ApiError, GetState,
    models::{
        server::{GetServer, GetServerActivityLogger},
        user::{GetPermissionManager, GetUser},
    },
    response::{ApiResponse, ApiResponseResult, DisplayError},
};
use std::collections::{BTreeMap, HashSet};
use utoipa::ToSchema;

#[derive(Serialize, ToSchema)]
struct PoolView {
    pool: crate::persistence::SharedPool,
    #[schema(value_type = serde_json::Value)]
    runtime: serde_json::Value,
    status: String,
    progress: Option<serde_json::Value>,
    #[schema(value_type = Vec<serde_json::Value>)]
    instances: Vec<serde_json::Value>,
    children: Vec<DatabaseRecordApi>,
}

#[derive(Serialize, ToSchema)]
struct ListResponse {
    pools: Vec<PoolView>,
}

async fn pool_view(state: &shared::State, owned: OwnedPool) -> Result<PoolView, anyhow::Error> {
    let instances = if owned.remote.is_null() {
        Vec::new()
    } else {
        owned_pool_instances(state, &owned).await?
    };
    let mut children = Vec::new();
    for database in local_pool_databases(state, &owned.mapping).await? {
        children.push(database.into_api(state, false).await?);
    }
    Ok(PoolView {
        pool: owned.mapping,
        runtime: owned.remote,
        status: owned
            .status
            .get("status")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("failed")
            .to_owned(),
        progress: owned.status.get("progress").cloned(),
        instances,
        children,
    })
}

#[utoipa::path(get, path = "/pools", responses(
    (status = OK, body = inline(ListResponse)),
    (status = FORBIDDEN, body = ApiError),
))]
pub async fn list(
    state: GetState,
    permissions: GetPermissionManager,
    server: GetServer,
) -> ApiResponseResult {
    permissions.has_server_permission("databases-everywhere.pools-read")?;
    let mut pools = Vec::new();
    for owned in list_owned_pools(&state, server.uuid).await? {
        pools.push(pool_view(&state, owned).await?);
    }
    ApiResponse::new_serialized(ListResponse { pools }).ok()
}

#[utoipa::path(get, path = "/pools/{pool_id}", params(
    ("pool_id" = String, Path, description = "Persistent DBEV pool runtime ID"),
), responses((status = OK, body = inline(PoolView)), (status = NOT_FOUND, body = ApiError)))]
pub async fn get(
    state: GetState,
    permissions: GetPermissionManager,
    server: GetServer,
    Path((_server, pool_id)): Path<(String, String)>,
) -> ApiResponseResult {
    permissions.has_server_permission("databases-everywhere.pools-read")?;
    let owned = load_owned_pool(&state, server.uuid, &pool_id).await?;
    ApiResponse::new_serialized(pool_view(&state, owned).await?).ok()
}

#[derive(Debug, Deserialize, ToSchema)]
#[serde(deny_unknown_fields)]
pub(super) struct PowerInput {
    action: String,
}

#[utoipa::path(post, path = "/pools/{pool_id}/power", params(
    ("pool_id" = String, Path, description = "Persistent DBEV pool runtime ID"),
), request_body = PowerInput, responses((status = OK, body = serde_json::Value)))]
pub async fn power(
    state: GetState,
    permissions: GetPermissionManager,
    activity: GetServerActivityLogger,
    server: GetServer,
    Path((_server, pool_id)): Path<(String, String)>,
    shared::Payload(input): shared::Payload<PowerInput>,
) -> ApiResponseResult {
    permissions.has_server_permission("databases-everywhere.pools-power")?;
    if !matches!(input.action.as_str(), "start" | "stop" | "restart" | "kill") {
        return Err(DisplayError::new("unsupported pool power action").into());
    }
    let owned = load_owned_pool(&state, server.uuid, &pool_id).await?;
    if owned.remote.is_null() || pool_image_requires_operator_attention(&owned.remote) {
        return Err(DisplayError::new(
            "the pool requires operator attention before ordinary power operations",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    }
    let result = owned
        .client
        .post::<serde_json::Value, _>(
            &format!(
                "/api/pools/{}/power",
                urlencoding::encode(owned.mapping.require_runtime()?)
            ),
            &serde_json::json!({ "action": input.action }),
        )
        .await?;
    activity
        .log(
            "server:databases-everywhere.pool-power",
            serde_json::json!({ "pool_id": pool_id, "action": input.action }),
        )
        .await;
    ApiResponse::new_serialized(result).ok()
}

#[utoipa::path(patch, path = "/pools/{pool_id}", params(
    ("pool_id" = String, Path, description = "Persistent DBEV pool runtime ID"),
), request_body = PoolLimits, responses((status = OK, body = serde_json::Value)))]
pub async fn resize(
    state: GetState,
    permissions: GetPermissionManager,
    activity: GetServerActivityLogger,
    server: GetServer,
    Path((_server, pool_id)): Path<(String, String)>,
    shared::Payload(limits): shared::Payload<PoolLimits>,
) -> ApiResponseResult {
    permissions.has_server_permission("databases-everywhere.pools-update")?;
    if let Err(errors) = shared::utils::validate_data(&limits) {
        return ApiResponse::new_serialized(ApiError::new_strings_value(errors))
            .with_status(axum::http::StatusCode::BAD_REQUEST)
            .ok();
    }
    let mut owned = load_owned_pool(&state, server.uuid, &pool_id).await?;
    let node = crate::persistence::NodeRecord::by_uuid(&state, owned.mapping.node_uuid)
        .await?
        .ok_or_else(|| DisplayError::new("the mapped DBEV node no longer exists"))?;
    let approved =
        crate::persistence::SharedPool::configured(&server, owned.mapping.protocol, &node)
            .await?
            .limits;
    if limits.cpu_cores > approved.cpu_cores
        || limits.memory_mib > approved.memory_mib
        || limits.disk_mib > approved.disk_mib
        || limits.max_tenants > approved.max_tenants
    {
        return Err(DisplayError::new(
            "pool limits exceed this server's administrator-approved allocation",
        )
        .with_status(axum::http::StatusCode::FORBIDDEN)
        .into());
    }
    let (tenant_count, reserved_disk_mib) = pool_capacity_usage(&state, &owned, None).await?;
    let mut proposed = owned.mapping.clone();
    proposed.limits = limits;
    if let Some(message) = proposed.capacity_error(tenant_count, reserved_disk_mib) {
        return Err(DisplayError::new(message)
            .with_status(axum::http::StatusCode::CONFLICT)
            .into());
    }
    let result = owned
        .client
        .patch::<serde_json::Value, _>(
            &format!(
                "/api/pools/{}",
                urlencoding::encode(owned.mapping.require_runtime()?)
            ),
            &limits,
        )
        .await?;
    owned
        .mapping
        .verify_configuration(&result, &owned.panel_id, limits)?;
    let before = owned.mapping.limits;
    owned.mapping.save_limits(&state, limits).await?;
    activity
        .log(
            "server:databases-everywhere.pool-resize",
            serde_json::json!({ "pool_id": pool_id, "before": before, "after": limits }),
        )
        .await;
    ApiResponse::new_serialized(result).ok()
}

#[derive(Debug, Deserialize, ToSchema)]
#[serde(deny_unknown_fields)]
pub(super) struct ImageInput {
    image: String,
    confirm: bool,
    reason: String,
}

#[utoipa::path(patch, path = "/pools/{pool_id}/image", params(
    ("pool_id" = String, Path, description = "Persistent DBEV pool runtime ID"),
), request_body = ImageInput, responses((status = OK, body = serde_json::Value)))]
pub async fn image(
    state: GetState,
    permissions: GetPermissionManager,
    activity: GetServerActivityLogger,
    server: GetServer,
    Path((_server, pool_id)): Path<(String, String)>,
    shared::Payload(input): shared::Payload<ImageInput>,
) -> ApiResponseResult {
    permissions.has_server_permission("databases-everywhere.pools-update")?;
    permissions.has_server_permission("databases-everywhere.backup-create")?;
    if !input.confirm || input.reason.trim().is_empty() {
        return Err(
            DisplayError::new("pool image changes require confirmation and a reason").into(),
        );
    }
    if input.image.trim().is_empty() || input.image.len() > 255 {
        return Err(DisplayError::new("enter a valid pool image").into());
    }
    let owned = load_owned_pool(&state, server.uuid, &pool_id).await?;
    let node = NodeRecord::by_uuid(&state, owned.mapping.node_uuid)
        .await?
        .ok_or_else(|| DisplayError::new("the pool's DBEV node no longer exists"))?;
    if !node.allows_image(owned.mapping.protocol, Some(input.image.trim())) {
        return Err(
            DisplayError::new("the requested pool image is not allowed on its DBEV node")
                .with_status(axum::http::StatusCode::FORBIDDEN)
                .into(),
        );
    }
    let current_image = pool_image(&owned.remote).ok_or_else(|| {
        DisplayError::new(
            "DBEV did not report the pool's current image; its release line cannot be verified",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
    })?;
    if !same_image_release_line(owned.mapping.protocol, current_image, input.image.trim()) {
        return Err(DisplayError::new(
            "pool image updates must stay within the current repository and release line",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    }
    if pool_image_requires_operator_attention(&owned.remote) {
        return Err(DisplayError::new(
            "pending or quarantined pool image updates require operator attention",
        )
        .with_status(axum::http::StatusCode::CONFLICT)
        .into());
    }

    // Back up every child before forwarding the same-release pool image update.
    for database in reconciled_pool_databases(&state, &owned).await? {
        owned
            .client
            .post::<serde_json::Value, _>(
                &format!(
                    "/api/instances/{}/backups",
                    urlencoding::encode(&database.instance_id())
                ),
                &serde_json::json!({}),
            )
            .await?;
    }
    let result = owned
        .client
        .patch::<serde_json::Value, _>(
            &format!(
                "/api/pools/{}/image",
                urlencoding::encode(owned.mapping.require_runtime()?)
            ),
            &serde_json::json!({
                "image": input.image,
                "confirm": true,
                "reason": input.reason,
            }),
        )
        .await?;
    activity
        .log(
            "server:databases-everywhere.pool-image",
            serde_json::json!({ "pool_id": pool_id, "image": input.image, "reason": input.reason }),
        )
        .await;
    ApiResponse::new_serialized(result).ok()
}

#[derive(Debug, Deserialize, ToSchema)]
pub(super) struct DeleteQuery {
    confirm: bool,
    reason: String,
}

#[utoipa::path(delete, path = "/pools/{pool_id}", params(
    ("pool_id" = String, Path, description = "Persistent DBEV pool runtime ID"),
    ("confirm" = bool, Query, description = "Explicit destructive confirmation"),
    ("reason" = String, Query, description = "Audit reason"),
), responses((status = NO_CONTENT), (status = CONFLICT, body = ApiError)))]
pub async fn delete(
    state: GetState,
    permissions: GetPermissionManager,
    activity: GetServerActivityLogger,
    server: GetServer,
    Path((_server, pool_id)): Path<(String, String)>,
    Query(query): Query<DeleteQuery>,
) -> ApiResponseResult {
    permissions.has_server_permission("databases-everywhere.pools-delete")?;
    if !query.confirm || query.reason.trim().is_empty() {
        return Err(DisplayError::new("pool deletion requires confirmation and a reason").into());
    }
    let owned = load_owned_pool(&state, server.uuid, &pool_id).await?;
    let local = local_pool_databases(&state, &owned.mapping).await?;
    let remote = raw_pool_instances(&owned).await?;
    if !pool_is_empty(local.len(), remote.len())
        || owned
            .remote
            .get("tenant_count")
            .and_then(serde_json::Value::as_u64)
            != Some(0)
    {
        return Err(
            DisplayError::new("only an empty persistent pool can be deleted")
                .with_status(axum::http::StatusCode::CONFLICT)
                .into(),
        );
    }
    owned
        .client
        .delete_success(&format!(
            "/api/pools/{}?confirm=true&reason={}",
            urlencoding::encode(owned.mapping.require_runtime()?),
            urlencoding::encode(query.reason.trim())
        ))
        .await?;
    owned.mapping.delete_mapping(&state).await?;
    activity
        .log(
            "server:databases-everywhere.pool-delete",
            serde_json::json!({ "pool_id": pool_id, "reason": query.reason }),
        )
        .await;
    Ok(ApiResponse::new_serialized(serde_json::json!({}))
        .with_status(axum::http::StatusCode::NO_CONTENT))
}

#[derive(Serialize, ToSchema)]
struct BackupsResponse {
    #[schema(value_type = std::collections::BTreeMap<String, Vec<serde_json::Value>>)]
    backups: BTreeMap<String, Vec<serde_json::Value>>,
}

fn pool_is_empty(local_count: usize, remote_count: usize) -> bool {
    local_count == 0 && remote_count == 0
}

fn pool_image(remote: &serde_json::Value) -> Option<&str> {
    remote
        .get("image")
        .and_then(serde_json::Value::as_str)
        .filter(|image| !image.trim().is_empty())
}

fn pool_image_requires_operator_attention(remote: &serde_json::Value) -> bool {
    remote
        .get("pending_image")
        .is_some_and(|image| !image.is_null())
        || remote.get("status").and_then(serde_json::Value::as_str) == Some("quarantined")
}

fn same_image_release_line(
    protocol: crate::domain::DatabaseProtocol,
    current: &str,
    requested: &str,
) -> bool {
    if current == requested {
        return true;
    }
    let (Some(current), Some(requested)) = (
        image_repository_and_version(current),
        image_repository_and_version(requested),
    ) else {
        return false;
    };
    current.repository == requested.repository
        && current.release == requested.release
        && (protocol == crate::domain::DatabaseProtocol::Postgres
            || (current.version.get(1).is_some()
                && current.version.get(1) == requested.version.get(1)))
        && requested.version >= current.version
}

struct ImageRelease<'a> {
    repository: &'a str,
    release: u64,
    version: Vec<u64>,
}

fn image_repository_and_version(image: &str) -> Option<ImageRelease<'_>> {
    let tagged = image.trim().split('@').next()?;
    let last_slash = tagged.rfind('/');
    let tag_separator = tagged
        .rfind(':')
        .filter(|index| last_slash.is_none_or(|slash| *index > slash))?;
    let repository = tagged[..tag_separator].trim();
    let tag = tagged[tag_separator + 1..].trim();
    let version = tag
        .trim_start_matches('v')
        .split(['-', '_'])
        .next()?
        .split('.')
        .map(str::parse::<u64>)
        .collect::<Result<Vec<_>, _>>()
        .ok()?;
    let release = *version.first()?;
    (!repository.is_empty()).then_some(ImageRelease {
        repository,
        release,
        version,
    })
}

#[utoipa::path(get, path = "/pools/{pool_id}/backups", params(
    ("pool_id" = String, Path, description = "Persistent DBEV pool runtime ID"),
), responses((status = OK, body = inline(BackupsResponse))))]
pub async fn backups(
    state: GetState,
    permissions: GetPermissionManager,
    server: GetServer,
    Path((_server, pool_id)): Path<(String, String)>,
) -> ApiResponseResult {
    permissions.has_server_permission("databases-everywhere.pools-backups")?;
    let owned = load_owned_pool(&state, server.uuid, &pool_id).await?;
    let allowed = local_pool_databases(&state, &owned.mapping)
        .await?
        .into_iter()
        .map(|database| database.instance_id())
        .collect::<HashSet<_>>();
    let remote = owned
        .client
        .get::<Vec<serde_json::Value>>(&format!(
            "/api/pools/{}/backups",
            urlencoding::encode(owned.mapping.require_runtime()?)
        ))
        .await?;
    let mut backups = BTreeMap::<String, Vec<serde_json::Value>>::new();
    for backup in remote {
        let Some(instance_id) = backup
            .get("instance_id")
            .and_then(serde_json::Value::as_str)
            .filter(|instance_id| allowed.contains(*instance_id))
        else {
            continue;
        };
        backups
            .entry(instance_id.to_owned())
            .or_default()
            .push(backup);
    }
    ApiResponse::new_serialized(BackupsResponse { backups }).ok()
}

#[derive(Debug, Clone, Copy, Deserialize, ToSchema)]
#[serde(rename_all = "lowercase")]
enum PoolSocketChannel {
    Monitor,
    Logs,
}

#[derive(Debug, Deserialize, ToSchema)]
#[serde(deny_unknown_fields)]
pub(super) struct PoolSocketInput {
    channel: PoolSocketChannel,
}

#[derive(Serialize)]
struct MintPayload<'a> {
    subject: String,
    server_id: uuid::Uuid,
    pools: &'a [&'a str],
    scopes: &'a [&'static str],
    ttl_seconds: u16,
}

#[derive(Deserialize)]
struct MintedToken {
    token_type: String,
    token: String,
    expires_at_unix: i64,
}

#[derive(Serialize, ToSchema)]
struct PoolSocketResponse {
    token_type: String,
    token: String,
    expires_at_unix: i64,
    url: String,
    pool_id: String,
    scopes: Vec<&'static str>,
}

#[utoipa::path(post, path = "/pools/{pool_id}/ws-token", params(
    ("pool_id" = String, Path, description = "Persistent DBEV pool runtime ID"),
), request_body = PoolSocketInput, responses((status = OK, body = inline(PoolSocketResponse))))]
pub async fn websocket_token(
    state: GetState,
    permissions: GetPermissionManager,
    user: GetUser,
    server: GetServer,
    Path((_server, pool_id)): Path<(String, String)>,
    shared::Payload(input): shared::Payload<PoolSocketInput>,
) -> ApiResponseResult {
    let (permission, scope, logs) = match input.channel {
        PoolSocketChannel::Monitor => {
            ("databases-everywhere.pools-monitor", "pools:monitor", false)
        }
        PoolSocketChannel::Logs => ("databases-everywhere.pools-logs", "pools:logs", true),
    };
    permissions.has_server_permission(permission)?;
    let owned = load_owned_pool(&state, server.uuid, &pool_id).await?;
    let runtime_id = owned.mapping.require_runtime()?;
    let scopes = &[scope];
    let pools = &[runtime_id];
    let minted = owned
        .client
        .post::<MintedToken, _>(
            "/api/ws-token",
            &MintPayload {
                subject: format!("panel-user-{}", user.uuid),
                server_id: server.uuid,
                pools,
                scopes,
                ttl_seconds: 900,
            },
        )
        .await?;
    let path = format!(
        "/ws/pools/{runtime_id}/{}",
        if logs { "logs" } else { "monitoring" }
    );
    let url = if logs {
        owned.client.websocket_url_with_query(&path, "tail=100")?
    } else {
        owned.client.websocket_url(&path)?
    };
    ApiResponse::new_serialized(PoolSocketResponse {
        token_type: minted.token_type,
        token: minted.token,
        expires_at_unix: minted.expires_at_unix,
        url,
        pool_id: runtime_id.to_owned(),
        scopes: scopes.to_vec(),
    })
    .ok()
}

pub fn router(state: &shared::State) -> utoipa_axum::router::OpenApiRouter<shared::State> {
    use utoipa_axum::{router::OpenApiRouter, routes};
    OpenApiRouter::new()
        .routes(routes!(list))
        .routes(routes!(get))
        .routes(routes!(power))
        .routes(routes!(resize))
        .routes(routes!(image))
        .routes(routes!(delete))
        .routes(routes!(backups))
        .routes(routes!(websocket_token))
        .with_state(state.clone())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pool_jwt_contract_uses_only_pool_targets_and_scope() {
        let server_id = uuid::Uuid::new_v4();
        let pools = &["pool-1"];
        let scopes = &["pools:monitor"];
        let value = serde_json::to_value(MintPayload {
            subject: "panel-user-example".to_owned(),
            server_id,
            pools,
            scopes,
            ttl_seconds: 900,
        })
        .unwrap();
        assert_eq!(value["server_id"], serde_json::json!(server_id));
        assert_eq!(value["pools"], serde_json::json!(["pool-1"]));
        assert_eq!(value["scopes"], serde_json::json!(["pools:monitor"]));
        assert_eq!(value["ttl_seconds"], 900);
        assert!(value.get("instances").is_none());
    }

    #[test]
    fn pool_log_jwt_uses_the_log_scope_without_instance_targets() {
        let pools = &["pool-1"];
        let scopes = &["pools:logs"];
        let value = serde_json::to_value(MintPayload {
            subject: "panel-user-example".to_owned(),
            server_id: uuid::Uuid::new_v4(),
            pools,
            scopes,
            ttl_seconds: 900,
        })
        .unwrap();
        assert_eq!(value["scopes"], serde_json::json!(["pools:logs"]));
        assert_eq!(value["pools"], serde_json::json!(["pool-1"]));
        assert!(value.get("instances").is_none());
    }

    #[test]
    fn a_last_child_deletion_does_not_implicitly_delete_the_pool() {
        assert!(!pool_is_empty(0, 1));
        assert!(!pool_is_empty(1, 0));
        assert!(pool_is_empty(0, 0));
    }

    #[test]
    fn pool_images_only_move_forward_within_a_verifiable_release_line() {
        assert!(same_image_release_line(
            crate::domain::DatabaseProtocol::Postgres,
            "registry.example/postgres:17.2",
            "registry.example/postgres:17.4",
        ));
        assert!(!same_image_release_line(
            crate::domain::DatabaseProtocol::Mysql,
            "registry.example/mysql:v8.0@sha256:old",
            "registry.example/mysql:v8.4@sha256:new",
        ));
        assert!(!same_image_release_line(
            crate::domain::DatabaseProtocol::Postgres,
            "registry.example/postgres:17.2",
            "registry.example/postgres:18.0",
        ));
        assert!(!same_image_release_line(
            crate::domain::DatabaseProtocol::Postgres,
            "registry.example/postgres:17.2",
            "registry.example/postgres:17.1",
        ));
        assert!(!same_image_release_line(
            crate::domain::DatabaseProtocol::Postgres,
            "registry.example/postgres:17.2",
            "other.example/postgres:17.4",
        ));
        assert!(!same_image_release_line(
            crate::domain::DatabaseProtocol::Postgres,
            "registry.example/postgres@sha256:old",
            "registry.example/postgres@sha256:new",
        ));
        assert_eq!(
            pool_image(&serde_json::json!({ "image": "postgres:17.2" })),
            Some("postgres:17.2"),
        );
        assert!(pool_image_requires_operator_attention(
            &serde_json::json!({ "status": "running", "pending_image": "postgres:17.4" }),
        ));
    }
}
