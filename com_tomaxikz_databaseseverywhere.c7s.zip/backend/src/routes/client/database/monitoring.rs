use crate::{
    dbev::{DbevClient, mutation_contract_block_reason},
    domain::DeploymentMode,
    persistence::{
        DatabaseRecord, NodeRecord, remote_operation_completed, remote_runtime_id, remote_status,
    },
};
use axum::{Extension, extract::Query};
use serde::{Deserialize, Serialize};
use shared::{
    ApiError, GetState, State,
    models::{
        server::GetServer,
        user::{GetPermissionManager, GetUser},
    },
    response::{ApiResponse, ApiResponseResult, DisplayError, extract_readable_error},
};
use std::collections::HashSet;
use utoipa::ToSchema;
use utoipa_axum::{router::OpenApiRouter, routes};

#[derive(Serialize, ToSchema)]
struct Response {
    #[schema(value_type = serde_json::Value)]
    result: serde_json::Value,
}

#[derive(Debug, Clone, Copy, Deserialize, ToSchema)]
#[serde(rename_all = "kebab-case")]
enum WebSocketChannel {
    Monitor,
    Logs,
    ImportExport,
}

#[derive(Debug, Deserialize, ToSchema)]
struct WebSocketTokenPayload {
    channel: WebSocketChannel,
    /// Optional, server-validated monitor scope used by the native database list.
    instances: Option<Vec<uuid::Uuid>>,
}

#[derive(Debug, Deserialize)]
struct MintedWebSocketToken {
    #[serde(default = "default_token_type")]
    token_type: String,
    #[serde(alias = "jwt")]
    token: String,
    expires_at_unix: i64,
}

#[derive(Serialize, ToSchema)]
struct WebSocketTokenResponse {
    token_type: String,
    token: String,
    expires_at_unix: i64,
    url: String,
    instance_id: String,
    scopes: Vec<&'static str>,
}

fn default_token_type() -> String {
    "Bearer".to_owned()
}

mod websocket_token {
    use super::*;

    #[derive(Serialize)]
    struct MintPayload<'a> {
        subject: String,
        scopes: &'a [&'static str],
        instances: &'a [String],
        ttl_seconds: u16,
    }

    #[utoipa::path(post, path = "/ws-token", request_body = WebSocketTokenPayload, responses(
        (status = OK, body = inline(WebSocketTokenResponse)),
        (status = FORBIDDEN, body = ApiError),
        (status = BAD_REQUEST, body = ApiError),
        (status = NOT_FOUND, body = ApiError),
        (status = BAD_GATEWAY, body = ApiError),
    ))]
    pub async fn route(
        state: GetState,
        permissions: GetPermissionManager,
        user: GetUser,
        server: GetServer,
        Extension(database): Extension<DatabaseRecord>,
        shared::Payload(payload): shared::Payload<WebSocketTokenPayload>,
    ) -> ApiResponseResult {
        let (scopes, path): (&[&'static str], String) = match payload.channel {
            WebSocketChannel::Monitor => {
                if database.deployment_mode == DeploymentMode::Shared {
                    return Err(DisplayError::new(
                        "shared engine metrics require whole-pool authorization and the pool monitoring socket",
                    )
                    .with_status(axum::http::StatusCode::FORBIDDEN)
                    .into());
                }
                (&["monitor:read"], "/ws/monitoring".to_owned())
            }
            WebSocketChannel::Logs => {
                permissions.has_server_permission("databases-everywhere.logs")?;
                if database.deployment_mode == DeploymentMode::Shared {
                    return Err(DisplayError::new(
                        "container logs are unavailable for shared database tenants",
                    )
                    .with_status(axum::http::StatusCode::CONFLICT)
                    .into());
                }
                (
                    &["logs:read"],
                    format!("/ws/instances/{}/logs", database.instance_id()),
                )
            }
            WebSocketChannel::ImportExport => {
                permissions.has_server_permission("databases-everywhere.transfers")?;
                (
                    &["import-export:read"],
                    format!("/ws/instances/{}/import-export", database.instance_id()),
                )
            }
        };

        let instance_ids = monitor_instances(&state, &server, &database, &payload).await?;
        let (node, client) = node_client(&state, &database).await?;
        // Refresh capabilities whenever a new browser token is minted.
        let system = client.system().await?;
        let contract_error = mutation_contract_block_reason(Some(&system));
        node.store_health(&state, Some(&system), None, contract_error.as_deref())
            .await?;
        let instance_id = database.instance_id();
        let token = client
            .post::<MintedWebSocketToken, _>(
                "/api/ws-token",
                &MintPayload {
                    subject: format!("panel-user-{}", user.uuid),
                    scopes,
                    instances: &instance_ids,
                    ttl_seconds: 120,
                },
            )
            .await?;

        ApiResponse::new_serialized(WebSocketTokenResponse {
            token_type: token.token_type,
            token: token.token,
            expires_at_unix: token.expires_at_unix,
            url: client.websocket_url(&path)?,
            instance_id,
            scopes: scopes.to_vec(),
        })
        .ok()
    }

    async fn monitor_instances(
        state: &State,
        server: &shared::models::server::Server,
        database: &DatabaseRecord,
        payload: &WebSocketTokenPayload,
    ) -> Result<Vec<String>, anyhow::Error> {
        if !matches!(payload.channel, WebSocketChannel::Monitor) {
            if payload.instances.is_some() {
                return Err(DisplayError::new(
                    "custom instance scopes are only supported for monitoring sockets",
                )
                .with_status(axum::http::StatusCode::BAD_REQUEST)
                .into());
            }
            return Ok(vec![database.instance_id()]);
        }

        let requested = payload
            .instances
            .clone()
            .unwrap_or_else(|| vec![database.uuid]);
        if requested.is_empty() || requested.len() > 4096 {
            return Err(DisplayError::new(
                "monitoring WebSocket scopes must contain between 1 and 4096 databases",
            )
            .with_status(axum::http::StatusCode::BAD_REQUEST)
            .into());
        }

        let mut seen = HashSet::with_capacity(requested.len());
        let mut instance_ids = Vec::with_capacity(requested.len());
        for uuid in requested {
            if !seen.insert(uuid) {
                continue;
            }
            let scoped = DatabaseRecord::by_server_uuid(state, server.uuid, uuid)
                .await?
                .ok_or_else(|| {
                    DisplayError::new("a requested monitoring database was not found")
                        .with_status(axum::http::StatusCode::NOT_FOUND)
                })?;
            if scoped.deployment_mode == DeploymentMode::Shared {
                return Err(DisplayError::new(
                    "shared engine metrics require whole-pool authorization and cannot be added to an instance monitoring scope",
                )
                .with_status(axum::http::StatusCode::FORBIDDEN)
                .into());
            }
            if scoped.dbev_node_uuid != database.dbev_node_uuid {
                return Err(DisplayError::new(
                    "all databases in a monitoring WebSocket scope must use the same DBE node",
                )
                .with_status(axum::http::StatusCode::BAD_REQUEST)
                .into());
            }
            instance_ids.push(scoped.instance_id());
        }

        Ok(instance_ids)
    }
}

mod status {
    use super::*;

    #[utoipa::path(get, path = "/", responses(
        (status = OK, body = inline(Response)),
        (status = BAD_GATEWAY, body = ApiError),
    ))]
    pub async fn route(
        state: GetState,
        Extension(database): Extension<DatabaseRecord>,
    ) -> ApiResponseResult {
        let client = client(&state, &database).await?;
        let mut result = match client
            .get::<serde_json::Value>(&database.status_url())
            .await
        {
            Ok(result) => result,
            Err(status_error)
                if database.creation_pending()
                    && error_has_status(&status_error, axum::http::StatusCode::NOT_FOUND) =>
            {
                let instance_path = format!(
                    "/api/instances/{}",
                    urlencoding::encode(&database.instance_id())
                );
                match client.get::<serde_json::Value>(&instance_path).await {
                    Ok(instance) => instance,
                    Err(instance_error)
                        if error_has_status(&instance_error, axum::http::StatusCode::NOT_FOUND) =>
                    {
                        const MESSAGE: &str =
                            "DatabasesEverywhere no longer reports the accepted database creation";
                        database.release_quota_with_error(&state, MESSAGE).await?;
                        serde_json::json!({
                            "instance": {
                                "instance_id": database.instance_id(),
                                "status": "failed",
                                "failure": {
                                    "code": "not_found",
                                    "message": MESSAGE,
                                }
                            }
                        })
                    }
                    Err(instance_error) => return Err(instance_error.into()),
                }
            }
            Err(error) => return Err(error.into()),
        };
        database.update_remote_state(&state, &result).await?;
        let terminal_without_runtime = remote_status(&result)
            .is_some_and(|status| !matches!(status, "creating" | "booting" | "failed"))
            && remote_runtime_id(&result).is_none();
        if terminal_without_runtime || remote_operation_completed(&result) {
            result = client
                .get::<serde_json::Value>(&format!(
                    "/api/instances/{}",
                    urlencoding::encode(&database.instance_id())
                ))
                .await?;
            database.update_remote_state(&state, &result).await?;
        }
        ApiResponse::new_serialized(Response { result }).ok()
    }
}

fn error_has_status(error: &anyhow::Error, expected: axum::http::StatusCode) -> bool {
    extract_readable_error(error).is_some_and(|(_, status)| status == expected)
}

mod instance {
    use super::*;

    #[utoipa::path(get, path = "/", responses(
        (status = OK, body = inline(Response)),
        (status = BAD_GATEWAY, body = ApiError),
    ))]
    pub async fn route(
        state: GetState,
        Extension(database): Extension<DatabaseRecord>,
    ) -> ApiResponseResult {
        let client = client(&state, &database).await?;
        let result = client
            .get::<serde_json::Value>(&format!(
                "/api/instances/{}",
                urlencoding::encode(&database.instance_id())
            ))
            .await?;
        database.update_remote_state(&state, &result).await?;
        ApiResponse::new_serialized(Response { result }).ok()
    }
}

mod resources {
    use super::*;

    #[utoipa::path(get, path = "/", responses(
        (status = OK, body = inline(Response)),
        (status = BAD_GATEWAY, body = ApiError),
    ))]
    pub async fn route(
        state: GetState,
        Extension(database): Extension<DatabaseRecord>,
    ) -> ApiResponseResult {
        reject_shared_engine_telemetry(&database)?;
        let client = client(&state, &database).await?;
        let result = client
            .get::<serde_json::Value>(&format!(
                "/api/instances/{}/resources",
                urlencoding::encode(&database.instance_id())
            ))
            .await?;
        ApiResponse::new_serialized(Response { result }).ok()
    }
}

mod logs {
    use super::*;

    #[derive(Deserialize, ToSchema)]
    pub struct Params {
        tail: Option<u16>,
    }

    #[utoipa::path(get, path = "/", params(
        ("tail" = Option<u16>, Query, description = "Number of log lines (1-2000)"),
    ), responses(
        (status = OK, body = inline(Response)),
        (status = BAD_GATEWAY, body = ApiError),
    ))]
    pub async fn route(
        state: GetState,
        permissions: GetPermissionManager,
        Extension(database): Extension<DatabaseRecord>,
        Query(params): Query<Params>,
    ) -> ApiResponseResult {
        permissions.has_server_permission("databases-everywhere.logs")?;
        if database.deployment_mode == DeploymentMode::Shared {
            return Err(DisplayError::new(
                "container logs are unavailable for shared database tenants",
            )
            .with_status(axum::http::StatusCode::CONFLICT)
            .into());
        }
        let client = client(&state, &database).await?;
        let tail = params.tail.unwrap_or(200).clamp(1, 2000);
        let result = client
            .get::<serde_json::Value>(&format!(
                "/api/instances/{}/logs?tail={tail}",
                urlencoding::encode(&database.instance_id())
            ))
            .await?;
        ApiResponse::new_serialized(Response { result }).ok()
    }
}

mod activity {
    use super::*;

    #[utoipa::path(get, path = "/", responses(
        (status = OK, body = inline(Response)),
        (status = BAD_GATEWAY, body = ApiError),
    ))]
    pub async fn route(
        state: GetState,
        Extension(database): Extension<DatabaseRecord>,
    ) -> ApiResponseResult {
        reject_shared_engine_telemetry(&database)?;
        let result = client(&state, &database)
            .await?
            .get::<serde_json::Value>(&format!(
                "/api/instances/{}/activity",
                urlencoding::encode(&database.instance_id())
            ))
            .await?;
        ApiResponse::new_serialized(Response { result }).ok()
    }
}

mod activity_history {
    use super::*;

    #[utoipa::path(get, path = "/", responses(
        (status = OK, body = inline(Response)),
        (status = BAD_GATEWAY, body = ApiError),
    ))]
    pub async fn route(
        state: GetState,
        Extension(database): Extension<DatabaseRecord>,
    ) -> ApiResponseResult {
        reject_shared_engine_telemetry(&database)?;
        let result = client(&state, &database)
            .await?
            .get::<serde_json::Value>(&format!(
                "/api/instances/{}/activity/history",
                urlencoding::encode(&database.instance_id())
            ))
            .await?;
        ApiResponse::new_serialized(Response { result }).ok()
    }
}

fn reject_shared_engine_telemetry(database: &DatabaseRecord) -> Result<(), anyhow::Error> {
    if database.deployment_mode == DeploymentMode::Shared {
        return Err(DisplayError::new(
            "shared engine telemetry is available only from the authorized parent pool",
        )
        .with_status(axum::http::StatusCode::FORBIDDEN)
        .into());
    }
    Ok(())
}

async fn client(state: &State, database: &DatabaseRecord) -> Result<DbevClient, anyhow::Error> {
    Ok(node_client(state, database).await?.1)
}

async fn node_client(
    state: &State,
    database: &DatabaseRecord,
) -> Result<(NodeRecord, DbevClient), anyhow::Error> {
    let node = NodeRecord::by_uuid(state, database.dbev_node_uuid)
        .await?
        .ok_or_else(|| anyhow::anyhow!("DatabasesEverywhere node no longer exists"))?;
    let client = DbevClient::for_node(state, &node).await?;
    Ok((node, client))
}

pub fn router(state: &State) -> OpenApiRouter<State> {
    OpenApiRouter::new()
        .routes(routes!(websocket_token::route))
        .nest(
            "/status",
            OpenApiRouter::new()
                .routes(routes!(status::route))
                .with_state(state.clone()),
        )
        .nest(
            "/instance",
            OpenApiRouter::new()
                .routes(routes!(instance::route))
                .with_state(state.clone()),
        )
        .nest(
            "/resources",
            OpenApiRouter::new()
                .routes(routes!(resources::route))
                .with_state(state.clone()),
        )
        .nest(
            "/logs",
            OpenApiRouter::new()
                .routes(routes!(logs::route))
                .with_state(state.clone()),
        )
        .nest(
            "/activity",
            OpenApiRouter::new()
                .routes(routes!(activity::route))
                .with_state(state.clone()),
        )
        .nest(
            "/activity-history",
            OpenApiRouter::new()
                .routes(routes!(activity_history::route))
                .with_state(state.clone()),
        )
        .with_state(state.clone())
}
