use super::validate_id;
use crate::{
    dbev::DbevCapabilities,
    persistence::{DatabaseRecord, NodeRecord},
};
use axum::{
    Extension,
    body::Body,
    extract::{DefaultBodyLimit, Path},
    http::{HeaderMap, StatusCode},
};
use contracts::{
    CSRF_HEADER, CSRF_VALUE, DeleteResponse, DumpInspection, MAX_UPLOAD_BYTES, TemporaryUpload,
    UploadListResponse, UploadResponse, validate_upload_headers,
};
use serde::{Deserialize, Serialize};
use shared::{
    ApiError, GetState, State,
    models::{server::GetServerActivityLogger, user::GetPermissionManager},
    response::{ApiResponse, ApiResponseResult, DisplayError},
};
use utoipa::ToSchema;
use utoipa_axum::{
    router::{OpenApiRouter, UtoipaMethodRouterExt},
    routes,
};

mod contracts;
mod legacy;

#[derive(Debug, Serialize, ToSchema)]
struct DetailResponse {
    upload: TemporaryUpload,
}

async fn system_and_capabilities(
    state: &State,
    database: &DatabaseRecord,
) -> Result<
    (
        crate::dbev::DbevClient,
        serde_json::Value,
        DbevCapabilities,
        u64,
    ),
    anyhow::Error,
> {
    let node = NodeRecord::by_uuid(state, database.dbev_node_uuid)
        .await?
        .ok_or_else(|| anyhow::anyhow!("DatabasesEverywhere node no longer exists"))?;
    let max_upload_bytes = configured_upload_max_bytes(&node.configuration);
    let (client, system) = crate::dbev::DbevClient::for_mutation_with_system(state, &node).await?;
    let capabilities = DbevCapabilities::from_system(&system);
    Ok((client, system, capabilities, max_upload_bytes))
}

async fn mutation_system_and_capabilities(
    state: &State,
    database: &DatabaseRecord,
) -> Result<
    (
        crate::dbev::DbevClient,
        serde_json::Value,
        DbevCapabilities,
        u64,
    ),
    anyhow::Error,
> {
    let node = NodeRecord::by_uuid(state, database.dbev_node_uuid)
        .await?
        .ok_or_else(|| anyhow::anyhow!("DatabasesEverywhere node no longer exists"))?;
    let max_upload_bytes = configured_upload_max_bytes(&node.configuration);
    let (client, system) = crate::dbev::DbevClient::for_mutation_with_system(state, &node).await?;
    let capabilities = DbevCapabilities::from_system(&system);
    Ok((client, system, capabilities, max_upload_bytes))
}

fn configured_upload_max_bytes(configuration: &serde_json::Value) -> u64 {
    configuration
        .pointer("/artifacts/import_upload_max_bytes")
        .and_then(serde_json::Value::as_u64)
        .filter(|value| (1..=MAX_UPLOAD_BYTES).contains(value))
        .unwrap_or(MAX_UPLOAD_BYTES)
}

fn api_version(system: &serde_json::Value) -> Option<String> {
    system
        .get("api_version")
        .and_then(serde_json::Value::as_str)
        .map(str::to_owned)
}

fn temporary_uploads(value: serde_json::Value) -> Result<Vec<TemporaryUpload>, anyhow::Error> {
    serde_json::from_value(value).map_err(|_| {
        DisplayError::new("DatabasesEverywhere returned an invalid temporary upload list")
            .with_status(StatusCode::BAD_GATEWAY)
            .into()
    })
}

fn dump_inspection(value: serde_json::Value) -> Result<DumpInspection, anyhow::Error> {
    serde_json::from_value(value).map_err(|_| {
        DisplayError::new("DatabasesEverywhere returned an invalid temporary upload catalog")
            .with_status(StatusCode::BAD_GATEWAY)
            .into()
    })
}

fn require_temporary_uploads(capabilities: DbevCapabilities) -> Result<(), anyhow::Error> {
    if capabilities.temporary_dump_uploads {
        Ok(())
    } else {
        Err(DisplayError::new(
            "this DBEV node does not advertise the required temporary upload contract",
        )
        .with_status(StatusCode::NOT_FOUND)
        .into())
    }
}

fn require_csrf(headers: &HeaderMap) -> Result<(), anyhow::Error> {
    if headers
        .get(CSRF_HEADER)
        .and_then(|value| value.to_str().ok())
        == Some(CSRF_VALUE)
    {
        Ok(())
    } else {
        Err(DisplayError::new("missing or invalid upload CSRF header")
            .with_status(StatusCode::FORBIDDEN)
            .into())
    }
}

mod list {
    use super::*;
    #[utoipa::path(get, path = "/", responses(
        (status = OK, body = inline(UploadListResponse)),
        (status = BAD_GATEWAY, body = ApiError),
    ))]
    pub async fn route(
        state: GetState,
        permissions: GetPermissionManager,
        Extension(database): Extension<DatabaseRecord>,
    ) -> ApiResponseResult {
        permissions.has_server_permission("databases-everywhere.transfers")?;
        let (client, system, capabilities, max_upload_bytes) =
            system_and_capabilities(&state, &database).await?;
        require_temporary_uploads(capabilities)?;
        let result = client
            .get::<serde_json::Value>(&format!(
                "/api/instances/{}/import/uploads",
                urlencoding::encode(&database.instance_id())
            ))
            .await?;
        // Operator-staged imports are still supported, independently of temporary uploads.
        let (staged_uploads, reason) = legacy::list(&state, &database).await?;
        ApiResponse::new_serialized(UploadListResponse {
            available: true,
            reason,
            api_version: api_version(&system),
            max_upload_bytes,
            uploads: temporary_uploads(result)?,
            staged_uploads,
        })
        .ok()
    }
}

mod upload {
    use super::*;

    #[utoipa::path(post, path = "/", request_body(
        content = Vec<u8>,
        content_type = "application/octet-stream",
    ), responses(
        (status = CREATED, body = inline(UploadResponse)),
        (status = BAD_REQUEST, body = ApiError),
        (status = FORBIDDEN, body = ApiError),
        (status = REQUEST_TIMEOUT, body = ApiError),
        (status = PAYLOAD_TOO_LARGE, body = ApiError),
        (status = UNSUPPORTED_MEDIA_TYPE, body = ApiError),
        (status = TOO_MANY_REQUESTS, body = ApiError),
    ))]
    pub async fn route(
        state: GetState,
        permissions: GetPermissionManager,
        activity_logger: GetServerActivityLogger,
        Extension(database): Extension<DatabaseRecord>,
        headers: HeaderMap,
        body: Body,
    ) -> ApiResponseResult {
        // Authorization and CSRF checks finish before the body stream is consumed.
        permissions.has_server_permission("databases-everywhere.import")?;
        let (client, _system, capabilities, max_upload_bytes) =
            mutation_system_and_capabilities(&state, &database).await?;
        let upload_headers = validate_upload_headers(&headers, max_upload_bytes)?;
        require_temporary_uploads(capabilities)?;

        let instance_id = database.instance_id();
        let stream = reqwest::Body::wrap_stream(body.into_data_stream());
        let upload = client
            .post_import_upload::<TemporaryUpload>(
                &format!(
                    "/api/instances/{}/import",
                    urlencoding::encode(&instance_id),
                ),
                upload_headers.content_length,
                &upload_headers.encoded_filename,
                upload_headers.sha256.as_deref(),
                stream,
            )
            .await?;

        if upload.instance_id != instance_id
            || upload.size_bytes != upload_headers.content_length
            || upload.original_filename != upload_headers.filename
        {
            return Err(DisplayError::new(
                "DatabasesEverywhere returned inconsistent temporary upload metadata",
            )
            .with_status(StatusCode::BAD_GATEWAY)
            .into());
        }
        activity_logger
            .log(
                "server:databases-everywhere.import-upload",
                serde_json::json!({
                    "uuid": database.uuid,
                    "upload_id": upload.upload_id,
                    "size_bytes": upload.size_bytes,
                }),
            )
            .await;

        Ok(ApiResponse::new_serialized(UploadResponse { upload }).with_status(StatusCode::CREATED))
    }
}

mod detail {
    use super::*;

    #[utoipa::path(get, path = "/", responses(
        (status = OK, body = inline(DetailResponse)),
        (status = NOT_FOUND, body = ApiError),
    ))]
    pub async fn route(
        state: GetState,
        permissions: GetPermissionManager,
        Extension(database): Extension<DatabaseRecord>,
        Path((_server, _database, upload)): Path<(String, uuid::Uuid, String)>,
    ) -> ApiResponseResult {
        permissions.has_server_permission("databases-everywhere.transfers")?;
        validate_id("upload", &upload)?;
        let (client, _system, capabilities, _max_upload_bytes) =
            system_and_capabilities(&state, &database).await?;
        require_temporary_uploads(capabilities)?;
        let upload = client
            .get::<TemporaryUpload>(&format!(
                "/api/instances/{}/import/uploads/{}",
                urlencoding::encode(&database.instance_id()),
                urlencoding::encode(&upload),
            ))
            .await?;
        ApiResponse::new_serialized(DetailResponse { upload }).ok()
    }
}

mod catalog {
    use super::*;

    #[utoipa::path(get, path = "/", responses(
        (status = OK, body = inline(DumpInspection)),
        (status = NOT_FOUND, body = ApiError),
        (status = CONFLICT, body = ApiError),
    ))]
    pub async fn get_route(
        state: GetState,
        permissions: GetPermissionManager,
        Extension(database): Extension<DatabaseRecord>,
        Path((_server, _database, upload)): Path<(String, uuid::Uuid, String)>,
    ) -> ApiResponseResult {
        permissions.has_server_permission("databases-everywhere.transfers")?;
        validate_id("upload", &upload)?;
        let (client, _system, capabilities, _max_upload_bytes) =
            system_and_capabilities(&state, &database).await?;
        require_temporary_uploads(capabilities)?;
        let result = client
            .get::<serde_json::Value>(&format!(
                "/api/instances/{}/import/uploads/{}/catalog",
                urlencoding::encode(&database.instance_id()),
                urlencoding::encode(&upload),
            ))
            .await?;
        ApiResponse::new_serialized(dump_inspection(result)?).ok()
    }

    #[utoipa::path(post, path = "/", responses(
        (status = OK, body = inline(DumpInspection)),
        (status = CONFLICT, body = ApiError),
        (status = TOO_MANY_REQUESTS, body = ApiError),
        (status = SERVICE_UNAVAILABLE, body = ApiError),
    ))]
    pub async fn post_route(
        state: GetState,
        permissions: GetPermissionManager,
        activity_logger: GetServerActivityLogger,
        Extension(database): Extension<DatabaseRecord>,
        Path((_server, _database, upload)): Path<(String, uuid::Uuid, String)>,
        headers: HeaderMap,
    ) -> ApiResponseResult {
        permissions.has_server_permission("databases-everywhere.import")?;
        require_csrf(&headers)?;
        validate_id("upload", &upload)?;
        let (client, _system, capabilities, _max_upload_bytes) =
            mutation_system_and_capabilities(&state, &database).await?;
        require_temporary_uploads(capabilities)?;
        let result = client
            .post::<serde_json::Value, _>(
                &format!(
                    "/api/instances/{}/import/uploads/{}/catalog",
                    urlencoding::encode(&database.instance_id()),
                    urlencoding::encode(&upload),
                ),
                &serde_json::json!({}),
            )
            .await?;
        let catalog = dump_inspection(result)?;
        activity_logger
            .log(
                "server:databases-everywhere.import-upload-inspect",
                serde_json::json!({ "uuid": database.uuid, "upload_id": upload }),
            )
            .await;
        ApiResponse::new_serialized(catalog).ok()
    }
}

mod delete {
    use super::*;

    #[derive(Debug, Deserialize, ToSchema)]
    pub struct Params {
        source: Option<String>,
    }

    #[utoipa::path(delete, path = "/", params(
        ("source" = Option<String>, Query, description = "Use legacy only for an operator-staged local file."),
    ), responses(
        (status = OK, body = inline(DeleteResponse)),
        (status = CONFLICT, body = ApiError),
        (status = NOT_FOUND, body = ApiError),
    ))]
    pub async fn route(
        state: GetState,
        permissions: GetPermissionManager,
        activity_logger: GetServerActivityLogger,
        Extension(database): Extension<DatabaseRecord>,
        Path((_server, _database, upload)): Path<(String, uuid::Uuid, String)>,
        axum::extract::Query(params): axum::extract::Query<Params>,
        headers: HeaderMap,
    ) -> ApiResponseResult {
        permissions.has_server_permission("databases-everywhere.import")?;
        require_csrf(&headers)?;
        validate_id("upload", &upload)?;
        let (client, _system, capabilities, _max_upload_bytes) =
            mutation_system_and_capabilities(&state, &database).await?;

        if params
            .source
            .as_deref()
            .is_some_and(|source| source != "legacy")
        {
            return Err(ApiResponse::error("invalid temporary upload source"));
        }

        require_temporary_uploads(capabilities)?;
        let delete_legacy = params.source.as_deref() == Some("legacy");
        let deleted = if !delete_legacy {
            client
                .delete_success(&format!(
                    "/api/instances/{}/import/uploads/{}",
                    urlencoding::encode(&database.instance_id()),
                    urlencoding::encode(&upload),
                ))
                .await?;
            true
        } else {
            legacy::delete(&state, &database, &upload).await?
        };
        if !deleted {
            return Err(DisplayError::new("temporary upload was not found")
                .with_status(StatusCode::NOT_FOUND)
                .into());
        }
        activity_logger
            .log(
                "server:databases-everywhere.import-upload-delete",
                serde_json::json!({ "uuid": database.uuid, "upload_id": upload }),
            )
            .await;
        ApiResponse::new_serialized(DeleteResponse { deleted: true }).ok()
    }
}

pub fn router(state: &State) -> OpenApiRouter<State> {
    OpenApiRouter::new()
        .routes(routes!(list::route))
        .routes(routes!(upload::route).layer(DefaultBodyLimit::disable()))
        .nest(
            "/{upload}",
            OpenApiRouter::new()
                .routes(routes!(detail::route))
                .routes(routes!(delete::route))
                .nest(
                    "/catalog",
                    OpenApiRouter::new()
                        .routes(routes!(catalog::get_route))
                        .routes(routes!(catalog::post_route))
                        .with_state(state.clone()),
                )
                .with_state(state.clone()),
        )
        .with_state(state.clone())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn accepts_only_root_upload_arrays_without_artifact_conversion() {
        let upload = serde_json::json!({
            "upload_id": "upl_test",
            "instance_id": "instance",
            "original_filename": "dump.sql",
            "protocol": "postgres",
            "archive_format": "plain",
            "state": "ready",
            "size_bytes": 1,
            "sha256": null,
            "created_at": "2026-08-10T00:00:00Z",
            "updated_at": "2026-08-10T00:00:00Z",
            "expires_at": "2026-08-11T00:00:00Z",
            "catalog_available": false
        });
        assert_eq!(
            temporary_uploads(serde_json::json!([upload.clone()]))
                .unwrap()
                .len(),
            1
        );
        assert!(temporary_uploads(serde_json::json!({ "uploads": [upload.clone()] })).is_err());
        let parsed = temporary_uploads(serde_json::json!([upload])).unwrap();
        assert_eq!(parsed[0].upload_id, "upl_test");
        assert!(!parsed[0].catalog_available);
        assert!(parsed[0].extra.get("artifact_id").is_none());
    }

    #[test]
    fn accepts_root_catalog_and_rejects_removed_upload_wrapper() {
        let catalog = serde_json::json!({
            "protocol": "mongodb",
            "sha256": "a".repeat(64),
            "source_size_bytes": 1,
            "detected_archive_format": "plain",
            "selection_kind": "full_only",
            "selective_supported": false,
            "catalog_complete": true,
            "namespaces": ["tenant"],
            "objects": [],
            "unselectable_object_count": 0,
            "selective_unavailable_reason": "full import only"
        });
        assert_eq!(
            dump_inspection(catalog.clone()).unwrap().namespaces,
            vec!["tenant"]
        );
        assert!(dump_inspection(serde_json::json!({ "catalog": catalog })).is_err());
    }

    #[test]
    fn configured_upload_limit_drives_panel_validation_and_scheduler_defaults() {
        assert_eq!(
            configured_upload_max_bytes(&serde_json::json!({
                "artifacts": { "import_upload_max_bytes": 536_870_912_u64 }
            })),
            536_870_912
        );
        assert_eq!(
            configured_upload_max_bytes(&serde_json::json!({
                "artifacts": { "import_upload_max_bytes": MAX_UPLOAD_BYTES + 1 }
            })),
            MAX_UPLOAD_BYTES
        );
    }
}
