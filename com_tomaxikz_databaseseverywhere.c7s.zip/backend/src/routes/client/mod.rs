use crate::{
    dbev::{DbevCapabilities, DbevClient, mutation_contract_block_reason},
    domain::{
        DatabaseProtocol, DeploymentMode, ResourceLimits, ServerDatabaseConfigurationExtension,
    },
    persistence::{DatabaseRecord, DatabaseRecordApi, HostAssignment},
    services::{CreateDatabaseInput, create_database, extension_provisioning_enabled},
};
use futures_util::{StreamExt, stream};
use serde::Serialize;
use shared::{
    ApiError, GetState, State,
    models::{
        BaseModel,
        server::{GetServer, GetServerActivityLogger},
        user::GetPermissionManager,
    },
    response::{ApiResponse, ApiResponseResult},
};
use std::collections::{BTreeMap, BTreeSet};
use utoipa::ToSchema;
use utoipa_axum::{router::OpenApiRouter, routes};

mod database;
mod shared_pools;

#[derive(Serialize, ToSchema)]
struct DeploymentNodeStatus {
    node_uuid: uuid::Uuid,
    api_url: String,
    api_version: Option<String>,
    deployment_policy: crate::domain::NodeDeploymentPolicy,
    deployment_capabilities: serde_json::Value,
    error: Option<String>,
}

#[derive(Serialize, ToSchema)]
struct ListResponse {
    provider_available: bool,
    provisioning_enabled: bool,
    provisioning_block_reason: Option<String>,
    protocols: Vec<DatabaseProtocol>,
    available_deployment_modes: Vec<DeploymentMode>,
    protocol_deployment_modes: BTreeMap<String, Vec<DeploymentMode>>,
    deployment_nodes: Vec<DeploymentNodeStatus>,
    shared_node_pins: BTreeMap<String, uuid::Uuid>,
    shared_pool_ids: BTreeMap<String, String>,
    database_limit: i32,
    database_usage: i64,
    max_dedicated_databases: i32,
    max_shared_databases: i32,
    dedicated_database_usage: i64,
    shared_database_usage: i64,
    database_cpu_cores: Option<f64>,
    database_memory_mib: Option<i64>,
    database_disk_mib: Option<i64>,
    database_backup_limit: i32,
    image_options: BTreeMap<String, Vec<String>>,
    placement_defaults: BTreeMap<String, ResourceLimits>,
    databases: Vec<DatabaseRecordApi>,
}

#[utoipa::path(get, path = "/", responses(
    (status = OK, body = inline(ListResponse)),
    (status = CONFLICT, body = ApiError),
))]
async fn get(
    state: GetState,
    permissions: GetPermissionManager,
    server: GetServer,
) -> ApiResponseResult {
    permissions.has_server_permission("databases-everywhere.read")?;
    let configuration = server.parse_model_extension::<ServerDatabaseConfigurationExtension>()?;
    let extension_enabled = extension_provisioning_enabled(&state).await?;
    let panel_node = server.node.fetch_cached(&state.database).await?;
    let availability =
        HostAssignment::availability(&state, panel_node.uuid, panel_node.location.uuid).await?;
    let mut image_sets = BTreeMap::<String, BTreeSet<String>>::new();
    let mut protocol_mode_sets = BTreeMap::<String, BTreeSet<DeploymentMode>>::new();
    let mut placement_defaults = BTreeMap::<String, ResourceLimits>::new();
    let mut provisioning_block_reason = None;
    let shared_pool_mappings = crate::persistence::SharedPool::list(&state, server.uuid).await?;
    let shared_node_pins = shared_pool_mappings
        .iter()
        .map(|pool| (pool.protocol.as_str().to_owned(), pool.node_uuid))
        .collect::<BTreeMap<_, _>>();
    let shared_pool_ids = shared_pool_mappings
        .iter()
        .filter_map(|pool| {
            pool.runtime_id
                .as_ref()
                .map(|runtime_id| (pool.protocol.as_str().to_owned(), runtime_id.clone()))
        })
        .collect::<BTreeMap<_, _>>();
    let eligible_hosts =
        HostAssignment::eligible_for_panel_node(&state, panel_node.uuid, panel_node.location.uuid)
            .await?;
    let has_enabled_host = !eligible_hosts.is_empty();
    let mut deployment_nodes = Vec::new();
    // Preserve assignment priority while refreshing only this server's assigned nodes.
    let mut snapshots = stream::iter(eligible_hosts)
        .map(|mut eligible| {
            let state = &state;
            async move {
                let result = async {
                    DbevClient::for_node(state, &eligible.host)
                        .await?
                        .system()
                        .await
                }
                .await;
                let error = result.as_ref().err().map(ToString::to_string);
                // Never merge a new snapshot with old capabilities, including on failure.
                eligible.host.cached_system = result.ok();
                let error = error.or_else(|| node_provisioning_block_reason(&eligible.host));
                eligible
                    .host
                    .store_health(
                        state,
                        eligible.host.cached_system.as_ref(),
                        None,
                        error.as_deref(),
                    )
                    .await?;
                Ok::<_, anyhow::Error>((eligible, error))
            }
        })
        .buffered(4);
    while let Some(snapshot) = snapshots.next().await {
        let (eligible, error) = snapshot?;
        let system = eligible
            .host
            .cached_system
            .as_ref()
            .unwrap_or(&serde_json::Value::Null);
        deployment_nodes.push(DeploymentNodeStatus {
            node_uuid: eligible.host.uuid,
            api_url: eligible.host.api_url.clone(),
            api_version: system
                .get("api_version")
                .and_then(serde_json::Value::as_str)
                .map(str::to_owned),
            deployment_policy: eligible.host.deployment_policy,
            deployment_capabilities: system
                .get("deployment_capabilities")
                .cloned()
                .unwrap_or(serde_json::Value::Null),
            error: error.clone(),
        });
        if let Some(reason) = error {
            provisioning_block_reason.get_or_insert(reason);
            continue;
        }
        let capabilities = eligible
            .host
            .cached_system
            .as_ref()
            .map(DbevCapabilities::from_system)
            .unwrap_or_else(|| DbevCapabilities::from_system(&serde_json::Value::Null));
        for protocol in DatabaseProtocol::ALL {
            if eligible
                .host
                .deployment_policy
                .allows(DeploymentMode::Shared)
                && !capabilities.supports_private_shared(protocol)
                && (capabilities.supports_deployment(protocol, DeploymentMode::Dedicated)
                    || capabilities.supports_deployment(protocol, DeploymentMode::Shared))
            {
                provisioning_block_reason.get_or_insert_with(|| {
                    crate::dbev::private_shared_block_reason(
                        system,
                        protocol,
                        &eligible.host.api_url,
                    )
                });
            }
            for mode in DeploymentMode::ALL {
                if !eligible.host.deployment_policy.allows(mode)
                    || !capabilities.supports_placement(protocol, mode)
                    || (mode == DeploymentMode::Shared
                        && shared_node_pins
                            .get(protocol.as_str())
                            .is_some_and(|node| *node != eligible.host.uuid))
                {
                    continue;
                }
                protocol_mode_sets
                    .entry(protocol.as_str().to_owned())
                    .or_default()
                    .insert(mode);
                image_sets
                    .entry(protocol.as_str().to_owned())
                    .or_default()
                    .extend(eligible.host.allowed_images(protocol));
                placement_defaults
                    .entry(format!("{}:{}", mode.as_str(), protocol.as_str()))
                    .or_insert_with(|| {
                        ResourceLimits {
                            cpu_cores: configuration
                                .cpu_cores
                                .unwrap_or(eligible.host.default_cpu_cores),
                            memory_mib: configuration
                                .memory_mib
                                .unwrap_or(eligible.host.default_memory_mib),
                            disk_mib: configuration
                                .disk_mib
                                .unwrap_or(eligible.host.default_disk_mib),
                        }
                        .with_protocol_floors(protocol)
                    });
            }
        }
    }
    let image_options = image_sets
        .into_iter()
        .map(|(protocol, images)| (protocol, images.into_iter().collect()))
        .collect::<BTreeMap<_, _>>();
    let protocol_deployment_modes = protocol_mode_sets
        .into_iter()
        .map(|(protocol, modes)| (protocol, modes.into_iter().collect::<Vec<_>>()))
        .collect::<BTreeMap<_, _>>();
    let protocols = DatabaseProtocol::ALL
        .into_iter()
        .filter(|protocol| protocol_deployment_modes.contains_key(protocol.as_str()))
        .collect::<Vec<_>>();
    let available_deployment_modes = DeploymentMode::ALL
        .into_iter()
        .filter(|mode| {
            protocol_deployment_modes
                .values()
                .any(|modes| modes.contains(mode))
        })
        .collect::<Vec<_>>();
    let include_password = permissions
        .has_server_permission("databases-everywhere.credentials")
        .is_ok();
    let mut databases = Vec::new();
    for database in DatabaseRecord::all_for_server(&state, server.uuid).await? {
        databases.push(database.into_api(&state, include_password).await?);
    }
    let provisioning_enabled = has_enabled_host
        && extension_enabled
        && !protocols.is_empty()
        && !available_deployment_modes.is_empty();
    if provisioning_enabled {
        provisioning_block_reason = None;
    }
    if !extension_enabled {
        provisioning_block_reason = Some(
            "DatabasesEverywhere provisioning is disabled by the panel administrator.".to_owned(),
        );
    } else if !has_enabled_host {
        provisioning_block_reason = Some(
            "No DatabasesEverywhere host is assigned to this server's node or location.".to_owned(),
        );
    } else if protocols.is_empty() && provisioning_block_reason.is_none() {
        provisioning_block_reason = Some(
            "No database protocol is currently enabled on a ready DatabasesEverywhere node."
                .to_owned(),
        );
    }
    let dedicated_database_usage =
        DatabaseRecord::placement_usage(&state, server.uuid, DeploymentMode::Dedicated).await?;
    let shared_database_usage =
        DatabaseRecord::placement_usage(&state, server.uuid, DeploymentMode::Shared).await?;
    ApiResponse::new_serialized(ListResponse {
        provider_available: availability.available,
        provisioning_enabled,
        provisioning_block_reason,
        protocols,
        available_deployment_modes,
        protocol_deployment_modes,
        deployment_nodes,
        shared_node_pins,
        shared_pool_ids,
        database_limit: configuration
            .max_dedicated_databases
            .saturating_add(configuration.max_shared_databases),
        database_usage: dedicated_database_usage.saturating_add(shared_database_usage),
        max_dedicated_databases: configuration.max_dedicated_databases,
        max_shared_databases: configuration.max_shared_databases,
        dedicated_database_usage,
        shared_database_usage,
        database_cpu_cores: configuration.cpu_cores,
        database_memory_mib: configuration.memory_mib,
        database_disk_mib: configuration.disk_mib,
        database_backup_limit: configuration.backup_limit,
        image_options,
        placement_defaults,
        databases,
    })
    .ok()
}

fn node_provisioning_block_reason(node: &crate::persistence::NodeRecord) -> Option<String> {
    if let Some(reason) = mutation_contract_block_reason(node.cached_system.as_ref()) {
        return Some(reason);
    }
    let gateways = node.cached_system.as_ref()?.get("gateways")?;
    match gateways.get("status").and_then(serde_json::Value::as_str) {
        Some("ready") => None,
        Some("starting" | "stopping") => Some(
            "The DBEV management API is ready, but database listeners are still starting."
                .to_owned(),
        ),
        Some("failed") => Some(format!(
            "DBEV is running, but one or more database gateways failed: {}",
            gateways
                .get("failure")
                .and_then(serde_json::Value::as_str)
                .filter(|failure| !failure.trim().is_empty())
                .unwrap_or("the daemon did not report a listener failure reason")
        )),
        _ => Some(
            "The DBEV management API is ready, but database listener readiness is unavailable."
                .to_owned(),
        ),
    }
}

#[derive(Serialize, ToSchema)]
struct CreateResponse {
    database: DatabaseRecordApi,
}

#[utoipa::path(post, path = "/", request_body = CreateDatabaseInput, responses(
    (status = ACCEPTED, body = inline(CreateResponse)),
    (status = BAD_REQUEST, body = ApiError),
    (status = CONFLICT, body = ApiError),
    (status = EXPECTATION_FAILED, body = ApiError),
))]
async fn post(
    state: GetState,
    permissions: GetPermissionManager,
    server: GetServer,
    activity_logger: GetServerActivityLogger,
    shared::Payload(data): shared::Payload<CreateDatabaseInput>,
) -> ApiResponseResult {
    permissions.has_server_permission("databases-everywhere.create")?;
    let database = create_database(&state, &server, data).await?;
    activity_logger
        .log(
            "server:databases-everywhere.create",
            serde_json::json!({
                "uuid": database.uuid,
                "node_uuid": database.dbev_node_uuid,
                "protocol": database.protocol,
                "deployment_mode": database.deployment_mode,
                "runtime_id": database.runtime_id,
                "name": database.display_name,
                "limits": database.limits(),
            }),
        )
        .await;
    let include_password = permissions
        .has_server_permission("databases-everywhere.credentials")
        .is_ok();
    Ok(ApiResponse::new_serialized(CreateResponse {
        database: database.into_api(&state, include_password).await?,
    })
    .with_status(axum::http::StatusCode::ACCEPTED))
}

pub fn router(state: &State) -> OpenApiRouter<State> {
    OpenApiRouter::new()
        .nest("/{database}", database::router(state))
        .routes(routes!(get))
        .routes(routes!(post))
        .merge(shared_pools::router(state))
        .with_state(state.clone())
}
