use crate::domain::NodeDeploymentPolicy;
use crate::persistence::{
    GeneratedNodeCredentials, NodeConfigurationSecretsPatch, NodeRecord, NodeRecordApi, PoolLimits,
    validate_daemon_api_url,
};
use serde::{Deserialize, Serialize};
use shared::{
    ApiError, GetState, State,
    models::{admin_activity::GetAdminActivityLogger, user::GetPermissionManager},
    response::{ApiResponse, ApiResponseResult, DisplayError},
};
use std::net::{IpAddr, SocketAddr};
use utoipa::ToSchema;
use utoipa_axum::{router::OpenApiRouter, routes};

mod assignments;
mod image_registry;
mod node;
mod settings;

#[derive(Serialize, ToSchema)]
struct ListResponse {
    nodes: Vec<NodeRecordApi>,
}

#[utoipa::path(get, path = "/", responses((status = OK, body = inline(ListResponse))))]
async fn get(state: GetState, permissions: GetPermissionManager) -> ApiResponseResult {
    permissions.has_admin_permission("databases-everywhere-nodes.read")?;
    ApiResponse::new_serialized(ListResponse {
        nodes: NodeRecord::all(&state)
            .await?
            .into_iter()
            .map(NodeRecord::into_api)
            .collect(),
    })
    .ok()
}

#[derive(Deserialize, ToSchema)]
struct CreatePayload {
    name: String,
    enabled: Option<bool>,
    deployment_policy: Option<NodeDeploymentPolicy>,
    api_url: String,
    public_host: String,
    default_cpu_cores: Option<f64>,
    default_memory_mib: Option<i64>,
    default_disk_mib: Option<i64>,
    default_pool_limits: Option<PoolLimits>,
    #[schema(value_type = Option<serde_json::Value>)]
    configuration: Option<serde_json::Value>,
    configuration_secrets: Option<NodeConfigurationSecretsPatch>,
}

#[derive(Serialize, ToSchema)]
struct CreateResponse {
    node: NodeRecordApi,
    credentials: GeneratedNodeCredentials,
}

#[utoipa::path(post, path = "/", request_body = inline(CreatePayload), responses(
    (status = OK, body = inline(CreateResponse)),
    (status = BAD_REQUEST, body = ApiError),
    (status = CONFLICT, body = ApiError),
))]
async fn post(
    state: GetState,
    permissions: GetPermissionManager,
    activity_logger: GetAdminActivityLogger,
    shared::Payload(data): shared::Payload<CreatePayload>,
) -> ApiResponseResult {
    permissions.has_admin_permission("databases-everywhere-nodes.create")?;
    let public_host = normalize_public_database_host(&data.public_host)?;
    validate_name_and_endpoint(&data.name, &data.api_url, &public_host)?;
    let cpu = data.default_cpu_cores.unwrap_or(0.5);
    let memory = data.default_memory_mib.unwrap_or(512);
    let disk = data.default_disk_mib.unwrap_or(1024);
    validate_defaults(cpu, memory, disk)?;
    let pool_defaults = data.default_pool_limits.unwrap_or_default();
    if let Err(errors) = shared::utils::validate_data(&pool_defaults) {
        return ApiResponse::new_serialized(ApiError::new_strings_value(errors))
            .with_status(axum::http::StatusCode::BAD_REQUEST)
            .ok();
    }
    let configuration = data.configuration.unwrap_or_else(|| serde_json::json!({}));
    let panel_url = panel_url(&state).await?;
    let (node, credentials) = NodeRecord::create(
        &state,
        data.name.trim(),
        data.enabled.unwrap_or(true),
        data.deployment_policy.unwrap_or_default(),
        data.api_url.trim_end_matches('/'),
        &public_host,
        cpu,
        memory,
        disk,
        pool_defaults,
        configuration,
        data.configuration_secrets,
        &panel_url,
    )
    .await?;
    activity_logger
        .log(
            "databases-everywhere-node:create",
            serde_json::json!({
                "uuid": node.uuid,
                "name": node.name,
                "enabled": node.enabled,
                "deployment_policy": node.deployment_policy,
                "api_url": node.api_url,
                "public_host": node.public_host,
                "default_pool_limits": node.default_pool_limits,
            }),
        )
        .await;
    ApiResponse::new_serialized(CreateResponse {
        node: node.into_api(),
        credentials,
    })
    .ok()
}

pub fn router(state: &State) -> OpenApiRouter<State> {
    OpenApiRouter::new()
        .nest("/assignments", assignments::router(state))
        .nest("/image-registry", image_registry::router(state))
        .nest("/settings", settings::router(state))
        .nest("/{dbev_node}", node::router(state))
        .routes(routes!(get))
        .routes(routes!(post))
        .with_state(state.clone())
}

pub(super) async fn panel_url(state: &State) -> Result<String, anyhow::Error> {
    let settings = state.settings.get().await?;
    let extension = settings.get_extension_settings::<crate::settings::ExtensionSettingsData>(
        "com.tomaxikz.databaseseverywhere",
    )?;
    Ok(if extension.panel_url.trim().is_empty() {
        settings.app.url.trim_end_matches('/').to_owned()
    } else {
        extension.panel_url.trim_end_matches('/').to_owned()
    })
}

pub(super) fn validate_defaults(cpu: f64, memory: i64, disk: i64) -> Result<(), anyhow::Error> {
    if !cpu.is_finite() || !(0.01..=1024.0).contains(&cpu) {
        return Err(DisplayError::new("default CPU must be between 0.01 and 1024 cores").into());
    }
    if !(1..=1_048_576).contains(&memory) {
        return Err(DisplayError::new("default memory must be between 1 and 1048576 MiB").into());
    }
    if disk < 1 {
        return Err(DisplayError::new("default disk must be at least 1 MiB").into());
    }
    Ok(())
}

pub(super) fn validate_name_and_endpoint(
    name: &str,
    api_url: &str,
    public_host: &str,
) -> Result<(), anyhow::Error> {
    if name.trim().is_empty() || name.chars().count() > 191 {
        return Err(DisplayError::new("node name must contain 1 to 191 characters").into());
    }
    validate_daemon_api_url(api_url)?;
    if public_host.trim().is_empty()
        || public_host.len() > 253
        || public_host.chars().any(char::is_whitespace)
        || public_host.contains('/')
    {
        return Err(DisplayError::new("invalid public database host").into());
    }
    Ok(())
}

pub(super) fn normalize_public_database_host(value: &str) -> Result<String, anyhow::Error> {
    let value = value.trim();
    if let Ok(address) = value.parse::<IpAddr>() {
        return Ok(address.to_string());
    }
    if let Ok(address) = value.parse::<SocketAddr>() {
        return Ok(address.ip().to_string());
    }
    if let Some(address) = value
        .strip_prefix('[')
        .and_then(|value| value.strip_suffix(']'))
        && let Ok(address) = address.parse::<IpAddr>()
    {
        return Ok(address.to_string());
    }

    let host = value
        .rsplit_once(':')
        .filter(|(host, port)| !host.contains(':') && port.parse::<u16>().is_ok())
        .map_or(value, |(host, _)| host);
    if host.is_empty()
        || host.len() > 253
        || host.chars().any(char::is_whitespace)
        || host
            .chars()
            .any(|character| matches!(character, '/' | ':' | '\\'))
    {
        return Err(DisplayError::new(
            "public database host must be a hostname or IP address without a port",
        )
        .into());
    }

    Ok(host.to_owned())
}

#[cfg(test)]
mod tests {
    use super::normalize_public_database_host;

    #[test]
    fn normalizes_legacy_public_database_hosts() {
        for (input, expected) in [
            ("192.144.78.101:8090", "192.144.78.101"),
            ("db.example.com:8090", "db.example.com"),
            ("[2001:db8::10]:8090", "2001:db8::10"),
            ("2001:db8::10", "2001:db8::10"),
        ] {
            assert_eq!(normalize_public_database_host(input).unwrap(), expected);
        }
    }
}
