use axum::{Extension, extract::Path};
use garde::Validate;
use serde::Deserialize;
use shared::{
    ApiError, GetState, State,
    models::{admin_activity::GetAdminActivityLogger, user::GetPermissionManager},
    response::{ApiResponse, ApiResponseResult},
};
use utoipa::ToSchema;
use utoipa_axum::{router::OpenApiRouter, routes};

use crate::{
    persistence::{NodeRecord, PoolLimits},
    services::pools::load_owned_pool_on_node,
};

#[derive(Deserialize, ToSchema, Validate)]
#[serde(deny_unknown_fields)]
struct Input {
    #[garde(range(min = 0.01, max = 1024.0))]
    cpu_cores: f64,
    #[garde(range(min = 1, max = 1_048_576))]
    memory_mib: i64,
    #[garde(range(min = 1, max = 9_007_199_254_740_991))]
    disk_mib: i64,
    #[garde(range(min = 1, max = 1024))]
    max_tenants: i32,
}

#[utoipa::path(patch, path = "/pools/{runtime_id}", params(
        ("runtime_id" = String, Path, description = "Physical shared-pool runtime ID"),
    ), request_body = Input,
    responses((status = OK, body = serde_json::Value), (status = CONFLICT, body = ApiError)))]
async fn resize(
    state: GetState,
    permissions: GetPermissionManager,
    activity: GetAdminActivityLogger,
    Extension(node): Extension<NodeRecord>,
    Path((_dbev_node, runtime_id)): Path<(String, String)>,
    shared::Payload(input): shared::Payload<Input>,
) -> ApiResponseResult {
    permissions.has_admin_permission("databases-everywhere-nodes.operations")?;
    permissions.has_admin_permission("databases-everywhere-nodes.update")?;
    if let Err(errors) = shared::utils::validate_data(&input) {
        return ApiResponse::new_serialized(ApiError::new_strings_value(errors))
            .with_status(axum::http::StatusCode::BAD_REQUEST)
            .ok();
    }
    let mut owned = load_owned_pool_on_node(&state, node.uuid, &runtime_id).await?;
    let before = owned.mapping.limits;
    let limits = PoolLimits {
        cpu_cores: input.cpu_cores,
        memory_mib: input.memory_mib,
        disk_mib: input.disk_mib,
        max_tenants: input.max_tenants,
    };
    let route = format!("/api/pools/{}", urlencoding::encode(&runtime_id));
    let remote = owned
        .client
        .patch::<serde_json::Value, _>(&route, &limits)
        .await?;
    owned
        .mapping
        .verify_configuration(&remote, &owned.panel_id, limits)?;
    owned.mapping.save_limits(&state, limits).await?;
    activity
        .log(
            "databases-everywhere-node:pool.resize",
            serde_json::json!({"runtime_id": runtime_id, "before": before, "after": limits}),
        )
        .await;
    ApiResponse::new_serialized(remote).ok()
}

pub fn router(state: &State) -> OpenApiRouter<State> {
    OpenApiRouter::new()
        .routes(routes!(resize))
        .with_state(state.clone())
}
