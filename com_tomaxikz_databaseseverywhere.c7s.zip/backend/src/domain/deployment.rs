use super::DatabaseProtocol;
use serde::{Deserialize, Serialize};
use std::{fmt::Display, str::FromStr};
use utoipa::ToSchema;

#[derive(
    Debug,
    Clone,
    Copy,
    Default,
    PartialEq,
    Eq,
    PartialOrd,
    Ord,
    Hash,
    Serialize,
    Deserialize,
    ToSchema,
)]
#[serde(rename_all = "snake_case")]
pub enum NodeDeploymentPolicy {
    #[default]
    DedicatedOnly,
    SharedOnly,
    Hybrid,
}

impl NodeDeploymentPolicy {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::DedicatedOnly => "dedicated_only",
            Self::SharedOnly => "shared_only",
            Self::Hybrid => "hybrid",
        }
    }

    pub const fn allows(self, mode: DeploymentMode) -> bool {
        matches!(
            (self, mode),
            (Self::DedicatedOnly, DeploymentMode::Dedicated)
                | (Self::SharedOnly, DeploymentMode::Shared)
                | (Self::Hybrid, _)
        )
    }
}

impl Display for NodeDeploymentPolicy {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str(self.as_str())
    }
}

impl FromStr for NodeDeploymentPolicy {
    type Err = anyhow::Error;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        match value {
            "dedicated_only" => Ok(Self::DedicatedOnly),
            "shared_only" => Ok(Self::SharedOnly),
            "hybrid" => Ok(Self::Hybrid),
            _ => Err(anyhow::anyhow!(
                "unsupported DatabasesEverywhere node deployment policy"
            )),
        }
    }
}

#[derive(
    Debug,
    Clone,
    Copy,
    Default,
    PartialEq,
    Eq,
    PartialOrd,
    Ord,
    Hash,
    Serialize,
    Deserialize,
    ToSchema,
)]
#[serde(rename_all = "lowercase")]
pub enum DeploymentMode {
    #[default]
    Dedicated,
    Shared,
}

impl DeploymentMode {
    pub const ALL: [Self; 2] = [Self::Dedicated, Self::Shared];

    pub const fn supports(self, protocol: DatabaseProtocol) -> bool {
        match self {
            Self::Dedicated => true,
            Self::Shared => matches!(
                protocol,
                DatabaseProtocol::Postgres
                    | DatabaseProtocol::Mysql
                    | DatabaseProtocol::Mariadb
                    | DatabaseProtocol::Mongodb
                    | DatabaseProtocol::Clickhouse
            ),
        }
    }

    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Dedicated => "dedicated",
            Self::Shared => "shared",
        }
    }
}

impl Display for DeploymentMode {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str(self.as_str())
    }
}

impl FromStr for DeploymentMode {
    type Err = anyhow::Error;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        match value {
            "dedicated" => Ok(Self::Dedicated),
            "shared" => Ok(Self::Shared),
            _ => Err(anyhow::anyhow!(
                "unsupported DatabasesEverywhere deployment mode"
            )),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{DeploymentMode, NodeDeploymentPolicy};

    #[test]
    fn policies_allow_only_their_configured_placements() {
        assert!(NodeDeploymentPolicy::DedicatedOnly.allows(DeploymentMode::Dedicated));
        assert!(!NodeDeploymentPolicy::DedicatedOnly.allows(DeploymentMode::Shared));
        assert!(!NodeDeploymentPolicy::SharedOnly.allows(DeploymentMode::Dedicated));
        assert!(NodeDeploymentPolicy::SharedOnly.allows(DeploymentMode::Shared));
        assert!(NodeDeploymentPolicy::Hybrid.allows(DeploymentMode::Dedicated));
        assert!(NodeDeploymentPolicy::Hybrid.allows(DeploymentMode::Shared));
    }
}
