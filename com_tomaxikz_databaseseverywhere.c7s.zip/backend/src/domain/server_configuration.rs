use crate::persistence::{
    HostAssignment, LOCATION_HOSTS_TABLE, PANEL_NODE_HOSTS_TABLE, PoolLimits,
};
use compact_str::CompactString;
use garde::Validate;
use serde::{Deserialize, Serialize};
use shared::{
    Extendible,
    models::{
        BaseModel, CreatableModel, DeletableModel, ListenerPriority, ModelExtension,
        ModelExtensionMapType, SafeModelExtension, UpdatableModel,
        server::{ApiServerFeatureLimits, Server},
    },
};
use sqlx::{Row, postgres::PgRow};
use std::collections::BTreeMap;
use utoipa::ToSchema;

const EXTENSION_NAME: &str = "com.tomaxikz.databaseseverywhere";
const DATABASES_TABLE: &str = "com_tomaxikz_databaseseverywhere_databases";
const OPERATIONS_TABLE: &str = "com_tomaxikz_databaseseverywhere_operations";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServerDatabaseConfiguration {
    pub cpu_cores: Option<f64>,
    pub memory_mib: Option<i64>,
    pub disk_mib: Option<i64>,
    pub backup_limit: i32,
    pub max_dedicated_databases: i32,
    pub max_shared_databases: i32,
    #[serde(default)]
    pub pool_use_node_defaults: bool,
    #[serde(default = "default_pool_cpu")]
    pub pool_cpu_cores: f64,
    #[serde(default = "default_pool_memory")]
    pub pool_memory_mib: i64,
    #[serde(default = "default_pool_disk")]
    pub pool_disk_mib: i64,
    #[serde(default = "default_pool_count")]
    pub pool_max_databases: i32,
}

fn default_pool_cpu() -> f64 {
    PoolLimits::default().cpu_cores
}
fn default_pool_memory() -> i64 {
    PoolLimits::default().memory_mib
}
fn default_pool_disk() -> i64 {
    PoolLimits::default().disk_mib
}
fn default_pool_count() -> i32 {
    PoolLimits::default().max_tenants
}

impl ServerDatabaseConfiguration {
    pub fn pool_limits(&self, node_defaults: PoolLimits) -> PoolLimits {
        if self.pool_use_node_defaults {
            node_defaults
        } else {
            PoolLimits {
                cpu_cores: self.pool_cpu_cores,
                memory_mib: self.pool_memory_mib,
                disk_mib: self.pool_disk_mib,
                max_tenants: self.pool_max_databases,
            }
        }
    }
}

pub struct ServerDatabaseConfigurationExtension;

impl SafeModelExtension for ServerDatabaseConfigurationExtension {
    type Value = ServerDatabaseConfiguration;

    fn name() -> &'static str {
        EXTENSION_NAME
    }
}

impl ModelExtension for ServerDatabaseConfigurationExtension {
    fn extension_name(&self) -> &'static str {
        EXTENSION_NAME
    }

    fn extended_columns(&self, prefix: &str) -> BTreeMap<&'static str, CompactString> {
        BTreeMap::from([
            (
                "servers.dbev_pool_use_node_defaults",
                compact_str::format_compact!("{prefix}dbev_pool_use_node_defaults"),
            ),
            (
                "servers.dbev_pool_cpu_cores",
                compact_str::format_compact!("{prefix}dbev_pool_cpu_cores"),
            ),
            (
                "servers.dbev_pool_memory_mib",
                compact_str::format_compact!("{prefix}dbev_pool_memory_mib"),
            ),
            (
                "servers.dbev_pool_disk_mib",
                compact_str::format_compact!("{prefix}dbev_pool_disk_mib"),
            ),
            (
                "servers.dbev_pool_max_databases",
                compact_str::format_compact!("{prefix}dbev_pool_max_databases"),
            ),
            (
                "servers.dbev_database_cpu_cores",
                compact_str::format_compact!("{prefix}dbev_database_cpu_cores"),
            ),
            (
                "servers.dbev_database_memory_mib",
                compact_str::format_compact!("{prefix}dbev_database_memory_mib"),
            ),
            (
                "servers.dbev_database_disk_mib",
                compact_str::format_compact!("{prefix}dbev_database_disk_mib"),
            ),
            (
                "servers.dbev_database_backup_limit",
                compact_str::format_compact!("{prefix}dbev_database_backup_limit"),
            ),
            (
                "servers.dbev_max_dedicated_databases",
                compact_str::format_compact!("{prefix}dbev_max_dedicated_databases"),
            ),
            (
                "servers.dbev_max_shared_databases",
                compact_str::format_compact!("{prefix}dbev_max_shared_databases"),
            ),
        ])
    }

    fn map_extended(
        &self,
        prefix: &str,
        row: &PgRow,
    ) -> Result<ModelExtensionMapType, shared::database::DatabaseError> {
        Ok(Box::new(ServerDatabaseConfiguration {
            pool_use_node_defaults: row.try_get(
                compact_str::format_compact!("{prefix}dbev_pool_use_node_defaults").as_str(),
            )?,
            pool_cpu_cores: row
                .try_get(compact_str::format_compact!("{prefix}dbev_pool_cpu_cores").as_str())?,
            pool_memory_mib: row
                .try_get(compact_str::format_compact!("{prefix}dbev_pool_memory_mib").as_str())?,
            pool_disk_mib: row
                .try_get(compact_str::format_compact!("{prefix}dbev_pool_disk_mib").as_str())?,
            pool_max_databases: row.try_get(
                compact_str::format_compact!("{prefix}dbev_pool_max_databases").as_str(),
            )?,
            cpu_cores: row.try_get(
                compact_str::format_compact!("{prefix}dbev_database_cpu_cores").as_str(),
            )?,
            memory_mib: row.try_get(
                compact_str::format_compact!("{prefix}dbev_database_memory_mib").as_str(),
            )?,
            disk_mib: row
                .try_get(compact_str::format_compact!("{prefix}dbev_database_disk_mib").as_str())?,
            backup_limit: row.try_get(
                compact_str::format_compact!("{prefix}dbev_database_backup_limit").as_str(),
            )?,
            max_dedicated_databases: row.try_get(
                compact_str::format_compact!("{prefix}dbev_max_dedicated_databases").as_str(),
            )?,
            max_shared_databases: row.try_get(
                compact_str::format_compact!("{prefix}dbev_max_shared_databases").as_str(),
            )?,
        }))
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema, Validate)]
pub struct ExtendedServerDatabaseLimits {
    #[garde(skip)]
    pub pool_use_node_defaults: Option<bool>,
    #[garde(range(min = 0.01, max = 1024.0))]
    pub pool_cpu_cores: Option<f64>,
    #[garde(range(min = 1, max = 1048576))]
    pub pool_memory_mib: Option<i64>,
    #[garde(range(min = 1, max = 9007199254740991))]
    pub pool_disk_mib: Option<i64>,
    #[garde(range(min = 1, max = 1024))]
    pub pool_max_databases: Option<i32>,
    #[garde(skip)]
    pub databases_everywhere_available: Option<bool>,
    #[garde(skip)]
    pub databases_everywhere_in_use: Option<bool>,
    #[garde(range(min = 0.0, max = 1024.0))]
    #[schema(minimum = 0, maximum = 1024)]
    pub database_cpu_cores: Option<f64>,
    #[garde(range(min = 0, max = 1048576))]
    #[schema(minimum = 0, maximum = 1048576)]
    pub database_memory_mib: Option<i64>,
    #[garde(range(min = 0))]
    #[schema(minimum = 0)]
    pub database_disk_mib: Option<i64>,
    #[garde(range(min = 0))]
    #[schema(minimum = 0)]
    pub database_backups: Option<i32>,
    #[garde(range(min = 0))]
    #[schema(minimum = 0)]
    pub max_dedicated_databases: Option<i32>,
    #[garde(range(min = 0))]
    #[schema(minimum = 0)]
    pub max_shared_databases: Option<i32>,
}

impl ExtendedServerDatabaseLimits {
    fn has_pool_override(&self) -> bool {
        self.pool_cpu_cores.is_some()
            || self.pool_memory_mib.is_some()
            || self.pool_disk_mib.is_some()
            || self.pool_max_databases.is_some()
    }

    fn pool_inheritance_update(&self) -> Option<bool> {
        self.pool_use_node_defaults
            .or_else(|| self.has_pool_override().then_some(false))
    }
}

fn normalized_f64(value: Option<f64>) -> Option<f64> {
    value.filter(|value| *value > 0.0)
}

fn normalized_i64(value: Option<i64>) -> Option<i64> {
    value.filter(|value| *value > 0)
}

async fn may_configure_databases_everywhere(
    transaction: &mut sqlx::Transaction<'_, sqlx::Postgres>,
    panel_node_uuid: uuid::Uuid,
    server_uuid: Option<uuid::Uuid>,
) -> Result<bool, sqlx::Error> {
    sqlx::query_scalar::<_, bool>(sqlx::AssertSqlSafe(format!(
        r#"
        SELECT EXISTS (
            SELECT 1
            FROM nodes AS panel_node
            WHERE panel_node.uuid = $1
              AND (
                EXISTS (
                    SELECT 1 FROM {PANEL_NODE_HOSTS_TABLE} AS assignment
                    WHERE assignment.node_uuid = panel_node.uuid
                )
                OR EXISTS (
                    SELECT 1 FROM {LOCATION_HOSTS_TABLE} AS assignment
                    WHERE assignment.location_uuid = panel_node.location_uuid
                )
              )
        ) OR (
            $2::uuid IS NOT NULL
            AND EXISTS (SELECT 1 FROM {DATABASES_TABLE} WHERE server_uuid = $2)
        )
        "#
    )))
    .bind(panel_node_uuid)
    .bind(server_uuid)
    .fetch_one(&mut **transaction)
    .await
}

pub fn register_server_integration() {
    Server::register_model_extension(ServerDatabaseConfigurationExtension);

    Server::register_create_handler(
        ListenerPriority::Normal,
        |options, query_builder, _state, transaction| {
            Box::pin(async move {
                let extended = options
                    .feature_limits
                    .parse_extended::<ExtendedServerDatabaseLimits>()
                    .ok();
                let configurable =
                    may_configure_databases_everywhere(transaction, options.node_uuid, None)
                        .await?;

                query_builder
                    .set(
                        "dbev_pool_use_node_defaults",
                        extended
                            .as_ref()
                            .and_then(|value| value.pool_inheritance_update())
                            .unwrap_or(true),
                    )
                    .set(
                        "dbev_pool_cpu_cores",
                        extended
                            .as_ref()
                            .and_then(|value| value.pool_cpu_cores)
                            .unwrap_or_else(default_pool_cpu),
                    )
                    .set(
                        "dbev_pool_memory_mib",
                        extended
                            .as_ref()
                            .and_then(|value| value.pool_memory_mib)
                            .unwrap_or_else(default_pool_memory),
                    )
                    .set(
                        "dbev_pool_disk_mib",
                        extended
                            .as_ref()
                            .and_then(|value| value.pool_disk_mib)
                            .unwrap_or_else(default_pool_disk),
                    )
                    .set(
                        "dbev_pool_max_databases",
                        extended
                            .as_ref()
                            .and_then(|value| value.pool_max_databases)
                            .unwrap_or_else(default_pool_count),
                    )
                    .set(
                        "dbev_database_cpu_cores",
                        configurable
                            .then(|| {
                                normalized_f64(
                                    extended.as_ref().and_then(|value| value.database_cpu_cores),
                                )
                            })
                            .flatten(),
                    )
                    .set(
                        "dbev_database_memory_mib",
                        configurable
                            .then(|| {
                                normalized_i64(
                                    extended
                                        .as_ref()
                                        .and_then(|value| value.database_memory_mib),
                                )
                            })
                            .flatten(),
                    )
                    .set(
                        "dbev_database_disk_mib",
                        configurable
                            .then(|| {
                                normalized_i64(
                                    extended.as_ref().and_then(|value| value.database_disk_mib),
                                )
                            })
                            .flatten(),
                    )
                    .set(
                        "dbev_database_backup_limit",
                        if configurable {
                            extended
                                .as_ref()
                                .and_then(|value| value.database_backups)
                                .unwrap_or(0)
                        } else {
                            0
                        },
                    )
                    .set(
                        "dbev_max_dedicated_databases",
                        if configurable {
                            extended
                                .as_ref()
                                .and_then(|value| value.max_dedicated_databases)
                                .unwrap_or(options.feature_limits.databases)
                        } else {
                            0
                        },
                    )
                    .set(
                        "dbev_max_shared_databases",
                        if configurable {
                            extended
                                .as_ref()
                                .and_then(|value| value.max_shared_databases)
                                .unwrap_or(0)
                        } else {
                            0
                        },
                    );
                Ok(())
            })
        },
    );

    Server::register_update_handler(
        ListenerPriority::Normal,
        |server, options, query_builder, _state, transaction| {
            Box::pin(async move {
                let Some(feature_limits) = &options.feature_limits else {
                    return Ok(());
                };
                let Ok(extended) = feature_limits.parse_extended::<ExtendedServerDatabaseLimits>()
                else {
                    return Ok(());
                };
                let configurable = may_configure_databases_everywhere(
                    transaction,
                    server.node.uuid,
                    Some(server.uuid),
                )
                .await?;

                let previous =
                    server.parse_model_extension::<ServerDatabaseConfigurationExtension>()?;
                let disk_changed = extended.database_disk_mib.is_some()
                    && normalized_i64(extended.database_disk_mib) != previous.disk_mib;
                let resources_changed = disk_changed
                    || (extended.database_cpu_cores.is_some()
                        && normalized_f64(extended.database_cpu_cores) != previous.cpu_cores)
                    || (extended.database_memory_mib.is_some()
                        && normalized_i64(extended.database_memory_mib) != previous.memory_mib);

                if extended.database_cpu_cores.is_some() {
                    query_builder.set(
                        "dbev_database_cpu_cores",
                        configurable
                            .then(|| normalized_f64(extended.database_cpu_cores))
                            .flatten(),
                    );
                }
                if extended.database_memory_mib.is_some() {
                    query_builder.set(
                        "dbev_database_memory_mib",
                        configurable
                            .then(|| normalized_i64(extended.database_memory_mib))
                            .flatten(),
                    );
                }
                if extended.database_disk_mib.is_some() {
                    query_builder.set(
                        "dbev_database_disk_mib",
                        configurable
                            .then(|| normalized_i64(extended.database_disk_mib))
                            .flatten(),
                    );
                }
                if let Some(backup_limit) = extended.database_backups {
                    query_builder.set(
                        "dbev_database_backup_limit",
                        Some(if configurable { backup_limit } else { 0 }),
                    );
                }
                if let Some(maximum) = extended.max_dedicated_databases {
                    query_builder.set(
                        "dbev_max_dedicated_databases",
                        Some(if configurable { maximum } else { 0 }),
                    );
                }
                if let Some(maximum) = extended.max_shared_databases {
                    query_builder.set(
                        "dbev_max_shared_databases",
                        Some(if configurable { maximum } else { 0 }),
                    );
                }

                if let Some(value) = extended.pool_inheritance_update() {
                    query_builder.set("dbev_pool_use_node_defaults", Some(value));
                }

                if let Some(value) = extended.pool_cpu_cores {
                    query_builder.set("dbev_pool_cpu_cores", Some(value));
                }

                if let Some(value) = extended.pool_memory_mib {
                    query_builder.set("dbev_pool_memory_mib", Some(value));
                }

                if let Some(value) = extended.pool_disk_mib {
                    query_builder.set("dbev_pool_disk_mib", Some(value));
                }

                if let Some(value) = extended.pool_max_databases {
                    query_builder.set("dbev_pool_max_databases", Some(value));
                }

                if resources_changed {
                    sqlx::query(sqlx::AssertSqlSafe(format!(
                        "UPDATE {DATABASES_TABLE} SET limits_sync_pending = true, updated = now() WHERE server_uuid = $1 AND (deployment_mode = 'dedicated' OR $2)"
                    )))
                    .bind(server.uuid)
                    .bind(disk_changed)
                    .execute(&mut **transaction)
                    .await?;
                }

                Ok(())
            })
        },
    );

    Server::register_delete_handler(
        ListenerPriority::Normal,
        |server, _options, _state, transaction| {
            Box::pin(async move {
                sqlx::query(sqlx::AssertSqlSafe(format!(
                    r#"
                    INSERT INTO {OPERATIONS_TABLE}
                        (kind, dbev_node_uuid, instance_id, reason)
                    SELECT 'delete_instance', dbev_node_uuid, uuid::text, 'Calagopus server deleted'
                    FROM {DATABASES_TABLE}
                    WHERE server_uuid = $1
                    ON CONFLICT (kind, dbev_node_uuid, instance_id) DO NOTHING
                    "#,
                )))
                .bind(server.uuid)
                .execute(&mut **transaction)
                .await?;
                Ok(())
            })
        },
    );

    ApiServerFeatureLimits::extend_validated(
        |server, state| {
            Box::pin(async move {
                let configuration =
                    server.parse_model_extension::<ServerDatabaseConfigurationExtension>()?;
                let panel_node = server.node.fetch_cached(&state.database).await?;
                let availability =
                    HostAssignment::availability(state, panel_node.uuid, panel_node.location.uuid)
                        .await?;
                let in_use = sqlx::query_scalar::<_, bool>(sqlx::AssertSqlSafe(format!(
                    "SELECT EXISTS(SELECT 1 FROM {DATABASES_TABLE} WHERE server_uuid = $1)"
                )))
                .bind(server.uuid)
                .fetch_one(state.database.read())
                .await?;
                Ok(ServerDatabaseProjection {
                    configuration,
                    available: availability.available,
                    in_use,
                })
            })
        },
        |_limits, projection, _state| ExtendedServerDatabaseLimits {
            databases_everywhere_available: Some(projection.available),
            databases_everywhere_in_use: Some(projection.in_use),
            database_cpu_cores: Some(projection.configuration.cpu_cores.unwrap_or(0.0)),
            database_memory_mib: Some(projection.configuration.memory_mib.unwrap_or(0)),
            database_disk_mib: Some(projection.configuration.disk_mib.unwrap_or(0)),
            database_backups: Some(projection.configuration.backup_limit),
            max_dedicated_databases: Some(projection.configuration.max_dedicated_databases),
            max_shared_databases: Some(projection.configuration.max_shared_databases),
            pool_use_node_defaults: Some(projection.configuration.pool_use_node_defaults),
            pool_cpu_cores: Some(projection.configuration.pool_cpu_cores),
            pool_memory_mib: Some(projection.configuration.pool_memory_mib),
            pool_disk_mib: Some(projection.configuration.pool_disk_mib),
            pool_max_databases: Some(projection.configuration.pool_max_databases),
        },
    );
}

struct ServerDatabaseProjection {
    configuration: ServerDatabaseConfiguration,
    available: bool,
    in_use: bool,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn configuration() -> ServerDatabaseConfiguration {
        serde_json::from_value(serde_json::json!({
            "cpu_cores": 0.5, "memory_mib": 512, "disk_mib": 4096,
            "backup_limit": 2, "max_dedicated_databases": 4, "max_shared_databases": 8,
            "pool_cpu_cores": 3.0, "pool_memory_mib": 3072,
            "pool_disk_mib": 32768, "pool_max_databases": 12
        }))
        .unwrap()
    }

    #[test]
    fn new_pool_defaults_are_inherited_from_the_selected_node_only_when_enabled() {
        let node_defaults = PoolLimits {
            cpu_cores: 2.0,
            memory_mib: 2048,
            disk_mib: 16384,
            max_tenants: 16,
        };
        let mut server = configuration();
        let explicit = server.pool_limits(node_defaults);
        assert_eq!(explicit.cpu_cores, 3.0);
        assert_eq!(explicit.memory_mib, 3072);
        assert_eq!(explicit.disk_mib, 32768);
        assert_eq!(explicit.max_tenants, 12);
        server.pool_use_node_defaults = true;
        let saved_pool_limits = server.pool_limits(node_defaults);
        assert_eq!(saved_pool_limits, node_defaults);
        let other_node_defaults = PoolLimits {
            cpu_cores: 4.0,
            ..node_defaults
        };
        assert_eq!(server.pool_limits(other_node_defaults), other_node_defaults);
        assert_eq!(saved_pool_limits, node_defaults); // Existing allocations are snapshots.
        server.pool_use_node_defaults = false;
        assert_eq!(server.pool_limits(other_node_defaults), explicit);
        assert_eq!(server.cpu_cores, Some(0.5));
        assert_eq!(server.memory_mib, Some(512));
        assert_eq!(server.disk_mib, Some(4096));
    }

    #[test]
    fn omitted_pool_fields_preserve_updates_but_default_new_servers_to_inheritance() {
        let omitted: ExtendedServerDatabaseLimits =
            serde_json::from_value(serde_json::json!({})).unwrap();
        assert_eq!(omitted.pool_inheritance_update(), None);
        assert!(omitted.pool_inheritance_update().unwrap_or(true));
        for (input, expected) in [
            (serde_json::json!({"pool_cpu_cores": 2.0}), Some(false)),
            (
                serde_json::json!({"pool_use_node_defaults": false}),
                Some(false),
            ),
            (
                serde_json::json!({"pool_use_node_defaults": true, "pool_cpu_cores": 3.0}),
                Some(true),
            ),
        ] {
            let limits: ExtendedServerDatabaseLimits = serde_json::from_value(input).unwrap();
            assert_eq!(limits.pool_inheritance_update(), expected);
        }
    }

    #[test]
    fn legacy_cached_configuration_gets_pool_defaults_without_changing_tenant_limits() {
        let config: ServerDatabaseConfiguration = serde_json::from_value(serde_json::json!({
            "cpu_cores": 0.5, "memory_mib": 512, "disk_mib": 4096,
            "backup_limit": 2, "max_dedicated_databases": 4, "max_shared_databases": 8
        }))
        .unwrap();
        assert!(!config.pool_use_node_defaults);
        assert_eq!(config.cpu_cores, Some(0.5));
        assert_eq!(config.disk_mib, Some(4096));
        assert_eq!(config.pool_cpu_cores, default_pool_cpu());
        assert_eq!(config.pool_memory_mib, default_pool_memory());
        assert_eq!(config.pool_disk_mib, default_pool_disk());
        assert_eq!(config.pool_max_databases, default_pool_count());
    }
}
