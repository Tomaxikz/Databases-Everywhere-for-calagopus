use super::{DbevClient, client::ProbeFailure, mutation_contract_block_reason};
use axum::http::StatusCode;
use serde::Serialize;
use std::time::Instant;
use utoipa::ToSchema;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum StepId {
    Reach,
    Authenticate,
    Identity,
    Contract,
    Resources,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum StepStatus {
    Passed,
    Warning,
    Failed,
    Skipped,
}

#[derive(Debug, Serialize, ToSchema)]
pub struct CheckStep {
    pub id: StepId,
    pub status: StepStatus,
    pub message: Option<String>,
    pub hint: Option<String>,
}

#[derive(Debug, Serialize, ToSchema)]
pub struct ConnectionCheck {
    pub ok: bool,
    pub latency_ms: Option<u64>,
    pub steps: Vec<CheckStep>,
    pub mutations_allowed: bool,
    pub mutation_block_reason: Option<String>,
    #[schema(value_type = Option<serde_json::Value>)]
    pub system: Option<serde_json::Value>,
    #[schema(value_type = Option<serde_json::Value>)]
    pub resources: Option<serde_json::Value>,
}

impl ConnectionCheck {
    /// The first failure, as stored on the node record.
    pub fn failure(&self) -> Option<String> {
        self.steps
            .iter()
            .find(|step| step.status == StepStatus::Failed)
            .and_then(|step| step.message.clone())
    }
}

pub struct ExpectedIdentity<'a> {
    pub daemon_uuid: &'a str,
    pub token_id: &'a str,
}

/// Runs every step in order and stops at the first one that makes the rest meaningless.
pub async fn run(client: &DbevClient, expected: ExpectedIdentity<'_>) -> ConnectionCheck {
    let mut steps = Steps::default();

    let started = Instant::now();
    let heartbeat = client.probe("/api/heartbeat").await;
    let latency_ms = Some(started.elapsed().as_millis() as u64);
    match heartbeat {
        Ok(_) => steps.pass(StepId::Reach),
        Err(failure) if failure.is_auth() => {
            steps.pass(StepId::Reach);
            steps.fail(StepId::Authenticate, failure.message, auth_hint());
            return steps.finish(latency_ms, None, None);
        }
        Err(failure) => {
            let hint = reach_hint(&failure);
            steps.fail(StepId::Reach, failure.message, hint);
            return steps.finish(None, None, None);
        }
    }

    let system = match client.probe("/api/system").await {
        Ok(system) => {
            steps.pass(StepId::Authenticate);
            system
        }
        Err(failure) => {
            let hint = if failure.is_auth() {
                auth_hint()
            } else {
                reach_hint(&failure)
            };
            steps.fail(StepId::Authenticate, failure.message, hint);
            return steps.finish(latency_ms, None, None);
        }
    };

    if let Err(error) =
        DbevClient::validate_identity(&system, expected.daemon_uuid, expected.token_id)
    {
        steps.fail(
            StepId::Identity,
            error.to_string(),
            Some("This URL answers with a different daemon, or the daemon was set up again with new credentials. Check the API URL, or copy the daemon file to the host again.".to_owned()),
        );
        return steps.finish(latency_ms, Some(system), None);
    }
    steps.pass(StepId::Identity);

    match mutation_contract_block_reason(Some(&system)) {
        None => steps.pass(StepId::Contract),
        Some(reason) => steps.warn(
            StepId::Contract,
            reason,
            "The panel can read from this host but will not change anything on it until this is fixed.",
        ),
    }

    let resources = match client.probe("/api/admin/resources/summary").await {
        Ok(resources) => {
            steps.pass(StepId::Resources);
            Some(resources)
        }
        Err(failure) => {
            steps.warn(
                StepId::Resources,
                failure.message,
                "Resource usage will be missing until the daemon reports it.",
            );
            None
        }
    };

    steps.finish(latency_ms, Some(system), resources)
}

fn auth_hint() -> Option<String> {
    Some("The daemon rejected the panel token. Rotate the credentials under Maintenance and copy the new daemon file to the host.".to_owned())
}

fn reach_hint(failure: &ProbeFailure) -> Option<String> {
    let hint = match failure.http_status? {
        StatusCode::NOT_FOUND => {
            "Something answered, but not the daemon API. Check the API URL path and that a reverse proxy forwards /api to the daemon."
        }
        status if status.is_server_error() => {
            "A proxy answered, but the daemon behind it did not. Check that the daemon service is running."
        }
        _ => return None,
    };
    Some(hint.to_owned())
}

const ORDER: [StepId; 5] = [
    StepId::Reach,
    StepId::Authenticate,
    StepId::Identity,
    StepId::Contract,
    StepId::Resources,
];

#[derive(Default)]
struct Steps(Vec<CheckStep>);

impl Steps {
    fn push(&mut self, id: StepId, status: StepStatus, message: Option<String>, hint: Option<String>) {
        self.0.push(CheckStep {
            id,
            status,
            message,
            hint,
        });
    }

    fn pass(&mut self, id: StepId) {
        self.push(id, StepStatus::Passed, None, None);
    }

    fn warn(&mut self, id: StepId, message: String, hint: &str) {
        self.push(id, StepStatus::Warning, Some(message), Some(hint.to_owned()));
    }

    fn fail(&mut self, id: StepId, message: String, hint: Option<String>) {
        self.push(id, StepStatus::Failed, Some(message), hint);
    }

    fn finish(
        mut self,
        latency_ms: Option<u64>,
        system: Option<serde_json::Value>,
        resources: Option<serde_json::Value>,
    ) -> ConnectionCheck {
        for id in ORDER {
            if !self.0.iter().any(|step| step.id == id) {
                self.push(id, StepStatus::Skipped, None, None);
            }
        }
        let mutation_block_reason = mutation_contract_block_reason(system.as_ref());
        ConnectionCheck {
            ok: !self.0.iter().any(|step| step.status == StepStatus::Failed),
            latency_ms,
            steps: self.0,
            mutations_allowed: mutation_block_reason.is_none(),
            mutation_block_reason,
            system,
            resources,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::{Json, Router, http::StatusCode, routing::get};

    async fn serve(app: Router) -> (DbevClient, tokio::task::JoinHandle<()>) {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let client = DbevClient::for_test(&format!("http://{}", listener.local_addr().unwrap()));
        let server = tokio::spawn(async move {
            axum::serve(listener, app).await.unwrap();
        });
        (client, server)
    }

    fn statuses(check: &ConnectionCheck) -> Vec<StepStatus> {
        check.steps.iter().map(|step| step.status).collect()
    }

    const EXPECTED: ExpectedIdentity<'static> = ExpectedIdentity {
        daemon_uuid: "daemon",
        token_id: "token",
    };

    #[tokio::test]
    async fn unreachable_host_fails_the_first_step_and_skips_the_rest() {
        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let address = listener.local_addr().unwrap();
        drop(listener);
        let check = run(&DbevClient::for_test(&format!("http://{address}")), EXPECTED).await;
        assert!(!check.ok);
        assert_eq!(
            statuses(&check),
            [
                StepStatus::Failed,
                StepStatus::Skipped,
                StepStatus::Skipped,
                StepStatus::Skipped,
                StepStatus::Skipped
            ]
        );
        assert!(check.failure().unwrap().contains("refused"));
    }

    #[tokio::test]
    async fn rejected_token_is_reported_as_an_authentication_failure() {
        let (client, server) = serve(Router::new().route(
            "/api/heartbeat",
            get(|| async { StatusCode::UNAUTHORIZED }),
        ))
        .await;
        let check = run(&client, EXPECTED).await;
        assert_eq!(check.steps[0].status, StepStatus::Passed);
        assert_eq!(check.steps[1].id, StepId::Authenticate);
        assert_eq!(check.steps[1].status, StepStatus::Failed);
        assert!(check.steps[1].hint.as_deref().unwrap().contains("token"));
        server.abort();
    }

    #[tokio::test]
    async fn wrong_daemon_fails_identity_and_old_contract_only_warns() {
        let (client, server) = serve(
            Router::new()
                .route("/api/heartbeat", get(|| async { Json(serde_json::json!({"status": "ok"})) }))
                .route(
                    "/api/system",
                    get(|| async {
                        Json(serde_json::json!({"uuid": "daemon", "token_id": "token", "api_version": "0.1.0"}))
                    }),
                ),
        )
        .await;
        let check = run(&client, EXPECTED).await;
        assert!(check.ok);
        assert_eq!(
            statuses(&check)[..4],
            [
                StepStatus::Passed,
                StepStatus::Passed,
                StepStatus::Passed,
                StepStatus::Warning
            ]
        );
        assert!(!check.mutations_allowed);

        let other = ExpectedIdentity {
            daemon_uuid: "other",
            token_id: "token",
        };
        let check = run(&client, other).await;
        assert!(!check.ok);
        assert_eq!(check.steps[2].status, StepStatus::Failed);
        server.abort();
    }
}
