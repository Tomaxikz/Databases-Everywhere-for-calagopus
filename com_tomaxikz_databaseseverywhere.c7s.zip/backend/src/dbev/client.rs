use crate::persistence::NodeRecord;
use axum::http::StatusCode;
use reqwest::{Method, RequestBuilder, Response};
use serde::{Serialize, de::DeserializeOwned};
use shared::{
    State,
    response::{DisplayError, extract_readable_error},
};
use std::time::Duration;

#[derive(Debug, Clone, serde::Deserialize, utoipa::ToSchema)]
struct DbevErrorBody {
    #[serde(default)]
    pub error: Option<serde_json::Value>,
    #[serde(default)]
    pub message: Option<String>,
    #[serde(default)]
    pub detail: Option<String>,
    pub code: Option<String>,
    pub error_id: Option<String>,
}

#[derive(Clone)]
pub struct DbevClient {
    client: reqwest::Client,
    base_url: String,
    token: String,
    origin: Option<String>,
}

#[derive(Debug, Clone)]
pub struct AcceptedResponse<T> {
    pub value: T,
    pub location: Option<String>,
}

impl DbevClient {
    pub async fn for_node(state: &State, node: &NodeRecord) -> Result<Self, anyhow::Error> {
        let settings = state.settings.get().await?;
        let extension_settings = settings
            .get_extension_settings::<crate::settings::ExtensionSettingsData>(
                "com.tomaxikz.databaseseverywhere",
            )?;
        let origin = if extension_settings.panel_url.trim().is_empty() {
            settings.app.url.trim_end_matches('/').to_owned()
        } else {
            extension_settings
                .panel_url
                .trim_end_matches('/')
                .to_owned()
        };
        Ok(Self {
            client: state.client.clone(),
            base_url: node.api_url.trim_end_matches('/').to_owned(),
            token: node.decrypted_token(state).await?,
            origin: Some(origin),
        })
    }

    pub async fn for_mutation(state: &State, node: &NodeRecord) -> Result<Self, anyhow::Error> {
        Self::for_mutation_with_system(state, node)
            .await
            .map(|(client, _)| client)
    }

    pub async fn for_mutation_with_system(
        state: &State,
        node: &NodeRecord,
    ) -> Result<(Self, serde_json::Value), anyhow::Error> {
        let client = Self::for_node(state, node).await?;
        let system = match client.system().await {
            Ok(system) => system,
            Err(error) => {
                let message = error.to_string();
                node.store_health(state, None, None, Some(&message)).await?;
                return Err(error);
            }
        };
        let contract = crate::dbev::validate_system_response(&system)
            .and_then(|_| Self::validate_identity(&system, &node.daemon_uuid, &node.token_id));
        let error = contract.as_ref().err().map(ToString::to_string);
        node.store_health(state, Some(&system), None, error.as_deref())
            .await?;
        contract?;
        Ok((client, system))
    }

    pub fn validate_identity(
        system: &serde_json::Value,
        daemon_uuid: &str,
        token_id: &str,
    ) -> Result<(), anyhow::Error> {
        if system.get("uuid").and_then(serde_json::Value::as_str) != Some(daemon_uuid)
            || system.get("token_id").and_then(serde_json::Value::as_str) != Some(token_id)
        {
            return Err(shared::response::DisplayError::new(
                "DBEV identity does not match the registered node and ownership namespace",
            )
            .with_status(axum::http::StatusCode::CONFLICT)
            .into());
        }
        Ok(())
    }

    pub fn resolve_url(&self, path: &str) -> Result<String, anyhow::Error> {
        if !path.starts_with('/') || path.starts_with("//") {
            return Err(anyhow::anyhow!(
                "DatabasesEverywhere returned an invalid URL"
            ));
        }
        Ok(format!("{}{path}", self.base_url))
    }

    pub fn websocket_url(&self, path: &str) -> Result<String, anyhow::Error> {
        if !path.starts_with("/ws/") || path.starts_with("//") {
            return Err(anyhow::anyhow!(
                "refusing to build an invalid DatabasesEverywhere WebSocket URL"
            ));
        }

        let mut url = url::Url::parse(&self.base_url)
            .map_err(|_| anyhow::anyhow!("DatabasesEverywhere node has an invalid API URL"))?;
        let websocket_scheme = match url.scheme() {
            "http" => "ws",
            "https" => "wss",
            _ => {
                return Err(anyhow::anyhow!(
                    "DatabasesEverywhere API URL must use HTTP or HTTPS"
                ));
            }
        };
        url.set_scheme(websocket_scheme)
            .map_err(|_| anyhow::anyhow!("failed to build DatabasesEverywhere WebSocket URL"))?;
        url.set_path(path);
        url.set_query(None);
        url.set_fragment(None);
        Ok(url.to_string())
    }

    pub fn websocket_url_with_query(
        &self,
        path: &str,
        query: &str,
    ) -> Result<String, anyhow::Error> {
        let mut url = url::Url::parse(&self.websocket_url(path)?)?;
        url.set_query(Some(query));
        Ok(url.to_string())
    }

    fn request(&self, method: Method, path: &str) -> Result<RequestBuilder, anyhow::Error> {
        if !path.starts_with("/api/") {
            return Err(anyhow::anyhow!(
                "refusing to call an invalid DatabasesEverywhere API path"
            ));
        }

        let mut request = self
            .client
            .request(method, self.resolve_url(path)?)
            .bearer_auth(&self.token)
            .timeout(Duration::from_secs(900));
        if let Some(origin) = &self.origin {
            request = request.header(reqwest::header::ORIGIN, origin);
        }
        Ok(request)
    }

    async fn send<B: Serialize + ?Sized>(
        &self,
        method: Method,
        path: &str,
        body: Option<&B>,
    ) -> Result<Response, anyhow::Error> {
        let mut request = self.request(method, path)?;
        if let Some(body) = body {
            request = request.json(body);
        }
        let response = request.send().await.map_err(Self::transport_error)?;
        if response.status().is_success() {
            return Ok(response);
        }

        Err(Self::response_error(response).await)
    }

    async fn response_error(response: Response) -> anyhow::Error {
        let status = response.status();
        let body = response.json::<DbevErrorBody>().await.ok();
        let message = body
            .as_ref()
            .map(format_error_body)
            .unwrap_or_else(|| format!("DatabasesEverywhere returned HTTP {status}"));
        let status = StatusCode::from_u16(status.as_u16()).unwrap_or(StatusCode::BAD_GATEWAY);
        DisplayError::new(message).with_status(status).into()
    }

    fn transport_error(error: reqwest::Error) -> anyhow::Error {
        if error.is_timeout() {
            DisplayError::new("the database host request timed out")
                .with_status(StatusCode::GATEWAY_TIMEOUT)
                .into()
        } else {
            DisplayError::new("Panel could not reach the database host")
                .with_status(StatusCode::BAD_GATEWAY)
                .into()
        }
    }

    async fn decode<T: DeserializeOwned>(response: Response) -> Result<T, anyhow::Error> {
        response.json::<T>().await.map_err(|error| {
            anyhow::Error::new(
                DisplayError::new(format!(
                    "DatabasesEverywhere returned an invalid response: {error}"
                ))
                .with_status(StatusCode::BAD_GATEWAY),
            )
        })
    }

    pub async fn get<T: DeserializeOwned>(&self, path: &str) -> Result<T, anyhow::Error> {
        const ATTEMPTS: usize = 3;
        for attempt in 0..ATTEMPTS {
            let response = self.request(Method::GET, path)?.send().await;
            match response {
                Ok(response) if response.status().is_success() => {
                    return Self::decode(response).await;
                }
                Ok(response)
                    if should_retry_request(Method::GET, response.status(), attempt, ATTEMPTS) =>
                {
                    // Only safe reads are replayed during a daemon restart.
                    drop(response);
                }
                Ok(response) => return Err(Self::response_error(response).await),
                Err(_error) if attempt + 1 < ATTEMPTS => {
                    tracing::debug!(attempt, "retrying safe DatabasesEverywhere GET");
                }
                Err(error) => return Err(Self::transport_error(error)),
            }
            tokio::time::sleep(get_retry_delay(attempt)).await;
        }
        unreachable!("bounded GET retry loop always returns")
    }

    pub async fn system(&self) -> Result<serde_json::Value, anyhow::Error> {
        let response = self
            .request(Method::GET, "/api/system")?
            .header(reqwest::header::CACHE_CONTROL, "no-cache")
            .timeout(Duration::from_secs(10))
            .send()
            .await
            .map_err(Self::transport_error)?;
        if !response.status().is_success() {
            return Err(websocket_setup_error(
                Self::response_error(response).await,
                "DBEV discovery GET /api/system failed; check the node API address and proxy routing",
            ));
        }
        let response = Self::decode::<serde_json::Value>(response).await?;
        Ok(response)
    }

    /// Diagnose a refused grant without changing instances or widening its target scope.
    pub async fn instance_websocket_token<T: DeserializeOwned, B: Serialize + ?Sized>(
        &self,
        body: &B,
        instances: &[String],
        pending: Option<(&str, &str)>,
    ) -> Result<T, anyhow::Error> {
        let error = match self.post("/api/ws-token", body).await {
            Ok(token) => return Ok(token),
            Err(error) => error,
        };
        if !has_status(&error, StatusCode::NOT_FOUND) {
            return Err(websocket_setup_error(
                error,
                "DBEV WebSocket token request failed",
            ));
        }
        for id in instances {
            let path = format!("/api/instances/{}", urlencoding::encode(id));
            match self.get::<serde_json::Value>(&path).await {
                Ok(_) => continue,
                Err(cause) if has_status(&cause, StatusCode::NOT_FOUND) => {}
                Err(cause) => {
                    return Err(websocket_setup_error(
                        cause,
                        "Could not verify the WebSocket target on its assigned DBEV node",
                    ));
                }
            }
            if let Some((pending_id, status_url)) =
                pending.filter(|(pending_id, _)| *pending_id == id)
            {
                match self.get::<serde_json::Value>(status_url).await {
                    Ok(status) if pending_socket_creation(&status, pending_id) => {
                        return Err(DisplayError::new("DBEV confirms database creation is still pending. Live monitoring will retry with a fresh token when the instance becomes available.")
                            .with_status(StatusCode::SERVICE_UNAVAILABLE).into());
                    }
                    Ok(_) => {}
                    Err(cause) if has_status(&cause, StatusCode::NOT_FOUND) => {}
                    Err(cause) => {
                        return Err(websocket_setup_error(
                            cause,
                            "Could not verify pending database creation",
                        ));
                    }
                }
            }
            return Err(DisplayError::new(format!("DBEV cannot find database instance {id} on its assigned node. Monitoring cannot connect. Check the creation result and node mapping; the database has not been recreated or moved."))
                .with_status(StatusCode::NOT_FOUND).into());
        }
        Err(websocket_setup_error(
            error,
            "DBEV POST /api/ws-token was not found although the requested instances exist. Check the daemon version and proxy routing for this endpoint",
        ))
    }

    pub async fn post<T: DeserializeOwned, B: Serialize + ?Sized>(
        &self,
        path: &str,
        body: &B,
    ) -> Result<T, anyhow::Error> {
        Self::decode(self.send(Method::POST, path, Some(body)).await?).await
    }

    pub async fn post_accepted<T: DeserializeOwned, B: Serialize + ?Sized>(
        &self,
        path: &str,
        body: &B,
    ) -> Result<T, anyhow::Error> {
        Ok(self.post_accepted_with_location(path, body).await?.value)
    }

    pub async fn post_accepted_with_location<T: DeserializeOwned, B: Serialize + ?Sized>(
        &self,
        path: &str,
        body: &B,
    ) -> Result<AcceptedResponse<T>, anyhow::Error> {
        let response = self.send(Method::POST, path, Some(body)).await?;
        if response.status() != reqwest::StatusCode::ACCEPTED {
            return Err(anyhow::Error::new(
                DisplayError::new(format!(
                    "DatabasesEverywhere returned HTTP {}; expected HTTP 202",
                    response.status()
                ))
                .with_status(StatusCode::BAD_GATEWAY),
            ));
        }
        let location = response
            .headers()
            .get(reqwest::header::LOCATION)
            .and_then(|value| value.to_str().ok())
            .map(str::to_owned);
        if location
            .as_deref()
            .is_some_and(|location| !location.starts_with("/api/") || location.starts_with("//"))
        {
            return Err(anyhow::Error::new(
                DisplayError::new("DatabasesEverywhere returned an invalid operation status URL")
                    .with_status(StatusCode::BAD_GATEWAY),
            ));
        }
        Ok(AcceptedResponse {
            value: Self::decode(response).await?,
            location,
        })
    }

    /// Streams an allow-listed raw upload to DBEV without replaying or buffering it.
    pub async fn post_import_upload<T: DeserializeOwned>(
        &self,
        path: &str,
        content_length: u64,
        encoded_filename: &str,
        sha256: Option<&str>,
        body: reqwest::Body,
    ) -> Result<T, anyhow::Error> {
        let request =
            self.import_upload_request(path, content_length, encoded_filename, sha256, body)?;

        let response = request.send().await.map_err(|error| {
            if error.is_timeout() {
                anyhow::Error::new(
                    DisplayError::new("upload stalled or exceeded its deadline")
                        .with_status(StatusCode::REQUEST_TIMEOUT),
                )
            } else {
                DisplayError::new("Panel could not reach the database host")
                    .with_status(StatusCode::BAD_GATEWAY)
                    .into()
            }
        })?;
        if !response.status().is_success() {
            return Err(Self::response_error(response).await);
        }
        if response.status() != reqwest::StatusCode::CREATED {
            return Err(anyhow::Error::new(
                DisplayError::new(format!(
                    "DatabasesEverywhere returned HTTP {}; expected HTTP 201",
                    response.status()
                ))
                .with_status(StatusCode::BAD_GATEWAY),
            ));
        }
        Self::decode(response).await
    }

    fn import_upload_request(
        &self,
        path: &str,
        content_length: u64,
        encoded_filename: &str,
        sha256: Option<&str>,
        body: reqwest::Body,
    ) -> Result<RequestBuilder, anyhow::Error> {
        let mut request = self
            .request(Method::POST, path)?
            .timeout(Duration::from_secs(3_600))
            .header(reqwest::header::CONTENT_TYPE, "application/octet-stream")
            .header(reqwest::header::CONTENT_LENGTH, content_length)
            .header("X-DBEV-Filename", encoded_filename)
            .body(body);
        if let Some(sha256) = sha256 {
            request = request.header("X-DBEV-SHA256", sha256);
        }
        Ok(request)
    }

    pub async fn patch<T: DeserializeOwned, B: Serialize + ?Sized>(
        &self,
        path: &str,
        body: &B,
    ) -> Result<T, anyhow::Error> {
        Self::decode(self.send(Method::PATCH, path, Some(body)).await?).await
    }

    pub async fn delete<T: DeserializeOwned>(&self, path: &str) -> Result<T, anyhow::Error> {
        Self::decode(self.send::<()>(Method::DELETE, path, None).await?).await
    }

    pub async fn delete_success(&self, path: &str) -> Result<(), anyhow::Error> {
        self.send::<()>(Method::DELETE, path, None).await?;
        Ok(())
    }

    pub async fn delete_allow_not_found(
        &self,
        path: &str,
    ) -> Result<Option<serde_json::Value>, anyhow::Error> {
        if !path.starts_with("/api/") {
            return Err(anyhow::anyhow!(
                "refusing to call an invalid DatabasesEverywhere API path"
            ));
        }
        let mut request = self
            .client
            .delete(self.resolve_url(path)?)
            .bearer_auth(&self.token)
            .timeout(Duration::from_secs(900));
        if let Some(origin) = &self.origin {
            request = request.header(reqwest::header::ORIGIN, origin);
        }
        let response = request.send().await.map_err(Self::transport_error)?;
        if response.status() == reqwest::StatusCode::NOT_FOUND {
            return Ok(None);
        }
        if !response.status().is_success() {
            return Err(Self::response_error(response).await);
        }
        Ok(Some(Self::decode(response).await?))
    }

    pub async fn download_signed(&self, path: &str) -> Result<Response, anyhow::Error> {
        if !path.starts_with("/api/instances/")
            || !path.contains("/download?token=")
            || path.starts_with("//")
        {
            return Err(anyhow::anyhow!(
                "DatabasesEverywhere returned an invalid signed download URL"
            ));
        }
        let mut request = self
            .client
            .get(self.resolve_url(path)?)
            .timeout(Duration::from_secs(900));
        if let Some(origin) = &self.origin {
            request = request.header(reqwest::header::ORIGIN, origin);
        }
        let response = request.send().await.map_err(Self::transport_error)?;
        if response.status().is_success() {
            Ok(response)
        } else {
            Err(Self::response_error(response).await)
        }
    }
}

fn format_error_body(body: &DbevErrorBody) -> String {
    let nested_error = body.error.as_ref().and_then(serde_json::Value::as_object);
    let mut message = body
        .error
        .as_ref()
        .and_then(|error| {
            error
                .as_str()
                .or_else(|| error.get("message").and_then(serde_json::Value::as_str))
        })
        .or(body.message.as_deref())
        .or(body.detail.as_deref())
        .map(str::trim)
        .filter(|message| !message.is_empty())
        .unwrap_or("DatabasesEverywhere rejected the request")
        .to_owned();
    if let Some(code) = body
        .code
        .as_deref()
        .or_else(|| {
            nested_error
                .and_then(|error| error.get("code"))
                .and_then(serde_json::Value::as_str)
        })
        .map(str::trim)
        .filter(|code| !code.is_empty())
    {
        message.push_str(&format!(" [{code}]"));
    }
    if let Some(error_id) = body
        .error_id
        .as_deref()
        .or_else(|| {
            nested_error
                .and_then(|error| error.get("error_id"))
                .and_then(serde_json::Value::as_str)
        })
        .map(str::trim)
        .filter(|error_id| !error_id.is_empty())
    {
        message.push_str(&format!(" (error id: {error_id})"));
    }
    message
}

pub(crate) fn websocket_setup_error(error: anyhow::Error, context: &str) -> anyhow::Error {
    match extract_readable_error(&error) {
        Some((message, status)) => DisplayError::new(format!("{context}: {message}"))
            .with_status(status)
            .into(),
        None => error.context(context.to_owned()),
    }
}

fn has_status(error: &anyhow::Error, status: StatusCode) -> bool {
    extract_readable_error(error).is_some_and(|(_, actual)| actual == status)
}

fn pending_socket_creation(status: &serde_json::Value, instance_id: &str) -> bool {
    // A local 'creating' flag or absent progress is not proof of an active daemon operation.
    status
        .get("instance_id")
        .and_then(serde_json::Value::as_str)
        == Some(instance_id)
        && matches!(
            status.get("status").and_then(serde_json::Value::as_str),
            Some("creating" | "booting")
        )
}

fn get_retry_delay(attempt: usize) -> Duration {
    Duration::from_millis((250_u64.saturating_mul(2_u64.saturating_pow(attempt as u32))).min(2_000))
}

fn should_retry_request(
    method: Method,
    status: reqwest::StatusCode,
    attempt: usize,
    attempts: usize,
) -> bool {
    method == Method::GET
        && status == reqwest::StatusCode::SERVICE_UNAVAILABLE
        && attempt + 1 < attempts
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn system_identity_requires_the_exact_root_node_and_stable_pool_namespace() {
        let valid = serde_json::json!({"uuid": "node-a", "token_id": "panel-a"});
        assert!(DbevClient::validate_identity(&valid, "node-a", "panel-a").is_ok());
        assert!(DbevClient::validate_identity(&valid, "node-b", "panel-a").is_err());
        assert!(DbevClient::validate_identity(&valid, "node-a", "panel-b").is_err());
        assert!(
            DbevClient::validate_identity(&serde_json::json!({"data": valid}), "node-a", "panel-a")
                .is_err()
        );
        assert!(
            DbevClient::validate_identity(&serde_json::json!({}), "node-a", "panel-a").is_err()
        );
    }
    use futures_util::Stream;
    use std::{
        pin::Pin,
        sync::{
            Arc,
            atomic::{AtomicBool, AtomicUsize, Ordering},
        },
        task::{Context, Poll},
    };

    struct PendingUploadStream {
        polled: Arc<AtomicUsize>,
        dropped: Arc<AtomicBool>,
    }

    impl Stream for PendingUploadStream {
        type Item = Result<Vec<u8>, std::io::Error>;

        fn poll_next(self: Pin<&mut Self>, _context: &mut Context<'_>) -> Poll<Option<Self::Item>> {
            self.polled.fetch_add(1, Ordering::SeqCst);
            Poll::Pending
        }
    }

    impl Drop for PendingUploadStream {
        fn drop(&mut self) {
            self.dropped.store(true, Ordering::SeqCst);
        }
    }

    fn client(base_url: &str) -> DbevClient {
        DbevClient {
            client: reqwest::Client::new(),
            base_url: base_url.to_owned(),
            token: "test".to_owned(),
            origin: None,
        }
    }

    #[tokio::test]
    async fn system_fetch_authenticates_and_replaces_stale_snapshots_without_retrying_failures() {
        use axum::{
            http::{HeaderMap, StatusCode},
            response::IntoResponse,
        };
        let calls = Arc::new(AtomicUsize::new(0));
        let received = Arc::clone(&calls);
        let app = axum::Router::new().route(
            "/api/system",
            axum::routing::get(move |headers: HeaderMap| {
                let received = Arc::clone(&received);
                async move {
                    assert_eq!(headers.get("authorization").unwrap(), "Bearer test");
                    assert_eq!(headers.get("cache-control").unwrap(), "no-cache");
                    let call = received.fetch_add(1, Ordering::SeqCst);
                    if call >= 3 {
                        return StatusCode::UNAUTHORIZED.into_response();
                    }
                    let mut capability = serde_json::json!({
                        "protocol": "postgres", "enabled": true, "modes": ["dedicated", "shared"]
                    });
                    if call == 1 {
                        capability["shared_pool_scope"] = serde_json::json!("server");
                        capability["server_private_pools"] = serde_json::json!(true);
                    }
                    axum::Json(serde_json::json!({
                        "api_version": if call == 0 { "0.16.0" } else { "0.17.0" },
                        "version": "0.8.0", "future_field": 0,
                        "deployment_capabilities": [capability]
                    }))
                    .into_response()
                }
            }),
        );
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let client = client(&format!("http://{}", listener.local_addr().unwrap()));
        let server = tokio::spawn(async move {
            axum::serve(listener, app).await.unwrap();
        });
        for supported in [false, true, false] {
            let snapshot = client.system().await.unwrap();
            assert_eq!(snapshot["future_field"], 0);
            assert_eq!(
                crate::dbev::DbevCapabilities::from_system(&snapshot)
                    .supports_private_shared(crate::domain::DatabaseProtocol::Postgres),
                supported
            );
        }
        assert!(client.system().await.is_err());
        assert_eq!(calls.load(Ordering::SeqCst), 4);
        server.abort();
    }

    #[test]
    fn builds_browser_websocket_urls_from_the_trusted_node_origin() {
        assert_eq!(
            client("http://127.0.0.1:8090")
                .websocket_url("/ws/monitoring")
                .unwrap(),
            "ws://127.0.0.1:8090/ws/monitoring"
        );
        assert_eq!(
            client("https://db.example.test:9443/api?ignored=true")
                .websocket_url("/ws/instances/example/logs")
                .unwrap(),
            "wss://db.example.test:9443/ws/instances/example/logs"
        );
    }

    #[test]
    fn missing_progress_is_not_evidence_of_pending_creation() {
        for status in [
            serde_json::json!({}),
            serde_json::json!({"instance_id": "db-1"}),
            serde_json::json!({"instance_id": "another-db", "status": "creating"}),
            serde_json::json!({"instance_id": "db-1", "status": "failed"}),
        ] {
            assert!(!pending_socket_creation(&status, "db-1"));
        }
        assert!(pending_socket_creation(
            &serde_json::json!({"instance_id": "db-1", "status": "creating"}),
            "db-1"
        ));
    }

    #[tokio::test]
    async fn websocket_grants_distinguish_missing_instances_pending_creation_and_missing_routes() {
        use axum::{http::HeaderMap, response::IntoResponse};
        for (token_status, present, pending, expected, message) in [
            (
                StatusCode::NOT_FOUND,
                false,
                false,
                StatusCode::NOT_FOUND,
                "cannot find database instance db-1",
            ),
            (
                StatusCode::NOT_FOUND,
                false,
                true,
                StatusCode::SERVICE_UNAVAILABLE,
                "creation is still pending",
            ),
            (
                StatusCode::NOT_FOUND,
                true,
                false,
                StatusCode::NOT_FOUND,
                "POST /api/ws-token was not found",
            ),
            (
                StatusCode::FORBIDDEN,
                false,
                false,
                StatusCode::FORBIDDEN,
                "token request failed",
            ),
        ] {
            let reads = Arc::new(AtomicUsize::new(0));
            let read_count = Arc::clone(&reads);
            let app = axum::Router::new()
                .route("/api/ws-token", axum::routing::post(move |headers: HeaderMap, axum::Json(body): axum::Json<serde_json::Value>| async move {
                    assert_eq!(headers.get("authorization").unwrap(), "Bearer test");
                    assert_eq!(body["instances"], serde_json::json!(["db-1"]));
                    assert_eq!(body["scopes"], serde_json::json!(["monitor:read"]));
                    assert!(body.get("all_instances").is_none());
                    assert!(body.get("pools").is_none());
                    (token_status, axum::Json(serde_json::json!({"error": "not found", "code": "not_found"})))
                }))
                .route("/api/instances/db-1", axum::routing::get(move || {
                    let count = Arc::clone(&read_count);
                    async move {
                        count.fetch_add(1, Ordering::SeqCst);
                        if present { axum::Json(serde_json::json!({"instance_id": "db-1", "status": "running"})).into_response() }
                        else { StatusCode::NOT_FOUND.into_response() }
                    }
                }))
                .route("/api/instances/db-1/status", axum::routing::get(|| async {
                    axum::Json(serde_json::json!({"instance_id": "db-1", "status": "creating"}))
                }));
            let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let client = client(&format!("http://{}", listener.local_addr().unwrap()));
            let server = tokio::spawn(async move {
                axum::serve(listener, app).await.unwrap();
            });
            let error = client.instance_websocket_token::<serde_json::Value, _>(
                &serde_json::json!({"subject": "panel-user", "instances": ["db-1"], "scopes": ["monitor:read"], "ttl_seconds": 900}),
                &["db-1".to_owned()], pending.then_some(("db-1", "/api/instances/db-1/status")),
            ).await.unwrap_err();
            let (actual_message, actual_status) = extract_readable_error(&error).unwrap();
            assert_eq!(actual_status, expected);
            assert!(actual_message.contains(message), "{actual_message}");
            assert_eq!(
                reads.load(Ordering::SeqCst),
                usize::from(token_status == StatusCode::NOT_FOUND)
            );
            server.abort();
        }
    }

    #[tokio::test]
    async fn websocket_tokens_are_read_from_the_root_and_never_reused() {
        let calls = Arc::new(AtomicUsize::new(0));
        let counter = Arc::clone(&calls);
        let app = axum::Router::new().route("/api/ws-token", axum::routing::post(move || {
            let counter = Arc::clone(&counter);
            async move { axum::Json(serde_json::json!({"token": format!("fresh-{}", counter.fetch_add(1, Ordering::SeqCst)), "expires_at_unix": 2000})) }
        }));
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let client = client(&format!("http://{}", listener.local_addr().unwrap()));
        let server = tokio::spawn(async move {
            axum::serve(listener, app).await.unwrap();
        });
        for index in 0..2 {
            let token = client
                .instance_websocket_token::<serde_json::Value, _>(
                    &serde_json::json!({}),
                    &["db-1".to_owned()],
                    None,
                )
                .await
                .unwrap();
            assert_eq!(token["token"], format!("fresh-{index}"));
            assert!(token.get("data").is_none());
        }
        assert_eq!(calls.load(Ordering::SeqCst), 2);
        server.abort();
    }

    #[test]
    fn rejects_non_websocket_paths() {
        assert!(
            client("https://db.example.test")
                .websocket_url("//evil.test/ws")
                .is_err()
        );
        assert!(
            client("https://db.example.test")
                .websocket_url("/api/system")
                .is_err()
        );
    }

    #[test]
    fn safe_get_retry_backoff_is_bounded() {
        assert_eq!(get_retry_delay(0), Duration::from_millis(250));
        assert_eq!(get_retry_delay(1), Duration::from_millis(500));
        assert_eq!(get_retry_delay(20), Duration::from_millis(2_000));
    }

    #[test]
    fn non_idempotent_mutations_are_never_replayed() {
        for method in [Method::POST, Method::PATCH, Method::DELETE] {
            assert!(!should_retry_request(
                method,
                reqwest::StatusCode::SERVICE_UNAVAILABLE,
                0,
                3,
            ));
        }
        assert!(should_retry_request(
            Method::GET,
            reqwest::StatusCode::SERVICE_UNAVAILABLE,
            0,
            3,
        ));
        assert!(!should_retry_request(
            Method::GET,
            reqwest::StatusCode::CONFLICT,
            0,
            3,
        ));
    }

    #[test]
    fn preserves_sanitized_error_messages_and_codes_from_supported_envelopes() {
        let ordinary: DbevErrorBody = serde_json::from_value(serde_json::json!({
            "error": "shared placement is unavailable",
            "code": "placement_capability_unavailable",
            "error_id": "error-1"
        }))
        .unwrap();
        assert_eq!(
            format_error_body(&ordinary),
            "shared placement is unavailable [placement_capability_unavailable] (error id: error-1)"
        );

        let alternate: DbevErrorBody = serde_json::from_value(serde_json::json!({
            "message": "gateway recovery is not ready",
            "code": "gateway_not_ready"
        }))
        .unwrap();
        assert_eq!(
            format_error_body(&alternate),
            "gateway recovery is not ready [gateway_not_ready]"
        );

        let structured: DbevErrorBody = serde_json::from_value(serde_json::json!({
            "error": {
                "message": "disk shrink rejected because current data does not fit",
                "code": "disk_shrink_conflict",
                "error_id": "error-2"
            }
        }))
        .unwrap();
        assert_eq!(
            format_error_body(&structured),
            "disk shrink rejected because current data does not fit [disk_shrink_conflict] (error id: error-2)"
        );
    }

    #[test]
    fn raw_upload_request_forwards_only_the_contract_headers_and_server_credentials() {
        let request = client("https://db.example.test:9443")
            .import_upload_request(
                "/api/instances/instance-1/import",
                4_294_967_296,
                "tenant%20dump.sql",
                Some(&"a".repeat(64)),
                reqwest::Body::from("streamed"),
            )
            .unwrap()
            .build()
            .unwrap();
        assert_eq!(
            request.url().as_str(),
            "https://db.example.test:9443/api/instances/instance-1/import"
        );
        assert_eq!(
            request.headers()[reqwest::header::CONTENT_LENGTH],
            "4294967296"
        );
        assert_eq!(
            request.headers()[reqwest::header::CONTENT_TYPE],
            "application/octet-stream"
        );
        assert_eq!(request.headers()["X-DBEV-Filename"], "tenant%20dump.sql");
        assert_eq!(
            request.headers()["X-DBEV-SHA256"].to_str().unwrap(),
            "a".repeat(64).as_str()
        );
        assert_eq!(
            request.headers()[reqwest::header::AUTHORIZATION],
            "Bearer test"
        );
        assert!(
            request
                .headers()
                .get(reqwest::header::CONTENT_ENCODING)
                .is_none()
        );
    }

    #[test]
    fn multi_gibibyte_uploads_are_not_eagerly_buffered_and_drop_the_upstream_stream() {
        let polled = Arc::new(AtomicUsize::new(0));
        let dropped = Arc::new(AtomicBool::new(false));
        let body = reqwest::Body::wrap_stream(PendingUploadStream {
            polled: Arc::clone(&polled),
            dropped: Arc::clone(&dropped),
        });
        let request = client("https://db.example.test")
            .import_upload_request(
                "/api/instances/instance-1/import",
                8 * 1024 * 1024 * 1024,
                "large.sql",
                None,
                body,
            )
            .unwrap()
            .build()
            .unwrap();

        assert_eq!(polled.load(Ordering::SeqCst), 0);
        drop(request);
        assert!(dropped.load(Ordering::SeqCst));
    }
}
