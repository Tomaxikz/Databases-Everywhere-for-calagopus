use crate::domain::{DatabaseProtocol, DeploymentMode};
use axum::http::StatusCode;
use semver::Version;
use shared::response::DisplayError;
use std::collections::{BTreeMap, BTreeSet};

pub const SUPPORTED_API_VERSION: &str = "0.17.0";
pub const MINIMUM_API_VERSION: &str = "0.17.0";
pub const STORED_CREDENTIALS_API_VERSION: &str = "0.10.0";
pub const TEMPORARY_UPLOAD_API_VERSION: &str = "0.11.0";
pub const DISCOVERY_AND_SCHEDULER_API_VERSION: &str = "0.12.0";
pub const DBEV_SERVICE: &str = "databases-everywhere";

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DbevCapabilities {
    pub stored_tenant_credentials: bool,
    pub temporary_dump_uploads: bool,
    pub mongodb_source_discovery: bool,
    pub scheduler_recommendations: bool,
    deployment_modes: BTreeMap<DatabaseProtocol, BTreeSet<DeploymentMode>>,
    deployment_contract_valid: bool,
    server_private_protocols: BTreeSet<DatabaseProtocol>,
}

impl DbevCapabilities {
    pub fn from_system(system: &serde_json::Value) -> Self {
        let parsed = parse_deployment_capabilities(system.get("deployment_capabilities"));
        let deployment_contract_valid = parsed.is_some();
        let (deployment_modes, server_private_protocols) = parsed.unwrap_or_default();
        Self {
            stored_tenant_credentials: version_at_least(
                system,
                "api_version",
                STORED_CREDENTIALS_API_VERSION,
            ),
            temporary_dump_uploads: version_at_least(
                system,
                "api_version",
                TEMPORARY_UPLOAD_API_VERSION,
            ),
            mongodb_source_discovery: version_at_least(
                system,
                "api_version",
                DISCOVERY_AND_SCHEDULER_API_VERSION,
            ),
            scheduler_recommendations: version_at_least(
                system,
                "api_version",
                DISCOVERY_AND_SCHEDULER_API_VERSION,
            ),
            deployment_contract_valid,
            deployment_modes,
            server_private_protocols: if version_at_least(
                system,
                "api_version",
                MINIMUM_API_VERSION,
            ) {
                server_private_protocols
            } else {
                BTreeSet::new()
            },
        }
    }

    pub fn supports_deployment(&self, protocol: DatabaseProtocol, mode: DeploymentMode) -> bool {
        self.deployment_modes
            .get(&protocol)
            .is_some_and(|modes| modes.contains(&mode))
    }

    #[cfg(test)]
    pub fn deployment_modes(&self, protocol: DatabaseProtocol) -> Vec<DeploymentMode> {
        self.deployment_modes
            .get(&protocol)
            .map(|modes| modes.iter().copied().collect())
            .unwrap_or_default()
    }

    pub fn has_deployment_contract(&self) -> bool {
        self.deployment_contract_valid
    }

    pub fn supports_private_shared(&self, protocol: DatabaseProtocol) -> bool {
        self.supports_deployment(protocol, DeploymentMode::Shared)
            && self.server_private_protocols.contains(&protocol)
    }

    pub fn supports_placement(&self, protocol: DatabaseProtocol, mode: DeploymentMode) -> bool {
        self.supports_deployment(protocol, mode)
            && (mode != DeploymentMode::Shared || self.supports_private_shared(protocol))
    }
}

fn parse_deployment_capabilities(
    value: Option<&serde_json::Value>,
) -> Option<(
    BTreeMap<DatabaseProtocol, BTreeSet<DeploymentMode>>,
    BTreeSet<DatabaseProtocol>,
)> {
    #[derive(serde::Deserialize)]
    struct Capability {
        protocol: String,
        enabled: bool,
        modes: Vec<String>,
        #[serde(default)]
        shared_pool_scope: serde_json::Value,
        #[serde(default)]
        server_private_pools: serde_json::Value,
    }

    let entries: Vec<Capability> = serde_json::from_value(value?.clone()).ok()?;
    if entries.is_empty() {
        return None;
    }
    let mut seen = BTreeSet::new();
    let mut result = BTreeMap::new();
    let mut private_protocols = BTreeSet::new();
    for entry in entries {
        let canonical = entry.protocol.parse::<DatabaseProtocol>().ok();
        let name = canonical
            .map(|protocol| protocol.as_str().to_owned())
            .unwrap_or_else(|| entry.protocol.to_lowercase());
        if entry.modes.is_empty() || !seen.insert(name) {
            return None;
        }
        let Some(protocol) = canonical else {
            continue;
        };
        if !entry.enabled {
            continue;
        }
        let modes = entry
            .modes
            .iter()
            .filter_map(|mode| mode.parse::<DeploymentMode>().ok())
            .filter(|mode| mode.supports(protocol))
            .collect::<BTreeSet<_>>();
        if !modes.is_empty() {
            if modes.contains(&DeploymentMode::Shared)
                && entry.shared_pool_scope.as_str() == Some("server")
                && entry.server_private_pools.as_bool() == Some(true)
            {
                private_protocols.insert(protocol);
            }
            result.insert(protocol, modes);
        }
    }
    Some((result, private_protocols))
}

pub fn private_shared_block_reason(
    system: &serde_json::Value,
    protocol: DatabaseProtocol,
    api_url: &str,
) -> String {
    let api_version = system
        .get("api_version")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("unknown");
    format!(
        "{} server-private pool support is not confirmed by {api_url} (API {api_version}). The enabled protocol must advertise shared mode, shared_pool_scope=server and server_private_pools=true.",
        protocol.label()
    )
}

fn parse_version(value: &str) -> Option<Version> {
    Version::parse(value.trim().trim_start_matches('v')).ok()
}

fn version_at_least(system: &serde_json::Value, field: &str, minimum: &str) -> bool {
    let Some(advertised) = system
        .get(field)
        .and_then(serde_json::Value::as_str)
        .and_then(parse_version)
    else {
        return false;
    };
    let minimum = Version::parse(minimum).expect("valid DBEV capability version");
    advertised >= minimum
}

pub fn mutation_contract_block_reason(system: Option<&serde_json::Value>) -> Option<String> {
    let Some(system) = system else {
        return Some(
            "The DatabasesEverywhere node has not been sampled yet. Test the connection before changing node or database state."
                .to_owned(),
        );
    };
    let service = system
        .get("service")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("an unknown service");
    if service != DBEV_SERVICE {
        return Some(format!(
            "This extension requires the {DBEV_SERVICE} service, but this node reports {service}. Read-only diagnostics remain available."
        ));
    }

    let advertised = system
        .get("api_version")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("an unknown version");
    if !parse_version(advertised).is_some_and(|version| {
        version >= Version::parse(SUPPORTED_API_VERSION).expect("valid supported DBEV API version")
    }) {
        return Some(format!(
            "This extension requires DatabasesEverywhere API {SUPPORTED_API_VERSION} or newer, but this node reports {advertised}. Update the daemon before changing node or database state."
        ));
    }

    match system
        .get("api_readiness")
        .and_then(serde_json::Value::as_str)
    {
        Some("ready") => {}
        Some("starting") => {
            return Some(
                "The DatabasesEverywhere management API is still starting. Try again after it reports ready."
                    .to_owned(),
            );
        }
        Some("stopping") => {
            return Some(
                "The DatabasesEverywhere management API is stopping and cannot accept mutations."
                    .to_owned(),
            );
        }
        Some("failed") => {
            return Some(
                "The DatabasesEverywhere management API reports a failed readiness state. Review node diagnostics before retrying."
                    .to_owned(),
            );
        }
        Some(readiness) => {
            return Some(format!(
                "The DatabasesEverywhere management API reports an unsupported readiness state: {readiness}."
            ));
        }
        None => {
            return Some(format!(
                "DatabasesEverywhere API {SUPPORTED_API_VERSION} response is missing required field api_readiness"
            ));
        }
    }

    if !DbevCapabilities::from_system(system).has_deployment_contract() {
        return Some(format!(
            "DatabasesEverywhere API {SUPPORTED_API_VERSION} response is missing a usable deployment_capabilities contract"
        ));
    }

    for field in [
        "prevent_cpu_overallocation",
        "prevent_memory_overallocation",
        "prevent_disk_overallocation",
    ] {
        if system
            .get(field)
            .and_then(serde_json::Value::as_bool)
            .is_none()
        {
            return Some(format!(
                "DatabasesEverywhere API {SUPPORTED_API_VERSION} response is missing required field {field}"
            ));
        }
    }
    None
}

pub fn validate_system_response(system: &serde_json::Value) -> Result<(), anyhow::Error> {
    if let Some(reason) = mutation_contract_block_reason(Some(system)) {
        return Err(DisplayError::new(reason)
            .with_status(StatusCode::CONFLICT)
            .into());
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn private_system() -> serde_json::Value {
        serde_json::json!({
            "api_version": "0.17.0", "version": "0.9.0",
            "deployment_capabilities": [{
                "protocol": "postgres", "enabled": true, "modes": ["dedicated", "shared"],
                "shared_pool_scope": "server", "server_private_pools": true
            }]
        })
    }

    #[test]
    fn private_shared_uses_the_selected_protocol_at_the_system_root() {
        let system = private_system();
        let capabilities = DbevCapabilities::from_system(&system);
        assert!(capabilities.supports_private_shared(DatabaseProtocol::Postgres));
        assert!(!capabilities.supports_private_shared(DatabaseProtocol::Mysql));
        assert!(
            capabilities.supports_placement(DatabaseProtocol::Postgres, DeploymentMode::Shared)
        );
        assert!(
            !DbevCapabilities::from_system(&serde_json::json!({"data": system}))
                .supports_private_shared(DatabaseProtocol::Postgres)
        );
    }

    #[test]
    fn unsupported_missing_or_disabled_private_pool_fields_fail_closed() {
        for (field, value) in [
            ("enabled", serde_json::json!(false)),
            ("shared_pool_scope", serde_json::json!("global")),
            ("shared_pool_scope", serde_json::Value::Null),
            ("server_private_pools", serde_json::json!(false)),
            ("server_private_pools", serde_json::json!("true")),
            ("server_private_pools", serde_json::Value::Null),
            ("modes", serde_json::json!(["dedicated"])),
        ] {
            let mut system = private_system();
            system["deployment_capabilities"][0][field] = value;
            assert!(
                !DbevCapabilities::from_system(&system)
                    .supports_private_shared(DatabaseProtocol::Postgres)
            );
        }
        for field in [
            "shared_pool_scope",
            "server_private_pools",
            "enabled",
            "modes",
        ] {
            let mut system = private_system();
            system["deployment_capabilities"][0]
                .as_object_mut()
                .unwrap()
                .remove(field);
            assert!(
                !DbevCapabilities::from_system(&system)
                    .supports_private_shared(DatabaseProtocol::Postgres)
            );
        }
    }

    #[test]
    fn binary_version_and_obsolete_top_level_flags_cannot_enable_private_pools() {
        let mut system = private_system();
        system["api_version"] = serde_json::json!("0.14.0");
        assert!(
            !DbevCapabilities::from_system(&system)
                .supports_private_shared(DatabaseProtocol::Postgres)
        );
        system["api_version"] = serde_json::json!("0.17.0");
        system["shared_pool_ownership"] = serde_json::json!("server_private");
        system["deployment_capabilities"][0]
            .as_object_mut()
            .unwrap()
            .remove("server_private_pools");
        assert!(
            !DbevCapabilities::from_system(&system)
                .supports_private_shared(DatabaseProtocol::Postgres)
        );
        assert!(
            DbevCapabilities::from_system(&system)
                .supports_placement(DatabaseProtocol::Postgres, DeploymentMode::Dedicated)
        );
    }

    #[test]
    fn private_pool_protocol_aliases_cannot_hide_conflicting_entries() {
        let mut system = private_system();
        system["deployment_capabilities"][0]["protocol"] = serde_json::json!("PostgreSQL");
        assert!(
            DbevCapabilities::from_system(&system)
                .supports_private_shared(DatabaseProtocol::Postgres)
        );
        let conflict = private_system()["deployment_capabilities"][0].clone();
        system["deployment_capabilities"]
            .as_array_mut()
            .unwrap()
            .push(conflict);
        assert!(
            !DbevCapabilities::from_system(&system)
                .supports_private_shared(DatabaseProtocol::Postgres)
        );
    }

    #[test]
    fn root_system_preserves_unknown_fields_without_accepting_wrappers() {
        let mut system = private_system();
        system["future_field"] = serde_json::json!(0);
        system["deployment_capabilities"][0]["future_method"] = serde_json::json!("unknown");
        assert!(
            DbevCapabilities::from_system(&system)
                .supports_private_shared(DatabaseProtocol::Postgres)
        );
        assert!(
            !DbevCapabilities::from_system(&serde_json::json!({"data": system.clone()}))
                .supports_private_shared(DatabaseProtocol::Postgres)
        );
        let reason = private_shared_block_reason(
            &system,
            DatabaseProtocol::Postgres,
            "https://selected.example.test:8090",
        );
        assert!(reason.contains("https://selected.example.test:8090 (API 0.17.0)"));
    }

    #[test]
    fn accepts_current_or_newer_mutation_contract() {
        assert!(
            validate_system_response(&serde_json::json!({
                "service": "databases-everywhere",
                "api_version": "0.17.0",
                "api_readiness": "ready",
                "prevent_cpu_overallocation": true,
                "prevent_memory_overallocation": true,
                "prevent_disk_overallocation": true,
                "deployment_capabilities": [
                    { "protocol": "postgres", "enabled": true, "modes": ["dedicated", "shared"] },
                    { "protocol": "redis", "enabled": true, "modes": ["dedicated"] }
                ]
            }))
            .is_ok()
        );
        assert!(
            validate_system_response(&serde_json::json!({
                "service": "databases-everywhere",
                "api_version": "0.18.0",
                "api_readiness": "ready",
                "prevent_cpu_overallocation": true,
                "prevent_memory_overallocation": true,
                "prevent_disk_overallocation": true,
                "deployment_capabilities": [{ "protocol": "postgres", "enabled": true, "modes": ["dedicated"] }]
            }))
            .is_ok()
        );
    }

    #[test]
    fn rejects_older_or_incomplete_system_contracts() {
        assert!(
            validate_system_response(&serde_json::json!({
                "api_version": "0.9.0",
                "service": "databases-everywhere",
                "prevent_cpu_overallocation": true,
                "prevent_memory_overallocation": true,
                "prevent_disk_overallocation": true
            }))
            .is_err()
        );
        assert!(
            validate_system_response(&serde_json::json!({
                "api_version": "0.15.0",
                "service": "databases-everywhere",
                "api_readiness": "ready",
                "prevent_cpu_overallocation": true,
                "deployment_capabilities": [{ "protocol": "postgres", "enabled": true, "modes": ["dedicated"] }]
            }))
            .is_err()
        );
        assert!(
            validate_system_response(&serde_json::json!({
                "service": "something-else",
                "api_version": "0.16.0",
                "api_readiness": "ready",
                "prevent_cpu_overallocation": true,
                "prevent_memory_overallocation": true,
                "prevent_disk_overallocation": true,
                "deployment_capabilities": [{ "protocol": "postgres", "enabled": true, "modes": ["dedicated"] }]
            }))
            .is_err()
        );
    }

    #[test]
    fn detects_v010_capabilities_from_the_api_contract() {
        let capabilities = DbevCapabilities::from_system(&serde_json::json!({
            "api_version": "0.10.0"
        }));
        assert!(capabilities.stored_tenant_credentials);
        assert!(!capabilities.temporary_dump_uploads);
        assert!(!capabilities.mongodb_source_discovery);
        assert!(!capabilities.scheduler_recommendations);
    }

    #[test]
    fn capabilities_use_semantic_api_versions_and_ignore_binary_versions() {
        assert!(
            DbevCapabilities::from_system(&serde_json::json!({
                "api_version": "0.11.0",
                "version": "0.5.1"
            }))
            .temporary_dump_uploads
        );
        let current = DbevCapabilities::from_system(&serde_json::json!({
            "api_version": "0.12.0",
            "version": "0.0.1"
        }));
        assert!(current.temporary_dump_uploads);
        assert!(current.mongodb_source_discovery);
        assert!(current.scheduler_recommendations);
        assert!(
            !DbevCapabilities::from_system(&serde_json::json!({
                "api_version": "0.10.99",
                "version": "99.0.0"
            }))
            .temporary_dump_uploads
        );
        assert!(
            !DbevCapabilities::from_system(&serde_json::json!({
                "api_version": "0.11.99",
                "version": "99.0.0"
            }))
            .mongodb_source_discovery
        );
    }

    #[test]
    fn deployment_capabilities_use_the_canonical_contract() {
        let capabilities = DbevCapabilities::from_system(&serde_json::json!({
            "deployment_capabilities": [
                { "protocol": "postgres", "enabled": true, "modes": ["dedicated", "shared", "future"] },
                { "protocol": "mysql", "enabled": false, "modes": ["dedicated", "shared"] },
                { "protocol": "redis", "enabled": true, "modes": ["dedicated", "shared"] },
                { "protocol": "future", "enabled": true, "modes": ["future"] }
            ]
        }));
        assert!(capabilities.has_deployment_contract());
        assert!(
            capabilities.supports_deployment(DatabaseProtocol::Postgres, DeploymentMode::Shared)
        );
        assert!(
            !capabilities.supports_deployment(DatabaseProtocol::Mysql, DeploymentMode::Dedicated)
        );
        assert!(
            capabilities.supports_deployment(DatabaseProtocol::Redis, DeploymentMode::Dedicated)
        );
        assert!(!capabilities.supports_deployment(DatabaseProtocol::Redis, DeploymentMode::Shared));
        for invalid in [
            serde_json::json!({"postgres": ["dedicated"]}),
            serde_json::json!([{"protocol": "postgres", "modes": ["dedicated"]}]),
            serde_json::json!([
                {"protocol": "postgres", "enabled": true, "modes": ["dedicated"]},
                {"protocol": "postgres", "enabled": false, "modes": ["dedicated"]}
            ]),
        ] {
            assert!(
                !DbevCapabilities::from_system(&serde_json::json!({
                    "deployment_capabilities": invalid
                }))
                .has_deployment_contract()
            );
        }
    }

    #[test]
    fn disabled_protocols_do_not_block_node_administration() {
        let capabilities = DbevCapabilities::from_system(&serde_json::json!({
            "deployment_capabilities": [
                { "protocol": "postgres", "enabled": false, "modes": ["dedicated", "shared"] }
            ]
        }));
        assert!(capabilities.has_deployment_contract());
        assert!(
            capabilities
                .deployment_modes(DatabaseProtocol::Postgres)
                .is_empty()
        );
    }

    #[test]
    fn mutation_contract_requires_management_api_readiness() {
        let mut system = serde_json::json!({
            "service": "databases-everywhere",
            "api_version": "0.17.0",
            "prevent_cpu_overallocation": true,
            "prevent_memory_overallocation": true,
            "prevent_disk_overallocation": true,
            "deployment_capabilities": [{ "protocol": "postgres", "enabled": true, "modes": ["dedicated"] }]
        });
        assert!(validate_system_response(&system).is_err());

        system["api_readiness"] = serde_json::json!("starting");
        let error = validate_system_response(&system).unwrap_err().to_string();
        assert!(error.contains("still starting"));

        system["api_readiness"] = serde_json::json!("ready");
        assert!(validate_system_response(&system).is_ok());
    }
}
