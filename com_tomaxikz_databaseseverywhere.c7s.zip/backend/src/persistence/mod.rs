macro_rules! safe_query {
    (($($argument:tt)*)) => {
        sqlx::query(sqlx::AssertSqlSafe(format!($($argument)*)))
    };
}

macro_rules! safe_query_scalar {
    (($($argument:tt)*)) => {
        sqlx::query_scalar(sqlx::AssertSqlSafe(format!($($argument)*)))
    };
}

mod database;
mod host_assignment;
mod node;
mod node_configuration;
mod operation;
mod shared_pool;
pub use shared_pool::{PoolLimits, SharedPool, validate_runtime_id, validate_status_url};

pub use database::{DatabaseRecord, DatabaseRecordApi};
pub(crate) use database::{
    migration_status, remote_instance, remote_operation_completed, remote_runtime_id, remote_status,
};
pub use host_assignment::{AssignedHost, HostAssignment, PanelNodeHostAvailability};
pub use node::{GeneratedNodeCredentials, NodeRecord, NodeRecordApi};
pub use node_configuration::{NodeConfigurationSecretsPatch, validate_daemon_api_url};
pub use operation::DeleteInstanceOperation;

pub const DATABASES_TABLE: &str = "com_tomaxikz_databaseseverywhere_databases";
pub const LOCATION_HOSTS_TABLE: &str = "com_tomaxikz_databaseseverywhere_location_hosts";
pub const NODES_TABLE: &str = "com_tomaxikz_databaseseverywhere_nodes";
pub const PANEL_NODE_HOSTS_TABLE: &str = "com_tomaxikz_databaseseverywhere_panel_node_hosts";
pub const OPERATIONS_TABLE: &str = "com_tomaxikz_databaseseverywhere_operations";
