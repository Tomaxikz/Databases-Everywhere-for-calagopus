use garde::Validate;
use serde::{Deserialize, Serialize};
use shared::{
    State,
    models::{BaseModel, server::Server},
    response::DisplayError,
};
use sqlx::{Row, postgres::PgRow};
use utoipa::ToSchema;

use crate::{
    domain::{DatabaseProtocol, ServerDatabaseConfigurationExtension},
    persistence::NodeRecord,
};

const TABLE: &str = "com_tomaxikz_databaseseverywhere_shared_pools";

#[derive(Debug, Clone, Copy, Serialize, Deserialize, ToSchema, Validate, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct PoolLimits {
    #[garde(range(min = 0.01, max = 1024.0))]
    pub cpu_cores: f64,
    #[garde(range(min = 1, max = 1_048_576))]
    pub memory_mib: i64,
    #[garde(range(min = 1, max = 9_007_199_254_740_991))]
    pub disk_mib: i64,
    #[garde(range(min = 1, max = 1024))]
    pub max_tenants: i32,
}

impl Default for PoolLimits {
    fn default() -> Self {
        Self {
            cpu_cores: 1.0,
            memory_mib: 1024,
            disk_mib: 16384,
            max_tenants: 8,
        }
    }
}

#[derive(Debug, Clone, Serialize, ToSchema)]
pub struct SharedPool {
    pub server_id: uuid::Uuid,
    pub node_uuid: uuid::Uuid,
    pub protocol: DatabaseProtocol,
    pub runtime_id: Option<String>,
    pub status_url: Option<String>,
    pub limits: PoolLimits,
}

impl SharedPool {
    pub async fn configured(
        server: &Server,
        protocol: DatabaseProtocol,
        node: &NodeRecord,
    ) -> Result<Self, anyhow::Error> {
        let config = server.parse_model_extension::<ServerDatabaseConfigurationExtension>()?;
        Ok(Self {
            server_id: server.uuid,
            node_uuid: node.uuid,
            protocol,
            runtime_id: None,
            status_url: None,
            limits: config.pool_limits(node.default_pool_limits),
        })
    }

    pub async fn get(
        state: &State,
        server: uuid::Uuid,
        protocol: DatabaseProtocol,
    ) -> Result<Option<Self>, anyhow::Error> {
        let row = safe_query!(("SELECT * FROM {TABLE} WHERE server_uuid = $1 AND protocol = $2"))
            .bind(server)
            .bind(protocol.as_str())
            .fetch_optional(state.database.read())
            .await?;
        row.as_ref().map(Self::from_row).transpose()
    }

    pub async fn by_runtime(
        state: &State,
        server: uuid::Uuid,
        runtime_id: &str,
    ) -> Result<Option<Self>, anyhow::Error> {
        validate_runtime_id(runtime_id)?;
        let row = safe_query!(("SELECT * FROM {TABLE} WHERE server_uuid = $1 AND runtime_id = $2"))
            .bind(server)
            .bind(runtime_id)
            .fetch_optional(state.database.read())
            .await?;
        row.as_ref().map(Self::from_row).transpose()
    }

    pub async fn by_node_runtime(
        state: &State,
        node: uuid::Uuid,
        runtime_id: &str,
    ) -> Result<Option<Self>, anyhow::Error> {
        validate_runtime_id(runtime_id)?;
        let row =
            safe_query!(("SELECT * FROM {TABLE} WHERE dbev_node_uuid = $1 AND runtime_id = $2"))
                .bind(node)
                .bind(runtime_id)
                .fetch_optional(state.database.read())
                .await?;
        row.as_ref().map(Self::from_row).transpose()
    }

    pub async fn list(state: &State, server: uuid::Uuid) -> Result<Vec<Self>, anyhow::Error> {
        safe_query!(("SELECT * FROM {TABLE} WHERE server_uuid = $1 ORDER BY protocol"))
            .bind(server)
            .fetch_all(state.database.read())
            .await?
            .iter()
            .map(Self::from_row)
            .collect()
    }

    pub async fn list_for_node(
        state: &State,
        node: uuid::Uuid,
    ) -> Result<Vec<Self>, anyhow::Error> {
        safe_query!(
            ("SELECT * FROM {TABLE} WHERE dbev_node_uuid = $1 ORDER BY server_uuid, protocol")
        )
        .bind(node)
        .fetch_all(state.database.read())
        .await?
        .iter()
        .map(Self::from_row)
        .collect()
    }

    pub async fn pin(
        state: &State,
        server: &Server,
        protocol: DatabaseProtocol,
        node: &NodeRecord,
    ) -> Result<Self, anyhow::Error> {
        let configured = Self::configured(server, protocol, node).await?;
        safe_query!(("INSERT INTO {TABLE} (server_uuid, protocol, dbev_node_uuid, cpu_cores, memory_mib, disk_mib, max_databases)
            VALUES ($1, $2, $3, $4, $5, $6, $7) ON CONFLICT (server_uuid, protocol) DO NOTHING"))
            .bind(server.uuid)
            .bind(protocol.as_str())
            .bind(node.uuid)
            .bind(configured.limits.cpu_cores)
            .bind(configured.limits.memory_mib)
            .bind(configured.limits.disk_mib)
            .bind(configured.limits.max_tenants)
            .execute(state.database.write())
            .await?;
        let pool = Self::get(state, server.uuid, protocol)
            .await?
            .ok_or_else(|| DisplayError::new("shared pool mapping could not be loaded"))?;
        if pool.node_uuid != node.uuid {
            return Err(DisplayError::new(
                "this server's pool is mapped to another node; refresh before creating a database",
            )
            .with_status(axum::http::StatusCode::CONFLICT)
            .into());
        }
        Ok(pool)
    }

    /// Persist the claim before contacting DBEV. An ambiguous POST must never be retried
    /// by another worker (or after a panel restart) as a new engine creation.
    pub async fn claim_creation(&self, state: &State) -> Result<(), anyhow::Error> {
        let result = safe_query!(
            ("UPDATE {TABLE} SET creation_attempted = true
            WHERE server_uuid = $1 AND protocol = $2 AND dbev_node_uuid = $3
            AND runtime_id IS NULL AND creation_attempted = false")
        )
        .bind(self.server_id)
        .bind(self.protocol.as_str())
        .bind(self.node_uuid)
        .execute(state.database.write())
        .await?;
        if result.rows_affected() != 1 {
            return Err(DisplayError::new(
                "pool creation was already attempted; refresh its status or ask an operator to reconcile the original request"
            ).with_status(axum::http::StatusCode::CONFLICT).into());
        }
        Ok(())
    }

    pub async fn bind_runtime(
        &mut self,
        state: &State,
        runtime_id: &str,
        status_url: &str,
    ) -> Result<(), anyhow::Error> {
        validate_runtime_id(runtime_id)?;
        validate_status_url(status_url)?;
        let result = safe_query!(("UPDATE {TABLE} SET runtime_id = $4, status_url = $5
            WHERE server_uuid = $1 AND protocol = $2 AND dbev_node_uuid = $3 AND runtime_id IS NULL"))
            .bind(self.server_id)
            .bind(self.protocol.as_str())
            .bind(self.node_uuid)
            .bind(runtime_id)
            .bind(status_url)
            .execute(state.database.write())
            .await?;
        if result.rows_affected() != 1 {
            return Err(DisplayError::new(
                "pool runtime mapping changed while the parent was being created; operator reconciliation is required",
            )
            .with_status(axum::http::StatusCode::CONFLICT)
            .into());
        }
        self.runtime_id = Some(runtime_id.to_owned());
        self.status_url = Some(status_url.to_owned());
        Ok(())
    }

    pub async fn save_limits(
        &mut self,
        state: &State,
        limits: PoolLimits,
    ) -> Result<(), anyhow::Error> {
        let runtime_id = self.require_runtime()?.to_owned();
        let result = safe_query!(("UPDATE {TABLE} SET cpu_cores = $4, memory_mib = $5, disk_mib = $6, max_databases = $7
            WHERE server_uuid = $1 AND protocol = $2 AND dbev_node_uuid = $3 AND runtime_id = $8"))
            .bind(self.server_id)
            .bind(self.protocol.as_str())
            .bind(self.node_uuid)
            .bind(limits.cpu_cores)
            .bind(limits.memory_mib)
            .bind(limits.disk_mib)
            .bind(limits.max_tenants)
            .bind(runtime_id)
            .execute(state.database.write())
            .await?;
        if result.rows_affected() != 1 {
            return Err(anyhow::anyhow!(
                "pool limits could not be persisted; refresh and reconcile before further creation"
            ));
        }
        self.limits = limits;
        Ok(())
    }

    pub async fn delete_mapping(&self, state: &State) -> Result<(), anyhow::Error> {
        let runtime_id = self.require_runtime()?;
        safe_query!(
            ("DELETE FROM {TABLE} WHERE server_uuid = $1 AND protocol = $2
            AND dbev_node_uuid = $3 AND runtime_id = $4")
        )
        .bind(self.server_id)
        .bind(self.protocol.as_str())
        .bind(self.node_uuid)
        .bind(runtime_id)
        .execute(state.database.write())
        .await?;
        Ok(())
    }

    pub fn require_runtime(&self) -> Result<&str, anyhow::Error> {
        self.runtime_id.as_deref().ok_or_else(|| {
            DisplayError::new(
                "this pool has no DBEV 0.17 runtime mapping; create or reconcile its parent first",
            )
            .with_status(axum::http::StatusCode::CONFLICT)
            .into()
        })
    }

    pub fn verify_remote(
        &self,
        remote: &serde_json::Value,
        panel_id: &str,
    ) -> Result<(), anyhow::Error> {
        self.verify_identity(remote, panel_id)?;
        if remote.get("protocol").and_then(serde_json::Value::as_str)
            != Some(self.protocol.as_str())
        {
            return Err(DisplayError::new(
                "DBEV pool engine does not match its persistent mapping",
            )
            .with_status(axum::http::StatusCode::FORBIDDEN)
            .into());
        }
        Ok(())
    }

    pub fn verify_configuration(
        &self,
        remote: &serde_json::Value,
        panel_id: &str,
        limits: PoolLimits,
    ) -> Result<(), anyhow::Error> {
        self.verify_identity(remote, panel_id)?;
        if serde_json::from_value::<PoolLimits>(remote["limits"].clone()).ok() != Some(limits) {
            return Err(DisplayError::new("DBEV did not confirm the requested pool limits; operator reconciliation is required")
                .with_status(axum::http::StatusCode::BAD_GATEWAY).into());
        }
        Ok(())
    }

    fn verify_identity(
        &self,
        remote: &serde_json::Value,
        panel_id: &str,
    ) -> Result<(), anyhow::Error> {
        let runtime_id = self.require_runtime()?;
        let server_id = self.server_id.to_string();
        let matches = remote.get("runtime_id").and_then(serde_json::Value::as_str)
            == Some(runtime_id)
            && remote
                .pointer("/owner/server_id")
                .and_then(serde_json::Value::as_str)
                == Some(server_id.as_str())
            && remote
                .pointer("/owner/panel_id")
                .and_then(serde_json::Value::as_str)
                == Some(panel_id);
        if !matches {
            return Err(DisplayError::new(
                "DBEV pool ownership does not match the authorized server, engine, node and runtime mapping",
            )
            .with_status(axum::http::StatusCode::FORBIDDEN)
            .into());
        }
        Ok(())
    }

    pub fn create_payload(&self, image: Option<&str>) -> serde_json::Value {
        let mut payload = serde_json::json!({
            "server_id": self.server_id,
            "protocol": self.protocol,
            "limits": self.limits,
        });
        if let Some(image) = image {
            payload["image"] = serde_json::Value::String(image.to_owned());
        }
        payload
    }

    pub fn capacity_error(
        &self,
        tenant_count: i64,
        reserved_disk_mib: i64,
    ) -> Option<&'static str> {
        if tenant_count > i64::from(self.limits.max_tenants) {
            Some("the persistent pool has no remaining tenant capacity")
        } else if reserved_disk_mib > self.limits.disk_mib {
            Some("the persistent pool has no remaining disk allowance")
        } else {
            None
        }
    }

    fn from_row(row: &PgRow) -> Result<Self, anyhow::Error> {
        Ok(Self {
            server_id: row.try_get("server_uuid")?,
            node_uuid: row.try_get("dbev_node_uuid")?,
            protocol: row.try_get::<String, _>("protocol")?.parse()?,
            runtime_id: row.try_get("runtime_id")?,
            status_url: row.try_get("status_url")?,
            limits: PoolLimits {
                cpu_cores: row.try_get("cpu_cores")?,
                memory_mib: row.try_get("memory_mib")?,
                disk_mib: row.try_get("disk_mib")?,
                max_tenants: row.try_get("max_databases")?,
            },
        })
    }
}

pub fn validate_runtime_id(runtime_id: &str) -> Result<&str, anyhow::Error> {
    if runtime_id.trim().is_empty()
        || runtime_id.len() > 1024
        || runtime_id.chars().any(char::is_control)
    {
        return Err(DisplayError::new("invalid pool runtime ID")
            .with_status(axum::http::StatusCode::BAD_REQUEST)
            .into());
    }
    Ok(runtime_id)
}

pub fn validate_status_url(status_url: &str) -> Result<&str, anyhow::Error> {
    if !status_url.starts_with("/api/") || status_url.starts_with("//") {
        return Err(
            DisplayError::new("DBEV returned an invalid pool status URL")
                .with_status(axum::http::StatusCode::BAD_GATEWAY)
                .into(),
        );
    }
    Ok(status_url)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pool() -> SharedPool {
        SharedPool {
            server_id: uuid::Uuid::new_v4(),
            node_uuid: uuid::Uuid::new_v4(),
            protocol: DatabaseProtocol::Postgres,
            runtime_id: Some("pool-1".to_owned()),
            status_url: Some("/api/operations/pool-1".to_owned()),
            limits: PoolLimits {
                cpu_cores: 2.0,
                memory_mib: 2048,
                disk_mib: 16_384,
                max_tenants: 16,
            },
        }
    }

    #[test]
    fn node_pool_defaults_validate_as_complete_pool_limits() {
        let defaults = PoolLimits::default();
        assert!(shared::utils::validate_data(&defaults).is_ok());
        for limits in [
            PoolLimits {
                cpu_cores: 0.0,
                ..defaults
            },
            PoolLimits {
                cpu_cores: f64::INFINITY,
                ..defaults
            },
            PoolLimits {
                memory_mib: 0,
                ..defaults
            },
            PoolLimits {
                memory_mib: 1_048_577,
                ..defaults
            },
            PoolLimits {
                disk_mib: 0,
                ..defaults
            },
            PoolLimits {
                disk_mib: 9_007_199_254_740_992,
                ..defaults
            },
            PoolLimits {
                max_tenants: 0,
                ..defaults
            },
            PoolLimits {
                max_tenants: 1025,
                ..defaults
            },
        ] {
            assert!(shared::utils::validate_data(&limits).is_err(), "{limits:?}");
        }
        assert!(serde_json::from_value::<PoolLimits>(serde_json::json!({"cpu_cores": 2})).is_err());
        let mut unknown = serde_json::to_value(defaults).unwrap();
        unknown["instance_id"] = serde_json::json!("not-a-default");
        assert!(serde_json::from_value::<PoolLimits>(unknown).is_err());
    }

    #[test]
    fn ownership_requires_server_engine_and_runtime_to_match() {
        let pool = pool();
        let report = serde_json::json!({
            "runtime_id": "pool-1",
            "owner": { "server_id": pool.server_id, "panel_id": "panel-token-id" },
            "protocol": "postgres"
        });
        assert!(pool.verify_remote(&report, "panel-token-id").is_ok());
        for (field, value) in [
            ("runtime_id", serde_json::json!("pool-2")),
            (
                "owner",
                serde_json::json!({"server_id": uuid::Uuid::new_v4(), "panel_id": "panel-token-id"}),
            ),
            ("protocol", serde_json::json!("mysql")),
        ] {
            let mut mismatched = report.clone();
            mismatched[field] = value;
            assert!(pool.verify_remote(&mismatched, "panel-token-id").is_err());
        }
        assert!(pool.verify_remote(&report, "another-panel").is_err());
        assert!(
            pool.verify_remote(
                &serde_json::json!({"runtime_id": "pool-1", "protocol": "postgres", "owner": null}),
                "panel-token-id"
            )
            .is_err()
        );
        let config = serde_json::json!({"runtime_id": "pool-1", "owner": report["owner"], "limits": pool.limits});
        assert!(
            pool.verify_configuration(&config, "panel-token-id", pool.limits)
                .is_ok()
        );
        assert!(pool.verify_remote(&config, "panel-token-id").is_err());
    }

    #[test]
    fn capacity_never_creates_an_overflow_pool() {
        let pool = pool();
        assert_eq!(
            pool.capacity_error(17, 1024),
            Some("the persistent pool has no remaining tenant capacity")
        );
        assert_eq!(
            pool.capacity_error(16, 16_385),
            Some("the persistent pool has no remaining disk allowance")
        );
        assert_eq!(pool.capacity_error(16, 16_384), None);
    }

    #[test]
    fn pool_create_contract_contains_no_implicit_instance_limits() {
        let pool = pool();
        assert_eq!(
            pool.create_payload(Some("postgres:17")),
            serde_json::json!({
                "server_id": pool.server_id,
                "protocol": "postgres",
                "limits": { "cpu_cores": 2.0, "memory_mib": 2048, "disk_mib": 16384, "max_tenants": 16 },
                "image": "postgres:17"
            })
        );
    }
}
