use crate::{
    dbev::{DbevCapabilities, mutation_contract_block_reason},
    domain::{DatabaseProtocol, DeploymentMode, NodeDeploymentPolicy, ResourceLimits},
    persistence::{DATABASES_TABLE, NodeRecord},
};
use serde::Serialize;
use shared::State;
use sqlx::{Row, postgres::PgRow};
use std::str::FromStr;
use utoipa::ToSchema;

#[derive(Debug, Clone)]
pub struct DatabaseRecord {
    pub uuid: uuid::Uuid,
    pub server_uuid: uuid::Uuid,
    pub dbev_node_uuid: uuid::Uuid,
    pub protocol: DatabaseProtocol,
    pub deployment_mode: DeploymentMode,
    pub runtime_id: String,
    pub quota_reserved: bool,
    pub migration_target_mode: Option<DeploymentMode>,
    pub deployment_migration: Option<serde_json::Value>,
    pub display_name: String,
    pub database_name: String,
    pub username: String,
    pub password: Vec<u8>,
    pub public_host: String,
    pub public_port: i32,
    pub tls: bool,
    pub status: String,
    pub image: Option<String>,
    pub cpu_cores: f64,
    pub memory_mib: i64,
    pub disk_mib: i64,
    pub limits_sync_pending: bool,
    pub last_error: Option<String>,
    pub metadata: serde_json::Value,
    pub created: chrono::DateTime<chrono::Utc>,
    pub updated: chrono::DateTime<chrono::Utc>,
}

#[derive(Debug, Clone, Serialize, ToSchema)]
pub struct DatabaseRecordApi {
    pub uuid: uuid::Uuid,
    pub node_uuid: uuid::Uuid,
    pub protocol: DatabaseProtocol,
    pub protocol_label: &'static str,
    pub deployment_mode: DeploymentMode,
    pub runtime_id: String,
    pub quota_reserved: bool,
    pub deployment_migration: Option<serde_json::Value>,
    pub migration_active: bool,
    pub node_deployment_policy: Option<NodeDeploymentPolicy>,
    pub available_migration_targets: Vec<DeploymentMode>,
    pub display_name: String,
    pub database_name: String,
    pub username: String,
    pub password: Option<String>,
    pub public_host: String,
    pub public_port: i32,
    pub tls: bool,
    pub connection_uri: Option<String>,
    pub status: String,
    pub image: Option<String>,
    pub default_image: Option<String>,
    pub allowed_images: Vec<String>,
    pub stream_exports_only: bool,
    pub max_artifacts_per_instance: u32,
    pub mutations_allowed: bool,
    pub mutation_block_reason: Option<String>,
    pub remote_import_enabled: bool,
    pub remote_import_allow_plaintext: bool,
    pub limits: ResourceLimits,
    pub limits_sync_pending: bool,
    pub last_error: Option<String>,
    pub metadata: serde_json::Value,
    pub created: chrono::DateTime<chrono::Utc>,
    pub updated: chrono::DateTime<chrono::Utc>,
}

impl DatabaseRecord {
    fn map(row: &PgRow) -> Result<Self, anyhow::Error> {
        let protocol: String = row.try_get("protocol")?;
        let deployment_mode: String = row.try_get("deployment_mode")?;
        let migration_target_mode = row
            .try_get::<Option<String>, _>("migration_target_mode")?
            .map(|value| DeploymentMode::from_str(&value))
            .transpose()?;
        Ok(Self {
            uuid: row.try_get("uuid")?,
            server_uuid: row.try_get("server_uuid")?,
            dbev_node_uuid: row.try_get("dbev_node_uuid")?,
            protocol: DatabaseProtocol::from_str(&protocol)?,
            deployment_mode: DeploymentMode::from_str(&deployment_mode)?,
            runtime_id: row.try_get("runtime_id")?,
            quota_reserved: row.try_get("quota_reserved")?,
            migration_target_mode,
            deployment_migration: row.try_get("deployment_migration")?,
            display_name: row.try_get("display_name")?,
            database_name: row.try_get("database_name")?,
            username: row.try_get("username")?,
            password: row.try_get("password")?,
            public_host: row.try_get("public_host")?,
            public_port: row.try_get("public_port")?,
            tls: row.try_get("tls")?,
            status: row.try_get("status")?,
            image: row.try_get("image")?,
            cpu_cores: row.try_get("cpu_cores")?,
            memory_mib: row.try_get("memory_mib")?,
            disk_mib: row.try_get("disk_mib")?,
            limits_sync_pending: row.try_get("limits_sync_pending")?,
            last_error: row.try_get("last_error")?,
            metadata: row.try_get("metadata")?,
            created: row.try_get("created")?,
            updated: row.try_get("updated")?,
        })
    }

    pub fn instance_id(&self) -> String {
        self.uuid.to_string()
    }

    pub fn creation_pending(&self) -> bool {
        self.metadata
            .get("panel_creation_pending")
            .and_then(serde_json::Value::as_bool)
            == Some(true)
    }

    pub fn status_url(&self) -> String {
        self.metadata
            .get("status_url")
            .and_then(serde_json::Value::as_str)
            .filter(|location| location.starts_with("/api/") && !location.starts_with("//"))
            .map(str::to_owned)
            .unwrap_or_else(|| format!("/api/instances/{}/status", self.instance_id()))
    }

    pub fn limits(&self) -> ResourceLimits {
        ResourceLimits {
            cpu_cores: self.cpu_cores,
            memory_mib: self.memory_mib,
            disk_mib: self.disk_mib,
        }
    }

    pub fn migration_active(&self) -> bool {
        self.deployment_migration
            .as_ref()
            .is_some_and(deployment_migration_active)
    }

    pub async fn decrypted_password(&self, state: &State) -> Result<String, anyhow::Error> {
        Ok(state
            .database
            .decrypt(self.password.clone())
            .await?
            .to_string())
    }

    pub async fn into_api(
        self,
        state: &State,
        include_password: bool,
    ) -> Result<DatabaseRecordApi, anyhow::Error> {
        let password = if include_password {
            Some(self.decrypted_password(state).await?)
        } else {
            None
        };
        let connection_uri = password
            .as_deref()
            .and_then(|password| self.connection_uri(password).ok());
        let protocol_label = self.protocol.label();
        let limits = self.limits();
        let migration_active = self.migration_active();
        let node = NodeRecord::by_uuid(state, self.dbev_node_uuid).await?;
        let default_image = node
            .as_ref()
            .and_then(|node| node.default_image(self.protocol));
        let allowed_images = node
            .as_ref()
            .map(|node| node.allowed_images(self.protocol))
            .unwrap_or_default();
        let stream_exports_only = node.as_ref().is_some_and(NodeRecord::stream_exports_only);
        let max_artifacts_per_instance = node
            .as_ref()
            .map(NodeRecord::max_artifacts_per_instance)
            .unwrap_or(20);
        let mutation_block_reason = migration_active
            .then(|| {
                "A dedicated/shared migration is active. Database mutations are disabled until it reaches a terminal state."
                    .to_owned()
            })
            .or_else(|| node
            .as_ref()
            .and_then(|node| mutation_contract_block_reason(node.cached_system.as_ref()))
            .or_else(|| {
                node.is_none()
                    .then(|| "The DatabasesEverywhere node no longer exists.".to_owned())
            }));
        let node_deployment_policy = node.as_ref().map(|node| node.deployment_policy);
        let available_migration_targets = node
            .as_ref()
            .filter(|node| node.deployment_policy == NodeDeploymentPolicy::Hybrid)
            .and_then(|node| node.cached_system.as_ref())
            .map(DbevCapabilities::from_system)
            .map(|capabilities| {
                DeploymentMode::ALL
                    .into_iter()
                    .filter(|mode| {
                        *mode != self.deployment_mode
                            && capabilities.supports_deployment(self.protocol, *mode)
                    })
                    .collect()
            })
            .unwrap_or_default();
        let remote_import_enabled = node
            .as_ref()
            .and_then(|node| node.cached_system.as_ref())
            .and_then(|system| system.get("remote_import_enabled"))
            .and_then(serde_json::Value::as_bool)
            .unwrap_or(false);
        let remote_import_allow_plaintext = remote_import_enabled
            && node
                .as_ref()
                .and_then(|node| {
                    node.configuration
                        .pointer("/security/remote_import/allow_plaintext")
                })
                .and_then(serde_json::Value::as_bool)
                .unwrap_or(false);

        Ok(DatabaseRecordApi {
            uuid: self.uuid,
            node_uuid: self.dbev_node_uuid,
            protocol: self.protocol,
            protocol_label,
            deployment_mode: self.deployment_mode,
            runtime_id: self.runtime_id,
            quota_reserved: self.quota_reserved,
            deployment_migration: self.deployment_migration,
            migration_active,
            node_deployment_policy,
            available_migration_targets,
            display_name: self.display_name,
            database_name: self.database_name,
            username: self.username,
            password,
            public_host: self.public_host,
            public_port: self.public_port,
            tls: self.tls,
            connection_uri,
            status: self.status,
            image: self.image,
            default_image,
            allowed_images,
            stream_exports_only,
            max_artifacts_per_instance,
            mutations_allowed: mutation_block_reason.is_none(),
            mutation_block_reason,
            remote_import_enabled,
            remote_import_allow_plaintext,
            limits,
            limits_sync_pending: self.limits_sync_pending,
            last_error: self.last_error,
            metadata: self.metadata,
            created: self.created,
            updated: self.updated,
        })
    }

    fn connection_uri(&self, password: &str) -> Result<String, anyhow::Error> {
        let host = if self.public_host.contains(':') && !self.public_host.starts_with('[') {
            format!("[{}]", self.public_host)
        } else {
            self.public_host.clone()
        };
        if self.protocol == DatabaseProtocol::Qdrant {
            return Ok(format!(
                "{}://{host}:{}",
                if self.tls { "grpcs" } else { "grpc" },
                self.public_port,
            ));
        }

        let scheme = match self.protocol {
            DatabaseProtocol::Postgres => "postgresql",
            DatabaseProtocol::Mysql => "mysql",
            DatabaseProtocol::Mariadb => "mariadb",
            DatabaseProtocol::Redis => {
                if self.tls {
                    "rediss"
                } else {
                    "redis"
                }
            }
            DatabaseProtocol::Valkey => {
                if self.tls {
                    "rediss"
                } else {
                    "redis"
                }
            }
            DatabaseProtocol::Mongodb => "mongodb",
            DatabaseProtocol::Clickhouse => {
                if self.tls {
                    "clickhouses"
                } else {
                    "clickhouse"
                }
            }
            DatabaseProtocol::Qdrant => unreachable!("Qdrant handled above"),
        };
        let database = if matches!(
            self.protocol,
            DatabaseProtocol::Redis | DatabaseProtocol::Valkey
        ) {
            "0"
        } else {
            &self.database_name
        };
        Ok(format!(
            "{scheme}://{}:{}@{host}:{}/{}",
            urlencoding::encode(&self.username),
            urlencoding::encode(password),
            self.public_port,
            urlencoding::encode(database),
        ))
    }

    pub async fn all_for_server(
        state: &State,
        server_uuid: uuid::Uuid,
    ) -> Result<Vec<Self>, anyhow::Error> {
        let rows = safe_query!(
            ("SELECT * FROM {DATABASES_TABLE} WHERE server_uuid = $1 ORDER BY created")
        )
        .bind(server_uuid)
        .fetch_all(state.database.read())
        .await?;
        rows.iter().map(Self::map).collect()
    }

    pub async fn pending_limit_sync(state: &State) -> Result<Vec<Self>, anyhow::Error> {
        let rows = safe_query!((
            "SELECT * FROM {DATABASES_TABLE} WHERE limits_sync_pending = true AND quota_reserved = true AND migration_target_mode IS NULL ORDER BY updated LIMIT 50"
        ))
        .fetch_all(state.database.read())
        .await?;
        rows.iter().map(Self::map).collect()
    }

    pub async fn pending_lifecycle_refresh(state: &State) -> Result<Vec<Self>, anyhow::Error> {
        let rows = safe_query!((
            "SELECT * FROM {DATABASES_TABLE} WHERE quota_reserved = true AND (metadata @> '{{\"panel_creation_pending\": true}}'::jsonb OR status IN ('creating', 'booting') OR migration_target_mode IS NOT NULL) ORDER BY updated LIMIT 100"
        ))
        .fetch_all(state.database.read())
        .await?;
        rows.iter().map(Self::map).collect()
    }

    pub async fn by_server_uuid(
        state: &State,
        server_uuid: uuid::Uuid,
        uuid: uuid::Uuid,
    ) -> Result<Option<Self>, anyhow::Error> {
        let row =
            safe_query!(("SELECT * FROM {DATABASES_TABLE} WHERE server_uuid = $1 AND uuid = $2"))
                .bind(server_uuid)
                .bind(uuid)
                .fetch_optional(state.database.read())
                .await?;
        row.as_ref().map(Self::map).transpose()
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn create(
        state: &State,
        uuid: uuid::Uuid,
        server_uuid: uuid::Uuid,
        node_uuid: uuid::Uuid,
        protocol: DatabaseProtocol,
        deployment_mode: DeploymentMode,
        display_name: &str,
        database_name: &str,
        username: &str,
        password: &str,
        public_host: &str,
        public_port: i32,
        tls: bool,
        status: &str,
        image: Option<&str>,
        limits: ResourceLimits,
        metadata: serde_json::Value,
    ) -> Result<Self, anyhow::Error> {
        let encrypted_password = state.database.encrypt(password.to_owned()).await?;
        // Serialize quota reservations for one server before the INSERT trigger counts
        // existing reservations. Using a separate statement gives PostgreSQL a fresh
        // READ COMMITTED snapshot after any competing reservation commits.
        let mut transaction = state.database.write().begin().await?;
        sqlx::query_scalar::<_, uuid::Uuid>("SELECT uuid FROM servers WHERE uuid = $1 FOR UPDATE")
            .bind(server_uuid)
            .fetch_one(&mut *transaction)
            .await?;
        let row = safe_query!((r#"
            INSERT INTO {DATABASES_TABLE}
                (uuid, server_uuid, dbev_node_uuid, protocol, deployment_mode, runtime_id,
                 display_name, database_name,
                 username, password, public_host, public_port, tls, status, image,
                 cpu_cores, memory_mib, disk_mib, metadata)
            VALUES ($1, $2, $3, $4, $5, '', $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
            RETURNING *
            "#,))
        .bind(uuid)
        .bind(server_uuid)
        .bind(node_uuid)
        .bind(protocol.as_str())
        .bind(deployment_mode.as_str())
        .bind(display_name)
        .bind(database_name)
        .bind(username)
        .bind(encrypted_password)
        .bind(public_host)
        .bind(public_port)
        .bind(tls)
        .bind(status)
        .bind(image)
        .bind(limits.cpu_cores)
        .bind(limits.memory_mib)
        .bind(limits.disk_mib)
        .bind(metadata)
        .fetch_one(&mut *transaction)
        .await
        .map_err(map_placement_quota_error)?;
        let record = Self::map(&row)?;
        transaction.commit().await?;
        Ok(record)
    }

    pub async fn update_remote_state(
        &self,
        state: &State,
        remote: &serde_json::Value,
    ) -> Result<(), anyhow::Error> {
        // Lifecycle responses wrap the authoritative metadata in `instance`.
        let instance = remote_instance(remote);
        let status = remote_status(remote).unwrap_or(&self.status);
        let image = instance
            .pointer("/image/current")
            .and_then(serde_json::Value::as_str)
            .or_else(|| remote.get("image").and_then(serde_json::Value::as_str))
            .or(self.image.as_deref());
        let (deployment_mode, runtime_id) = if self.migration_active() {
            (self.deployment_mode, self.runtime_id.as_str())
        } else {
            (
                instance
                    .get("deployment_mode")
                    .and_then(serde_json::Value::as_str)
                    .and_then(|value| DeploymentMode::from_str(value).ok())
                    .unwrap_or(self.deployment_mode),
                remote_runtime_id(remote).unwrap_or(&self.runtime_id),
            )
        };
        let mut metadata = merge_remote_metadata(&self.metadata, instance);
        if let Some(status_url) = remote_status_location(remote) {
            metadata["status_url"] = serde_json::Value::String(status_url.to_owned());
        }
        let creation_pending = self.creation_pending();
        if creation_pending {
            let completed_with_runtime = !matches!(status, "creating" | "booting" | "failed")
                && !runtime_id.trim().is_empty();
            metadata["panel_creation_pending"] =
                serde_json::Value::Bool(status != "failed" && !completed_with_runtime);
        }
        let last_error = remote
            .pointer("/progress/diagnostic/message")
            .or_else(|| remote.pointer("/diagnostic/message"))
            .or_else(|| remote.pointer("/failure/message"))
            .or_else(|| remote.pointer("/result/progress/diagnostic/message"))
            .or_else(|| remote.pointer("/result/diagnostic/message"))
            .or_else(|| remote.pointer("/result/failure/message"))
            .or_else(|| remote.pointer("/operation/diagnostic/message"))
            .or_else(|| remote.pointer("/operation/failure/message"))
            .or_else(|| instance.pointer("/diagnostic/message"))
            .or_else(|| instance.pointer("/failure/message"))
            .and_then(serde_json::Value::as_str)
            .filter(|message| !message.trim().is_empty());
        let definitive_creation_failure = creation_pending && status == "failed";

        safe_query!((r#"
            UPDATE {DATABASES_TABLE}
            SET status = $2, image = $3, metadata = $4, last_error = $5,
                deployment_mode = $6, runtime_id = $7,
                quota_reserved = CASE WHEN $8 THEN false ELSE quota_reserved END,
                updated = now()
            WHERE uuid = $1
            "#,))
        .bind(self.uuid)
        .bind(status)
        .bind(image)
        .bind(metadata)
        .bind(last_error)
        .bind(deployment_mode.as_str())
        .bind(runtime_id)
        .bind(definitive_creation_failure)
        .execute(state.database.write())
        .await?;
        Ok(())
    }

    pub async fn update_limits(
        &self,
        state: &State,
        limits: ResourceLimits,
        synchronized: bool,
    ) -> Result<(), anyhow::Error> {
        safe_query!((r#"
            UPDATE {DATABASES_TABLE}
            SET cpu_cores = $2, memory_mib = $3, disk_mib = $4,
                limits_sync_pending = $5, last_error = NULL, updated = now()
            WHERE uuid = $1
            "#,))
        .bind(self.uuid)
        .bind(limits.cpu_cores)
        .bind(limits.memory_mib)
        .bind(limits.disk_mib)
        .bind(!synchronized)
        .execute(state.database.write())
        .await?;
        Ok(())
    }

    pub async fn update_password(
        &self,
        state: &State,
        password: &str,
    ) -> Result<(), anyhow::Error> {
        let encrypted_password = state.database.encrypt(password.to_owned()).await?;
        safe_query!((
            "UPDATE {DATABASES_TABLE} SET password = $2, last_error = NULL, updated = now() WHERE uuid = $1"
        ))
        .bind(self.uuid)
        .bind(encrypted_password)
        .execute(state.database.write())
        .await?;
        Ok(())
    }

    pub async fn store_error(&self, state: &State, error: &str) -> Result<(), anyhow::Error> {
        safe_query!(
            ("UPDATE {DATABASES_TABLE} SET last_error = $2, updated = now() WHERE uuid = $1")
        )
        .bind(self.uuid)
        .bind(error)
        .execute(state.database.write())
        .await?;
        Ok(())
    }

    pub async fn release_quota_with_error(
        &self,
        state: &State,
        error: &str,
    ) -> Result<(), anyhow::Error> {
        safe_query!((
            "UPDATE {DATABASES_TABLE} SET status = 'failed', quota_reserved = false, migration_target_mode = NULL, metadata = jsonb_set(metadata, '{{panel_creation_pending}}', 'false'::jsonb, true), last_error = $2, updated = now() WHERE uuid = $1"
        ))
        .bind(self.uuid)
        .bind(error)
        .execute(state.database.write())
        .await?;
        Ok(())
    }

    pub async fn reserve_migration_target(
        &self,
        state: &State,
        target: DeploymentMode,
        migration: &serde_json::Value,
    ) -> Result<(), anyhow::Error> {
        if target == self.deployment_mode {
            return Err(shared::response::DisplayError::new(
                "the database already uses the requested deployment mode",
            )
            .with_status(axum::http::StatusCode::CONFLICT)
            .into());
        }
        let mut transaction = state.database.write().begin().await?;
        sqlx::query_scalar::<_, uuid::Uuid>("SELECT uuid FROM servers WHERE uuid = $1 FOR UPDATE")
            .bind(self.server_uuid)
            .fetch_one(&mut *transaction)
            .await?;
        let result = safe_query!((r#"
            UPDATE {DATABASES_TABLE}
            SET migration_target_mode = $2, deployment_migration = $3, updated = now()
            WHERE uuid = $1 AND migration_target_mode IS NULL
            "#,))
        .bind(self.uuid)
        .bind(target.as_str())
        .bind(migration)
        .execute(&mut *transaction)
        .await
        .map_err(map_placement_quota_error)?;
        if result.rows_affected() != 1 {
            transaction.rollback().await?;
            return Err(shared::response::DisplayError::new(
                "a dedicated/shared migration is already active",
            )
            .with_status(axum::http::StatusCode::CONFLICT)
            .into());
        }
        transaction.commit().await?;
        Ok(())
    }

    pub async fn store_deployment_migration(
        &self,
        state: &State,
        migration: &serde_json::Value,
    ) -> Result<(), anyhow::Error> {
        safe_query!((
            "UPDATE {DATABASES_TABLE} SET deployment_migration = $2, updated = now() WHERE uuid = $1"
        ))
        .bind(self.uuid)
        .bind(migration)
        .execute(state.database.write())
        .await?;
        Ok(())
    }

    pub async fn finish_deployment_migration(
        &self,
        state: &State,
        migration: &serde_json::Value,
    ) -> Result<(), anyhow::Error> {
        let status = migration_status(migration).unwrap_or("failed");
        if status == "completed" {
            let target = self
                .migration_target_mode
                .or_else(|| {
                    migration
                        .get("target_mode")
                        .or_else(|| migration.pointer("/migration/target_mode"))
                        .or_else(|| migration.pointer("/result/target_mode"))
                        .or_else(|| migration.pointer("/result/migration/target_mode"))
                        .and_then(serde_json::Value::as_str)
                        .and_then(|value| DeploymentMode::from_str(value).ok())
                })
                .ok_or_else(|| anyhow::anyhow!("deployment migration target is missing"))?;
            let runtime_id = remote_runtime_id(migration).ok_or_else(|| {
                anyhow::anyhow!("completed deployment migration is missing runtime_id")
            })?;
            let mut metadata = self.metadata.as_object().cloned().unwrap_or_default();
            if target == DeploymentMode::Shared {
                let pool_id = migration
                    .get("pool_id")
                    .and_then(serde_json::Value::as_str)
                    .filter(|value| !value.trim().is_empty())
                    .ok_or_else(|| {
                        anyhow::anyhow!("completed shared deployment migration is missing pool_id")
                    })?;
                metadata.insert(
                    "pool_id".to_owned(),
                    serde_json::Value::String(pool_id.to_owned()),
                );
            } else {
                metadata.remove("pool_id");
            }
            safe_query!((r#"
                UPDATE {DATABASES_TABLE}
                SET deployment_mode = $2, runtime_id = $3, migration_target_mode = NULL,
                    deployment_migration = $4, metadata = $5, last_error = NULL, updated = now()
                WHERE uuid = $1
                "#,))
            .bind(self.uuid)
            .bind(target.as_str())
            .bind(runtime_id)
            .bind(migration)
            .bind(serde_json::Value::Object(metadata))
            .execute(state.database.write())
            .await
            .map_err(map_placement_quota_error)?;
        } else {
            let error = migration
                .pointer("/diagnostic/message")
                .or_else(|| migration.pointer("/failure/message"))
                .or_else(|| migration.pointer("/migration/diagnostic/message"))
                .or_else(|| migration.pointer("/migration/failure/message"))
                .or_else(|| migration.pointer("/result/diagnostic/message"))
                .or_else(|| migration.pointer("/result/failure/message"))
                .or_else(|| migration.pointer("/result/migration/diagnostic/message"))
                .or_else(|| migration.pointer("/result/migration/failure/message"))
                .and_then(serde_json::Value::as_str);
            safe_query!((r#"
                UPDATE {DATABASES_TABLE}
                SET migration_target_mode = NULL, deployment_migration = $2,
                    last_error = COALESCE($3, last_error), updated = now()
                WHERE uuid = $1
                "#,))
            .bind(self.uuid)
            .bind(migration)
            .bind(error)
            .execute(state.database.write())
            .await?;
        }
        Ok(())
    }

    pub async fn placement_usage(
        state: &State,
        server_uuid: uuid::Uuid,
        mode: DeploymentMode,
    ) -> Result<i64, anyhow::Error> {
        Ok(safe_query_scalar!((r#"
            SELECT COUNT(*)
            FROM {DATABASES_TABLE}
            WHERE server_uuid = $1
              AND (
                (quota_reserved = true AND deployment_mode = $2)
                OR migration_target_mode = $2
              )
            "#,))
        .bind(server_uuid)
        .bind(mode.as_str())
        .fetch_one(state.database.read())
        .await?)
    }

    pub async fn delete_local(&self, state: &State) -> Result<(), anyhow::Error> {
        safe_query!(("DELETE FROM {DATABASES_TABLE} WHERE uuid = $1"))
            .bind(self.uuid)
            .execute(state.database.write())
            .await?;
        Ok(())
    }
}

pub(crate) fn migration_status(migration: &serde_json::Value) -> Option<&str> {
    migration
        .get("status")
        .or_else(|| migration.pointer("/migration/status"))
        .or_else(|| migration.pointer("/result/status"))
        .or_else(|| migration.pointer("/result/migration/status"))
        .or_else(|| migration.pointer("/operation/status"))
        .and_then(serde_json::Value::as_str)
}

fn deployment_migration_active(migration: &serde_json::Value) -> bool {
    !matches!(
        migration_status(migration),
        Some("completed" | "failed" | "cancelled" | "manual_intervention")
    )
}

fn map_placement_quota_error(error: sqlx::Error) -> anyhow::Error {
    if let sqlx::Error::Database(database) = &error
        && database.code().as_deref() == Some("23514")
        && database.message().contains("maximum number of")
    {
        return shared::response::DisplayError::new(database.message().to_owned())
            .with_status(axum::http::StatusCode::CONFLICT)
            .into();
    }
    error.into()
}

pub(crate) fn remote_instance(remote: &serde_json::Value) -> &serde_json::Value {
    const INSTANCE_POINTERS: &[&str] = &[
        "/instance",
        "/result/instance",
        "/operation/instance",
        "/migration/instance",
        "/migration/result/instance",
    ];

    INSTANCE_POINTERS
        .iter()
        .find_map(|pointer| remote.pointer(pointer).filter(|value| value.is_object()))
        .or_else(|| {
            remote
                .get("result")
                .filter(|value| value.is_object() && instance_like(value))
        })
        .unwrap_or(remote)
}

pub(crate) fn remote_status(remote: &serde_json::Value) -> Option<&str> {
    let status = remote_instance(remote)
        .get("status")
        .and_then(serde_json::Value::as_str)
        .filter(|status| instance_status(status))
        .or_else(|| {
            remote
                .get("status")
                .and_then(serde_json::Value::as_str)
                .filter(|status| instance_status(status))
        });
    status
}

pub(crate) fn remote_operation_completed(remote: &serde_json::Value) -> bool {
    [
        "/status",
        "/operation/status",
        "/result/status",
        "/progress/status",
    ]
    .into_iter()
    .filter_map(|pointer| remote.pointer(pointer).and_then(serde_json::Value::as_str))
    .any(|status| matches!(status, "completed" | "succeeded" | "success"))
}

fn instance_status(status: &str) -> bool {
    matches!(
        status,
        "creating" | "booting" | "running" | "stopped" | "failed" | "quarantined" | "deleting"
    )
}

pub(crate) fn remote_runtime_id(remote: &serde_json::Value) -> Option<&str> {
    const RUNTIME_POINTERS: &[&str] = &[
        "/runtime_id",
        "/instance/runtime_id",
        "/result/runtime_id",
        "/result/instance/runtime_id",
        "/operation/runtime_id",
        "/operation/instance/runtime_id",
        "/migration/runtime_id",
        "/migration/instance/runtime_id",
        "/migration/result/runtime_id",
        "/migration/result/instance/runtime_id",
    ];

    RUNTIME_POINTERS.iter().find_map(|pointer| {
        remote
            .pointer(pointer)
            .and_then(serde_json::Value::as_str)
            .filter(|value| !value.trim().is_empty())
    })
}

pub(crate) fn remote_status_location(remote: &serde_json::Value) -> Option<&str> {
    const STATUS_POINTERS: &[&str] = &[
        "/status_url",
        "/instance/status_url",
        "/result/status_url",
        "/result/instance/status_url",
        "/operation/status_url",
        "/operation/instance/status_url",
    ];

    STATUS_POINTERS.iter().find_map(|pointer| {
        remote
            .pointer(pointer)
            .and_then(serde_json::Value::as_str)
            .filter(|location| location.starts_with("/api/") && !location.starts_with("//"))
    })
}

fn instance_like(value: &serde_json::Value) -> bool {
    value.get("instance_id").is_some()
        || value.get("runtime_id").is_some()
        || value.get("deployment_mode").is_some()
}

fn merge_remote_metadata(
    existing: &serde_json::Value,
    remote: &serde_json::Value,
) -> serde_json::Value {
    let mut merged = existing.as_object().cloned().unwrap_or_default();
    if let Some(remote) = remote.as_object() {
        merged.extend(remote.clone());
    }
    serde_json::Value::Object(merged)
}

#[cfg(test)]
mod tests {
    use super::{
        merge_remote_metadata, migration_status, remote_instance, remote_operation_completed,
        remote_runtime_id, remote_status, remote_status_location,
    };

    #[test]
    fn unwraps_lifecycle_instance_metadata() {
        let response = serde_json::json!({
            "action": "restart",
            "instance": {
                "status": "running",
                "image": { "current": "mysql:8.4" }
            }
        });

        assert_eq!(remote_instance(&response)["status"], "running");
        assert_eq!(remote_instance(&response)["image"]["current"], "mysql:8.4");
    }

    #[test]
    fn keeps_unwrapped_remote_metadata() {
        let response = serde_json::json!({ "status": "stopped" });
        assert_eq!(remote_instance(&response)["status"], "stopped");
    }

    #[test]
    fn unwraps_result_instance_and_runtime_metadata() {
        let response = serde_json::json!({
            "status": "completed",
            "result": {
                "instance": {
                    "instance_id": "database-1",
                    "runtime_id": "shared:mysql:pool-1:tenant-8",
                    "status": "running"
                }
            }
        });

        assert_eq!(remote_status(&response), Some("running"));
        assert_eq!(
            remote_runtime_id(&response),
            Some("shared:mysql:pool-1:tenant-8")
        );
    }

    #[test]
    fn preserves_safe_wrapped_creation_status_locations() {
        let response = serde_json::json!({
            "status_url": "/api/operations/create-1",
            "instance": {
                "instance_id": "database-1",
                "status": "creating"
            }
        });
        assert_eq!(
            remote_status_location(&response),
            Some("/api/operations/create-1")
        );
        assert_eq!(
            remote_status_location(&serde_json::json!({
                "status_url": "https://attacker.invalid/api/operations/create-1"
            })),
            None
        );
    }

    #[test]
    fn keeps_operation_statuses_out_of_instance_status() {
        let operation = serde_json::json!({
            "status": "completed",
            "runtime_id": "shared:mysql:pool-1:tenant-8"
        });
        assert_eq!(remote_status(&operation), None);
        assert!(remote_operation_completed(&operation));
    }

    #[test]
    fn reads_wrapped_migration_status_and_runtime_id() {
        let response = serde_json::json!({
            "result": {
                "migration": { "status": "completed" },
                "runtime_id": "dedicated:database-1"
            }
        });

        assert_eq!(migration_status(&response), Some("completed"));
        assert_eq!(remote_runtime_id(&response), Some("dedicated:database-1"));
    }

    #[test]
    fn partial_status_responses_preserve_runtime_metadata() {
        let existing = serde_json::json!({
            "status": "running",
            "image": { "current": "mysql:8.4", "update_available": false },
            "api_version": "v1"
        });
        let status = serde_json::json!({ "instance_id": "database-1", "status": "stopped" });

        let merged = merge_remote_metadata(&existing, &status);
        assert_eq!(merged["status"], "stopped");
        assert_eq!(merged["image"]["current"], "mysql:8.4");
        assert_eq!(merged["api_version"], "v1");
    }
}
