use shared::response::DisplayError;

mod defaults;
mod secrets;
#[cfg(test)]
mod tests;
mod validation;

pub use defaults::default_daemon_configuration;
pub(super) use secrets::embedded_configuration_secrets;
use secrets::take_embedded_secrets;
pub use secrets::{
    NodeConfigurationSecrets, NodeConfigurationSecretsPatch, apply_configuration_secrets,
    public_daemon_configuration,
};
use validation::{valid_dns_hostname, validate_daemon_configuration};

pub fn normalize_daemon_configuration(
    mut configuration: serde_json::Value,
) -> Result<(serde_json::Value, NodeConfigurationSecrets), anyhow::Error> {
    if !configuration.is_object() {
        return Err(DisplayError::new("node configuration must be a JSON object").into());
    }

    for protected in ["remote", "uuid", "token_id", "token", "jwt_signing_key"] {
        configuration.as_object_mut().unwrap().remove(protected);
    }
    remove_obsolete_api_identity_fields(&mut configuration);
    // Preserve absent v0.5.2 keys when editing an older stored configuration.
    let existing_artifacts = configuration
        .get("artifacts")
        .and_then(serde_json::Value::as_object);
    let preserve_missing_stream_exports_only =
        existing_artifacts.is_some_and(|artifacts| !artifacts.contains_key("stream_exports_only"));
    let preserve_missing_max_artifacts_per_instance = existing_artifacts
        .is_some_and(|artifacts| !artifacts.contains_key("max_artifacts_per_instance"));
    let embedded_secrets = take_embedded_secrets(&mut configuration);
    let mut normalized = default_daemon_configuration();
    merge_configuration(&mut normalized, &configuration);
    if let Some(artifacts) = normalized
        .get_mut("artifacts")
        .and_then(serde_json::Value::as_object_mut)
    {
        if preserve_missing_stream_exports_only {
            artifacts.remove("stream_exports_only");
        }
        if preserve_missing_max_artifacts_per_instance {
            artifacts.remove("max_artifacts_per_instance");
        }
    }
    normalize_legacy_disk_mode(&mut normalized);
    normalize_legacy_logs_path(&mut normalized);
    validate_daemon_configuration(&normalized)?;
    Ok((normalized, embedded_secrets))
}

pub fn normalize_node_daemon_configuration(
    mut configuration: serde_json::Value,
    api_url: &str,
) -> Result<(serde_json::Value, NodeConfigurationSecrets), anyhow::Error> {
    let configured_bind_port = match configuration.pointer("/api/port") {
        None => None,
        Some(value) => Some(
            value
                .as_u64()
                .and_then(|value| u16::try_from(value).ok())
                .filter(|value| *value > 0)
                .ok_or_else(|| {
                    DisplayError::new("daemon API bind port must be from 1 through 65535")
                })?,
        ),
    };
    let endpoint = parse_daemon_api_url(api_url).or_else(|error| {
        configured_bind_port
            .map(|port| parse_legacy_daemon_api_url(api_url, port))
            .unwrap_or(Err(error))
    })?;
    let bind_port = configured_bind_port.unwrap_or(endpoint.port);
    remove_obsolete_api_identity_fields(&mut configuration);
    let api = configuration
        .as_object_mut()
        .and_then(|configuration| {
            configuration
                .entry("api")
                .or_insert_with(|| serde_json::json!({}))
                .as_object_mut()
        })
        .ok_or_else(|| DisplayError::new("daemon API configuration must be an object"))?;
    api.insert("host".to_owned(), serde_json::json!("0.0.0.0"));
    api.insert("port".to_owned(), serde_json::json!(bind_port));
    let ssl = api
        .entry("ssl")
        .or_insert_with(|| serde_json::json!({}))
        .as_object_mut()
        .ok_or_else(|| DisplayError::new("daemon API TLS configuration must be an object"))?;
    ssl.insert(
        "enabled".to_owned(),
        serde_json::json!(endpoint.tls_enabled),
    );
    if !endpoint.tls_enabled {
        ssl.insert("require_client_cert".to_owned(), serde_json::json!(false));
    }
    normalize_daemon_configuration(configuration)
}

pub(super) fn remove_primary_remote_origin(configuration: &mut serde_json::Value, remote: &str) {
    let Ok(remote) = url::Url::parse(remote.trim()) else {
        return;
    };
    let remote_origin = remote.origin().ascii_serialization();
    let Some(origins) = configuration
        .pointer_mut("/api/trusted_origins")
        .and_then(serde_json::Value::as_array_mut)
    else {
        return;
    };
    origins.retain(|origin| {
        origin
            .as_str()
            .and_then(|origin| url::Url::parse(origin).ok())
            .is_none_or(|origin| origin.origin().ascii_serialization() != remote_origin)
    });
}

fn remove_obsolete_api_identity_fields(configuration: &mut serde_json::Value) {
    if let Some(api) = configuration
        .get_mut("api")
        .and_then(serde_json::Value::as_object_mut)
    {
        for obsolete in ["fqdn", "trusted_hosts", "allowed_hosts", "url"] {
            api.remove(obsolete);
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct ParsedDaemonApiUrl {
    port: u16,
    tls_enabled: bool,
}

pub fn validate_daemon_api_url(api_url: &str) -> Result<(), anyhow::Error> {
    parse_daemon_api_url(api_url).map(|_| ())
}

fn parse_daemon_api_url(api_url: &str) -> Result<ParsedDaemonApiUrl, anyhow::Error> {
    let value = api_url.trim();
    let (_, remainder) = value
        .split_once("://")
        .ok_or_else(|| invalid_daemon_api_url())?;
    let authority_end = remainder
        .find(|character| matches!(character, '/' | '?' | '#'))
        .unwrap_or(remainder.len());
    let authority = &remainder[..authority_end];
    if authority.is_empty() || authority.contains('@') {
        return Err(invalid_daemon_api_url().into());
    }
    let port_text = if authority.starts_with('[') {
        authority
            .rsplit_once("]:")
            .filter(|(host, _)| host.starts_with('[') && !host[1..].contains(']'))
            .map(|(_, port)| port)
    } else {
        authority
            .rsplit_once(':')
            .filter(|(host, _)| !host.is_empty() && !host.contains(':'))
            .map(|(_, port)| port)
    }
    .ok_or_else(|| invalid_daemon_api_url())?;
    if port_text.is_empty() || !port_text.bytes().all(|byte| byte.is_ascii_digit()) {
        return Err(invalid_daemon_api_url().into());
    }
    let port = port_text
        .parse::<u16>()
        .ok()
        .filter(|port| *port > 0)
        .ok_or_else(|| invalid_daemon_api_url())?;

    let url = url::Url::parse(value).map_err(|_| invalid_daemon_api_url())?;
    if !matches!(url.scheme(), "http" | "https")
        || url.host().is_none()
        || !url.username().is_empty()
        || url.password().is_some()
        || !matches!(url.path(), "" | "/")
        || url.query().is_some()
        || url.fragment().is_some()
    {
        return Err(invalid_daemon_api_url().into());
    }
    if let Some(url::Host::Domain(host)) = url.host()
        && !valid_dns_hostname(host)
    {
        return Err(invalid_daemon_api_url().into());
    }
    Ok(ParsedDaemonApiUrl {
        port,
        tls_enabled: url.scheme() == "https",
    })
}

fn parse_legacy_daemon_api_url(
    api_url: &str,
    configured_port: u16,
) -> Result<ParsedDaemonApiUrl, anyhow::Error> {
    let url = url::Url::parse(api_url.trim()).map_err(|_| invalid_daemon_api_url())?;
    if !matches!(url.scheme(), "http" | "https")
        || url.host().is_none()
        || !url.username().is_empty()
        || url.password().is_some()
        || !matches!(url.path(), "" | "/")
        || url.query().is_some()
        || url.fragment().is_some()
    {
        return Err(invalid_daemon_api_url().into());
    }
    if let Some(url::Host::Domain(host)) = url.host()
        && !valid_dns_hostname(host)
    {
        return Err(invalid_daemon_api_url().into());
    }
    Ok(ParsedDaemonApiUrl {
        port: configured_port,
        tls_enabled: url.scheme() == "https",
    })
}

fn invalid_daemon_api_url() -> DisplayError<'static> {
    DisplayError::new(
        "Daemon API URL must use HTTP or HTTPS, include an explicit port from 1 through 65535, and contain no credentials, path, query, or fragment.",
    )
}

fn normalize_legacy_disk_mode(configuration: &mut serde_json::Value) {
    if configuration
        .pointer("/disk/mode")
        .and_then(serde_json::Value::as_str)
        == Some("none")
        && let Some(mode) = configuration.pointer_mut("/disk/mode")
    {
        *mode = serde_json::Value::String("soft_scanner".to_owned());
    }
}

fn normalize_legacy_logs_path(configuration: &mut serde_json::Value) {
    if configuration
        .pointer("/paths/logs")
        .and_then(serde_json::Value::as_str)
        == Some("/var/log/dbev")
        && let Some(logs) = configuration.pointer_mut("/paths/logs")
    {
        *logs = serde_json::Value::String("/var/lib/dbev/logs".to_owned());
    }
}

fn merge_configuration(target: &mut serde_json::Value, source: &serde_json::Value) {
    match (target, source) {
        (serde_json::Value::Object(target), serde_json::Value::Object(source)) => {
            for (key, value) in source {
                if let Some(existing) = target.get_mut(key) {
                    merge_configuration(existing, value);
                } else {
                    target.insert(key.clone(), value.clone());
                }
            }
        }
        (target, source) => *target = source.clone(),
    }
}
