use super::{
    NodeConfigurationSecrets, NodeConfigurationSecretsPatch, default_daemon_configuration,
    normalize_daemon_configuration, normalize_node_daemon_configuration,
    remove_primary_remote_origin, validate_daemon_api_url,
};

#[test]
fn defaults_are_valid_and_complete() {
    let (configuration, secrets) = normalize_daemon_configuration(serde_json::json!({})).unwrap();
    assert!(secrets.is_empty());
    assert_eq!(
        configuration.pointer("/paths/volumes").unwrap(),
        "/var/lib/dbev/volumes"
    );
    assert_eq!(
        configuration.pointer("/backups/storage/driver").unwrap(),
        "local"
    );
    for guard in [
        "prevent_cpu_overallocation",
        "prevent_memory_overallocation",
        "prevent_disk_overallocation",
    ] {
        assert_eq!(
            configuration.pointer(&format!("/allocation/{guard}")),
            Some(&serde_json::Value::Bool(true))
        );
    }
    let yaml = serde_norway::to_string(&configuration).unwrap();
    assert_eq!(
        configuration.pointer("/api/host"),
        Some(&serde_json::json!("0.0.0.0"))
    );
    for obsolete in ["fqdn", "trusted_hosts", "allowed_hosts", "url"] {
        assert!(configuration.pointer(&format!("/api/{obsolete}")).is_none());
    }
    assert!(yaml.contains("prevent_cpu_overallocation: true"));
    assert!(yaml.contains("prevent_memory_overallocation: true"));
    assert!(yaml.contains("prevent_disk_overallocation: true"));
    assert!(yaml.contains("trusted_origins: []"));
    assert!(yaml.contains("mode: auto"));
    assert!(yaml.contains("scan_interval_seconds: 15"));
    assert!(yaml.contains("dynamic_limiter_enabled: true"));
    assert!(yaml.contains("max_queued_jobs: 1024"));
    assert!(yaml.contains("stream_exports_only: false"));
    assert!(yaml.contains("max_artifacts_per_instance: 20"));
    assert!(yaml.contains("self_upgrade_enabled: false"));
    assert!(yaml.contains("allow_plaintext: false"));
    assert!(yaml.contains("max_staged_bytes: 8589934592"));
    assert!(yaml.contains("import_upload_max_bytes: 8589934592"));
    assert!(yaml.contains("import_upload_max_total_bytes: 34359738368"));
    assert!(yaml.contains("use_inotify: true"));
    assert!(yaml.contains("full_scan_interval_seconds: 90"));
    assert!(yaml.contains("inotify_debounce_milliseconds: 500"));
    assert!(yaml.contains("max_dirty_paths_per_instance: 512"));
    assert!(yaml.contains("logs: /var/lib/dbev/logs"));
}

#[test]
fn validates_artifact_policy_boundaries() {
    for value in [1_u64, 20, 10_000] {
        let mut input = default_daemon_configuration();
        input["artifacts"]["max_artifacts_per_instance"] = serde_json::json!(value);
        normalize_daemon_configuration(input)
            .unwrap_or_else(|error| panic!("max_artifacts_per_instance={value}: {error}"));
    }

    for value in [0_u64, 10_001] {
        let mut input = default_daemon_configuration();
        input["artifacts"]["max_artifacts_per_instance"] = serde_json::json!(value);
        assert!(
            normalize_daemon_configuration(input).is_err(),
            "max_artifacts_per_instance={value} should be rejected"
        );
    }

    let mut invalid_boolean = default_daemon_configuration();
    invalid_boolean["artifacts"]["stream_exports_only"] = serde_json::json!("false");
    assert!(normalize_daemon_configuration(invalid_boolean).is_err());
}

#[test]
fn older_artifact_configuration_keeps_v052_keys_absent() {
    let input = serde_json::json!({
        "artifacts": {
            "retention_keep_latest": 5,
            "retention_max_age_days": 10
        }
    });
    let (configuration, _) = normalize_daemon_configuration(input).unwrap();
    assert!(
        configuration
            .pointer("/artifacts/stream_exports_only")
            .is_none()
    );
    assert!(
        configuration
            .pointer("/artifacts/max_artifacts_per_instance")
            .is_none()
    );
    assert_eq!(
        configuration.pointer("/artifacts/retention_keep_latest"),
        Some(&serde_json::json!(5))
    );
}

#[test]
fn embedded_backup_secrets_are_removed() {
    let mut input = default_daemon_configuration();
    input["backups"]["storage"]["s3"]["secret_access_key"] = serde_json::json!("secret");
    let (configuration, secrets) = normalize_daemon_configuration(input).unwrap();
    assert_eq!(secrets.s3_secret_access_key, "secret");
    assert_eq!(
        configuration
            .pointer("/backups/storage/s3/secret_access_key")
            .unwrap(),
        ""
    );
}

#[test]
fn secret_patches_preserve_existing_values_until_explicitly_changed_or_cleared() {
    let original = NodeConfigurationSecrets {
        s3_access_key_id: "existing-access".to_owned(),
        s3_secret_access_key: "existing-secret".to_owned(),
        s3_session_token: "existing-session".to_owned(),
        kopia_repository_password: "existing-kopia".to_owned(),
    };

    let mut unchanged = original.clone();
    unchanged.apply_patch(None);
    assert_eq!(unchanged.s3_access_key_id, "existing-access");
    assert_eq!(unchanged.s3_secret_access_key, "existing-secret");
    assert_eq!(unchanged.kopia_repository_password, "existing-kopia");

    let mut replaced = original.clone();
    replaced.apply_patch(Some(NodeConfigurationSecretsPatch {
        s3_access_key_id: Some("replacement-access".to_owned()),
        s3_secret_access_key: Some(String::new()),
        ..Default::default()
    }));
    assert_eq!(replaced.s3_access_key_id, "replacement-access");
    assert_eq!(replaced.s3_secret_access_key, "existing-secret");
    assert_eq!(replaced.kopia_repository_password, "existing-kopia");

    let mut cleared = original;
    cleared.apply_patch(Some(NodeConfigurationSecretsPatch {
        clear_s3_credentials: true,
        clear_kopia_repository_password: true,
        ..Default::default()
    }));
    assert!(cleared.is_empty());
}

#[test]
fn accepts_plaintext_public_api_listener() {
    let (configuration, _) = normalize_node_daemon_configuration(
        serde_json::json!({}),
        "http://db-node.example.com:8090",
    )
    .unwrap();
    assert_eq!(configuration.pointer("/api/host").unwrap(), "0.0.0.0");
    assert_eq!(
        configuration.pointer("/api/ssl/enabled").unwrap(),
        &serde_json::Value::Bool(false)
    );
}

#[test]
fn rejects_mysql_nine_images() {
    let mut input = default_daemon_configuration();
    input["images"]["mysql"] = serde_json::json!("mysql:9.0");
    input["images"]["allowed"]["mysql"] = serde_json::json!(["mysql:9.0"]);
    let error = normalize_daemon_configuration(input).unwrap_err();
    assert!(error.to_string().contains("MySQL 9.x"));
}

#[test]
fn preserves_unknown_official_configuration_keys() {
    let input = serde_json::json!({ "future_official_feature": { "enabled": true } });
    let (configuration, _) = normalize_daemon_configuration(input).unwrap();
    assert_eq!(
        configuration.pointer("/future_official_feature/enabled"),
        Some(&serde_json::Value::Bool(true))
    );
}

#[test]
fn legacy_none_disk_mode_is_normalized_to_active_soft_enforcement() {
    let input = serde_json::json!({ "disk": { "mode": "none" } });
    let (configuration, _) = normalize_daemon_configuration(input).unwrap();
    assert_eq!(
        configuration.pointer("/disk/mode"),
        Some(&serde_json::Value::String("soft_scanner".to_owned()))
    );
}

#[test]
fn legacy_log_path_is_migrated_to_the_current_safe_runtime_root() {
    let input = serde_json::json!({ "paths": { "logs": "/var/log/dbev" } });
    let (configuration, _) = normalize_daemon_configuration(input).unwrap();
    assert_eq!(
        configuration.pointer("/paths/logs"),
        Some(&serde_json::json!("/var/lib/dbev/logs"))
    );
}

#[test]
fn validates_remote_import_upload_and_pid_configuration() {
    let mut input = default_daemon_configuration();
    input["security"]["remote_import"]["allowed_private_hosts"] =
        serde_json::json!(["db.internal.example", "10.20.30.40", "[fd00::1234]"]);
    input["security"]["pids_limits"]["postgres"] = serde_json::json!(1024);
    normalize_daemon_configuration(input).unwrap();

    for invalid_host in ["https://db.internal", "db.internal/path", "127.1"] {
        let mut input = default_daemon_configuration();
        input["security"]["remote_import"]["allowed_private_hosts"] =
            serde_json::json!([invalid_host]);
        assert!(
            normalize_daemon_configuration(input).is_err(),
            "{invalid_host}"
        );
    }

    let mut input = default_daemon_configuration();
    input["artifacts"]["import_upload_max_total_bytes"] = serde_json::json!(1);
    assert!(normalize_daemon_configuration(input).is_err());

    let mut input = default_daemon_configuration();
    input["security"]["pids_limits"]["postgres"] = serde_json::json!(0);
    assert!(normalize_daemon_configuration(input).is_err());
}

#[test]
fn validates_trusted_browser_origins_independently_from_hosts() {
    for valid in [
        "https://panel.example.com",
        "https://panel.example.com:8443",
        "http://127.0.0.1:8000",
    ] {
        let input = serde_json::json!({ "api": { "trusted_origins": [valid] } });
        normalize_daemon_configuration(input).unwrap();
    }

    for invalid in [
        "panel.example.com",
        "ftp://panel.example.com",
        "https://panel.example.com/path",
        "https://user@panel.example.com",
        "https://panel.example.com?query=1",
    ] {
        let input = serde_json::json!({ "api": { "trusted_origins": [invalid] } });
        assert!(normalize_daemon_configuration(input).is_err());
    }
}

#[test]
fn primary_remote_origin_is_not_duplicated_in_generated_configuration() {
    let mut configuration = serde_json::json!({
        "api": {
            "trusted_origins": [
                "https://panel.example.com",
                "https://panel.example.com:8443",
                "https://additional-panel.example.com"
            ]
        }
    });
    remove_primary_remote_origin(&mut configuration, "https://panel.example.com/admin");
    assert_eq!(
        configuration.pointer("/api/trusted_origins"),
        Some(&serde_json::json!([
            "https://panel.example.com:8443",
            "https://additional-panel.example.com"
        ]))
    );
}

#[test]
fn derives_https_listener_and_removes_obsolete_api_identity_fields() {
    let input = serde_json::json!({
        "api": {
            "host": "127.0.0.1",
            "fqdn": "db-node.example.com",
            "trusted_hosts": ["legacy-alias.example.com"],
            "allowed_hosts": ["another-legacy-alias.example.com"],
            "url": "https://obsolete.example.com:8090",
            "ssl": {
                "cert": "/etc/dbev/fullchain.pem",
                "key": "/etc/dbev/privkey.pem"
            },
            "future_api_setting": true
        },
        "future_official_feature": { "enabled": true }
    });
    let (configuration, _) =
        normalize_node_daemon_configuration(input, "https://DB-NODE.example.com:8090").unwrap();

    assert_eq!(
        configuration.pointer("/api/host"),
        Some(&serde_json::json!("0.0.0.0"))
    );
    assert_eq!(
        configuration.pointer("/api/port"),
        Some(&serde_json::json!(8090))
    );
    assert_eq!(
        configuration.pointer("/api/ssl/enabled"),
        Some(&serde_json::json!(true))
    );
    for obsolete in ["fqdn", "trusted_hosts", "allowed_hosts", "url"] {
        assert!(configuration.pointer(&format!("/api/{obsolete}")).is_none());
    }
    assert_eq!(
        configuration.pointer("/api/future_api_setting"),
        Some(&serde_json::json!(true))
    );
    assert_eq!(
        configuration.pointer("/future_official_feature/enabled"),
        Some(&serde_json::Value::Bool(true))
    );
    let yaml = serde_norway::to_string(&configuration).unwrap();
    assert!(yaml.contains("host: 0.0.0.0"));
    assert!(yaml.contains("enabled: true"));
    for obsolete in ["fqdn", "trusted_hosts", "allowed_hosts", "url:"] {
        assert!(
            !yaml.contains(obsolete),
            "generated YAML contained {obsolete}"
        );
    }
}

#[test]
fn parses_http_ip_http_dns_and_https_dns_endpoints() {
    for endpoint in ["http://192.168.1.10:8090", "http://db.internal:9090"] {
        let (configuration, _) =
            normalize_node_daemon_configuration(serde_json::json!({}), endpoint).unwrap();
        assert_eq!(
            configuration.pointer("/api/host"),
            Some(&serde_json::json!("0.0.0.0"))
        );
        assert_eq!(
            configuration.pointer("/api/ssl/enabled"),
            Some(&serde_json::json!(false))
        );
    }

    let input = serde_json::json!({
        "api": { "ssl": { "cert": "/etc/dbev/fullchain.pem", "key": "/etc/dbev/privkey.pem" } }
    });
    let (configuration, _) =
        normalize_node_daemon_configuration(input, "https://db.example.com:9443").unwrap();
    assert_eq!(
        configuration.pointer("/api/port"),
        Some(&serde_json::json!(9443))
    );
    assert_eq!(
        configuration.pointer("/api/ssl/enabled"),
        Some(&serde_json::json!(true))
    );
}

#[test]
fn preserves_an_explicit_internal_bind_port_override() {
    let input = serde_json::json!({
        "api": {
            "port": 8090,
            "ssl": { "cert": "/etc/dbev/fullchain.pem", "key": "/etc/dbev/privkey.pem" }
        }
    });
    let (configuration, _) =
        normalize_node_daemon_configuration(input, "https://db.example.com:443").unwrap();
    assert_eq!(
        configuration.pointer("/api/port"),
        Some(&serde_json::json!(8090))
    );
    assert_eq!(
        configuration.pointer("/api/ssl/enabled"),
        Some(&serde_json::json!(true))
    );
}

#[test]
fn legacy_records_without_an_explicit_url_port_can_still_regenerate() {
    let input = serde_json::json!({
        "api": {
            "port": 8090,
            "ssl": { "cert": "/etc/dbev/fullchain.pem", "key": "/etc/dbev/privkey.pem" }
        }
    });
    let (configuration, _) =
        normalize_node_daemon_configuration(input, "https://legacy-db.example.com").unwrap();
    assert_eq!(
        configuration.pointer("/api/port"),
        Some(&serde_json::json!(8090))
    );
    assert_eq!(
        configuration.pointer("/api/ssl/enabled"),
        Some(&serde_json::json!(true))
    );
}

#[test]
fn validates_daemon_api_urls_as_explicit_origins() {
    for valid in [
        "http://192.168.1.10:8090",
        "http://db.internal:8090",
        "https://db.example.com:443",
        "https://[2001:db8::10]:8090",
    ] {
        assert!(
            validate_daemon_api_url(valid).is_ok(),
            "{valid} should be accepted"
        );
    }
    for invalid in [
        "db-node.example.com:8090",
        "ftp://db-node.example.com:8090",
        "https://db-node.example.com",
        "https://db-node.example.com:0",
        "https://db-node.example.com:65536",
        "https://user:secret@db-node.example.com:8090",
        "https://db-node.example.com:8090/api",
        "https://db-node.example.com:8090?query=1",
        "https://db-node.example.com:8090#fragment",
    ] {
        assert!(
            validate_daemon_api_url(invalid).is_err(),
            "{invalid} should be rejected"
        );
    }
}

#[test]
fn validates_every_scheduler_configuration_boundary() {
    let valid = [
        ("max_queued_jobs", 64_u64),
        ("max_queued_jobs", 8_192),
        ("max_queued_jobs_per_instance", 1),
        ("max_queued_jobs_per_instance", 256),
        ("manual_max_active_jobs", 1),
        ("manual_max_active_jobs", 1_024),
        ("dynamic_max_active_jobs", 1),
        ("dynamic_max_active_jobs", 1_024),
        ("dynamic_memory_budget_mib", 0),
        ("dynamic_memory_budget_mib", 128),
        ("dynamic_memory_budget_mib", 16_777_216),
        ("dynamic_io_budget_mib", 0),
        ("dynamic_io_budget_mib", 256),
        ("dynamic_io_budget_mib", 67_108_864),
        ("dynamic_cpu_units", 0),
        ("dynamic_cpu_units", 65_536),
        ("starvation_timeout_seconds", 1),
        ("starvation_timeout_seconds", 3_600),
        ("max_bypass", 0),
        ("max_bypass", 1_024),
    ];
    for (field, value) in valid {
        let mut input = default_daemon_configuration();
        input["artifacts"]["import_export_scheduler"][field] = serde_json::json!(value);
        if matches!(field, "manual_max_active_jobs" | "dynamic_max_active_jobs") {
            input["artifacts"]["import_export_scheduler"]["max_queued_jobs"] =
                serde_json::json!(8_192);
        }
        if field == "max_queued_jobs" && value == 64 {
            input["artifacts"]["import_export_scheduler"]["max_queued_jobs_per_instance"] =
                serde_json::json!(32);
            input["artifacts"]["import_export_scheduler"]["manual_max_active_jobs"] =
                serde_json::json!(16);
            input["artifacts"]["import_export_scheduler"]["dynamic_max_active_jobs"] =
                serde_json::json!(64);
        }
        normalize_daemon_configuration(input)
            .unwrap_or_else(|error| panic!("{field}={value}: {error}"));
    }

    for (field, value) in [
        ("max_queued_jobs", 63_u64),
        ("max_queued_jobs", 8_193),
        ("max_queued_jobs_per_instance", 0),
        ("max_queued_jobs_per_instance", 257),
        ("manual_max_active_jobs", 0),
        ("manual_max_active_jobs", 1_025),
        ("dynamic_max_active_jobs", 0),
        ("dynamic_max_active_jobs", 1_025),
        ("dynamic_memory_budget_mib", 127),
        ("dynamic_memory_budget_mib", 16_777_217),
        ("dynamic_io_budget_mib", 255),
        ("dynamic_io_budget_mib", 67_108_865),
        ("dynamic_cpu_units", 65_537),
        ("starvation_timeout_seconds", 0),
        ("starvation_timeout_seconds", 3_601),
        ("max_bypass", 1_025),
    ] {
        let mut input = default_daemon_configuration();
        input["artifacts"]["import_export_scheduler"][field] = serde_json::json!(value);
        assert!(
            normalize_daemon_configuration(input).is_err(),
            "{field}={value} should be rejected"
        );
    }
}

#[test]
fn scheduler_limits_cannot_exceed_the_durable_queue() {
    for field in [
        "max_queued_jobs_per_instance",
        "manual_max_active_jobs",
        "dynamic_max_active_jobs",
    ] {
        let mut input = default_daemon_configuration();
        input["artifacts"]["import_export_scheduler"]["max_queued_jobs"] = serde_json::json!(64);
        input["artifacts"]["import_export_scheduler"][field] = serde_json::json!(65);
        assert!(normalize_daemon_configuration(input).is_err(), "{field}");
    }
}
