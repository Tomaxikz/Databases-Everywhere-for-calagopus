use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Debug, Clone, Default, Deserialize, ToSchema)]
pub struct NodeConfigurationSecretsPatch {
    pub s3_access_key_id: Option<String>,
    pub s3_secret_access_key: Option<String>,
    pub s3_session_token: Option<String>,
    pub kopia_repository_password: Option<String>,
    #[serde(default)]
    pub clear_s3_credentials: bool,
    #[serde(default)]
    pub clear_kopia_repository_password: bool,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct NodeConfigurationSecrets {
    pub s3_access_key_id: String,
    pub s3_secret_access_key: String,
    pub s3_session_token: String,
    pub kopia_repository_password: String,
}

impl NodeConfigurationSecrets {
    pub fn is_empty(&self) -> bool {
        self.s3_access_key_id.is_empty()
            && self.s3_secret_access_key.is_empty()
            && self.s3_session_token.is_empty()
            && self.kopia_repository_password.is_empty()
    }

    pub fn overlay_non_empty(&mut self, other: Self) {
        for (target, value) in [
            (&mut self.s3_access_key_id, other.s3_access_key_id),
            (&mut self.s3_secret_access_key, other.s3_secret_access_key),
            (&mut self.s3_session_token, other.s3_session_token),
            (
                &mut self.kopia_repository_password,
                other.kopia_repository_password,
            ),
        ] {
            if !value.trim().is_empty() {
                *target = value;
            }
        }
    }

    pub fn apply_patch(&mut self, patch: Option<NodeConfigurationSecretsPatch>) {
        let Some(patch) = patch else { return };
        if patch.clear_s3_credentials {
            self.s3_access_key_id.clear();
            self.s3_secret_access_key.clear();
            self.s3_session_token.clear();
        }
        if patch.clear_kopia_repository_password {
            self.kopia_repository_password.clear();
        }
        for (target, value) in [
            (&mut self.s3_access_key_id, patch.s3_access_key_id),
            (&mut self.s3_secret_access_key, patch.s3_secret_access_key),
            (&mut self.s3_session_token, patch.s3_session_token),
            (
                &mut self.kopia_repository_password,
                patch.kopia_repository_password,
            ),
        ] {
            if let Some(value) = value.filter(|value| !value.trim().is_empty()) {
                *target = value;
            }
        }
    }
}

pub fn public_daemon_configuration(configuration: &serde_json::Value) -> serde_json::Value {
    let mut public = configuration.clone();
    take_embedded_secrets(&mut public);
    for protected in ["remote", "uuid", "token_id", "token", "jwt_signing_key"] {
        if let Some(object) = public.as_object_mut() {
            object.remove(protected);
        }
    }
    public
}

pub fn apply_configuration_secrets(
    configuration: &mut serde_json::Value,
    secrets: &NodeConfigurationSecrets,
) {
    set_nested_string(
        configuration,
        &["backups", "storage", "s3", "access_key_id"],
        &secrets.s3_access_key_id,
    );
    set_nested_string(
        configuration,
        &["backups", "storage", "s3", "secret_access_key"],
        &secrets.s3_secret_access_key,
    );
    set_nested_string(
        configuration,
        &["backups", "storage", "s3", "session_token"],
        &secrets.s3_session_token,
    );
    set_nested_string(
        configuration,
        &["backups", "storage", "kopia", "repository_password"],
        &secrets.kopia_repository_password,
    );
}

pub(super) fn take_embedded_secrets(
    configuration: &mut serde_json::Value,
) -> NodeConfigurationSecrets {
    NodeConfigurationSecrets {
        s3_access_key_id: take_nested_string(
            configuration,
            &["backups", "storage", "s3", "access_key_id"],
        ),
        s3_secret_access_key: take_nested_string(
            configuration,
            &["backups", "storage", "s3", "secret_access_key"],
        ),
        s3_session_token: take_nested_string(
            configuration,
            &["backups", "storage", "s3", "session_token"],
        ),
        kopia_repository_password: take_nested_string(
            configuration,
            &["backups", "storage", "kopia", "repository_password"],
        ),
    }
}

pub(in crate::persistence) fn embedded_configuration_secrets(
    configuration: &serde_json::Value,
) -> NodeConfigurationSecrets {
    let mut configuration = configuration.clone();
    take_embedded_secrets(&mut configuration)
}

fn take_nested_string(value: &mut serde_json::Value, path: &[&str]) -> String {
    let Some((leaf, parents)) = path.split_last() else {
        return String::new();
    };
    let mut current = value;
    for parent in parents {
        let Some(next) = current.get_mut(*parent) else {
            return String::new();
        };
        current = next;
    }
    let Some(slot) = current.get_mut(*leaf) else {
        return String::new();
    };
    let secret = slot.as_str().unwrap_or_default().to_owned();
    *slot = serde_json::Value::String(String::new());
    secret
}

fn set_nested_string(value: &mut serde_json::Value, path: &[&str], replacement: &str) {
    let Some((leaf, parents)) = path.split_last() else {
        return;
    };
    let mut current = value;
    for parent in parents {
        let Some(next) = current.get_mut(*parent) else {
            return;
        };
        current = next;
    }
    if let Some(object) = current.as_object_mut() {
        object.insert(
            (*leaf).to_owned(),
            serde_json::Value::String(replacement.to_owned()),
        );
    }
}
