use shared::response::DisplayError;
use std::net::IpAddr;

const PROTOCOLS: [&str; 8] = [
    "postgres",
    "mysql",
    "mariadb",
    "redis",
    "valkey",
    "mongodb",
    "clickhouse",
    "qdrant",
];

pub(super) fn validate_daemon_configuration(
    configuration: &serde_json::Value,
) -> Result<(), anyhow::Error> {
    required_string(configuration, "/api/host", "daemon API host")?;
    bounded_integer(configuration, "/api/port", "daemon API port", 1, 65_535)?;
    let api_ssl_enabled = required_bool(configuration, "/api/ssl/enabled", "API TLS")?;
    if api_ssl_enabled {
        absolute_path(configuration, "/api/ssl/cert", "API TLS certificate")?;
        absolute_path(configuration, "/api/ssl/key", "API TLS private key")?;
    }
    let require_client_certificate = required_bool(
        configuration,
        "/api/ssl/require_client_cert",
        "client certificate requirement",
    )?;
    if require_client_certificate && !api_ssl_enabled {
        return Err(
            DisplayError::new("client-certificate enforcement requires native API TLS").into(),
        );
    }
    if require_client_certificate {
        absolute_path(configuration, "/api/ssl/client_ca", "client certificate CA")?;
    }
    let trusted_origins = configuration
        .pointer("/api/trusted_origins")
        .and_then(serde_json::Value::as_array)
        .ok_or_else(|| DisplayError::new("trusted API origins must be an array"))?;
    if trusted_origins.len() > 100
        || trusted_origins.iter().any(|origin| {
            origin
                .as_str()
                .is_none_or(|origin| !valid_http_origin(origin))
        })
    {
        return Err(DisplayError::new(
            "Enter a complete HTTP(S) origin such as https://panel.example.com or https://panel.example.com:8443. Paths, credentials, queries, and fragments are not allowed.",
        )
        .into());
    }

    let mut enabled_gateway_binds = std::collections::HashSet::new();
    let mut protocol_tls_enabled = false;
    for protocol in PROTOCOLS {
        let section = configuration
            .get(protocol)
            .and_then(serde_json::Value::as_object)
            .ok_or_else(|| DisplayError::new(format!("missing {protocol} configuration")))?;
        let enabled = section
            .get("enabled")
            .and_then(serde_json::Value::as_bool)
            .ok_or_else(|| DisplayError::new(format!("invalid {protocol} enabled setting")))?;
        let tls = section
            .get("tls")
            .and_then(serde_json::Value::as_bool)
            .ok_or_else(|| DisplayError::new(format!("invalid {protocol} TLS setting")))?;
        protocol_tls_enabled |= enabled && tls;
        let bind = section
            .get("bind")
            .and_then(serde_json::Value::as_str)
            .ok_or_else(|| DisplayError::new(format!("invalid {protocol} gateway bind")))?;
        let (bind_identity, native_port) = validate_bind(protocol, bind)?;
        if enabled && !enabled_gateway_binds.insert(bind_identity) {
            return Err(DisplayError::new(format!(
                "enabled {protocol} gateway duplicates another bind address and port"
            ))
            .into());
        }
        if protocol == "clickhouse" {
            let (http_bind_identity, http_port) = validate_bind(
                "ClickHouse HTTP",
                section
                    .get("http_bind")
                    .and_then(serde_json::Value::as_str)
                    .ok_or_else(|| DisplayError::new("invalid ClickHouse HTTP gateway bind"))?,
            )?;
            if native_port == http_port {
                return Err(DisplayError::new(
                    "ClickHouse native and HTTP gateway ports must be different",
                )
                .into());
            }
            if enabled && !enabled_gateway_binds.insert(http_bind_identity) {
                return Err(DisplayError::new(
                    "enabled ClickHouse HTTP gateway duplicates another bind address and port",
                )
                .into());
            }
        }
    }
    if protocol_tls_enabled {
        absolute_path(configuration, "/tls/cert", "database TLS certificate")?;
        absolute_path(configuration, "/tls/key", "database TLS private key")?;
    }

    let daemon_engine = configuration
        .pointer("/daemon/engine")
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default();
    if !matches!(daemon_engine, "docker" | "podman") {
        return Err(DisplayError::new("daemon engine must be docker or podman").into());
    }

    let storage_driver = configuration
        .pointer("/backups/storage/driver")
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default();
    if !matches!(storage_driver, "local" | "s3" | "kopia") {
        return Err(DisplayError::new("backup storage driver must be local, s3, or kopia").into());
    }
    let backups_enabled = required_bool(configuration, "/backups/enabled", "automated backups")?;
    bounded_integer(
        configuration,
        "/backups/interval_minutes",
        "backup interval",
        1,
        525_600,
    )?;
    bounded_integer(
        configuration,
        "/backups/retention_keep_latest_per_instance",
        "backup retention count",
        1,
        100_000,
    )?;
    bounded_integer(
        configuration,
        "/backups/retention_max_age_days",
        "backup retention age",
        0,
        36_500,
    )?;
    if backups_enabled && storage_driver == "s3" {
        required_string(configuration, "/backups/storage/s3/bucket", "S3 bucket")?;
        let endpoint = configuration
            .pointer("/backups/storage/s3/endpoint")
            .and_then(serde_json::Value::as_str)
            .unwrap_or_default()
            .trim();
        if !endpoint.is_empty() {
            let endpoint = url::Url::parse(endpoint)
                .map_err(|_| DisplayError::new("S3 endpoint must be a valid HTTP(S) URL"))?;
            if !matches!(endpoint.scheme(), "http" | "https") {
                return Err(DisplayError::new("S3 endpoint must use HTTP or HTTPS").into());
            }
            let allow_http = required_bool(
                configuration,
                "/backups/storage/s3/allow_http",
                "S3 HTTP opt-in",
            )?;
            if endpoint.scheme() == "http" && !allow_http {
                return Err(DisplayError::new(
                    "plaintext S3 endpoints require the allow HTTP option",
                )
                .into());
            }
        }
    }
    if backups_enabled && storage_driver == "kopia" {
        absolute_path(
            configuration,
            "/backups/storage/kopia/executable",
            "Kopia executable",
        )?;
        optional_absolute_path(
            configuration,
            "/backups/storage/kopia/config_file",
            "Kopia configuration",
        )?;
    }

    validate_artifact_configuration(configuration)?;

    for protocol in PROTOCOLS {
        let image = configuration
            .pointer(&format!("/images/{protocol}"))
            .and_then(serde_json::Value::as_str)
            .unwrap_or_default();
        validate_image(protocol, image)?;
        let allowed = configuration
            .pointer(&format!("/images/allowed/{protocol}"))
            .and_then(serde_json::Value::as_array)
            .ok_or_else(|| DisplayError::new(format!("missing allowed {protocol} images")))?;
        if allowed.is_empty() || allowed.len() > 100 {
            return Err(DisplayError::new(format!(
                "{protocol} must have between 1 and 100 allowed images"
            ))
            .into());
        }
        let mut default_is_allowed = false;
        for image in allowed {
            let image = image
                .as_str()
                .ok_or_else(|| DisplayError::new(format!("invalid allowed {protocol} image")))?;
            validate_image(protocol, image)?;
            default_is_allowed |= image
                == configuration
                    .pointer(&format!("/images/{protocol}"))
                    .and_then(serde_json::Value::as_str)
                    .unwrap_or_default();
            if protocol == "mysql" && is_mysql_nine_image(image) {
                return Err(DisplayError::new(
                    "MySQL 9.x is not supported; use the MySQL 8.4 LTS image",
                )
                .into());
            }
        }
        if !default_is_allowed {
            return Err(DisplayError::new(format!(
                "the default {protocol} image must also appear in its allowed image list"
            ))
            .into());
        }
        if protocol == "mysql" && is_mysql_nine_image(image) {
            return Err(DisplayError::new(
                "MySQL 9.x is not supported; use the MySQL 8.4 LTS image",
            )
            .into());
        }
    }

    for (pointer, label) in [
        ("/paths/data", "data"),
        ("/paths/metadata", "metadata"),
        ("/paths/volumes", "volumes"),
        ("/paths/backups", "backups"),
        ("/paths/sockets", "sockets"),
        ("/paths/locks", "locks"),
        ("/paths/logs", "logs"),
        ("/paths/artifacts", "artifacts"),
        ("/paths/exports", "exports"),
        ("/paths/imports", "imports"),
        ("/paths/fuse", "FUSE"),
        ("/paths/tmp", "temporary"),
    ] {
        absolute_path(configuration, pointer, &format!("{label} path"))?;
    }
    for (pointer, label, minimum, maximum) in [
        (
            "/security/api_body_limit_bytes",
            "API body limit",
            1,
            u64::MAX,
        ),
        (
            "/security/api_rate_limit_per_minute",
            "API rate limit",
            1,
            u64::MAX,
        ),
        (
            "/security/db_connection_limit_per_minute",
            "database connection rate limit",
            1,
            u64::MAX,
        ),
        ("/security/pids_limit", "PID limit", 1, u64::MAX),
    ] {
        bounded_integer(configuration, pointer, label, minimum, maximum)?;
    }
    let self_upgrade_enabled = required_bool(
        configuration,
        "/security/self_upgrade_enabled",
        "API self-upgrade setting",
    )?;
    if self_upgrade_enabled {
        return Err(DisplayError::new(
            "DBEV API self-upgrade is unsupported; leave it disabled and deploy upgrades through a signed package or immutable container image",
        )
        .into());
    }
    for protocol in PROTOCOLS {
        nullable_positive_integer(
            configuration,
            &format!("/security/pids_limits/{protocol}"),
            &format!("{protocol} PID override"),
        )?;
    }
    validate_remote_import_security(configuration)?;
    nullable_positive_integer(
        configuration,
        "/allocation/max_memory_mib",
        "maximum memory",
    )?;
    nullable_positive_integer(configuration, "/allocation/max_disk_mib", "maximum disk")?;
    required_bool(
        configuration,
        "/allocation/prevent_cpu_overallocation",
        "CPU overallocation prevention",
    )?;
    required_bool(
        configuration,
        "/allocation/prevent_memory_overallocation",
        "memory overallocation prevention",
    )?;
    required_bool(
        configuration,
        "/allocation/prevent_disk_overallocation",
        "disk overallocation prevention",
    )?;
    bounded_integer(
        configuration,
        "/allocation/reserved_memory_mib",
        "reserved memory",
        0,
        1_048_576,
    )?;
    bounded_integer(
        configuration,
        "/allocation/reserved_disk_mib",
        "reserved disk",
        0,
        u64::MAX,
    )?;

    let fuse_binary =
        required_string(configuration, "/disk/fuse_quota_binary", "FuseQuota binary")?;
    if fuse_binary != "embedded" && !fuse_binary.starts_with('/') {
        return Err(
            DisplayError::new("FuseQuota binary must be 'embedded' or an absolute path").into(),
        );
    }
    let fuse_digest = configuration
        .pointer("/disk/fuse_quota_binary_sha256")
        .and_then(serde_json::Value::as_str)
        .ok_or_else(|| DisplayError::new("invalid FuseQuota SHA-256"))?;
    if !fuse_digest.is_empty()
        && (fuse_digest.len() != 64
            || !fuse_digest
                .bytes()
                .all(|byte| byte.is_ascii_digit() || matches!(byte, b'a'..=b'f')))
    {
        return Err(DisplayError::new(
            "FuseQuota SHA-256 must be empty or 64 lowercase hexadecimal characters",
        )
        .into());
    }
    bounded_integer(
        configuration,
        "/disk/fuse_quota_rescan_interval_seconds",
        "FuseQuota rescan interval",
        1,
        86_400,
    )?;
    bounded_integer(
        configuration,
        "/disk/project_id_base",
        "project quota ID base",
        1,
        2_147_000_000,
    )?;
    let disk_mode = required_string(configuration, "/disk/mode", "disk quota mode")?;
    if !matches!(
        disk_mode,
        "auto" | "project_quota" | "fuse_quota" | "soft_scanner"
    ) {
        return Err(DisplayError::new(
            "disk quota mode must be auto, project_quota, fuse_quota, or soft_scanner",
        )
        .into());
    }
    for (pointer, label, minimum, maximum) in [
        (
            "/disk/soft_scanner/scan_interval_seconds",
            "soft scanner interval",
            1,
            3_600,
        ),
        (
            "/disk/soft_scanner/full_scan_interval_seconds",
            "soft scanner full-scan interval",
            1,
            3_600,
        ),
        (
            "/disk/soft_scanner/inotify_debounce_milliseconds",
            "soft scanner filesystem-event debounce",
            1,
            60_000,
        ),
        (
            "/disk/soft_scanner/max_dirty_paths_per_instance",
            "soft scanner dirty-path limit",
            1,
            65_536,
        ),
        (
            "/disk/soft_scanner/max_concurrent_scans",
            "soft scanner concurrency",
            1,
            64,
        ),
        (
            "/disk/soft_scanner/max_entries_per_scan",
            "soft scanner entry limit",
            1,
            10_000_000,
        ),
        (
            "/disk/soft_scanner/scan_timeout_seconds",
            "soft scanner timeout",
            1,
            3_600,
        ),
        (
            "/disk/soft_scanner/max_consecutive_scan_failures",
            "soft scanner failure limit",
            1,
            10,
        ),
        (
            "/disk/soft_scanner/safety_reserve_mib",
            "soft scanner safety reserve",
            0,
            u64::MAX,
        ),
        (
            "/disk/soft_scanner/recovery_percent",
            "soft scanner recovery percentage",
            1,
            99,
        ),
        (
            "/disk/soft_scanner/shutdown_grace_seconds",
            "soft scanner shutdown grace period",
            1,
            300,
        ),
    ] {
        bounded_integer(configuration, pointer, label, minimum, maximum)?;
    }
    required_bool(
        configuration,
        "/disk/soft_scanner/use_inotify",
        "soft scanner filesystem-event acceleration",
    )?;

    Ok(())
}

fn required_string<'a>(
    configuration: &'a serde_json::Value,
    pointer: &str,
    label: &str,
) -> Result<&'a str, anyhow::Error> {
    configuration
        .pointer(pointer)
        .and_then(serde_json::Value::as_str)
        .filter(|value| !value.trim().is_empty())
        .ok_or_else(|| DisplayError::new(format!("{label} is required")).into())
}

fn optional_bool(
    configuration: &serde_json::Value,
    pointer: &str,
    label: &str,
) -> Result<(), anyhow::Error> {
    if configuration
        .pointer(pointer)
        .is_some_and(|value| !value.is_boolean())
    {
        return Err(DisplayError::new(format!("{label} must be true or false")).into());
    }
    Ok(())
}

fn optional_bounded_integer(
    configuration: &serde_json::Value,
    pointer: &str,
    label: &str,
    minimum: u64,
    maximum: u64,
) -> Result<(), anyhow::Error> {
    let Some(value) = configuration.pointer(pointer) else {
        return Ok(());
    };
    let value = value.as_u64().ok_or_else(|| {
        DisplayError::new(format!(
            "{label} must be an integer from {minimum} through {maximum}"
        ))
    })?;
    if !(minimum..=maximum).contains(&value) {
        return Err(
            DisplayError::new(format!("{label} must be from {minimum} through {maximum}")).into(),
        );
    }
    Ok(())
}

fn valid_http_origin(value: &str) -> bool {
    let Ok(url) = url::Url::parse(value.trim()) else {
        return false;
    };
    matches!(url.scheme(), "http" | "https")
        && url.host_str().is_some()
        && url.username().is_empty()
        && url.password().is_none()
        && matches!(url.path(), "" | "/")
        && url.query().is_none()
        && url.fragment().is_none()
        && url.port_or_known_default().is_some()
}

pub(super) fn valid_dns_hostname(value: &str) -> bool {
    if value.is_empty() || value.len() > 253 || !value.is_ascii() || value.ends_with('.') {
        return false;
    }
    let labels = value.split('.');
    for label in labels {
        if label.is_empty()
            || label.len() > 63
            || label.starts_with('-')
            || label.ends_with('-')
            || !label
                .bytes()
                .all(|byte| byte.is_ascii_alphanumeric() || byte == b'-')
        {
            return false;
        }
    }
    true
}

fn required_bool(
    configuration: &serde_json::Value,
    pointer: &str,
    label: &str,
) -> Result<bool, anyhow::Error> {
    configuration
        .pointer(pointer)
        .and_then(serde_json::Value::as_bool)
        .ok_or_else(|| DisplayError::new(format!("{label} must be true or false")).into())
}

fn bounded_integer(
    configuration: &serde_json::Value,
    pointer: &str,
    label: &str,
    minimum: u64,
    maximum: u64,
) -> Result<u64, anyhow::Error> {
    configuration
        .pointer(pointer)
        .and_then(serde_json::Value::as_u64)
        .filter(|value| *value >= minimum && *value <= maximum)
        .ok_or_else(|| {
            DisplayError::new(format!(
                "{label} must be an integer between {minimum} and {maximum}"
            ))
            .into()
        })
}

fn nullable_positive_integer(
    configuration: &serde_json::Value,
    pointer: &str,
    label: &str,
) -> Result<(), anyhow::Error> {
    let value = configuration
        .pointer(pointer)
        .ok_or_else(|| DisplayError::new(format!("{label} is required")))?;
    if value.is_null() || value.as_u64().is_some_and(|value| value > 0) {
        Ok(())
    } else {
        Err(DisplayError::new(format!("{label} must be null or a positive integer")).into())
    }
}

fn validate_artifact_configuration(configuration: &serde_json::Value) -> Result<(), anyhow::Error> {
    optional_bool(
        configuration,
        "/artifacts/stream_exports_only",
        "one-use export policy",
    )?;
    optional_bounded_integer(
        configuration,
        "/artifacts/max_artifacts_per_instance",
        "maximum artifacts per database",
        1,
        10_000,
    )?;
    bounded_integer(
        configuration,
        "/artifacts/retention_keep_latest",
        "artifact retention count",
        1,
        u64::MAX,
    )?;
    let max_upload_bytes = bounded_integer(
        configuration,
        "/artifacts/import_upload_max_bytes",
        "maximum temporary upload size",
        1,
        8 * 1024 * 1024 * 1024,
    )?;
    let max_total_bytes = bounded_integer(
        configuration,
        "/artifacts/import_upload_max_total_bytes",
        "total temporary upload capacity",
        1,
        i64::MAX as u64,
    )?;
    if max_total_bytes < max_upload_bytes {
        return Err(DisplayError::new(
            "total temporary upload capacity must be at least the per-upload size limit",
        )
        .into());
    }
    for (pointer, label, minimum, maximum) in [
        (
            "/artifacts/import_upload_max_per_instance",
            "temporary uploads per database",
            1,
            64,
        ),
        (
            "/artifacts/import_upload_max_concurrent",
            "concurrent temporary uploads",
            1,
            32,
        ),
        (
            "/artifacts/import_upload_ttl_hours",
            "temporary upload lifetime",
            1,
            168,
        ),
    ] {
        bounded_integer(configuration, pointer, label, minimum, maximum)?;
    }
    let total_timeout = bounded_integer(
        configuration,
        "/artifacts/import_upload_timeout_seconds",
        "temporary upload total timeout",
        60,
        86_400,
    )?;
    let idle_timeout = bounded_integer(
        configuration,
        "/artifacts/import_upload_idle_timeout_seconds",
        "temporary upload idle timeout",
        5,
        300,
    )?;
    if idle_timeout > total_timeout {
        return Err(DisplayError::new(
            "temporary upload idle timeout cannot exceed the total upload timeout",
        )
        .into());
    }
    validate_import_export_scheduler(configuration)
}

fn validate_remote_import_security(configuration: &serde_json::Value) -> Result<(), anyhow::Error> {
    required_bool(
        configuration,
        "/security/remote_import/enabled",
        "remote database imports",
    )?;
    required_bool(
        configuration,
        "/security/remote_import/allow_plaintext",
        "plaintext remote database imports",
    )?;
    let allowed_hosts = configuration
        .pointer("/security/remote_import/allowed_private_hosts")
        .and_then(serde_json::Value::as_array)
        .ok_or_else(|| DisplayError::new("remote import private hosts must be an array"))?;
    for host in allowed_hosts {
        let host = host.as_str().unwrap_or_default();
        if !valid_remote_import_host(host) {
            return Err(DisplayError::new(format!(
                "remote import private-host allow-list contains an invalid hostname or IP address: {host}"
            ))
            .into());
        }
    }
    let connect_timeout = bounded_integer(
        configuration,
        "/security/remote_import/connect_timeout_seconds",
        "remote import connect timeout",
        1,
        300,
    )?;
    let operation_timeout = bounded_integer(
        configuration,
        "/security/remote_import/operation_timeout_seconds",
        "remote import operation timeout",
        1,
        86_400,
    )?;
    bounded_integer(
        configuration,
        "/security/remote_import/max_concurrent_jobs",
        "concurrent remote import jobs",
        1,
        64,
    )?;
    bounded_integer(
        configuration,
        "/security/remote_import/max_staged_bytes",
        "remote import staging limit",
        1,
        8 * 1024 * 1024 * 1024,
    )?;
    if operation_timeout < connect_timeout {
        return Err(DisplayError::new(
            "remote import operation timeout cannot be shorter than the connect timeout",
        )
        .into());
    }
    Ok(())
}

fn valid_remote_import_host(value: &str) -> bool {
    let value = value.trim();
    if value.is_empty() {
        return false;
    }
    if value.parse::<IpAddr>().is_ok()
        || value
            .strip_prefix('[')
            .and_then(|value| value.strip_suffix(']'))
            .is_some_and(|value| value.parse::<std::net::Ipv6Addr>().is_ok())
    {
        return true;
    }

    let host = value.strip_suffix('.').unwrap_or(value);
    if host.is_empty()
        || host.len() > 253
        || !host.is_ascii()
        || host.bytes().any(|byte| byte.is_ascii_control())
        || host
            .bytes()
            .any(|byte| matches!(byte, b'/' | b'\\' | b':' | b'@' | b'#' | b'?' | b'[' | b']'))
    {
        return false;
    }
    let labels = host.split('.').collect::<Vec<_>>();
    if labels.iter().any(|label| {
        label.is_empty()
            || label.len() > 63
            || label.starts_with('-')
            || label.ends_with('-')
            || !label
                .bytes()
                .all(|byte| byte.is_ascii_alphanumeric() || byte == b'-')
    }) {
        return false;
    }
    !labels.iter().all(|label| {
        label.bytes().all(|byte| byte.is_ascii_digit())
            || label
                .strip_prefix("0x")
                .or_else(|| label.strip_prefix("0X"))
                .is_some_and(|digits| {
                    !digits.is_empty() && digits.bytes().all(|byte| byte.is_ascii_hexdigit())
                })
    })
}

fn validate_import_export_scheduler(
    configuration: &serde_json::Value,
) -> Result<(), anyhow::Error> {
    let prefix = "/artifacts/import_export_scheduler";
    required_bool(
        configuration,
        &format!("{prefix}/dynamic_limiter_enabled"),
        "dynamic import/export scheduler",
    )?;
    let max_queued_jobs = bounded_integer(
        configuration,
        &format!("{prefix}/max_queued_jobs"),
        "scheduler maximum queued jobs",
        64,
        8_192,
    )?;
    let max_queued_jobs_per_instance = bounded_integer(
        configuration,
        &format!("{prefix}/max_queued_jobs_per_instance"),
        "scheduler maximum queued jobs per instance",
        1,
        256,
    )?;
    let manual_max_active_jobs = bounded_integer(
        configuration,
        &format!("{prefix}/manual_max_active_jobs"),
        "scheduler manual active-job limit",
        1,
        1_024,
    )?;
    let dynamic_max_active_jobs = bounded_integer(
        configuration,
        &format!("{prefix}/dynamic_max_active_jobs"),
        "scheduler dynamic active-job limit",
        1,
        1_024,
    )?;
    if max_queued_jobs_per_instance > max_queued_jobs
        || manual_max_active_jobs > max_queued_jobs
        || dynamic_max_active_jobs > max_queued_jobs
    {
        return Err(DisplayError::new(
            "scheduler per-instance and active-job limits cannot exceed max_queued_jobs",
        )
        .into());
    }
    zero_or_bounded_integer(
        configuration,
        &format!("{prefix}/dynamic_memory_budget_mib"),
        "scheduler dynamic memory budget",
        128,
        16_777_216,
    )?;
    zero_or_bounded_integer(
        configuration,
        &format!("{prefix}/dynamic_io_budget_mib"),
        "scheduler dynamic I/O budget",
        256,
        67_108_864,
    )?;
    bounded_integer(
        configuration,
        &format!("{prefix}/dynamic_cpu_units"),
        "scheduler dynamic CPU units",
        0,
        65_536,
    )?;
    bounded_integer(
        configuration,
        &format!("{prefix}/starvation_timeout_seconds"),
        "scheduler starvation timeout",
        1,
        3_600,
    )?;
    bounded_integer(
        configuration,
        &format!("{prefix}/max_bypass"),
        "scheduler maximum bypass count",
        0,
        1_024,
    )?;
    Ok(())
}

fn zero_or_bounded_integer(
    configuration: &serde_json::Value,
    pointer: &str,
    label: &str,
    minimum_non_zero: u64,
    maximum: u64,
) -> Result<u64, anyhow::Error> {
    configuration
        .pointer(pointer)
        .and_then(serde_json::Value::as_u64)
        .filter(|value| *value == 0 || (*value >= minimum_non_zero && *value <= maximum))
        .ok_or_else(|| {
            DisplayError::new(format!(
                "{label} must be 0 or an integer between {minimum_non_zero} and {maximum}"
            ))
            .into()
        })
}

fn absolute_path(
    configuration: &serde_json::Value,
    pointer: &str,
    label: &str,
) -> Result<(), anyhow::Error> {
    let path = required_string(configuration, pointer, label)?;
    if path.starts_with('/') {
        Ok(())
    } else {
        Err(DisplayError::new(format!("{label} must be an absolute path")).into())
    }
}

fn optional_absolute_path(
    configuration: &serde_json::Value,
    pointer: &str,
    label: &str,
) -> Result<(), anyhow::Error> {
    let path = configuration
        .pointer(pointer)
        .and_then(serde_json::Value::as_str)
        .ok_or_else(|| DisplayError::new(format!("invalid {label}")))?;
    if path.is_empty() || path.starts_with('/') {
        Ok(())
    } else {
        Err(DisplayError::new(format!("{label} must be empty or an absolute path")).into())
    }
}

fn validate_bind(label: &str, bind: &str) -> Result<(String, u16), anyhow::Error> {
    let (host, port) = bind
        .rsplit_once(':')
        .ok_or_else(|| DisplayError::new(format!("invalid {label} gateway bind")))?;
    let host = host.trim();
    let port = port
        .parse::<u16>()
        .ok()
        .filter(|port| *port > 0)
        .ok_or_else(|| DisplayError::new(format!("invalid {label} gateway bind")))?;
    if host.is_empty() || host.chars().any(char::is_whitespace) {
        return Err(DisplayError::new(format!("invalid {label} gateway bind")).into());
    }
    Ok((format!("{}:{port}", host.to_lowercase()), port))
}

fn validate_image(protocol: &str, image: &str) -> Result<(), anyhow::Error> {
    let tail = image.rsplit('/').next().unwrap_or_default();
    let versioned = image.contains("@sha256:")
        || tail
            .rsplit_once(':')
            .is_some_and(|(_, tag)| !tag.is_empty() && !tag.eq_ignore_ascii_case("latest"));
    if image.trim().is_empty() || image.chars().any(char::is_whitespace) || !versioned {
        return Err(DisplayError::new(format!(
            "{protocol} image must use an immutable digest or a non-latest tag"
        ))
        .into());
    }
    Ok(())
}

fn is_mysql_nine_image(image: &str) -> bool {
    let without_digest = image.split('@').next().unwrap_or(image);
    let tail = without_digest.rsplit('/').next().unwrap_or_default();
    let tag = tail
        .rsplit_once(':')
        .map(|(_, tag)| tag)
        .unwrap_or_default();
    tag == "9" || tag.starts_with("9.") || tag.starts_with("9-")
}
