pub fn default_daemon_configuration() -> serde_json::Value {
    serde_json::json!({
        "debug": false,
        "tls": { "cert": "", "key": "" },
        "postgres": { "enabled": true, "bind": "0.0.0.0:20020", "tls": false },
        "mysql": { "enabled": true, "bind": "0.0.0.0:3308", "tls": false },
        "mariadb": { "enabled": true, "bind": "0.0.0.0:20021", "tls": false },
        "redis": { "enabled": true, "bind": "0.0.0.0:20022", "tls": false },
        "valkey": { "enabled": true, "bind": "0.0.0.0:20027", "tls": false },
        "mongodb": { "enabled": true, "bind": "0.0.0.0:20023", "tls": false },
        "clickhouse": { "enabled": true, "bind": "0.0.0.0:20024", "http_bind": "0.0.0.0:20026", "tls": false },
        "qdrant": { "enabled": true, "bind": "0.0.0.0:20025", "tls": false },
        "api": {
            "host": "0.0.0.0",
            "port": 8090,
            "trusted_origins": [],
            "ssl": { "enabled": false, "cert": "", "key": "", "require_client_cert": false, "client_ca": "" }
        },
        "security": {
            "api_body_limit_bytes": 1048576,
            "api_rate_limit_per_minute": 600,
            "db_connection_limit_per_minute": 240,
            "self_upgrade_enabled": false,
            "pids_limit": 512,
            "pids_limits": {
                "postgres": null,
                "mysql": null,
                "mariadb": null,
                "redis": null,
                "valkey": null,
                "mongodb": null,
                "clickhouse": 4096,
                "qdrant": null
            },
            "remote_import": {
                "enabled": true,
                "allow_plaintext": false,
                "allowed_private_hosts": [],
                "max_concurrent_jobs": 4,
                "connect_timeout_seconds": 15,
                "operation_timeout_seconds": 900,
                "max_staged_bytes": 8589934592_u64
            }
        },
        "artifacts": {
            "stream_exports_only": false,
            "max_artifacts_per_instance": 20,
            "retention_keep_latest": 20,
            "retention_max_age_days": 30,
            "import_upload_max_bytes": 8589934592_u64,
            "import_upload_max_total_bytes": 34359738368_u64,
            "import_upload_max_per_instance": 4,
            "import_upload_max_concurrent": 2,
            "import_upload_ttl_hours": 24,
            "import_upload_timeout_seconds": 3600,
            "import_upload_idle_timeout_seconds": 30,
            "import_export_scheduler": {
                "dynamic_limiter_enabled": true,
                "max_queued_jobs": 1024,
                "max_queued_jobs_per_instance": 32,
                "manual_max_active_jobs": 16,
                "dynamic_max_active_jobs": 256,
                "dynamic_memory_budget_mib": 0,
                "dynamic_io_budget_mib": 0,
                "dynamic_cpu_units": 0,
                "starvation_timeout_seconds": 30,
                "max_bypass": 8
            }
        },
        "allocation": {
            "prevent_cpu_overallocation": true,
            "prevent_memory_overallocation": true,
            "prevent_disk_overallocation": true,
            "max_memory_mib": null,
            "max_disk_mib": null,
            "reserved_memory_mib": 512,
            "reserved_disk_mib": 2048
        },
        "backups": {
            "enabled": false,
            "interval_minutes": 1440,
            "run_on_startup": false,
            "retention_keep_latest_per_instance": 7,
            "retention_max_age_days": 30,
            "storage": {
                "driver": "local",
                "s3": {
                    "bucket": "", "region": "us-east-1", "endpoint": "", "prefix": "dbev",
                    "access_key_id": "", "secret_access_key": "", "session_token": "",
                    "path_style": false, "allow_http": false,
                    "request_timeout_seconds": 900, "max_retries": 3
                },
                "kopia": {
                    "executable": "/usr/local/bin/kopia", "config_file": "",
                    "repository_password": "", "operation_timeout_seconds": 3600
                }
            },
            "browsing": {
                "enabled": true,
                "max_objects": 256,
                "max_preview_objects": 32,
                "preview_rows_per_object": 10,
                "max_row_bytes": 4096,
                "max_catalog_bytes": 1048576
            }
        },
        "disk": {
            "mode": "auto",
            "fuse_quota_binary": "embedded",
            "fuse_quota_binary_sha256": "",
            "fuse_quota_rescan_interval_seconds": 150,
            "project_id_base": 200000,
            "soft_scanner": {
                "scan_interval_seconds": 15,
                "use_inotify": true,
                "full_scan_interval_seconds": 90,
                "inotify_debounce_milliseconds": 500,
                "max_dirty_paths_per_instance": 512,
                "max_concurrent_scans": 2,
                "max_entries_per_scan": 1000000,
                "scan_timeout_seconds": 30,
                "max_consecutive_scan_failures": 3,
                "safety_reserve_mib": 64,
                "recovery_percent": 85,
                "shutdown_grace_seconds": 30
            }
        },
        "daemon": {
            "engine": "docker",
            "socket_path": "",
            "container_read_only_rootfs": false,
            "container_userns_mode": "",
            "container_seccomp_profile": "",
            "container_apparmor_profile": "",
            "container_security_opts": []
        },
        "images": {
            "postgres": "postgres:18.4",
            "mysql": "mysql:8.4",
            "redis": "redis:8.8.0",
            "valkey": "valkey/valkey:9.1.1",
            "mariadb": "mariadb:12.3.2",
            "mongodb": "mongo:8.3.4",
            "clickhouse": "clickhouse/clickhouse-server:26.4.4.38",
            "qdrant": "qdrant/qdrant:v1.18.2",
            "allowed": {
                "postgres": ["postgres:18.4"],
                "mysql": ["mysql:8.4"],
                "redis": ["redis:8.8.0"],
                "valkey": ["valkey/valkey:9.1.1"],
                "mariadb": ["mariadb:12.3.2"],
                "mongodb": ["mongo:8.3.4", "mongo:7.0.37"],
                "clickhouse": ["clickhouse/clickhouse-server:26.4.4.38"],
                "qdrant": ["qdrant/qdrant:v1.18.2"]
            }
        },
        "paths": {
            "data": "/var/lib/dbev",
            "metadata": "/var/lib/dbev/metadata",
            "volumes": "/var/lib/dbev/volumes",
            "backups": "/var/lib/dbev/backups",
            "sockets": "/run/dbev/sockets",
            "locks": "/run/dbev/locks",
            "logs": "/var/lib/dbev/logs",
            "artifacts": "/var/lib/dbev/artifacts",
            "exports": "/var/lib/dbev/artifacts/exports",
            "imports": "/var/lib/dbev/artifacts/imports",
            "fuse": "/var/lib/dbev/fuse",
            "tmp": "/var/lib/dbev/tmp"
        }
    })
}
