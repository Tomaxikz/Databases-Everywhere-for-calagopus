export const DBEV_API_VERSION = '0.17.0' as const;
export const DBEV_MINIMUM_API_VERSION = '0.17.0' as const;

export type DatabaseProtocol =
  | 'postgres'
  | 'redis'
  | 'valkey'
  | 'mariadb'
  | 'mysql'
  | 'mongodb'
  | 'clickhouse'
  | 'qdrant';
export type DeploymentMode = 'dedicated' | 'shared';
export type NodeDeploymentPolicy = 'dedicated_only' | 'shared_only' | 'hybrid';

export interface DbevSystemResponse {
  service?: string;
  version?: string;
  api_version?: string;
  uuid?: string;
  api_readiness?: string;
  api_bind?: string;
  api_host?: string;
  api_port?: number;
  api_ssl_enabled?: boolean;
  daemon_engine?: string;
  database_backend_transport?: string;
  disk_mode?: string;
  daemon_disk_limits_enforced?: boolean;
  prevent_cpu_overallocation?: boolean;
  prevent_memory_overallocation?: boolean;
  prevent_disk_overallocation?: boolean;
  remote_import_enabled?: boolean;
  clickhouse_http_enabled?: boolean;
  deployment_capabilities?: Array<{
    protocol?: string;
    enabled?: boolean;
    modes?: string[];
    shared_pool_scope?: string | null;
    server_private_pools?: boolean | null;
    [key: string]: unknown;
  }>;
  gateways: {
    status: 'starting' | 'ready' | 'failed' | 'stopping';
    expected_listeners: number;
    ready_listeners: number;
    failure?: string;
    [key: string]: unknown;
  };
  [key: string]: unknown;
}

export interface DbevNodeResourceSummary {
  node_uuid: string;
  sampled_at: string;
  cpu: { total_cores: number; allocated_cores: number; host_usage_percent: number; managed_usage_cores: number | null };
  memory: {
    total_bytes: number;
    allocation_limit_bytes: number;
    reserved_bytes: number;
    allocated_bytes: number;
    host_used_bytes: number;
    managed_used_bytes: number | null;
    available_bytes: number;
  };
  disk: {
    total_bytes: number;
    allocation_limit_bytes: number;
    reserved_bytes: number;
    allocated_bytes: number;
    host_used_bytes: number;
    managed_used_bytes: number | null;
    available_bytes: number;
  };
  instances: Record<string, number>;
}

export interface DbevConfigPatchResponse {
  applied: boolean;
  restart_required: boolean;
  config_path: string;
}
export interface DbevInstanceStatusResponse {
  instance_id: string;
  status: string;
  progress?: DatabaseInstallProgress;
}
export interface DbevResetPasswordRequest {
  password: string;
}
export interface DbevResetPasswordResponse {
  instance: Record<string, unknown>;
  restarted: boolean;
}

interface GeneratedDbevDiskResourceReport {
  configured_mib: number;
  limit_bytes: number;
  used_bytes: number;
  enforced: boolean;
  enforcement_method: string;
  enforcement_strength: DbevDiskEnforcementStrength;
  scanner_logical_bytes?: number;
  scanner_physical_bytes?: number;
  scanner_growth_bytes_per_second?: number;
  scanner_peak_growth_bytes_per_second?: number;
  scanner_predicted_seconds_to_limit?: number;
  scanner_stop_threshold_bytes?: number;
  scanner_recovery_threshold_bytes?: number;
  scanner_restart_blocked?: boolean;
  scanner_sample_age_seconds?: number;
}

interface GeneratedDbevResourceReport {
  instance_id: string;
  runtime_id: string;
  deployment_mode: DeploymentMode;
  scope: 'dedicated_instance' | 'shared_tenant';
  protocol: DatabaseProtocol;
  status: string;
  cpu: { configured_cores: number; usage_percent: number | null };
  memory: { configured_mib: number; usage_bytes: number | null; limit_bytes: number | null };
  disk: GeneratedDbevDiskResourceReport;
  network: { rx_bytes: number | null; tx_bytes: number | null };
}

export type DbevDiskEnforcementStrength = 'hard' | 'soft' | 'none';

/** Keeps `enforcement_strength` optional while existing records are reconciled from older nodes. */
export type DbevDiskResourceReport = Omit<GeneratedDbevDiskResourceReport, 'enforcement_strength' | 'used_bytes'> & {
  enforcement_strength?: DbevDiskEnforcementStrength;
  used_bytes: number | null;
  [key: string]: unknown;
};

export type DbevResourceReport = Omit<GeneratedDbevResourceReport, 'disk'> & {
  disk: DbevDiskResourceReport;
  [key: string]: unknown;
};

/** A monitoring frame contains only the three resource groups sampled for its instance. */
export interface DatabaseMonitoringResources {
  cpu: DbevResourceReport['cpu'];
  memory: DbevResourceReport['memory'];
  disk: DbevDiskResourceReport;
}

export type DatabasePowerAction = 'start' | 'stop' | 'restart' | 'kill';

export type DatabaseWebSocketChannel = 'monitor' | 'logs' | 'import-export';

export interface DatabaseWebSocketToken {
  token_type: string;
  token: string;
  expires_at_unix: number;
  url: string;
  instance_id: string;
  scopes: string[];
}

export type AdminMonitoringWebSocketToken = Omit<DatabaseWebSocketToken, 'instance_id'> & {
  instance_id?: string;
};

export interface DbevAdminInstance {
  instance_id: string;
  deployment_mode?: DeploymentMode;
  runtime_id?: string;
  protocol?: DatabaseProtocol | string;
  status?: string;
  database?: { name?: string; username?: string } | null;
  image?: { current?: string | null; configured?: string; update_available?: boolean } | null;
  database_version?: { current?: string | null } | null;
  limits?: Partial<ResourceLimits> & Record<string, unknown>;
  resources?: DbevResourceReport | Record<string, unknown> | null;
  activity?: DatabaseActivity | null;
  deployment_migration?: Record<string, unknown> | null;
  [key: string]: unknown;
}

export interface PoolLimits extends ResourceLimits {
  max_tenants: number;
}

export interface PoolResourceSample {
  state: string;
  fresh: boolean;
  sampled_at_unix: number | null;
  sample_age_seconds: number | null;
  source: string;
  diagnostic?: { message?: string; [key: string]: unknown } | null;
  [key: string]: unknown;
}

export interface PoolResources {
  cpu: {
    usage_percent: number | null;
    limit_cores: number;
    sample: PoolResourceSample;
    [key: string]: unknown;
  };
  memory: {
    usage_bytes: number | null;
    limit_bytes: number;
    sample: PoolResourceSample;
    [key: string]: unknown;
  };
  disk: {
    usage_bytes: number | null;
    limit_bytes: number;
    reserved_bytes: number;
    enforced: boolean;
    enforcement_method: string;
    sample: PoolResourceSample;
    [key: string]: unknown;
  };
}

export interface DbevSharedPool extends PoolResources {
  runtime_id: string;
  owner: { panel_id: string; server_id: string } | null;
  protocol: DatabaseProtocol | string;
  status: string;
  desired_state: 'running' | 'stopped';
  pending_image: string | null;
  tenant_count: number;
  max_tenants: number;
  image: string;
  database_version: string | null;
  [key: string]: unknown;
}

export interface SharedPoolMapping {
  server_id: string;
  node_uuid: string;
  protocol: DatabaseProtocol;
  runtime_id: string;
  status_url: string;
  limits: PoolLimits;
}

export interface ServerPoolView {
  pool: SharedPoolMapping;
  runtime: DbevSharedPool | null;
  status: string;
  progress: DatabaseInstallProgress | null;
  instances: DbevAdminInstance[];
  children: DatabaseRecord[];
}

export interface PoolWebSocketToken {
  token_type: string;
  token: string;
  expires_at_unix: number;
  url: string;
  pool_id: string;
  scopes: ('pools:monitor' | 'pools:logs')[];
}

export interface DatabaseMonitoringInstance {
  instance_id: string;
  protocol?: string;
  status?: string;
  deployment_mode?: DeploymentMode;
  resource_scope?: string;
  runtime_id?: string;
  runtime?: Record<string, unknown> | null;
  resources?: DatabaseMonitoringResources | null;
  activity?: DatabaseActivity | null;
  resource_error?: string | null;
  [key: string]: unknown;
}

export interface DatabaseActivity {
  source?: 'exact' | 'observed' | 'partial' | 'unavailable' | string;
  availability?: 'exact' | 'observed' | 'partial' | 'unavailable' | string;
  accepted?: number | null;
  rejected?: number | null;
  forwarded?: number | null;
  connections?: number | null;
  rx_bytes?: number | null;
  tx_bytes?: number | null;
  sampled_at_unix?: number;
  stats_epoch?: string | number | null;
  sources?: Record<string, unknown>;
  [key: string]: unknown;
}

export interface DatabaseActivityHistoryBucket {
  sampled_at_unix?: number;
  started_at_unix?: number;
  duration_seconds: number;
  gap?: boolean;
  operations_observed?: boolean;
  source?: string;
  availability?: string;
  accepted?: number | null;
  forwarded?: number | null;
  rejected?: number | null;
  [key: string]: unknown;
}

export interface DatabaseActivityHistory {
  buckets: DatabaseActivityHistoryBucket[];
  [key: string]: unknown;
}

export interface DatabaseInstallProgress {
  instance_id: string;
  action?: string;
  status?: string;
  stage?: string;
  message?: string;
  image?: string;
  layer?: string;
  current?: number;
  total?: number;
  percent?: number;
  diagnostic?: {
    code?: string;
    message?: string;
    error_id?: string;
  } | null;
  updated_at?: string;
}

export interface DatabaseRuntimeInfo {
  instance_id: string;
  protocol?: string;
  status?: string;
  image?: {
    current?: string | null;
    configured?: string;
    update_available?: boolean;
  } | null;
  database_version?: {
    current?: string | null;
    error?: unknown;
  } | null;
  updated_at?: string;
}

export interface ResourceLimits {
  cpu_cores: number;
  memory_mib: number;
  disk_mib: number;
}

export interface DatabaseRecord {
  uuid: string;
  node_uuid: string;
  protocol: DatabaseProtocol;
  protocol_label: string;
  deployment_mode: DeploymentMode;
  runtime_id: string;
  quota_reserved: boolean;
  deployment_migration: Record<string, unknown> | null;
  migration_active: boolean;
  node_deployment_policy: NodeDeploymentPolicy | null;
  available_migration_targets: DeploymentMode[];
  display_name: string;
  database_name: string;
  username: string;
  password: string | null;
  public_host: string;
  public_port: number;
  tls: boolean;
  connection_uri: string | null;
  status: string;
  image: string | null;
  default_image: string | null;
  allowed_images: string[];
  stream_exports_only: boolean;
  max_artifacts_per_instance: number;
  mutations_allowed: boolean;
  mutation_block_reason: string | null;
  remote_import_enabled: boolean;
  remote_import_allow_plaintext: boolean;
  limits: ResourceLimits;
  limits_sync_pending: boolean;
  last_error: string | null;
  metadata: Record<string, unknown>;
  created: string;
  updated: string;
}

export interface ResetDatabasePasswordResponse {
  restarted: boolean;
}

export interface DeploymentMigrationResponse {
  migration: Record<string, unknown>;
  location: string | null;
}

export interface DeploymentNodeStatus {
  node_uuid: string;
  api_url: string;
  api_version: string | null;
  deployment_policy: NodeDeploymentPolicy;
  deployment_capabilities: unknown;
  error: string | null;
}

export interface DatabaseList {
  provider_available: boolean;
  provisioning_enabled: boolean;
  provisioning_block_reason: string | null;
  protocols: DatabaseProtocol[];
  available_deployment_modes: DeploymentMode[];
  protocol_deployment_modes: Partial<Record<DatabaseProtocol, DeploymentMode[]>>;
  deployment_nodes?: DeploymentNodeStatus[];
  shared_node_pins?: Partial<Record<DatabaseProtocol, string>>;
  shared_pool_ids?: Partial<Record<DatabaseProtocol, string>>;
  database_limit: number;
  database_usage: number;
  max_dedicated_databases: number;
  max_shared_databases: number;
  dedicated_database_usage: number;
  shared_database_usage: number;
  database_cpu_cores: number | null;
  database_memory_mib: number | null;
  database_disk_mib: number | null;
  database_backup_limit: number;
  image_options: Partial<Record<DatabaseProtocol, string[]>>;
  placement_defaults: Record<string, ResourceLimits>;
  databases: DatabaseRecord[];
}

export interface DatabaseBackupRecord {
  id: string;
  instance_id?: string;
  size_bytes?: number;
  modified_at?: string;
  sha256?: string;
  [key: string]: unknown;
}

export interface DatabaseBackupList {
  backups: DatabaseBackupRecord[];
  backup_usage: number;
  backup_limit: number;
}

export interface CreateDatabaseInput {
  protocol: DatabaseProtocol;
  deployment_mode: DeploymentMode;
  display_name: string;
  database_name?: string;
  username?: string;
  image?: string;
  limits: ResourceLimits;
}

export interface DataObject {
  name: string;
  namespace: string | null;
  kind: string;
  metadata: Record<string, unknown>;
}

export interface DataColumn {
  name: string;
  data_type: string;
  nullable: boolean;
  primary_key: boolean;
  default_value: string | null;
  extra: string | null;
}

export interface ExplorerOverview {
  protocol: DatabaseProtocol;
  objects: DataObject[];
  selective_export_supported: boolean;
}

export interface QueryOutput {
  columns: string[];
  rows: unknown[];
  affected_rows: number | null;
  elapsed_ms: number;
  truncated: boolean;
}

export interface DataMutationInput {
  operation: 'insert' | 'update' | 'delete';
  namespace?: string | null;
  object: string;
  original?: unknown;
  value?: unknown;
}

export interface BatchDataMutationInput {
  operation: 'delete';
  namespace?: string | null;
  object: string;
  originals: unknown[];
}

export type SchemaMutationOperation =
  | 'create_object'
  | 'rename_object'
  | 'delete_object'
  | 'add_column'
  | 'rename_column'
  | 'delete_column';

export type SchemaColumnType =
  | 'integer'
  | 'bigint'
  | 'decimal'
  | 'boolean'
  | 'varchar'
  | 'text'
  | 'json'
  | 'uuid'
  | 'date'
  | 'timestamp';

export interface SchemaColumnInput {
  name: string;
  data_type: SchemaColumnType;
  nullable: boolean;
  primary_key: boolean;
  auto_increment: boolean;
}

export interface SchemaMutationInput {
  operation: SchemaMutationOperation;
  namespace?: string | null;
  object: string;
  column?: SchemaColumnInput;
  columns?: SchemaColumnInput[];
  new_name?: string;
  confirm?: boolean;
}

export interface TransferSelection {
  mode: 'full' | 'selective';
  include?: string[];
  exclude?: string[];
  fields?: Record<string, string[]>;
}

export interface RemoteImportSource {
  type: 'remote';
  host: string;
  port: number;
  tls: boolean;
  database?: string;
  username?: string;
  password?: string;
  authentication_database?: string;
  database_index?: number;
  api_key?: string;
}

export interface ImportExportSchedulerConfiguration {
  dynamic_limiter_enabled: boolean;
  max_queued_jobs: number;
  max_queued_jobs_per_instance: number;
  manual_max_active_jobs: number;
  dynamic_max_active_jobs: number;
  dynamic_memory_budget_mib: number;
  dynamic_io_budget_mib: number;
  dynamic_cpu_units: number;
  starvation_timeout_seconds: number;
  max_bypass: number;
}

export interface SchedulerRecommendationRequest {
  protocol: DatabaseProtocol;
  action: 'import' | 'export';
  size_bytes: number;
  target_disk_mib: number;
  mode: 'merge' | 'wipe';
  compressed: boolean;
}

export interface SchedulerRecommendation {
  scheduler: {
    capacity: {
      mode: string;
      max_active_jobs: number;
      memory_budget_mib: number;
      io_budget_mib: number;
      cpu_units: number;
      [key: string]: unknown;
    };
    active_jobs: number;
    waiting_jobs: number;
    active_memory_mib: number;
    active_io_mib: number;
    active_cpu_units: number;
    accepting: boolean;
    [key: string]: unknown;
  };
  estimate: {
    input_size_bytes: number;
    memory_mib: number;
    io_mib: number;
    cpu_units: number;
    [key: string]: unknown;
  };
  recommended_active_jobs: number;
  admitted_jobs: number;
  max_queued_jobs: number;
  max_queued_jobs_per_instance: number;
  [key: string]: unknown;
}

export interface NodeRecord {
  uuid: string;
  name: string;
  enabled: boolean;
  deployment_policy: NodeDeploymentPolicy;
  api_url: string;
  public_host: string;
  daemon_uuid: string;
  token_id: string;
  default_cpu_cores: number;
  default_memory_mib: number;
  default_disk_mib: number;
  default_pool_limits: PoolLimits;
  configuration: Record<string, unknown>;
  has_configuration_secrets: boolean;
  cached_system: DbevSystemResponse | null;
  cached_resources: DbevNodeResourceSummary | null;
  last_seen: string | null;
  last_error: string | null;
  restart_required: boolean;
  mutations_allowed: boolean;
  mutation_block_reason: string | null;
  created: string;
  updated: string;
}

export interface RegistryImage {
  tag: string;
  reference: string;
  digest_reference: string | null;
  last_updated: string | null;
  size_bytes: number | null;
}

export interface ImageRegistryResponse {
  protocol: DatabaseProtocol;
  repository: string;
  page: number;
  per_page: number;
  total: number;
  has_next: boolean;
  has_previous: boolean;
  images: RegistryImage[];
}

export interface NodeCredentials {
  daemon_uuid: string;
  token_id: string;
  token: string;
  jwt_signing_key: string;
  configuration_yaml: string;
}

export interface NodeInput {
  name: string;
  enabled?: boolean;
  deployment_policy?: NodeDeploymentPolicy;
  api_url: string;
  public_host: string;
  default_cpu_cores: number;
  default_memory_mib: number;
  default_disk_mib: number;
  default_pool_limits: PoolLimits;
  configuration?: Record<string, unknown>;
  configuration_secrets?: {
    s3_access_key_id?: string;
    s3_secret_access_key?: string;
    s3_session_token?: string;
    kopia_repository_password?: string;
    clear_s3_credentials?: boolean;
    clear_kopia_repository_password?: boolean;
  };
}

export interface HostAssignment {
  host: NodeRecord;
  created: string;
}

export interface PanelNodeHostAvailability {
  available: boolean;
  schedulable: boolean;
  direct_host_count: number;
  location_host_count: number;
  available_deployment_modes?: DeploymentMode[];
}

export interface ExtensionSettings {
  enabled: boolean;
  panel_url: string;
  raw_console_enabled: boolean;
  query_timeout_seconds: number;
  max_console_rows: number;
  node_health_interval_seconds: number;
}

export interface ArtifactRecord {
  id: string;
  instance_id?: string;
  size_bytes?: number | null;
  modified_at?: string | null;
  sha256?: string | null;
  [key: string]: unknown;
}

export interface StagedUploadRecord {
  id: string;
  original_name: string;
  size_bytes: number;
  modified_at: string;
}

export type TemporaryUploadState =
  | 'uploading'
  | 'uploaded'
  | 'processing'
  | 'ready'
  | 'failed'
  | 'importing'
  | 'consumed'
  | 'deleting';

export interface TemporaryUploadRecord {
  upload_id: string;
  instance_id: string;
  original_filename: string;
  protocol: DatabaseProtocol;
  archive_format: 'plain' | 'gzip' | 'bzip2' | 'tar' | 'tar.gz' | 'zip' | null;
  state: TemporaryUploadState;
  size_bytes: number;
  sha256: string | null;
  created_at: string;
  updated_at: string;
  expires_at: string;
  catalog_available: boolean;
  error?: unknown;
  [key: string]: unknown;
}

export interface DumpInspectionObject {
  kind: 'table' | 'collection';
  name: string;
  namespace?: string;
  selection_key: string;
  [key: string]: unknown;
}

export interface DumpInspection {
  protocol: DatabaseProtocol;
  sha256: string;
  source_size_bytes: number;
  detected_archive_format: 'plain' | 'gzip' | 'bzip2' | 'tar' | 'tar.gz' | 'zip';
  selection_kind: 'tables' | 'collections' | 'full_only';
  selective_supported: boolean;
  catalog_complete: boolean;
  namespaces: string[];
  objects: DumpInspectionObject[];
  unselectable_object_count: number;
  selective_unavailable_reason?: string;
  [key: string]: unknown;
}

export interface StagedUploadList {
  available: boolean;
  reason: string | null;
  api_version: string | null;
  max_upload_bytes: number;
  uploads: TemporaryUploadRecord[];
  staged_uploads: StagedUploadRecord[];
}

export interface DatabaseBackupContentObject extends Record<string, unknown> {
  column_count: number;
}

export interface DatabaseBackupContentSelection extends Record<string, unknown> {
  columns: unknown[];
  rows: unknown[];
}

export interface DatabaseBackupContents extends Record<string, unknown> {
  objects?: DatabaseBackupContentObject[];
  selection?: DatabaseBackupContentSelection;
}

export interface TransferJob {
  job_id: string;
  instance_id?: string;
  action?: string;
  status?: string;
  artifact_id?: string | null;
  error?: unknown;
  created_at?: string;
  updated_at?: string;
  artifact_size_bytes?: number | null;
  [key: string]: unknown;
}

export interface AcceptedTransfer {
  job: Record<string, unknown>;
  location: string | null;
}
