import { z } from 'zod';
import { poolLimitsSchema } from './poolSchemas.ts';
import type { NodeRecord } from './types.ts';

// Validate panel allocation fields independently of the daemon's configuration.
// Missing pool defaults are an API/deployment error, never silently substituted.
export const nodeAllocationSchema = z.looseObject({
  uuid: z.uuid(),
  default_cpu_cores: z.number().min(0.01).max(1024),
  default_memory_mib: z.number().int().min(1).max(1_048_576),
  default_disk_mib: z.number().int().positive(),
  default_pool_limits: poolLimitsSchema,
});

export function parseNodeAllocations(node: NodeRecord): NodeRecord {
  return { ...node, ...nodeAllocationSchema.parse(node) };
}
