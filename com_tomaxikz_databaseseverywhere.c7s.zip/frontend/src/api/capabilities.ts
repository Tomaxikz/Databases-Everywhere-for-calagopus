import type { DatabaseProtocol, DeploymentMode } from './types.ts';

export interface DbevCapabilities {
  storedTenantCredentials: boolean;
  temporaryDumpUploads: boolean;
  mongodbSourceDiscovery: boolean;
  schedulerRecommendations: boolean;
  deploymentModes: Partial<Record<DatabaseProtocol, DeploymentMode[]>>;
  serverPrivateProtocols: DatabaseProtocol[];
}

export interface DbevMutationContract {
  compatible: boolean;
  message: string | null;
}

export const DBEV_SERVICE = 'databases-everywhere';
export const DBEV_MUTATION_API_VERSION = '0.17.0';

const protocols: DatabaseProtocol[] = [
  'postgres',
  'mysql',
  'mariadb',
  'redis',
  'valkey',
  'mongodb',
  'clickhouse',
  'qdrant',
];
const modes: DeploymentMode[] = ['dedicated', 'shared'];

function record(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function protocol(value: unknown): DatabaseProtocol | null {
  if (typeof value !== 'string') return null;
  const name = value.toLowerCase() === 'postgresql' ? 'postgres' : value.toLowerCase();
  return protocols.includes(name as DatabaseProtocol) ? (name as DatabaseProtocol) : null;
}

const sharedProtocols = new Set<DatabaseProtocol>(['postgres', 'mysql', 'mariadb', 'mongodb', 'clickhouse']);

function parseDeploymentCapabilities(value: unknown): Partial<Record<DatabaseProtocol, DeploymentMode[]>> | null {
  if (!Array.isArray(value) || value.length === 0) return null;
  const result: Partial<Record<DatabaseProtocol, DeploymentMode[]>> = {};
  const seen = new Set<string>();
  for (const candidate of value) {
    const item = record(candidate);
    if (
      !item ||
      typeof item.protocol !== 'string' ||
      typeof item.enabled !== 'boolean' ||
      !Array.isArray(item.modes) ||
      item.modes.length === 0 ||
      item.modes.some((value) => typeof value !== 'string') ||
      seen.has(protocol(item.protocol) ?? item.protocol.toLowerCase())
    )
      return null;
    seen.add(protocol(item.protocol) ?? item.protocol.toLowerCase());
    const databaseProtocol = protocol(item.protocol);
    if (!databaseProtocol || !item.enabled) continue;
    const declaredModes = item.modes;
    const supported = modes.filter(
      (mode) => declaredModes.includes(mode) && (mode === 'dedicated' || sharedProtocols.has(databaseProtocol)),
    );
    if (supported.length) result[databaseProtocol] = supported;
  }
  return result;
}

export function deploymentCapabilities(value: unknown): Partial<Record<DatabaseProtocol, DeploymentMode[]>> {
  return parseDeploymentCapabilities(value) ?? {};
}

function parseVersion(value: unknown): number[] | null {
  if (typeof value !== 'string') return null;
  const match = value
    .trim()
    .replace(/^v/, '')
    .match(/^(\d+)\.(\d+)\.(\d+)/);
  return match ? match.slice(1).map(Number) : null;
}

export function versionAtLeast(value: unknown, minimum: readonly [number, number, number]): boolean {
  const version = parseVersion(value);
  if (!version) return false;
  for (let index = 0; index < minimum.length; index += 1) {
    if (version[index] !== minimum[index]) return version[index] > minimum[index];
  }
  return true;
}

export function dbevCapabilities(system: Record<string, unknown>): DbevCapabilities {
  const deploymentModes = deploymentCapabilities(system.deployment_capabilities);
  const entries = Array.isArray(system.deployment_capabilities) ? system.deployment_capabilities : [];
  return {
    storedTenantCredentials: versionAtLeast(system.api_version, [0, 10, 0]),
    temporaryDumpUploads: versionAtLeast(system.api_version, [0, 11, 0]),
    mongodbSourceDiscovery: versionAtLeast(system.api_version, [0, 12, 0]),
    schedulerRecommendations: versionAtLeast(system.api_version, [0, 12, 0]),
    deploymentModes,
    serverPrivateProtocols: versionAtLeast(system.api_version, [0, 17, 0])
      ? protocols.filter(
          (name) =>
            deploymentModes[name]?.includes('shared') &&
            entries.some((candidate) => {
              const item = record(candidate);
              return (
                item &&
                protocol(item.protocol) === name &&
                item.enabled === true &&
                item.shared_pool_scope === 'server' &&
                item.server_private_pools === true
              );
            }),
        )
      : [],
  };
}

export function supportsPrivateShared(system: Record<string, unknown>, databaseProtocol: DatabaseProtocol): boolean {
  return dbevCapabilities(system).serverPrivateProtocols.includes(databaseProtocol);
}

export function databaseCapabilities(metadata: Record<string, unknown>): DbevCapabilities {
  return dbevCapabilities(metadata);
}

export function supportsDeployment(
  capabilities: Pick<DbevCapabilities, 'deploymentModes'>,
  databaseProtocol: DatabaseProtocol,
  deploymentMode: DeploymentMode,
): boolean {
  return capabilities.deploymentModes[databaseProtocol]?.includes(deploymentMode) === true;
}

export function dbevMutationContract(system: Record<string, unknown> | null | undefined): DbevMutationContract {
  if (!system) {
    return {
      compatible: false,
      message:
        'The DatabasesEverywhere node has not been sampled yet. Test the connection before changing node or database state.',
    };
  }
  const service = typeof system.service === 'string' ? system.service : 'an unknown service';
  if (service !== DBEV_SERVICE) {
    return {
      compatible: false,
      message: `This extension requires the ${DBEV_SERVICE} service, but this node reports ${service}. Read-only diagnostics remain available.`,
    };
  }
  const version = typeof system.api_version === 'string' ? system.api_version : 'an unknown version';
  if (!versionAtLeast(version, [0, 17, 0])) {
    return {
      compatible: false,
      message: `This extension requires DatabasesEverywhere API ${DBEV_MUTATION_API_VERSION} or newer, but this node reports ${version}. Read-only diagnostics remain available.`,
    };
  }
  if (system.api_readiness !== 'ready') {
    const readiness = typeof system.api_readiness === 'string' ? system.api_readiness : 'missing';
    const message =
      readiness === 'starting'
        ? 'The DatabasesEverywhere management API is still starting. Try again after it reports ready.'
        : readiness === 'stopping'
          ? 'The DatabasesEverywhere management API is stopping and cannot accept mutations.'
          : readiness === 'failed'
            ? 'The DatabasesEverywhere management API reports a failed readiness state. Review node diagnostics before retrying.'
            : `DatabasesEverywhere API ${version} reports an unsupported or missing api_readiness state: ${readiness}.`;
    return { compatible: false, message };
  }
  if (parseDeploymentCapabilities(system.deployment_capabilities) === null) {
    return {
      compatible: false,
      message: `DatabasesEverywhere API ${version} did not report usable deployment_capabilities.`,
    };
  }
  const missingGuard = [
    'prevent_cpu_overallocation',
    'prevent_memory_overallocation',
    'prevent_disk_overallocation',
  ].find((field) => typeof system[field] !== 'boolean');
  if (missingGuard) {
    return {
      compatible: false,
      message: `DatabasesEverywhere API ${version} response is missing required field ${missingGuard}.`,
    };
  }
  return { compatible: true, message: null };
}
