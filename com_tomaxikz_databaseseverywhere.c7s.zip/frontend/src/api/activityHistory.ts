import type { DatabaseActivity, DatabaseActivityHistory, DatabaseActivityHistoryBucket } from './types.ts';

type UnknownRecord = Record<string, unknown>;

function record(value: unknown): UnknownRecord | null {
  return value !== null && typeof value === 'object' && !Array.isArray(value) ? (value as UnknownRecord) : null;
}

function finite(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function numberAt(value: unknown, ...paths: string[]): number | null {
  for (const path of paths) {
    let current: unknown = value;
    for (const part of path.split('.')) current = record(current)?.[part];
    const candidate = finite(current);
    if (candidate !== null) return candidate;
  }
  return null;
}

function stringAt(value: unknown, ...paths: string[]): string | undefined {
  for (const path of paths) {
    let current: unknown = value;
    for (const part of path.split('.')) current = record(current)?.[part];
    if (typeof current === 'string' && current.trim()) return current;
  }
  return undefined;
}

function activityValue(value: unknown): UnknownRecord | null {
  const source = record(value);
  return record(source?.activity) ?? source;
}

/** Normalizes the live aggregate while retaining unknown future contract fields. */
export function normalizeDatabaseActivity(value: unknown): DatabaseActivity | null {
  const source = activityValue(value);
  if (!source) return null;

  const accepted = numberAt(source, 'accepted', 'forwarded', 'operations.accepted', 'operations.forwarded');
  const rejected = numberAt(source, 'rejected', 'operations.rejected');
  const connections = numberAt(source, 'connections', 'active_connections', 'connections.active');
  const availability = stringAt(source, 'availability');
  const activitySource = stringAt(source, 'source');

  return {
    ...source,
    ...(activitySource ? { source: activitySource } : {}),
    ...(availability ? { availability } : {}),
    accepted,
    forwarded: accepted,
    rejected,
    connections,
  };
}

function historyContainer(value: unknown, depth = 0): { root: UnknownRecord; buckets: unknown[] } | null {
  if (Array.isArray(value)) return { root: {}, buckets: value };
  if (depth > 4) return null;
  const root = record(value);
  if (!root) return null;
  for (const key of ['buckets', 'history', 'items', 'data', 'result']) {
    if (!Object.hasOwn(root, key)) continue;
    if (Array.isArray(root[key])) return { root, buckets: root[key] as unknown[] };
    const nested = historyContainer(root[key], depth + 1);
    if (nested) return { root: { ...root, ...nested.root }, buckets: nested.buckets };
  }
  return null;
}

function normalizeBucket(value: unknown, inheritedDuration: number | null): DatabaseActivityHistoryBucket | null {
  const source = record(value);
  if (!source) return null;
  const activity = activityValue(source) ?? source;
  const sampledAt = numberAt(source, 'sampled_at_unix');
  const startedAt = numberAt(source, 'started_at_unix', 'start_unix', 'bucket_start_unix');
  const duration = numberAt(source, 'duration_seconds') ?? inheritedDuration;
  if ((sampledAt === null && startedAt === null) || duration === null || duration <= 0) return null;

  const gap = source.gap === true;
  const operationsObserved = source.operations_observed;
  const measured = !gap && operationsObserved !== false;
  const accepted = measured
    ? numberAt(activity, 'accepted', 'forwarded', 'operations.accepted', 'operations.forwarded')
    : null;
  const rejected = measured ? numberAt(activity, 'rejected', 'operations.rejected') : null;

  return {
    ...source,
    ...(sampledAt !== null ? { sampled_at_unix: sampledAt } : {}),
    ...(startedAt !== null ? { started_at_unix: startedAt } : {}),
    duration_seconds: duration,
    gap,
    ...(typeof operationsObserved === 'boolean' ? { operations_observed: operationsObserved } : {}),
    ...(stringAt(activity, 'source') ? { source: stringAt(activity, 'source') } : {}),
    ...(stringAt(activity, 'availability') ? { availability: stringAt(activity, 'availability') } : {}),
    accepted,
    forwarded: accepted,
    rejected,
  };
}

/** Parses direct, wrapped, and future-additive history responses without manufacturing buckets. */
export function normalizeDatabaseActivityHistory(value: unknown): DatabaseActivityHistory {
  const container = historyContainer(value);
  if (!container) return { buckets: [] };
  const inheritedDuration = numberAt(container.root, 'duration_seconds');
  const buckets = container.buckets.flatMap((candidate) => {
    const bucket = normalizeBucket(candidate, inheritedDuration);
    return bucket ? [bucket] : [];
  });
  return { ...container.root, buckets };
}

export interface DatabaseActivityChartPoint {
  t: number;
  durationSeconds: number;
  forwarded: number | null;
  rejected: number | null;
  gap: boolean;
}

export function databaseActivityChartPoints(history: DatabaseActivityHistory): DatabaseActivityChartPoint[] {
  return history.buckets
    .flatMap((bucket) => {
      const seconds = bucket.started_at_unix ?? bucket.sampled_at_unix;
      if (typeof seconds !== 'number' || !Number.isFinite(seconds)) return [];
      const unavailable = bucket.gap === true || bucket.operations_observed === false;
      return [
        {
          t: seconds * 1_000,
          durationSeconds: bucket.duration_seconds,
          forwarded: unavailable ? null : finite(bucket.forwarded ?? bucket.accepted),
          rejected: unavailable ? null : finite(bucket.rejected),
          gap: unavailable,
        },
      ];
    })
    .sort((left, right) => left.t - right.t);
}
