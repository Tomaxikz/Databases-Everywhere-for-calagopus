import { axiosInstance } from '@/api/axios.ts';
import { poolConfigSchema, poolsSchema, poolViewSchema } from './poolSchemas.ts';
import type { DatabaseBackupRecord, PoolLimits, PoolWebSocketToken, ServerPoolView } from './types.ts';

export type { PoolReport } from './poolSchemas.ts';
export { poolReportSchema } from './poolSchemas.ts';

const base = (server: string) => `/api/client/servers/${server}/databases-everywhere/pools`;
const poolBase = (server: string, runtime: string) => `${base(server)}/${encodeURIComponent(runtime)}`;

export async function getServerPools(server: string): Promise<ServerPoolView[]> {
  const { data } = await axiosInstance.get(base(server));
  return poolsSchema.parse(data).pools as unknown as ServerPoolView[];
}

export async function getServerPool(server: string, runtime: string): Promise<ServerPoolView> {
  const { data } = await axiosInstance.get(poolBase(server, runtime));
  return poolViewSchema.parse(data) as unknown as ServerPoolView;
}

export async function powerPool(server: string, runtime: string, action: 'start' | 'stop' | 'restart' | 'kill') {
  const { data } = await axiosInstance.post(`${poolBase(server, runtime)}/power`, { action });
  return data;
}

export async function resizeServerPool(server: string, runtime: string, limits: PoolLimits) {
  const { data } = await axiosInstance.patch(poolBase(server, runtime), limits);
  return poolConfigSchema.parse(data);
}

export async function resizePool(node: string, runtime: string, limits: PoolLimits) {
  const { data } = await axiosInstance.patch(
    `/api/admin/databases-everywhere/${node}/pools/${encodeURIComponent(runtime)}`,
    limits,
  );
  return poolConfigSchema.parse(data);
}

export async function updatePoolImage(server: string, runtime: string, image: string, reason: string) {
  const { data } = await axiosInstance.patch(`${poolBase(server, runtime)}/image`, {
    image,
    confirm: true,
    reason,
  });
  return data;
}

export async function deleteEmptyPool(server: string, runtime: string, reason: string) {
  await axiosInstance.delete(poolBase(server, runtime), { params: { confirm: true, reason } });
}

export async function getPoolBackups(server: string, runtime: string): Promise<Record<string, DatabaseBackupRecord[]>> {
  const { data } = await axiosInstance.get(`${poolBase(server, runtime)}/backups`);
  return data.backups;
}

export async function mintPoolWebSocketToken(
  server: string,
  runtime: string,
  channel: 'monitor' | 'logs',
  signal?: AbortSignal,
): Promise<PoolWebSocketToken> {
  const { data } = await axiosInstance.post(`${poolBase(server, runtime)}/ws-token`, { channel }, { signal });
  return data;
}
