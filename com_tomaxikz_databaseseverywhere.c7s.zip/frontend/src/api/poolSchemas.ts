import { z } from 'zod';

const nullableFinite = z.number().finite().nullable();
const sampleSchema = z.looseObject({
  state: z.enum(['fresh', 'warming', 'stale', 'stopped', 'failed']),
  fresh: z.boolean(),
  sampled_at_unix: nullableFinite,
  sample_age_seconds: nullableFinite,
  source: z.string(),
  diagnostic: z.looseObject({ message: z.string().optional() }).nullable().optional(),
});

export const poolLimitsSchema = z.strictObject({
  cpu_cores: z.number().min(0.01).max(1024),
  memory_mib: z.number().int().min(1).max(1_048_576),
  disk_mib: z.number().int().positive(),
  max_tenants: z.number().int().min(1).max(1024),
});

const poolMetrics = {
  cpu: z.looseObject({
    usage_percent: nullableFinite,
    limit_cores: z.number().nonnegative(),
    sample: sampleSchema,
  }),
  memory: z.looseObject({
    usage_bytes: nullableFinite,
    limit_bytes: z.number().nonnegative(),
    sample: sampleSchema,
  }),
  disk: z.looseObject({
    usage_bytes: nullableFinite,
    limit_bytes: z.number().nonnegative(),
    reserved_bytes: z.number().nonnegative(),
    enforced: z.boolean(),
    enforcement_method: z.string(),
    sample: sampleSchema,
  }),
};

const ownerSchema = z.strictObject({ panel_id: z.string().min(1), server_id: z.string().min(1) });
export const poolStatusSchema = z.enum([
  'creating',
  'booting',
  'running',
  'stopped',
  'failed',
  'quarantined',
  'deleting',
]);

// SharedPoolReport has root-level physical metrics, unlike instance snapshots.
export const poolReportSchema = z.looseObject({
  runtime_id: z.string().min(1),
  owner: ownerSchema.nullable(),
  protocol: z.string().min(1),
  status: poolStatusSchema,
  desired_state: z.enum(['running', 'stopped']),
  pending_image: z.string().nullable(),
  tenant_count: z.number().int().nonnegative(),
  max_tenants: z.number().int().positive(),
  image: z.string(),
  database_version: z.string().nullable(),
  ...poolMetrics,
});

// PATCH returns PoolConfig, not SharedPoolReport.
export const poolConfigSchema = z.strictObject({
  runtime_id: z.string().min(1),
  owner: ownerSchema,
  limits: poolLimitsSchema,
});

const mappingSchema = z.strictObject({
  server_id: z.uuid(),
  node_uuid: z.uuid(),
  protocol: z.string().min(1),
  runtime_id: z.string().min(1),
  status_url: z.string().startsWith('/api/'),
  limits: poolLimitsSchema,
});

const childSchema = z.looseObject({
  uuid: z.uuid(),
  node_uuid: z.uuid(),
  protocol: z.string().min(1),
  deployment_mode: z.literal('shared'),
  runtime_id: z.string(),
});

export const poolViewSchema = z.strictObject({
  pool: mappingSchema,
  runtime: poolReportSchema.nullable(),
  status: poolStatusSchema,
  progress: z.record(z.string(), z.unknown()).nullable(),
  instances: z.array(z.looseObject({ instance_id: z.string().min(1) })),
  children: z.array(childSchema),
});

export const poolsSchema = z.strictObject({ pools: z.array(poolViewSchema) });

export type PoolReport = z.infer<typeof poolReportSchema>;
