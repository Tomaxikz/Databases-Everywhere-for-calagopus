import type { DbevSharedPool } from './types.ts';

// DBEV b679f09 SharedPoolReport (root JSON), shared by parser and stream tests.
export function poolReportFixture(): DbevSharedPool {
  const sample = { source: 'container_cpu', state: 'fresh', fresh: true, sampled_at_unix: 100, sample_age_seconds: 0 };
  return {
    runtime_id: 'pool-a',
    owner: { panel_id: 'panel-a', server_id: '5ea392aa-9c1a-43a0-a3bb-8e074f7c3679' },
    protocol: 'postgres',
    status: 'running',
    desired_state: 'running',
    image: 'postgres:17.4',
    pending_image: null,
    database_version: '17.4',
    tenant_count: 0,
    max_tenants: 16,
    cpu: { limit_cores: 4, usage_percent: 225, sample },
    memory: { limit_bytes: 4294967296, usage_bytes: 0, sample: { ...sample, source: 'container_memory_working_set' } },
    disk: {
      limit_bytes: 17179869184,
      reserved_bytes: 0,
      usage_bytes: null,
      enforced: true,
      enforcement_method: 'filesystem_quota',
      sample: {
        ...sample,
        source: 'filesystem_quota',
        state: 'warming',
        fresh: false,
        sampled_at_unix: null,
        sample_age_seconds: null,
      },
    },
  };
}
