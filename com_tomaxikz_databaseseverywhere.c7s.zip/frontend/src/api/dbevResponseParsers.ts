import { z } from 'zod';
import type { DatabaseBackupContents, DumpInspection } from './types.ts';

const dumpObject = z
  .object({
    kind: z.enum(['table', 'collection']),
    name: z.string(),
    namespace: z.string().optional(),
    selection_key: z.string(),
  })
  .passthrough();

const dumpInspection = z
  .object({
    protocol: z.enum(['postgres', 'mysql', 'mariadb', 'redis', 'valkey', 'mongodb', 'clickhouse', 'qdrant']),
    sha256: z.string(),
    source_size_bytes: z.number().nonnegative(),
    detected_archive_format: z.enum(['plain', 'gzip', 'bzip2', 'tar', 'tar.gz', 'zip']),
    selection_kind: z.enum(['tables', 'collections', 'full_only']),
    selective_supported: z.boolean(),
    catalog_complete: z.boolean(),
    namespaces: z.array(z.string()),
    objects: z.array(dumpObject),
    unselectable_object_count: z.number().int().nonnegative(),
    selective_unavailable_reason: z.string().optional(),
  })
  .passthrough();

const backupObject = z.object({ column_count: z.number().int().nonnegative() }).passthrough();
const backupSelection = z
  .object({
    columns: z.array(z.unknown()),
    rows: z.array(z.unknown()),
  })
  .passthrough();
const backupContents = z
  .object({
    objects: z.array(backupObject).optional(),
    selection: backupSelection.nullable().optional(),
  })
  .passthrough();

export function parseDumpInspection(value: unknown): DumpInspection {
  return dumpInspection.parse(value) as DumpInspection;
}

export function parseBackupContents(value: unknown): DatabaseBackupContents {
  return backupContents.parse(value) as DatabaseBackupContents;
}

export function retainedBackupObjects(
  previous: DatabaseBackupContents['objects'],
  response: DatabaseBackupContents,
): DatabaseBackupContents['objects'] {
  return response.objects ?? previous;
}
