import type { UseFormReturnType } from '@mantine/form';
import { useState } from 'react';
import SizeInput from '@/elements/input/SizeInput.tsx';

function valueAt(values: unknown, path: string): number {
  const value = path
    .split('.')
    .reduce<unknown>(
      (current, key) =>
        current && typeof current === 'object' ? (current as Record<string, unknown>)[key] : undefined,
      values,
    );
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

export default function FormSizeInput<T extends Record<string, unknown>>({
  form,
  name,
  label,
  description,
  min = 0,
}: {
  form: UseFormReturnType<T>;
  name: string;
  label: string;
  description?: string;
  min?: number;
}) {
  const [value, setValue] = useState(() => valueAt(form.getValues(), name));
  form.watch(name as never, ({ value: next }) => setValue(Number(next) || 0));

  return (
    <SizeInput
      mode='mb'
      min={min}
      label={label}
      description={description}
      value={value}
      onChange={(next) => form.setFieldValue(name as never, Math.round(next) as never)}
    />
  );
}
