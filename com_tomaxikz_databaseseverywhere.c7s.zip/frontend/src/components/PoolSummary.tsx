import { faHardDrive, faMemory, faMicrochip } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Group, SimpleGrid, Stack, Text } from '@mantine/core';
import Card from '@/elements/data-display/Card.tsx';
import { bytesToString, mbToBytes } from '@/lib/format/size.ts';
import { poolMetricValue } from '../admin/poolMetrics.ts';
import type { DbevSharedPool, PoolLimits } from '../api/types.ts';
import translations from '../translations.ts';

export default function PoolSummary({ pool, limits }: { pool: DbevSharedPool | null; limits?: PoolLimits }) {
  const { t } = translations.useTranslations();
  const values = [
    {
      label: t('pools.cpu', {}),
      icon: faMicrochip,
      usage: pool ? poolMetricValue(pool.cpu.usage_percent, pool.cpu.sample) : null,
      limit: pool ? pool.cpu.limit_cores : limits?.cpu_cores,
      sample: pool?.cpu.sample,
      format: (value: number) => `${Number(value.toFixed(2))}%`,
      formatLimit: (value: number) => t('server.cpuAllowance', { cores: value }),
    },
    {
      label: t('pools.memory', {}),
      icon: faMemory,
      usage: pool ? poolMetricValue(pool.memory.usage_bytes, pool.memory.sample) : null,
      limit: pool ? pool.memory.limit_bytes : limits ? mbToBytes(limits.memory_mib) : undefined,
      sample: pool?.memory.sample,
      format: bytesToString,
      formatLimit: bytesToString,
    },
    {
      label: t('pools.disk', {}),
      icon: faHardDrive,
      usage: pool ? poolMetricValue(pool.disk.usage_bytes, pool.disk.sample) : null,
      limit: pool ? pool.disk.limit_bytes : limits ? mbToBytes(limits.disk_mib) : undefined,
      sample: pool?.disk.sample,
      format: bytesToString,
      formatLimit: bytesToString,
    },
  ];
  return (
    <SimpleGrid cols={{ base: 1, md: 3 }} spacing='md'>
      {values.map((metric) => (
        <Card key={metric.label} p='lg'>
          <Stack gap='md'>
            <Group gap='md' wrap='nowrap' align='center'>
              <div className='flex size-11 shrink-0 items-center justify-center rounded-md bg-(--mantine-color-default) text-(--mantine-color-dimmed)'>
                <FontAwesomeIcon icon={metric.icon} size='lg' />
              </div>
              <Stack gap={5} className='min-w-0'>
                <Text size='sm' c='dimmed'>
                  {metric.label}
                </Text>
                <Text size='xl' fw={600} className='tabular-nums'>
                  {metric.usage === null ? t('pools.unavailable', {}) : metric.format(metric.usage)}
                </Text>
                <Text size='xs' c='dimmed'>
                  {t('poolWorkspace.capacity', {
                    value: metric.limit === undefined ? t('common.unavailable', {}) : metric.formatLimit(metric.limit),
                  })}
                </Text>
              </Stack>
            </Group>
            <Text size='xs' c='dimmed'>
              {metric.sample ? (
                <>
                  {metric.sample.source} · {metric.sample.state}
                  {metric.sample.sample_age_seconds !== null && ` · ${metric.sample.sample_age_seconds}s`}
                </>
              ) : (
                t('server.noSample', {})
              )}
            </Text>
            {metric.sample?.diagnostic?.message && (
              <Text size='xs' c='yellow'>
                {[metric.sample.diagnostic.message, metric.sample.diagnostic.code, metric.sample.diagnostic.error_id]
                  .filter((value) => typeof value === 'string')
                  .join(' · ')}
              </Text>
            )}
          </Stack>
        </Card>
      ))}
    </SimpleGrid>
  );
}
