import { Group, SimpleGrid, Stack, Text } from '@mantine/core';
import Alert from '@/elements/Alert.tsx';
import Badge from '@/elements/Badge.tsx';
import Button from '@/elements/Button.tsx';
import Card from '@/elements/Card.tsx';
import TitleCard from '@/elements/TitleCard.tsx';
import { StatusBadge } from '../components/common.tsx';
import translations from '../translations.ts';
import NodeRuntimeOverview from './NodeRuntimeOverview.tsx';
import { parseNodeHealthResult } from './nodeHealthResult.ts';

interface Props {
  value: unknown;
  onClose: () => void;
}

export default function NodeHealthReport({ value, onClose }: Props) {
  const { t } = translations.useTranslations();
  const report = parseNodeHealthResult(value);

  if (!report) {
    return (
      <Card>
        <Group justify='space-between' align='flex-start'>
          <Alert color='red' title={t('admin.healthReport.invalidTitle', {})} className='flex-1'>
            {t('admin.healthReport.invalidDescription', {})}
          </Alert>
          <Button size='xs' variant='default' onClick={onClose}>
            {t('common.close', {})}
          </Button>
        </Group>
      </Card>
    );
  }

  const system = report.system as Partial<NonNullable<typeof report.system>> | null;
  const heartbeatStatus = report.heartbeatStatus ?? t('admin.healthReport.notReported', {});

  return (
    <Stack>
      <TitleCard
        title={t('admin.healthReport.title', {})}
        rightSection={
          <Group className='ml-auto'>
            <StatusBadge status={report.heartbeatStatus === 'ok' ? 'healthy' : report.heartbeatStatus} />
            <Button size='xs' variant='default' onClick={onClose}>
              {t('common.close', {})}
            </Button>
          </Group>
        }
      >
        <Text size='xs' c='dimmed' mb='lg'>
          {t('admin.healthReport.description', {})}
        </Text>

        {report.mutationBlockReason && (
          <Alert color='yellow' title={t('admin.healthReport.readOnlyTitle', {})} mb='lg'>
            {report.mutationBlockReason}
          </Alert>
        )}

        <SimpleGrid cols={{ base: 1, sm: 2, xl: 4 }} spacing='lg'>
          <HealthMetric label={t('admin.healthReport.heartbeat', {})} value={heartbeatStatus} />
          <HealthMetric
            label={t('admin.healthReport.daemonIdentity', {})}
            value={system?.uuid ?? t('admin.healthReport.notReported', {})}
            detail={system?.service}
          />
          <HealthMetric
            label={t('admin.healthReport.apiContract', {})}
            value={system?.api_version ? `API ${system.api_version}` : t('admin.healthReport.notReported', {})}
            detail={system?.version ? `DBEV ${system.version}` : undefined}
          />
          <div>
            <Text size='xs' c='dimmed' mb={4}>
              {t('admin.healthReport.changeAccess', {})}
            </Text>
            <Badge
              color={report.mutationsAllowed === null ? 'gray' : report.mutationsAllowed ? 'green' : 'yellow'}
              variant='light'
            >
              {report.mutationsAllowed === null
                ? t('admin.healthReport.notReported', {})
                : report.mutationsAllowed
                  ? t('admin.healthReport.changesAllowed', {})
                  : t('admin.healthReport.readOnly', {})}
            </Badge>
          </div>
        </SimpleGrid>
      </TitleCard>

      <NodeRuntimeOverview system={report.system} resources={report.resources} />
    </Stack>
  );
}

function HealthMetric({ label, value, detail }: { label: string; value: string; detail?: string }) {
  return (
    <div className='min-w-0'>
      <Text size='xs' c='dimmed'>
        {label}
      </Text>
      <Text fw={600} className='break-all'>
        {value}
      </Text>
      {detail && (
        <Text size='xs' c='dimmed' className='break-all'>
          {detail}
        </Text>
      )}
    </div>
  );
}
