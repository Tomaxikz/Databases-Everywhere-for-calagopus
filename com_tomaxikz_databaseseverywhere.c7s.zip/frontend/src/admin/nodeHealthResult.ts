import type { DbevNodeResourceSummary, DbevSystemResponse } from '../api/types.ts';

export interface NodeHealthResult {
  heartbeatStatus: string | null;
  system: DbevSystemResponse | null;
  resources: DbevNodeResourceSummary | null;
  mutationsAllowed: boolean | null;
  mutationBlockReason: string | null;
}

export function parseNodeHealthResult(value: unknown): NodeHealthResult | null {
  if (!isRecord(value)) return null;

  const heartbeat = isRecord(value.heartbeat) ? value.heartbeat : null;
  const system = isRecord(value.system) ? (value.system as DbevSystemResponse) : null;
  const resources = isRecord(value.resources) ? (value.resources as unknown as DbevNodeResourceSummary) : null;
  const mutationsAllowed = typeof value.mutations_allowed === 'boolean' ? value.mutations_allowed : null;
  const mutationBlockReason =
    typeof value.mutation_block_reason === 'string' && value.mutation_block_reason.trim()
      ? value.mutation_block_reason
      : null;

  if (!heartbeat && !system && !resources && mutationsAllowed === null && !mutationBlockReason) return null;

  return {
    heartbeatStatus: typeof heartbeat?.status === 'string' ? heartbeat.status : null,
    system,
    resources,
    mutationsAllowed,
    mutationBlockReason,
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
