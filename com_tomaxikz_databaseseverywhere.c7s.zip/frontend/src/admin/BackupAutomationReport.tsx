import { Group, SimpleGrid, Stack, Text } from '@mantine/core';
import Button from '@/elements/buttons/Button.tsx';
import Badge from '@/elements/data-display/Badge.tsx';
import Card from '@/elements/data-display/Card.tsx';
import Table, { TableData, TableRow } from '@/elements/data-display/Table.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Code from '@/elements/typography/Code.tsx';
import { formatBytes, formatTimestamp } from '../components/common.tsx';
import translations from '../translations.ts';
import {
  type BackupAutomationRun,
  type BackupAutomationStatus,
  parseBackupAutomationRun,
  parseBackupAutomationStatus,
} from './backupAutomationResult.ts';

interface Props {
  value: unknown;
  operation: 'backup-status' | 'backup-run';
  onClose: () => void;
}

export default function BackupAutomationReport({ value, operation, onClose }: Props) {
  if (operation === 'backup-status') {
    const status = parseBackupAutomationStatus(value);
    return status ? <StatusReport status={status} onClose={onClose} /> : <InvalidReport onClose={onClose} />;
  }

  const run = parseBackupAutomationRun(value);
  return run ? <RunReport run={run} onClose={onClose} /> : <InvalidReport onClose={onClose} />;
}

function InvalidReport({ onClose }: { onClose: () => void }) {
  const { t } = translations.useTranslations();
  return (
    <Card>
      <Group justify='space-between' align='flex-start'>
        <Alert color='red' title={t('admin.backupReport.invalidTitle', {})} className='flex-1'>
          {t('admin.backupReport.invalidDescription', {})}
        </Alert>
        <Button size='xs' variant='default' onClick={onClose}>
          {t('common.close', {})}
        </Button>
      </Group>
    </Card>
  );
}

function StatusReport({ status, onClose }: { status: BackupAutomationStatus; onClose: () => void }) {
  const { t } = translations.useTranslations();
  return (
    <TitleCard
      title={t('admin.backupReport.statusTitle', {})}
      rightSection={
        <ReportActions
          badge={
            status.enabled === null
              ? t('admin.backupReport.notReported', {})
              : status.enabled
                ? t('common.enabled', {})
                : t('common.disabled', {})
          }
          badgeColor={status.enabled === null ? 'gray' : status.enabled ? 'green' : 'gray'}
          onClose={onClose}
        />
      }
    >
      <Text size='xs' c='dimmed' mb='lg'>
        {t('admin.backupReport.statusDescription', {})}
      </Text>

      {status.enabled === false && (
        <Alert color='yellow' title={t('admin.backupReport.disabledTitle', {})} mb='lg'>
          {t('admin.backupReport.disabledDescription', {})}
        </Alert>
      )}

      <SimpleGrid cols={{ base: 1, sm: 2, xl: 4 }} spacing='lg'>
        <Metric
          label={t('admin.backupReport.schedule', {})}
          value={formatInterval(status.intervalMinutes, t)}
          detail={booleanLabel(status.runOnStartup, t('admin.backupReport.runOnStartup', {}), t)}
        />
        <Metric
          label={t('admin.backupReport.storage', {})}
          value={status.storageDriver ? titleCase(status.storageDriver) : t('admin.backupReport.notReported', {})}
          detail={booleanLabel(status.browsingEnabled, t('admin.backupReport.browsing', {}), t)}
        />
        <Metric
          label={t('admin.backupReport.retentionCount', {})}
          value={retentionCount(status.retentionKeepLatestPerInstance, t)}
          detail={t('admin.backupReport.perDatabase', {})}
        />
        <Metric
          label={t('admin.backupReport.retentionAge', {})}
          value={retentionAge(status.retentionMaxAgeDays, t)}
          detail={booleanLabel(
            status.redisExcluded === null ? null : !status.redisExcluded,
            t('admin.backupReport.redisBackups', {}),
            t,
          )}
        />
      </SimpleGrid>
    </TitleCard>
  );
}

function RunReport({ run, onClose }: { run: BackupAutomationRun; onClose: () => void }) {
  const { t } = translations.useTranslations();
  const totalBytes = run.backups.reduce((total, backup) => total + (backup.sizeBytes ?? 0), 0);
  const totalSize = run.backups.every((backup) => backup.sizeBytes !== null)
    ? formatBytes(totalBytes)
    : t('admin.backupReport.incompleteSize', {});

  return (
    <Stack>
      <TitleCard
        title={t('admin.backupReport.runTitle', {})}
        rightSection={
          <ReportActions
            badge={t('admin.backupReport.completedCount', { count: run.backups.length })}
            badgeColor={run.failed.length ? 'red' : run.skipped.length ? 'yellow' : 'green'}
            onClose={onClose}
          />
        }
      >
        <Text size='xs' c='dimmed' mb='lg'>
          {t('admin.backupReport.runDescription', {})}
        </Text>
        <SimpleGrid cols={{ base: 1, sm: 4 }} spacing='lg'>
          <Metric label={t('admin.backupReport.failed', {})} value={String(run.failed.length)} />
          <Metric label={t('admin.backupReport.completed', {})} value={String(run.backups.length)} />
          <Metric label={t('admin.backupReport.skipped', {})} value={String(run.skipped.length)} />
          <Metric label={t('admin.backupReport.totalSize', {})} value={totalSize} />
        </SimpleGrid>
      </TitleCard>

      {run.backups.length > 0 && (
        <TitleCard title={t('admin.backupReport.completedBackups', {})} wrapperClassName='p-0!'>
          <Table
            columns={[
              t('admin.backupReport.databaseInstance', {}),
              t('admin.backupReport.backupId', {}),
              t('admin.backupReport.size', {}),
              t('admin.backupReport.created', {}),
            ]}
          >
            {run.backups.map((backup) => (
              <TableRow key={backup.id}>
                <TableData>
                  <Code>{backup.instanceId}</Code>
                </TableData>
                <TableData>
                  <Stack gap={2}>
                    <Code>{backup.id}</Code>
                    {backup.sha256 && (
                      <Text size='xs' c='dimmed' className='max-w-72 truncate' title={backup.sha256}>
                        SHA-256 {backup.sha256}
                      </Text>
                    )}
                  </Stack>
                </TableData>
                <TableData>
                  {backup.sizeBytes === null ? t('admin.backupReport.notReported', {}) : formatBytes(backup.sizeBytes)}
                </TableData>
                <TableData>{formatTimestamp(backup.modifiedAt)}</TableData>
              </TableRow>
            ))}
          </Table>
        </TitleCard>
      )}

      {run.failed.length > 0 && (
        <TitleCard title={t('admin.backupReport.failedBackups', {})} wrapperClassName='p-0!'>
          <Table
            columns={[
              t('admin.backupReport.databaseInstance', {}),
              t('server.protocol', {}),
              t('admin.backupReport.reason', {}),
            ]}
          >
            {run.failed.map((backup) => (
              <TableRow key={`${backup.instanceId}-${backup.reasonCode ?? backup.reasonMessage}`}>
                <TableData>
                  <Code>{backup.instanceId}</Code>
                </TableData>
                <TableData>
                  <Badge color='gray' variant='light'>
                    {backup.protocol ? titleCase(backup.protocol) : t('admin.backupReport.notReported', {})}
                  </Badge>
                </TableData>
                <TableData className='whitespace-normal'>
                  <Text size='sm'>{backup.reasonMessage}</Text>
                  {(backup.reasonCode || backup.errorId) && (
                    <Text size='xs' c='dimmed'>
                      {[backup.reasonCode, backup.errorId && `Error ID ${backup.errorId}`].filter(Boolean).join(' · ')}
                    </Text>
                  )}
                </TableData>
              </TableRow>
            ))}
          </Table>
        </TitleCard>
      )}

      {run.skipped.length > 0 && (
        <TitleCard title={t('admin.backupReport.skippedBackups', {})} wrapperClassName='p-0!'>
          <Table
            columns={[
              t('admin.backupReport.databaseInstance', {}),
              t('server.protocol', {}),
              t('admin.backupReport.reason', {}),
            ]}
          >
            {run.skipped.map((backup) => (
              <TableRow key={`${backup.instanceId}-${backup.reasonCode ?? backup.reasonMessage}`}>
                <TableData>
                  <Code>{backup.instanceId}</Code>
                </TableData>
                <TableData>
                  <Badge color='gray' variant='light'>
                    {backup.protocol ? titleCase(backup.protocol) : t('admin.backupReport.notReported', {})}
                  </Badge>
                </TableData>
                <TableData className='whitespace-normal'>
                  <Text size='sm'>{backup.reasonMessage}</Text>
                  {(backup.reasonCode || backup.errorId) && (
                    <Text size='xs' c='dimmed'>
                      {[backup.reasonCode, backup.errorId && `Error ID ${backup.errorId}`].filter(Boolean).join(' · ')}
                    </Text>
                  )}
                </TableData>
              </TableRow>
            ))}
          </Table>
        </TitleCard>
      )}

      {run.backups.length === 0 && run.skipped.length === 0 && run.failed.length === 0 && (
        <Alert color='blue' title={t('admin.backupReport.noEligibleTitle', {})}>
          {t('admin.backupReport.noEligibleDescription', {})}
        </Alert>
      )}
    </Stack>
  );
}

function ReportActions({ badge, badgeColor, onClose }: { badge: string; badgeColor: string; onClose: () => void }) {
  const { t } = translations.useTranslations();
  return (
    <Group className='ml-auto'>
      <Badge color={badgeColor} variant='light'>
        {badge}
      </Badge>
      <Button size='xs' variant='default' onClick={onClose}>
        {t('common.close', {})}
      </Button>
    </Group>
  );
}

function Metric({ label, value, detail }: { label: string; value: string; detail?: string }) {
  return (
    <div className='min-w-0'>
      <Text size='xs' c='dimmed'>
        {label}
      </Text>
      <Text fw={600} className='break-all'>
        {value}
      </Text>
      {detail && (
        <Text size='xs' c='dimmed'>
          {detail}
        </Text>
      )}
    </div>
  );
}

type Translation = ReturnType<typeof translations.useTranslations>['t'];

function booleanLabel(value: boolean | null, label: string, t: Translation): string {
  if (value === null) return `${label}: ${t('admin.backupReport.notReported', {})}`;
  return `${label}: ${value ? t('common.enabled', {}) : t('common.disabled', {})}`;
}

function formatInterval(minutes: number | null, t: Translation): string {
  if (minutes === null) return t('admin.backupReport.notReported', {});
  if (minutes === 0) return t('admin.backupReport.notScheduled', {});
  if (minutes % 1440 === 0) {
    const days = minutes / 1440;
    return days === 1 ? t('admin.backupReport.everyDay', {}) : t('admin.backupReport.everyDays', { count: days });
  }
  if (minutes % 60 === 0) {
    const hours = minutes / 60;
    return hours === 1 ? t('admin.backupReport.everyHour', {}) : t('admin.backupReport.everyHours', { count: hours });
  }
  return minutes === 1
    ? t('admin.backupReport.everyMinute', {})
    : t('admin.backupReport.everyMinutes', { count: minutes });
}

function retentionCount(value: number | null, t: Translation): string {
  if (value === null) return t('admin.backupReport.notReported', {});
  if (value === 0) return t('admin.backupReport.noCountLimit', {});
  return t('admin.backupReport.keepLatest', { count: value });
}

function retentionAge(value: number | null, t: Translation): string {
  if (value === null) return t('admin.backupReport.notReported', {});
  if (value === 0) return t('admin.backupReport.noAgeLimit', {});
  return value === 1 ? t('admin.backupReport.oneDay', {}) : t('admin.backupReport.days', { count: value });
}

function titleCase(value: string): string {
  return value.replaceAll('_', ' ').replace(/\b\w/g, (character) => character.toUpperCase());
}
