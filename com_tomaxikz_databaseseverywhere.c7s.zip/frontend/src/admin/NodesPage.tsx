import { faBoxesStacked, faGear, faPlus, faRotate } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Group } from '@mantine/core';
import { useQuery } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { Navigate, Route, Routes, useNavigate, useParams, useSearchParams } from 'react-router';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import { AdminCan } from '@/elements/Can.tsx';
import AdminContentContainer from '@/elements/containers/AdminContentContainer.tsx';
import Card from '@/elements/data-display/Card.tsx';
import Table from '@/elements/data-display/Table.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import Text from '@/elements/typography/Text.tsx';
import Title from '@/elements/typography/Title.tsx';
import { useAdminCan } from '@/plugins/usePermissions.ts';
import AdminPermissionGuard from '@/routers/guards/AdminPermissionGuard.tsx';
import { listNodes } from '../api/client.ts';
import { dbevQueryKeys } from '../api/queryKeys.ts';
import translations from '../translations.ts';
import { useCheckNodesOnLoad } from './ConnectionCheck.tsx';
import ImageCatalogPage from './ImageCatalogPage.tsx';
import NodeCreatePage from './NodeCreatePage.tsx';
import NodeTableRow from './NodeTableRow.tsx';
import NodeView from './NodeView.tsx';
import SettingsPage from './SettingsPage.tsx';

function NodesList() {
  const { t } = translations.useTranslations();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [search, setSearch] = useState('');
  const query = useQuery({
    queryKey: dbevQueryKeys.adminNodes(),
    queryFn: listNodes,
    refetchInterval: 30_000,
  });
  const canRunOperations = useAdminCan('databases-everywhere-nodes.operations');
  useCheckNodesOnLoad(query.data, canRunOperations);

  const filteredNodes = useMemo(() => {
    const needle = search.trim().toLowerCase();
    if (!needle) return query.data ?? [];
    return (query.data ?? []).filter((node) =>
      [node.uuid, node.name, node.api_url, node.public_host].some((value) => value?.toLowerCase().includes(needle)),
    );
  }, [query.data, search]);

  const legacyNode = searchParams.get('node');
  if (legacyNode) return <Navigate to={`/admin/databases-everywhere/${legacyNode}`} replace />;

  const addButton = (
    <AdminCan action='databases-everywhere-nodes.create'>
      <Button
        leftSection={<FontAwesomeIcon icon={faPlus} />}
        onClick={() => navigate('/admin/databases-everywhere/new')}
      >
        {t('manage.addHost', {})}
      </Button>
    </AdminCan>
  );

  return (
    <AdminContentContainer
      title={t('admin.title', {})}
      subtitle={t('manage.listSubtitle', {})}
      search={search}
      setSearch={setSearch}
      contentRight={
        <Group gap='xs'>
          <Button
            variant='default'
            loading={query.isFetching}
            leftSection={<FontAwesomeIcon icon={faRotate} />}
            onClick={() => void query.refetch()}
          >
            {t('common.refresh', {})}
          </Button>
          <Button
            variant='default'
            leftSection={<FontAwesomeIcon icon={faBoxesStacked} />}
            onClick={() => navigate('/admin/databases-everywhere/images')}
          >
            {t('admin.imageCatalog.open', {})}
          </Button>
          <AdminCan action='extensions.read'>
            <Button
              variant='default'
              leftSection={<FontAwesomeIcon icon={faGear} />}
              onClick={() => navigate('/admin/databases-everywhere/settings')}
            >
              {t('manage.settings', {})}
            </Button>
          </AdminCan>
          {addButton}
        </Group>
      }
    >
      {query.data && query.data.length === 0 ? (
        <Card p='xl'>
          <Stack align='center' gap='xs' py='lg'>
            <Title order={4}>{t('manage.list.emptyTitle', {})}</Title>
            <Text size='sm' c='dimmed' ta='center' maw={520}>
              {t('manage.list.emptyDescription', {})}
            </Text>
            <div className='mt-2'>{addButton}</div>
          </Stack>
        </Card>
      ) : (
        <Table
          columns={[
            t('admin.columns.name', {}),
            t('admin.columns.uuid', {}),
            t('admin.columns.status', {}),
            t('admin.columns.defaults', {}),
            t('admin.columns.lastSeen', {}),
          ]}
          loading={query.isPending}
          pagination={
            query.data
              ? {
                  total: filteredNodes.length,
                  perPage: Math.max(filteredNodes.length, 1),
                  page: 1,
                  data: filteredNodes,
                }
              : undefined
          }
          allowSelect={false}
          error={query.error ? httpErrorToHuman(query.error) : null}
        >
          {filteredNodes.map((node) => (
            <NodeTableRow node={node} key={node.uuid} />
          ))}
        </Table>
      )}
    </AdminContentContainer>
  );
}

function SettingsRoute() {
  const { t } = translations.useTranslations();
  return (
    <AdminContentContainer title={t('settings.title', {})} subtitle={t('settings.subtitle', {})}>
      <SettingsPage hideHeader />
    </AdminContentContainer>
  );
}

function LegacyEditRedirect() {
  const { node = '' } = useParams<{ node: string }>();
  return <Navigate to={`/admin/databases-everywhere/${node}/configuration`} replace />;
}

export default function NodesPage() {
  return (
    <Routes>
      <Route path='/' element={<NodesList />} />
      <Route path='/settings' element={<SettingsRoute />} />
      <Route path='/images' element={<ImageCatalogPage />} />
      <Route path='/images/:node' element={<ImageCatalogPage />} />
      <Route path='/images/:node/:protocol' element={<ImageCatalogPage />} />
      <Route element={<AdminPermissionGuard permission='databases-everywhere-nodes.create' />}>
        <Route path='/new' element={<NodeCreatePage />} />
      </Route>
      <Route path='/:node/edit' element={<LegacyEditRedirect />} />
      <Route path='/:node/*' element={<NodeView />} />
    </Routes>
  );
}
