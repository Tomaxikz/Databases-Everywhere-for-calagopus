import { faBoxesStacked, faRotate, faTrash } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { SimpleGrid } from '@mantine/core';
import { useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { useNavigate } from 'react-router';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Select from '@/elements/input/Select.tsx';
import TextArea from '@/elements/input/TextArea.tsx';
import TextInput from '@/elements/input/TextInput.tsx';
import Group from '@/elements/layout/Group.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import ConfirmationModal from '@/elements/modals/ConfirmationModal.tsx';
import { Modal, ModalFooter } from '@/elements/modals/Modal.tsx';
import Text from '@/elements/typography/Text.tsx';
import { useAdminCan } from '@/plugins/usePermissions.ts';
import { useToast } from '@/providers/ToastProvider.tsx';
import {
  deleteNode,
  nodeOperation,
  patchRemoteConfiguration,
  pullNodeImage,
  resetNodeCredentials,
} from '../api/client.ts';
import { normalizeDbevResourceReports } from '../api/normalizers.ts';
import { dbevQueryKeys } from '../api/queryKeys.ts';
import type { DatabaseProtocol, NodeCredentials, NodeRecord } from '../api/types.ts';
import { JsonView } from '../components/common.tsx';
import { protocolLabels } from '../components/protocols.ts';
import translations from '../translations.ts';
import BackupAutomationReport from './BackupAutomationReport.tsx';
import { parseBackupAutomationRun } from './backupAutomationResult.ts';
import { CheckConnectionButton, type ConnectionCheckState } from './ConnectionCheck.tsx';
import NodeConfigFileModal from './NodeConfigFileModal.tsx';
import NodeCredentialsModal from './NodeCredentialsModal.tsx';
import NodeResourceReports from './NodeResourceReports.tsx';
import { nodeRuntimeState } from './nodeRuntimeState.ts';
import SchedulerRecommendation from './SchedulerRecommendation.tsx';

type ResultKind = 'resources' | 'backup-status' | 'backup-run' | 'pull' | 'patch';

export default function NodeMaintenance({ node, check }: { node: NodeRecord; check: ConnectionCheckState }) {
  const { t } = translations.useTranslations();
  const { addToast } = useToast();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const runtimeState = nodeRuntimeState(node);
  const canRunOperations = useAdminCan('databases-everywhere-nodes.operations');
  const canUseCredentials = useAdminCan('databases-everywhere-nodes.credentials');
  const canUpdate = useAdminCan('databases-everywhere-nodes.update');
  const canDelete = useAdminCan('databases-everywhere-nodes.delete');
  const [busy, setBusy] = useState<string | null>(null);
  const [results, setResults] = useState<Partial<Record<ResultKind, unknown>>>({});
  const [protocol, setProtocol] = useState<DatabaseProtocol>('postgres');
  const [image, setImage] = useState('');
  const [patch, setPatch] = useState('{}');
  const [configOpen, setConfigOpen] = useState(false);
  const [rotateOpen, setRotateOpen] = useState(false);
  const [credentials, setCredentials] = useState<NodeCredentials | null>(null);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [confirmName, setConfirmName] = useState('');
  const [estimateOpen, setEstimateOpen] = useState(false);

  const clear = (kind: ResultKind) =>
    setResults((current) => {
      const next = { ...current };
      delete next[kind];
      return next;
    });

  const run = async (kind: ResultKind, operation: () => Promise<unknown>, refresh = false) => {
    setBusy(kind);
    try {
      const result = await operation();
      setResults((current) => ({ ...current, [kind]: result }));
      if (kind === 'backup-run') {
        const report = parseBackupAutomationRun(result);
        addToast(
          !report
            ? t('admin.backupReport.invalidDescription', {})
            : report.failed.length
              ? t('admin.backupReport.failedBackups', {})
              : t('admin.backupReport.completedCount', { count: report.backups.length }),
          !report || report.failed.length ? 'error' : report.skipped.length ? 'warning' : 'success',
        );
      }
      if (refresh) await queryClient.invalidateQueries({ queryKey: dbevQueryKeys.adminNodes() });
    } catch (error) {
      addToast(httpErrorToHuman(error), 'error');
    } finally {
      setBusy(null);
    }
  };

  const sendPatch = async () => {
    let parsed: unknown;
    try {
      parsed = JSON.parse(patch);
    } catch {
      parsed = null;
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      addToast(t('manage.rawPatch.invalid', {}), 'error');
      return;
    }
    await run('patch', () => patchRemoteConfiguration(node.uuid, parsed as Record<string, unknown>), true);
  };

  const rotate = async () => {
    try {
      const next = await resetNodeCredentials(node.uuid);
      setCredentials(next);
      await queryClient.invalidateQueries({ queryKey: dbevQueryKeys.adminNodeConfiguration(node.uuid) });
    } catch (error) {
      addToast(httpErrorToHuman(error), 'error');
    }
  };

  const remove = async () => {
    setBusy('delete');
    try {
      await deleteNode(node.uuid);
      await queryClient.invalidateQueries({ queryKey: dbevQueryKeys.adminNodes() });
      addToast(t('admin.nodeDeleted', {}), 'success');
      navigate('/admin/databases-everywhere');
    } catch (error) {
      addToast(httpErrorToHuman(error), 'error');
    } finally {
      setBusy(null);
    }
  };

  const closeButton = (kind: ResultKind) => (
    <Button className='ml-auto' size='xs' variant='default' onClick={() => clear(kind)}>
      {t('common.close', {})}
    </Button>
  );

  return (
    <Stack>
      <NodeConfigFileModal node={node.uuid} opened={configOpen} onClose={() => setConfigOpen(false)} />
      <NodeCredentialsModal credentials={credentials} onClose={() => setCredentials(null)} />
      <ConfirmationModal
        title={t('admin.rotateCredentials', {})}
        opened={rotateOpen}
        onClose={() => setRotateOpen(false)}
        onConfirmed={async () => {
          setRotateOpen(false);
          await rotate();
        }}
        confirm={t('admin.rotateCredentials', {})}
        confirmColor='orange'
      >
        {t('manage.rotateConfirm', {})}
      </ConfirmationModal>

      <SimpleGrid cols={{ base: 1, lg: 2 }}>
        {canRunOperations && (
          <TitleCard title={t('manage.connection.title', {})}>
            <Text size='sm' c='dimmed' mb='md'>
              {t('manage.connection.description', {})}
            </Text>
            <Group gap='sm'>
              <CheckConnectionButton check={check} />
              <Button
                variant='default'
                loading={busy === 'resources'}
                onClick={() => run('resources', () => nodeOperation(node.uuid, 'resources'))}
              >
                {t('manage.connection.diskReports', {})}
              </Button>
            </Group>
          </TitleCard>
        )}

        {canRunOperations && (
          <TitleCard title={t('admin.backupAutomation', {})}>
            <Text size='sm' c='dimmed' mb='md'>
              {t('manage.backups.description', {})}
            </Text>
            <Group gap='sm'>
              <Button
                variant='default'
                loading={busy === 'backup-status'}
                onClick={() => run('backup-status', () => nodeOperation(node.uuid, 'backup-status'))}
              >
                {t('manage.backups.status', {})}
              </Button>
              <Button
                loading={busy === 'backup-run'}
                disabled={runtimeState.mutationBlocked}
                onClick={() => run('backup-run', () => nodeOperation(node.uuid, 'backup-run', 'post'))}
              >
                {t('admin.runAllBackups', {})}
              </Button>
            </Group>
          </TitleCard>
        )}

        {canRunOperations && (
          <TitleCard
            title={t('manage.pull.title', {})}
            rightSection={
              <Button
                className='ml-auto'
                size='xs'
                variant='default'
                leftSection={<FontAwesomeIcon icon={faBoxesStacked} />}
                onClick={() => navigate(`/admin/databases-everywhere/images/${node.uuid}`)}
              >
                {t('admin.imageCatalog.open', {})}
              </Button>
            }
          >
            <Text size='sm' c='dimmed' mb='md'>
              {t('manage.pull.description', {})}
            </Text>
            <div className='grid grid-cols-1 gap-3 sm:grid-cols-[10rem_minmax(0,1fr)_auto] sm:items-end'>
              <Select
                label={t('server.protocol', {})}
                value={protocol}
                onChange={(value) => value && setProtocol(value as DatabaseProtocol)}
                data={Object.entries(protocolLabels).map(([value, label]) => ({ value, label }))}
              />
              <TextInput
                label={t('server.image', {})}
                placeholder={t('manage.pull.defaultImage', {})}
                value={image}
                onChange={(event) => setImage(event.currentTarget.value)}
              />
              <Button
                loading={busy === 'pull'}
                disabled={runtimeState.mutationBlocked}
                onClick={() => run('pull', () => pullNodeImage(node.uuid, protocol, image.trim() || undefined))}
              >
                {t('manage.pull.button', {})}
              </Button>
            </div>
          </TitleCard>
        )}

        {canRunOperations && (
          <TitleCard title={t('manage.estimate.title', {})}>
            <Text size='sm' c='dimmed' mb='md'>
              {t('manage.estimate.description', {})}
            </Text>
            <Button variant='default' onClick={() => setEstimateOpen(true)} disabled={estimateOpen}>
              {t('manage.estimate.open', {})}
            </Button>
          </TitleCard>
        )}

        {canUseCredentials && (
          <TitleCard title={t('manage.daemonFile.title', {})}>
            <Text size='sm' c='dimmed' mb='md'>
              {t('manage.daemonFile.description', {})}
            </Text>
            <Group gap='sm'>
              <Button variant='default' onClick={() => setConfigOpen(true)}>
                {t('manage.configFile.show', {})}
              </Button>
              <Button
                color='orange'
                variant='light'
                disabled={runtimeState.recordMutationBlocked}
                leftSection={<FontAwesomeIcon icon={faRotate} />}
                onClick={() => setRotateOpen(true)}
              >
                {t('admin.rotateCredentials', {})}
              </Button>
            </Group>
          </TitleCard>
        )}
      </SimpleGrid>

      {results.resources !== undefined && (
        <TitleCard title={t('manage.connection.diskReports', {})} rightSection={closeButton('resources')}>
          <NodeResourceReports reports={normalizeDbevResourceReports(results.resources)} />
        </TitleCard>
      )}
      {(['backup-status', 'backup-run'] as const).map(
        (kind) =>
          results[kind] !== undefined && (
            <BackupAutomationReport key={kind} value={results[kind]} operation={kind} onClose={() => clear(kind)} />
          ),
      )}
      {estimateOpen && <SchedulerRecommendation node={node} onClose={() => setEstimateOpen(false)} />}
      {results.pull !== undefined && (
        <TitleCard title={t('manage.pull.result', {})} rightSection={closeButton('pull')}>
          <JsonView value={results.pull} maxHeight={320} />
        </TitleCard>
      )}

      {canUpdate && (
        <TitleCard title={t('manage.rawPatch.title', {})}>
          <Text size='sm' c='dimmed' mb='md'>
            {t('manage.rawPatch.description', {})}
          </Text>
          <TextArea
            autosize
            minRows={4}
            maxRows={16}
            value={patch}
            onChange={(event) => setPatch(event.currentTarget.value)}
            styles={{ input: { fontFamily: 'var(--mantine-font-family-monospace)' } }}
          />
          {results.patch !== undefined && (
            <Alert color='green' mt='md' withCloseButton onClose={() => clear('patch')}>
              {t('manage.rawPatch.sent', {})}
            </Alert>
          )}
          <Group justify='flex-end' mt='md'>
            <Button loading={busy === 'patch'} disabled={runtimeState.mutationBlocked} onClick={sendPatch}>
              {t('manage.rawPatch.send', {})}
            </Button>
          </Group>
        </TitleCard>
      )}

      {canDelete && (
        <TitleCard title={t('manage.remove.title', {})}>
          <Group justify='space-between' wrap='wrap'>
            <Text size='sm' c='dimmed' maw={620}>
              {t('manage.remove.description', {})}
            </Text>
            <Button
              color='red'
              variant='light'
              disabled={runtimeState.recordMutationBlocked}
              leftSection={<FontAwesomeIcon icon={faTrash} />}
              onClick={() => setDeleteOpen(true)}
            >
              {t('admin.deleteNode', {})}
            </Button>
          </Group>
        </TitleCard>
      )}

      <Modal opened={deleteOpen} onClose={() => setDeleteOpen(false)} title={t('admin.deleteNode', {})}>
        <Stack>
          <Alert color='red'>{t('manage.remove.description', {})}</Alert>
          <TextInput
            label={t('manage.remove.confirm', { name: node.name })}
            value={confirmName}
            onChange={(event) => setConfirmName(event.currentTarget.value)}
          />
        </Stack>
        <ModalFooter>
          <Button
            color='red'
            loading={busy === 'delete'}
            disabled={runtimeState.recordMutationBlocked || confirmName !== node.name}
            onClick={remove}
          >
            {t('common.delete', {})}
          </Button>
          <Button variant='default' onClick={() => setDeleteOpen(false)}>
            {t('common.cancel', {})}
          </Button>
        </ModalFooter>
      </Modal>
    </Stack>
  );
}
