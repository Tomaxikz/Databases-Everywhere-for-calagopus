import {
  faArrowLeft,
  faDatabase,
  faGauge,
  faRotate,
  faScrewdriverWrench,
  faSliders,
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import AdminContentContainer from '@/elements/containers/AdminContentContainer.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Spinner from '@/elements/feedback/Spinner.tsx';
import Group from '@/elements/layout/Group.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import SubNavigation from '@/elements/navigation/SubNavigation.tsx';
import Text from '@/elements/typography/Text.tsx';
import { useAdminCan } from '@/plugins/usePermissions.ts';
import { useToast } from '@/providers/ToastProvider.tsx';
import { listNodes, nodeOperation } from '../api/client.ts';
import { dbevQueryKeys } from '../api/queryKeys.ts';
import type { NodeRecord } from '../api/types.ts';
import { StatusBadge } from '../components/common.tsx';
import translations from '../translations.ts';
import NodeConfigFileModal from './NodeConfigFileModal.tsx';
import NodeDatabaseInventory from './NodeDatabaseInventory.tsx';
import NodeMaintenance from './NodeMaintenance.tsx';
import NodeOverview from './NodeOverview.tsx';
import NodeSettingsEditor from './NodeSettingsEditor.tsx';
import { nodeRuntimeState, nodeStatus } from './nodeRuntimeState.ts';

function NodeBanners({ node }: { node: NodeRecord }) {
  const { t } = translations.useTranslations();
  const { addToast } = useToast();
  const queryClient = useQueryClient();
  const runtimeState = nodeRuntimeState(node);
  const canRunOperations = useAdminCan('databases-everywhere-nodes.operations');
  const canUseCredentials = useAdminCan('databases-everywhere-nodes.credentials');
  const [checking, setChecking] = useState(false);
  const [configOpen, setConfigOpen] = useState(false);

  const checkRestart = async () => {
    setChecking(true);
    try {
      await nodeOperation(node.uuid, 'restart-confirm', 'post');
      await queryClient.invalidateQueries({ queryKey: dbevQueryKeys.adminNodes() });
      addToast(t('manage.restartChecked', {}), 'success');
    } catch (error) {
      addToast(httpErrorToHuman(error), 'error');
    } finally {
      setChecking(false);
    }
  };

  return (
    <>
      <NodeConfigFileModal node={node.uuid} opened={configOpen} onClose={() => setConfigOpen(false)} />
      {runtimeState.recordMutationBlocked && (
        <Alert color='yellow' title={t('admin.readOnlyCompatibilityMode', {})}>
          {runtimeState.mutationBlockReason || t('admin.readOnlyCompatibilityDescription', {})}
        </Alert>
      )}
      {runtimeState.mutationBlocked && !runtimeState.recordMutationBlocked && (
        <Alert color='yellow' title={t('admin.unverifiedContractMode', {})}>
          {t('admin.unverifiedContractDescription', {})}
        </Alert>
      )}
      {runtimeState.restartRequired && (
        <Alert color='yellow' title={t('admin.restartRequired', {})}>
          <Stack gap='xs'>
            <Text size='sm'>{t('admin.restartRequiredDescription', {})}</Text>
            <Group gap='xs'>
              {canUseCredentials && (
                <Button size='compact-sm' variant='default' onClick={() => setConfigOpen(true)}>
                  {t('manage.configFile.show', {})}
                </Button>
              )}
              {canRunOperations && (
                <Button size='compact-sm' loading={checking} onClick={checkRestart}>
                  {t('admin.checkAfterRestart', {})}
                </Button>
              )}
            </Group>
          </Stack>
        </Alert>
      )}
      {runtimeState.operationalError && (
        <Alert color='red' title={t('manage.lastError', {})}>
          {runtimeState.operationalError}
        </Alert>
      )}
    </>
  );
}

export default function NodeView() {
  const { t } = translations.useTranslations();
  const navigate = useNavigate();
  const { node: uuid = '' } = useParams<{ node: string }>();
  const query = useQuery({
    queryKey: dbevQueryKeys.adminNodes(),
    queryFn: listNodes,
    refetchInterval: 30_000,
  });
  const node = query.data?.find((item) => item.uuid === uuid);
  const back = (
    <Button
      variant='default'
      leftSection={<FontAwesomeIcon icon={faArrowLeft} />}
      onClick={() => navigate('/admin/databases-everywhere')}
    >
      {t('manage.allHosts', {})}
    </Button>
  );

  if (!node) {
    return (
      <AdminContentContainer title={t('admin.title', {})} contentRight={back}>
        {query.isPending ? (
          <Spinner.Centered />
        ) : (
          <Alert color='red'>{query.error ? httpErrorToHuman(query.error) : t('manage.hostNotFound', {})}</Alert>
        )}
      </AdminContentContainer>
    );
  }

  return (
    <AdminContentContainer
      title={node.name}
      subtitle={`${node.public_host} · ${node.api_url}`}
      contentRight={
        <Group gap='sm'>
          <StatusBadge status={nodeStatus(node)} />
          <Button
            variant='default'
            loading={query.isFetching}
            leftSection={<FontAwesomeIcon icon={faRotate} />}
            onClick={() => void query.refetch()}
          >
            {t('common.refresh', {})}
          </Button>
          {back}
        </Group>
      }
    >
      <Stack>
        <NodeBanners node={node} />
        <SubNavigation
          baseUrl={`/admin/databases-everywhere/${node.uuid}`}
          items={[
            { name: t('manage.tabs.overview', {}), icon: faGauge, path: '/', element: <NodeOverview node={node} /> },
            {
              name: t('manage.tabs.databases', {}),
              icon: faDatabase,
              path: '/databases',
              element: <NodeDatabaseInventory node={node} />,
              permission: 'databases-everywhere-nodes.operations',
            },
            {
              name: t('manage.tabs.configuration', {}),
              icon: faSliders,
              path: '/configuration/*',
              end: false,
              element: <NodeSettingsEditor node={node} />,
              permission: 'databases-everywhere-nodes.read',
            },
            {
              name: t('manage.tabs.maintenance', {}),
              icon: faScrewdriverWrench,
              path: '/maintenance',
              element: <NodeMaintenance node={node} />,
            },
          ]}
        />
      </Stack>
    </AdminContentContainer>
  );
}
