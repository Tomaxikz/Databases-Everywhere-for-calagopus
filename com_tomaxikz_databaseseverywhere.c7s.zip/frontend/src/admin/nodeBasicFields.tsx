import type { FieldDef } from '@/elements/form-engine/index.ts';
import Switch from '@/elements/input/Switch.tsx';
import Text from '@/elements/typography/Text.tsx';
import translations from '../translations.ts';
import type { NodeFormValues } from './nodeForm.ts';

export function identityFields(): FieldDef<NodeFormValues>[] {
  const { t } = translations.getTranslations();
  return [
    {
      type: 'text',
      name: 'name',
      label: t('admin.nodeName', {}),
      description: t('admin.nodeNameDescription', {}),
      required: true,
    },
    {
      type: 'select',
      name: 'deploymentPolicy',
      label: t('admin.deploymentPolicy', {}),
      description: t('admin.deploymentPolicyDescription', {}),
      required: true,
      options: [
        { value: 'dedicated_only', label: t('admin.deploymentPolicies.dedicated', {}) },
        { value: 'shared_only', label: t('admin.deploymentPolicies.shared', {}) },
        { value: 'hybrid', label: t('admin.deploymentPolicies.hybrid', {}) },
      ],
    },
    {
      type: 'text',
      name: 'apiUrl',
      label: t('admin.apiUrl', {}),
      description: t('admin.apiUrlDescription', {}),
      required: true,
      props: { placeholder: 'https://db.example.com:8090' },
    },
    {
      type: 'text',
      name: 'publicHost',
      label: t('admin.publicHost', {}),
      description: t('admin.publicHostDescription', {}),
      required: true,
    },
    {
      type: 'custom',
      name: 'enabled',
      render: (fieldForm) => (
        <div className='flex h-full flex-col'>
          <Text size='sm' fw={500}>
            {t('admin.enabled', {})}
          </Text>
          <Text size='xs' c='dimmed' mt={2}>
            {t('admin.enabledDescription', {})}
          </Text>
          <Switch
            mt='sm'
            aria-label={t('admin.enabled', {})}
            key={fieldForm.key('enabled')}
            {...fieldForm.getInputProps('enabled', { type: 'checkbox' })}
          />
        </div>
      ),
    },
    {
      type: 'number',
      name: 'config.api.bindPortOverride',
      label: t('admin.nodeConfig.internalApiBindPort', {}),
      description: t('admin.nodeConfig.internalApiBindPortDescription', {}),
      advanced: true,
      props: { min: 0, max: 65_535 },
    },
  ];
}

export function resourceFields(): FieldDef<NodeFormValues>[] {
  const { t } = translations.getTranslations();
  return [
    { type: 'divider', name: 'resourceDefaults', label: t('admin.defaults', {}) },
    {
      type: 'number',
      name: 'defaultCpuCores',
      label: t('admin.cpu', {}),
      description: t('admin.cpuDescription', {}),
      required: true,
      props: { min: 0.01, max: 1024, decimalScale: 2, step: 0.25 },
    },
    {
      type: 'size',
      name: 'defaultMemoryMib',
      label: t('admin.memory', {}),
      description: t('admin.memoryDescription', {}),
      required: true,
      mode: 'mb',
      min: 1,
    },
    {
      type: 'size',
      name: 'defaultDiskMib',
      label: t('admin.disk', {}),
      description: t('admin.diskDescription', {}),
      required: true,
      mode: 'mb',
      min: 1,
    },
  ];
}

export function poolDefaultFields(): FieldDef<NodeFormValues>[] {
  const { t } = translations.getTranslations();
  return [
    { type: 'divider', name: 'poolResourceDefaults', label: t('admin.poolDefaults', {}) },
    {
      type: 'custom',
      name: 'poolDefaultsDescription',
      colSpan: 'full',
      render: () => (
        <Text size='sm' c='dimmed'>
          {t('admin.poolDefaultsDescription', {})}
        </Text>
      ),
    },
    {
      type: 'number',
      name: 'defaultPoolCpuCores',
      label: t('forms.poolCpuCores', {}),
      required: true,
      props: { min: 0.01, max: 1024, decimalScale: 2, step: 0.25 },
    },
    {
      type: 'size',
      name: 'defaultPoolMemoryMib',
      label: t('forms.poolMemoryMib', {}),
      required: true,
      mode: 'mb',
      min: 1,
    },
    {
      type: 'size',
      name: 'defaultPoolDiskMib',
      label: t('forms.poolDiskMib', {}),
      required: true,
      mode: 'mb',
      min: 1,
    },
    {
      type: 'number',
      name: 'defaultPoolMaxDatabases',
      label: t('forms.poolMaxDatabases', {}),
      required: true,
      props: { min: 1, max: 1024, allowDecimal: false },
    },
  ];
}
