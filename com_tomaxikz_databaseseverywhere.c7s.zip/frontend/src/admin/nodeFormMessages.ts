import translations from '../translations.ts';

export function nodeFormMessages() {
  const { t } = translations.getTranslations();
  return {
    apiUrlInvalid: t('admin.nodeConfig.apiUrlInvalid', {}),
    apiTlsRequired: t('admin.nodeConfig.apiTlsRequired', {}),
    clientCaRequired: t('admin.nodeConfig.clientCaRequired', {}),
    databaseTlsRequired: t('admin.nodeConfig.databaseTlsRequired', {}),
    s3BucketRequired: t('admin.nodeConfig.s3BucketRequired', {}),
    s3HttpRequiresOptIn: t('admin.nodeConfig.s3HttpRequiresOptIn', {}),
    clickhousePortsUnique: t('admin.nodeConfig.clickhousePortsUnique', {}),
    gatewayBindUnique: t('admin.nodeConfig.gatewayBindUnique', {}),
    gatewayProtocolRequired: t('admin.nodeConfig.gatewayProtocolRequired', {}),
    mysqlNineUnsupported: t('admin.nodeConfig.mysqlNineUnsupported', {}),
    schedulerLimitExceedsQueue: t('admin.nodeConfig.schedulerLimitExceedsQueue', {}),
    backupPreviewExceedsObjects: t('admin.nodeConfig.backupPreviewExceedsObjects', {}),
    remotePrivateHostInvalid: t('admin.nodeConfig.remotePrivateHostInvalid', {}),
    remoteOperationTimeoutTooShort: t('admin.nodeConfig.remoteOperationTimeoutTooShort', {}),
    uploadTotalSmallerThanFile: t('admin.nodeConfig.uploadTotalSmallerThanFile', {}),
    uploadIdleTimeoutTooLong: t('admin.nodeConfig.uploadIdleTimeoutTooLong', {}),
  };
}
