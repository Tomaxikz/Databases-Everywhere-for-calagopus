import { faPen } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { SimpleGrid } from '@mantine/core';
import { useNavigate } from 'react-router';
import Button from '@/elements/buttons/Button.tsx';
import CopyOnClick from '@/elements/CopyOnClick.tsx';
import Card from '@/elements/data-display/Card.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Group from '@/elements/layout/Group.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import Text from '@/elements/typography/Text.tsx';
import { bytesToString, mbToBytes } from '@/lib/format/size.ts';
import { useAdminCan } from '@/plugins/usePermissions.ts';
import type { NodeRecord } from '../api/types.ts';
import { formatTimestamp } from '../components/common.tsx';
import translations from '../translations.ts';
import NodeRuntimeOverview from './NodeRuntimeOverview.tsx';

function Fact({ label, value, copy }: { label: string; value: string; copy?: boolean }) {
  return (
    <div className='min-w-0'>
      <Text size='xs' c='dimmed'>
        {label}
      </Text>
      {copy ? (
        <CopyOnClick content={value}>
          <Text fw={600} className='truncate'>
            {value}
          </Text>
        </CopyOnClick>
      ) : (
        <Text fw={600} className='truncate'>
          {value}
        </Text>
      )}
    </div>
  );
}

export default function NodeOverview({ node }: { node: NodeRecord }) {
  const { t } = translations.useTranslations();
  const navigate = useNavigate();
  const canUpdate = useAdminCan('databases-everywhere-nodes.update');
  const size = (mib: number) => bytesToString(mbToBytes(mib));
  const policy =
    node.deployment_policy === 'dedicated_only'
      ? t('admin.deploymentPolicies.dedicated', {})
      : node.deployment_policy === 'shared_only'
        ? t('admin.deploymentPolicies.shared', {})
        : t('admin.deploymentPolicies.hybrid', {});
  const editResources = canUpdate ? (
    <Button
      className='ml-auto'
      size='xs'
      variant='default'
      leftSection={<FontAwesomeIcon icon={faPen} />}
      onClick={() => navigate(`/admin/databases-everywhere/${node.uuid}/configuration/resources`)}
    >
      {t('manage.change', {})}
    </Button>
  ) : undefined;

  return (
    <Stack>
      <Card p='md'>
        <div className='grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4'>
          <Fact label={t('admin.deploymentPolicy', {})} value={policy} />
          <Fact
            label={t('manage.newDatabases', {})}
            value={node.enabled ? t('manage.accepting', {}) : t('manage.notAccepting', {})}
          />
          <Fact
            label={t('admin.lastSeen', {})}
            value={node.last_seen ? formatTimestamp(node.last_seen) : t('admin.never', {})}
          />
          <Fact label={t('manage.daemonUuid', {})} value={node.daemon_uuid} copy />
        </div>
      </Card>

      <NodeRuntimeOverview system={node.cached_system} resources={node.cached_resources} />

      <SimpleGrid cols={{ base: 1, md: 2 }}>
        <TitleCard title={t('manage.dedicatedDefaults', {})} rightSection={editResources}>
          <Text size='sm' c='dimmed' mb='md'>
            {t('manage.dedicatedDefaultsDescription', {})}
          </Text>
          <SimpleGrid cols={3}>
            <Fact label={t('manage.cpu', {})} value={t('manage.cores', { cores: node.default_cpu_cores })} />
            <Fact label={t('manage.memory', {})} value={size(node.default_memory_mib)} />
            <Fact label={t('manage.disk', {})} value={size(node.default_disk_mib)} />
          </SimpleGrid>
        </TitleCard>
        <TitleCard title={t('admin.poolDefaults', {})} rightSection={editResources}>
          <Text size='sm' c='dimmed' mb='md'>
            {t('manage.poolDefaultsShort', {})}
          </Text>
          <SimpleGrid cols={{ base: 2, sm: 4 }}>
            <Fact
              label={t('manage.cpu', {})}
              value={t('manage.cores', { cores: node.default_pool_limits.cpu_cores })}
            />
            <Fact label={t('manage.memory', {})} value={size(node.default_pool_limits.memory_mib)} />
            <Fact label={t('manage.disk', {})} value={size(node.default_pool_limits.disk_mib)} />
            <Fact label={t('manage.databasesPerPool', {})} value={String(node.default_pool_limits.max_tenants)} />
          </SimpleGrid>
        </TitleCard>
      </SimpleGrid>

      <TitleCard title={t('admin.assignments', {})}>
        <Text size='sm' c='dimmed' mb='md'>
          {t('manage.assignmentsHelp', {})}
        </Text>
        <Group gap='sm'>
          <Button variant='default' size='xs' onClick={() => navigate('/admin/nodes')}>
            {t('manage.panelNodes', {})}
          </Button>
          <Button variant='default' size='xs' onClick={() => navigate('/admin/locations')}>
            {t('manage.panelLocations', {})}
          </Button>
        </Group>
      </TitleCard>
    </Stack>
  );
}
