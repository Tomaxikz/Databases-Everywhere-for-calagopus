import { Group, SimpleGrid, Stack, Text } from '@mantine/core';
import { useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import Card from '@/elements/data-display/Card.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Select from '@/elements/input/Select.tsx';
import SizeInput from '@/elements/input/SizeInput.tsx';
import Switch from '@/elements/input/Switch.tsx';
import { versionAtLeast } from '../api/capabilities.ts';
import { getSchedulerRecommendation } from '../api/client.ts';
import { dbevQueryKeys } from '../api/queryKeys.ts';
import type { DatabaseProtocol, NodeRecord, SchedulerRecommendationRequest } from '../api/types.ts';
import { formatBytes } from '../components/common.tsx';
import { protocolLabels } from '../components/protocols.ts';
import {
  configuredImportUploadMaxBytes,
  recommendationPresentation,
  schedulerRecommendationDefaults,
} from './schedulerContracts.ts';

const PHYSICAL_COMPRESSED = new Set<DatabaseProtocol>(['mongodb', 'redis', 'valkey', 'qdrant']);

export default function SchedulerRecommendation({ node, onClose }: { node: NodeRecord; onClose: () => void }) {
  const configuredUploadMaximum = configuredImportUploadMaxBytes(node.configuration);
  const [request, setRequest] = useState<SchedulerRecommendationRequest>(() =>
    schedulerRecommendationDefaults(configuredUploadMaximum),
  );
  const [debouncedRequest, setDebouncedRequest] = useState(request);
  const supported = versionAtLeast(node.cached_system?.api_version, [0, 16, 0]);

  useEffect(() => {
    setRequest(schedulerRecommendationDefaults(configuredUploadMaximum));
  }, [configuredUploadMaximum, node.uuid]);
  useEffect(() => {
    const timeout = window.setTimeout(() => setDebouncedRequest(request), 350);
    return () => window.clearTimeout(timeout);
  }, [request]);

  const recommendation = useQuery({
    queryKey: [...dbevQueryKeys.adminNode(node.uuid), 'scheduler-recommendation', debouncedRequest],
    queryFn: ({ signal }) => getSchedulerRecommendation(node.uuid, debouncedRequest, signal),
    enabled: supported,
    retry: false,
    refetchInterval: supported ? 15_000 : false,
    refetchOnWindowFocus: false,
  });
  const presentation = recommendationPresentation(recommendation.data);
  const compressedLocked = PHYSICAL_COMPRESSED.has(request.protocol);

  return (
    <TitleCard
      title='Transfer capacity estimate'
      rightSection={
        <Group className='ml-auto' gap='xs'>
          <Button
            variant='default'
            loading={recommendation.isFetching}
            disabled={!supported}
            onClick={() => void recommendation.refetch()}
          >
            Refresh
          </Button>
          <Button variant='default' onClick={onClose}>
            Close
          </Button>
        </Group>
      }
    >
      <Text size='xs' c='dimmed' mb='md'>
        Estimates how many import and export jobs this host can run at once for the job described below. Use it to
        choose the active job limit under Configuration, Imports & exports. It refreshes every 15 seconds while it is
        open.
      </Text>
      {!supported ? (
        <Alert color='yellow'>Run a connection test with DBEV API 0.16.0 or newer to use recommendations.</Alert>
      ) : (
        <Stack gap='md'>
          <SimpleGrid cols={{ base: 1, md: 2, xl: 3 }}>
            <Select
              label='Protocol'
              value={request.protocol}
              data={Object.entries(protocolLabels).map(([value, label]) => ({ value, label }))}
              onChange={(value) => {
                if (!value) return;
                const protocol = value as DatabaseProtocol;
                setRequest((current) => ({
                  ...current,
                  protocol,
                  compressed: PHYSICAL_COMPRESSED.has(protocol) || current.compressed,
                }));
              }}
            />
            <Select
              label='Action'
              value={request.action}
              data={[
                { value: 'import', label: 'Import' },
                { value: 'export', label: 'Export' },
              ]}
              onChange={(value) =>
                value &&
                setRequest((current) => ({
                  ...current,
                  action: value as 'import' | 'export',
                  mode: value === 'export' ? 'merge' : current.mode,
                }))
              }
            />
            <Select
              label='Import mode'
              value={request.mode}
              disabled={request.action === 'export'}
              data={[
                { value: 'merge', label: 'Merge' },
                { value: 'wipe', label: 'Wipe then import' },
              ]}
              onChange={(value) => value && setRequest((current) => ({ ...current, mode: value as 'merge' | 'wipe' }))}
            />
            <SizeInput
              mode='b'
              label='Input size'
              min={1}
              value={request.size_bytes}
              onChange={(value) => {
                const size = Math.max(1, Math.round(value) || 1);
                setRequest((current) => ({
                  ...current,
                  size_bytes: size,
                  target_disk_mib: Math.max(1, Math.ceil(size / 1_048_576)),
                }));
              }}
            />
            <SizeInput
              mode='mb'
              label='Target disk'
              min={1}
              value={request.target_disk_mib}
              onChange={(value) =>
                setRequest((current) => ({ ...current, target_disk_mib: Math.max(1, Math.round(value) || 1) }))
              }
            />
            <Switch
              mt='xl'
              checked={compressedLocked || request.compressed}
              disabled={compressedLocked}
              onChange={(event) => setRequest((current) => ({ ...current, compressed: event.currentTarget.checked }))}
              label='Compressed input'
              description={
                compressedLocked ? 'This protocol always uses a compressed/native archive model.' : undefined
              }
            />
          </SimpleGrid>

          {recommendation.error && <Alert color='red'>{httpErrorToHuman(recommendation.error)}</Alert>}
          {recommendation.data && (
            <>
              {!recommendation.data.scheduler.accepting && (
                <Alert color='yellow'>The scheduler is draining or shutting down and is not accepting new work.</Alert>
              )}
              {presentation.insufficientMemory && (
                <Alert color='red' title='Insufficient live memory/headroom'>
                  This modeled job does not safely fit right now. A recommendation of zero is intentional and was not
                  clamped to one.
                </Alert>
              )}
              {presentation.isolated && (
                <Alert color='blue' title='Isolated weighted execution'>
                  The job is memory-safe but exceeds the shared CPU or I/O weight. It may run alone and cannot overlap
                  another weighted job.
                </Alert>
              )}
              <SimpleGrid cols={{ base: 2, lg: 4 }}>
                <Metric label='Recommended active jobs' value={String(recommendation.data.recommended_active_jobs)} />
                <Metric label='Admitted operations' value={String(recommendation.data.admitted_jobs)} />
                <Metric
                  label='Mode / live limit'
                  value={`${recommendation.data.scheduler.capacity.mode} / ${recommendation.data.scheduler.capacity.max_active_jobs}`}
                />
                <Metric label='Modeled input' value={formatBytes(recommendation.data.estimate.input_size_bytes)} />
                <Metric label='Modeled memory' value={`${recommendation.data.estimate.memory_mib} MiB`} />
                <Metric label='I/O weight' value={`${recommendation.data.estimate.io_mib} MiB`} />
                <Metric label='CPU weight' value={String(recommendation.data.estimate.cpu_units)} />
                <Metric
                  label='Weighted active / waiting'
                  value={`${recommendation.data.scheduler.active_jobs} / ${recommendation.data.scheduler.waiting_jobs}`}
                />
              </SimpleGrid>
              <Text size='xs' c='dimmed'>
                Admitted operations include durable and synchronous work, including jobs waiting on an instance lock.
                Active and waiting counts describe weighted admission, not the full durable queue. Recommendations are
                models, not throughput guarantees.
              </Text>
            </>
          )}
        </Stack>
      )}
    </TitleCard>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <Card p='sm'>
      <Text size='xs' c='dimmed'>
        {label}
      </Text>
      <Text fw={700}>{value}</Text>
    </Card>
  );
}
