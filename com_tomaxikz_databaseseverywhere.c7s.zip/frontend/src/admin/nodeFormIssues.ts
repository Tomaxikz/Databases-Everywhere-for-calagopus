import type { ZodType } from 'zod';
import { resolveString } from '@/elements/form-engine/index.ts';
import translations from '../translations.ts';
import type { NodeFormValues } from './nodeForm.ts';
import { type NodeSettingsSection, type NodeSettingsSectionId, sectionForPath } from './nodeSettingsSections.tsx';

export interface NodeFormIssue {
  path: string;
  label: string;
  message: string;
  section: NodeSettingsSectionId;
}

export function nodeFormIssues(
  schema: ZodType<NodeFormValues>,
  values: NodeFormValues,
  sections: NodeSettingsSection[],
): NodeFormIssue[] {
  const parsed = schema.safeParse(values);
  if (parsed.success) return [];
  const { t } = translations.getTranslations();
  const seen = new Set<string>();
  return parsed.error.issues.flatMap((issue) => {
    const path = issue.path.map(String).join('.');
    if (seen.has(path)) return [];
    seen.add(path);
    const section = sectionForPath(sections, path);
    return [
      {
        path,
        section,
        label: fieldLabel(sections, path) ?? sections.find((item) => item.id === section)?.title ?? path,
        message: isBlank(valueAt(values, issue.path)) ? t('manage.issues.required', {}) : issue.message,
      },
    ];
  });
}

export function issueFor(issues: NodeFormIssue[], path: string): NodeFormIssue | undefined {
  return issues.find((issue) => issue.path === path);
}

function fieldLabel(sections: NodeSettingsSection[], path: string): string | null {
  for (const section of sections) {
    for (const field of section.fields) {
      if (field.type === 'divider' || field.name !== path) continue;
      const label = 'label' in field ? field.label : undefined;
      if (label) return resolveString(label);
    }
  }
  return null;
}

function valueAt(values: unknown, path: PropertyKey[]): unknown {
  let current = values;
  for (const key of path) {
    if (typeof current !== 'object' || current === null) return undefined;
    current = (current as Record<PropertyKey, unknown>)[key];
  }
  return current;
}

function isBlank(value: unknown): boolean {
  return value === undefined || value === null || (typeof value === 'string' && value.trim() === '');
}
