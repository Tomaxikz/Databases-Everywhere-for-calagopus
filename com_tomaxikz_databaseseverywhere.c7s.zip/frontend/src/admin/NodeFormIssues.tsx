import Button from '@/elements/buttons/Button.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Text from '@/elements/typography/Text.tsx';
import translations from '../translations.ts';
import type { NodeFormIssue } from './nodeFormIssues.ts';

export default function NodeFormIssues({
  issues,
  onFix,
}: {
  issues: NodeFormIssue[];
  onFix: (issue: NodeFormIssue) => void;
}) {
  const { t } = translations.useTranslations();
  if (!issues.length) return null;
  return (
    <Alert color='red' title={t('manage.issues.title', { count: issues.length })}>
      <ul className='m-0 list-none p-0'>
        {issues.map((issue) => (
          <li key={issue.path} className='py-0.5'>
            <Text size='sm' span fw={600}>
              {issue.label}
            </Text>
            <Text size='sm' span>
              {`: ${issue.message}`}
            </Text>
            <Button type='button' variant='subtle' size='compact-xs' onClick={() => onFix(issue)}>
              {t('manage.issues.fix', {})}
            </Button>
          </li>
        ))}
      </ul>
    </Alert>
  );
}
