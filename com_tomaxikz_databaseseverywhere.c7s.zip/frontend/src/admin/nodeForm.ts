import { z } from 'zod';
import type { NodeInput, NodeRecord } from '../api/types.ts';

export const protocols = [
  ['postgres', 'PostgreSQL', 20020, 'postgres:18.4'],
  ['mysql', 'MySQL', 3308, 'mysql:8.4'],
  ['mariadb', 'MariaDB', 20021, 'mariadb:12.3.2'],
  ['redis', 'Redis', 20022, 'redis:8.8.0'],
  ['valkey', 'Valkey', 20027, 'valkey/valkey:9.1.1'],
  ['mongodb', 'MongoDB', 20023, 'mongo:8.3.4'],
  ['clickhouse', 'ClickHouse', 20024, 'clickhouse/clickhouse-server:26.4.4.38'],
  ['qdrant', 'Qdrant', 20025, 'qdrant/qdrant:v1.18.2'],
] as const;

export type ProtocolKey = (typeof protocols)[number][0];

const MAX_IMPORT_BYTES = 8 * 1024 * 1024 * 1024;
const TRUSTED_ORIGIN_VALIDATION_ERROR =
  'Enter a complete HTTP(S) origin such as https://panel.example.com or https://panel.example.com:8443. Paths, credentials, queries, and fragments are not allowed.';

const REQUIRED = { error: 'Required' };

const hostName = z
  .string()
  .trim()
  .min(1, REQUIRED)
  .max(253)
  .refine((value) => !value.includes('/') && !value.match(/\s/), {
    error: 'Enter a host name without slashes or spaces.',
  });
const publicDatabaseHost = hostName.refine((value) => normalizePublicDatabaseHost(value) === value, {
  message: 'Enter a hostname or IP address without a port.',
});
const optionalAbsolutePath = z
  .string()
  .trim()
  .max(500)
  .refine((value) => !value || value.startsWith('/'));
const absolutePath = z.string().trim().startsWith('/').max(500);
const httpOrigin = z
  .string()
  .trim()
  .min(1, REQUIRED)
  .max(2048)
  .refine(isHttpOrigin, { message: TRUSTED_ORIGIN_VALIDATION_ERROR });
const imageReference = z
  .string()
  .trim()
  .min(1, REQUIRED)
  .max(255)
  .refine((image) => {
    const tail = image.split('/').at(-1) || '';
    const tag = tail.includes(':') ? tail.slice(tail.lastIndexOf(':') + 1) : '';
    return image.includes('@sha256:') || (tag.length > 0 && tag.toLowerCase() !== 'latest');
  });

const protocolConfigurationSchema = z.object({
  enabled: z.boolean(),
  bindHost: hostName,
  port: z.number().int().min(1).max(65_535),
  tls: z.boolean(),
  image: imageReference,
  allowedImages: z.array(imageReference).min(1).max(100),
});

const configurationSchema = z.object({
  debug: z.boolean(),
  protocols: z.object({
    postgres: protocolConfigurationSchema,
    mysql: protocolConfigurationSchema,
    mariadb: protocolConfigurationSchema,
    redis: protocolConfigurationSchema,
    valkey: protocolConfigurationSchema,
    mongodb: protocolConfigurationSchema,
    clickhouse: protocolConfigurationSchema.extend({
      httpBindHost: hostName,
      httpPort: z.number().int().min(1).max(65_535),
    }),
    qdrant: protocolConfigurationSchema,
  }),
  databaseTls: z.object({ cert: optionalAbsolutePath, key: optionalAbsolutePath }),
  api: z.object({
    bindPortOverride: z.number().int().min(0).max(65_535),
    trustedOrigins: z.array(httpOrigin).max(100),
    sslCert: optionalAbsolutePath,
    sslKey: optionalAbsolutePath,
    requireClientCert: z.boolean(),
    clientCa: optionalAbsolutePath,
  }),
  allocation: z.object({
    preventCpuOverallocation: z.boolean(),
    preventMemoryOverallocation: z.boolean(),
    preventDiskOverallocation: z.boolean(),
    maxMemoryMib: z.number().int().min(0).max(1_048_576),
    maxDiskMib: z.number().int().min(0),
    reservedMemoryMib: z.number().int().min(0).max(1_048_576),
    reservedDiskMib: z.number().int().min(0),
  }),
  backups: z.object({
    enabled: z.boolean(),
    intervalMinutes: z.number().int().min(1).max(525_600),
    runOnStartup: z.boolean(),
    retentionKeepLatestPerInstance: z.number().int().min(1).max(100_000),
    retentionMaxAgeDays: z.number().int().min(0).max(36_500),
    storageDriver: z.enum(['local', 's3', 'kopia']),
    s3: z.object({
      bucket: z.string().trim().max(255),
      region: z.string().trim().min(1, REQUIRED).max(100),
      endpoint: z
        .string()
        .trim()
        .max(2048)
        .refine((value) => !value || z.url({ protocol: /^https?$/ }).safeParse(value).success),
      prefix: z.string().trim().max(500),
      pathStyle: z.boolean(),
      allowHttp: z.boolean(),
      requestTimeoutSeconds: z.number().int().min(1).max(86_400),
      maxRetries: z.number().int().min(0).max(10),
    }),
    kopia: z.object({
      executable: absolutePath,
      configFile: optionalAbsolutePath,
      operationTimeoutSeconds: z.number().int().min(1).max(86_400),
    }),
    browsing: z.object({
      enabled: z.boolean(),
      maxObjects: z.number().int().min(1).max(1_000),
      maxPreviewObjects: z.number().int().min(0).max(1_000),
      previewRowsPerObject: z.number().int().min(0).max(100),
      maxRowBytes: z.number().int().min(256).max(16_384),
      maxCatalogBytes: z.number().int().min(65_536).max(1_048_576),
    }),
  }),
  artifacts: z.object({
    streamExportsOnly: z.boolean(),
    maxArtifactsPerInstance: z.number().int().min(1).max(10_000),
    retentionKeepLatest: z.number().int().min(1).max(100_000),
    retentionMaxAgeDays: z.number().int().min(0).max(36_500),
    importUploadMaxBytes: z.number().int().min(1).max(MAX_IMPORT_BYTES),
    importUploadMaxTotalBytes: z.number().int().min(1).max(Number.MAX_SAFE_INTEGER),
    importUploadMaxPerInstance: z.number().int().min(1).max(64),
    importUploadMaxConcurrent: z.number().int().min(1).max(32),
    importUploadTtlHours: z.number().int().min(1).max(168),
    importUploadTimeoutSeconds: z.number().int().min(60).max(86_400),
    importUploadIdleTimeoutSeconds: z.number().int().min(5).max(300),
    scheduler: z.object({
      dynamicLimiterEnabled: z.boolean(),
      maxQueuedJobs: z.number().int().min(64).max(8_192),
      maxQueuedJobsPerInstance: z.number().int().min(1).max(256),
      manualMaxActiveJobs: z.number().int().min(1).max(1_024),
      dynamicMaxActiveJobs: z.number().int().min(1).max(1_024),
      dynamicMemoryBudgetMib: z
        .number()
        .int()
        .refine((value) => value === 0 || (value >= 128 && value <= 16_777_216)),
      dynamicIoBudgetMib: z
        .number()
        .int()
        .refine((value) => value === 0 || (value >= 256 && value <= 67_108_864)),
      dynamicCpuUnits: z.number().int().min(0).max(65_536),
      starvationTimeoutSeconds: z.number().int().min(1).max(3_600),
      maxBypass: z.number().int().min(0).max(1_024),
    }),
  }),
  daemon: z.object({
    engine: z.enum(['docker', 'podman']),
    socketPath: optionalAbsolutePath,
    containerReadOnlyRootfs: z.boolean(),
    containerUsernsMode: z.string().trim().max(255),
    containerSeccompProfile: z.string().trim().max(500),
    containerApparmorProfile: z.string().trim().max(500),
    containerSecurityOpts: z.array(z.string().trim().min(1, REQUIRED).max(500)).max(100),
  }),
  security: z.object({
    apiBodyLimitBytes: z.number().int().min(1),
    apiRateLimitPerMinute: z.number().int().min(1),
    dbConnectionLimitPerMinute: z.number().int().min(1),
    pidsLimit: z.number().int().min(1),
    pidsLimits: z.object({
      postgres: z.number().int().min(0),
      mysql: z.number().int().min(0),
      mariadb: z.number().int().min(0),
      redis: z.number().int().min(0),
      valkey: z.number().int().min(0),
      mongodb: z.number().int().min(0),
      clickhouse: z.number().int().min(0),
      qdrant: z.number().int().min(0),
    }),
    remoteImport: z.object({
      enabled: z.boolean(),
      allowPlaintext: z.boolean(),
      allowedPrivateHosts: z.array(z.string().trim().min(1, REQUIRED).max(253)),
      maxConcurrentJobs: z.number().int().min(1).max(64),
      connectTimeoutSeconds: z.number().int().min(1).max(300),
      operationTimeoutSeconds: z.number().int().min(1).max(86_400),
      maxStagedBytes: z.number().int().min(1).max(MAX_IMPORT_BYTES),
    }),
  }),
  disk: z.object({
    mode: z.enum(['auto', 'project_quota', 'fuse_quota', 'soft_scanner']),
    fuseQuotaBinary: z
      .string()
      .trim()
      .min(1, REQUIRED)
      .max(500)
      .refine((value) => value === 'embedded' || value.startsWith('/')),
    fuseQuotaBinarySha256: z
      .string()
      .trim()
      .regex(/^(?:|[0-9a-f]{64})$/),
    fuseQuotaRescanIntervalSeconds: z.number().int().min(1).max(86_400),
    projectIdBase: z.number().int().min(1).max(2_147_000_000),
    softScanner: z.object({
      scanIntervalSeconds: z.number().int().min(1).max(3_600),
      useInotify: z.boolean(),
      fullScanIntervalSeconds: z.number().int().min(1).max(3_600),
      inotifyDebounceMilliseconds: z.number().int().min(1).max(60_000),
      maxDirtyPathsPerInstance: z.number().int().min(1).max(65_536),
      maxConcurrentScans: z.number().int().min(1).max(64),
      maxEntriesPerScan: z.number().int().min(1).max(10_000_000),
      scanTimeoutSeconds: z.number().int().min(1).max(3_600),
      maxConsecutiveScanFailures: z.number().int().min(1).max(10),
      safetyReserveMib: z.number().int().min(0),
      recoveryPercent: z.number().int().min(1).max(99),
      shutdownGraceSeconds: z.number().int().min(1).max(300),
    }),
  }),
  paths: z.object({
    data: z.string().trim().startsWith('/').max(500),
    metadata: z.string().trim().startsWith('/').max(500),
    volumes: z.string().trim().startsWith('/').max(500),
    backups: z.string().trim().startsWith('/').max(500),
    sockets: z.string().trim().startsWith('/').max(500),
    locks: z.string().trim().startsWith('/').max(500),
    logs: z.string().trim().startsWith('/').max(500),
    artifacts: z.string().trim().startsWith('/').max(500),
    exports: z.string().trim().startsWith('/').max(500),
    imports: z.string().trim().startsWith('/').max(500),
    fuse: z.string().trim().startsWith('/').max(500),
    tmp: z.string().trim().startsWith('/').max(500),
  }),
});

const secretSchema = z.object({
  s3AccessKeyId: z.string().max(5000),
  s3SecretAccessKey: z.string().max(5000),
  s3SessionToken: z.string().max(5000),
  kopiaRepositoryPassword: z.string().max(5000),
  clearS3Credentials: z.boolean(),
  clearKopiaRepositoryPassword: z.boolean(),
});

const baseNodeFormSchema = z.object({
  name: z.string().trim().min(1, REQUIRED).max(191),
  deploymentPolicy: z.enum(['dedicated_only', 'shared_only', 'hybrid']),
  apiUrl: z.string().trim().max(2048),
  publicHost: publicDatabaseHost,
  defaultCpuCores: z.number().min(0.01).max(1024),
  defaultMemoryMib: z.number().int().min(1).max(1_048_576),
  defaultDiskMib: z.number().int().min(1),
  defaultPoolCpuCores: z.number().min(0.01).max(1024),
  defaultPoolMemoryMib: z.number().int().min(1).max(1_048_576),
  defaultPoolDiskMib: z.number().int().min(1).max(Number.MAX_SAFE_INTEGER),
  defaultPoolMaxDatabases: z.number().int().min(1).max(1024),
  config: configurationSchema,
  secrets: secretSchema,
  enabled: z.boolean(),
});

export type NodeFormValues = z.infer<typeof baseNodeFormSchema>;

export type ParsedDaemonApiUrl = {
  scheme: 'http' | 'https';
  hostname: string;
  port: number;
  normalizedUrl: string;
};

export const nodeFormValidationOptions = {
  validateInputOnBlur: true,
  validateInputOnChange: false,
} as const;

export function parseDaemonApiUrl(value: string): ParsedDaemonApiUrl | null {
  const trimmed = value.trim();
  const origin = /^(https?):\/\/([^/?#]+)(?:\/)?$/i.exec(trimmed);
  if (!origin) return null;

  const scheme = origin[1].toLowerCase() as ParsedDaemonApiUrl['scheme'];
  const authority = origin[2];
  if (!authority || authority.includes('@')) return null;

  let rawHostname = '';
  let portText = '';
  if (authority.startsWith('[')) {
    const ipv6 = /^\[([^\]]+)]:(\d+)$/.exec(authority);
    if (!ipv6) return null;
    rawHostname = ipv6[1];
    portText = ipv6[2];
  } else {
    const separator = authority.lastIndexOf(':');
    if (separator <= 0 || authority.indexOf(':') !== separator) return null;
    rawHostname = authority.slice(0, separator);
    portText = authority.slice(separator + 1);
  }
  if (!/^\d+$/.test(portText)) return null;
  const port = Number(portText);
  if (!Number.isInteger(port) || port < 1 || port > 65_535) return null;

  try {
    const endpoint = new URL(trimmed);
    if (
      endpoint.protocol !== `${scheme}:` ||
      endpoint.username ||
      endpoint.password ||
      (endpoint.pathname !== '' && endpoint.pathname !== '/') ||
      endpoint.search ||
      endpoint.hash
    ) {
      return null;
    }
    const hostname = endpoint.hostname
      .replace(/^\[(.*)]$/, '$1')
      .replace(/\.$/, '')
      .toLowerCase();
    if (!isValidApiHostname(rawHostname, hostname)) return null;
    const serializedHost = hostname.includes(':') ? `[${hostname}]` : hostname;
    return { scheme, hostname, port, normalizedUrl: `${scheme}://${serializedHost}:${port}` };
  } catch {
    return null;
  }
}

export function apiUrlHostname(apiUrl: string): string {
  return parseDaemonApiUrl(apiUrl)?.hostname ?? '';
}

export function apiUrlUsesTls(apiUrl: string): boolean {
  return parseDaemonApiUrl(apiUrl)?.scheme === 'https';
}

export function normalizePublicDatabaseHost(value: string): string {
  const trimmed = value.trim();
  const bracketed = /^\[([^\]]+)](?::\d+)?$/.exec(trimmed);
  if (bracketed) return bracketed[1];

  const separator = trimmed.lastIndexOf(':');
  if (separator > 0 && trimmed.indexOf(':') === separator && /^\d+$/.test(trimmed.slice(separator + 1))) {
    return trimmed.slice(0, separator);
  }

  return trimmed;
}

export function daemonApiBindPort(values: NodeFormValues): number | null {
  const endpoint = parseDaemonApiUrl(values.apiUrl);
  if (!endpoint) return null;
  return values.config.api.bindPortOverride || endpoint.port;
}

function normalizeStoredDaemonApiUrl(value: string, fallbackPort: number): string {
  const parsed = parseDaemonApiUrl(value);
  if (parsed) return parsed.normalizedUrl;
  try {
    const endpoint = new URL(value.trim());
    if (
      !['http:', 'https:'].includes(endpoint.protocol) ||
      !endpoint.hostname ||
      endpoint.username ||
      endpoint.password ||
      (endpoint.pathname !== '' && endpoint.pathname !== '/') ||
      endpoint.search ||
      endpoint.hash ||
      fallbackPort < 1 ||
      fallbackPort > 65_535
    ) {
      return value;
    }
    const hostname = endpoint.hostname
      .replace(/^\[(.*)]$/, '$1')
      .replace(/\.$/, '')
      .toLowerCase();
    const serializedHost = hostname.includes(':') ? `[${hostname}]` : hostname;
    return `${endpoint.protocol.slice(0, -1)}://${serializedHost}:${fallbackPort}`;
  } catch {
    return value;
  }
}

export function hasLegacyApiIdentityFields(configuration: Record<string, unknown> | null | undefined): boolean {
  const api = configuration?.api;
  if (!api || typeof api !== 'object' || Array.isArray(api)) return false;
  return ['fqdn', 'trusted_hosts', 'allowed_hosts', 'url'].some((field) => field in (api as Record<string, unknown>));
}

export function hasUnsupportedSelfUpgrade(configuration: Record<string, unknown> | null | undefined): boolean {
  const security = configuration?.security;
  return (
    Boolean(security) &&
    typeof security === 'object' &&
    !Array.isArray(security) &&
    (security as Record<string, unknown>).self_upgrade_enabled === true
  );
}

export function createNodeFormSchema(messages: {
  apiUrlInvalid: string;
  apiTlsRequired: string;
  clientCaRequired: string;
  databaseTlsRequired: string;
  s3BucketRequired: string;
  s3HttpRequiresOptIn: string;
  clickhousePortsUnique: string;
  gatewayBindUnique: string;
  gatewayProtocolRequired: string;
  mysqlNineUnsupported: string;
  schedulerLimitExceedsQueue: string;
  backupPreviewExceedsObjects: string;
  remotePrivateHostInvalid: string;
  remoteOperationTimeoutTooShort: string;
  uploadTotalSmallerThanFile: string;
  uploadIdleTimeoutTooLong: string;
}) {
  return baseNodeFormSchema.superRefine((value, context) => {
    const apiEndpoint = parseDaemonApiUrl(value.apiUrl);
    if (!apiEndpoint) {
      context.addIssue({
        code: 'custom',
        path: ['apiUrl'],
        message: value.apiUrl.trim() ? messages.apiUrlInvalid : REQUIRED.error,
      });
    }
    if (value.enabled && !protocols.some(([protocol]) => value.config.protocols[protocol].enabled)) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'protocols'],
        message: messages.gatewayProtocolRequired,
      });
    }
    if (apiEndpoint?.scheme === 'https' && (!value.config.api.sslCert || !value.config.api.sslKey)) {
      context.addIssue({ code: 'custom', path: ['config', 'api', 'sslCert'], message: messages.apiTlsRequired });
    }
    if (apiEndpoint?.scheme === 'https' && value.config.api.requireClientCert && !value.config.api.clientCa) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'api', 'clientCa'],
        message: messages.clientCaRequired,
      });
    }
    const protocolTlsEnabled = protocols.some(
      ([protocol]) => value.config.protocols[protocol].enabled && value.config.protocols[protocol].tls,
    );
    if (protocolTlsEnabled && (!value.config.databaseTls.cert || !value.config.databaseTls.key)) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'databaseTls', 'cert'],
        message: messages.databaseTlsRequired,
      });
    }
    if (
      value.config.backups.enabled &&
      value.config.backups.storageDriver === 's3' &&
      value.config.backups.s3.endpoint.toLowerCase().startsWith('http://') &&
      !value.config.backups.s3.allowHttp
    ) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'backups', 's3', 'allowHttp'],
        message: messages.s3HttpRequiresOptIn,
      });
    }
    if (
      value.config.backups.enabled &&
      value.config.backups.storageDriver === 's3' &&
      !value.config.backups.s3.bucket
    ) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'backups', 's3', 'bucket'],
        message: messages.s3BucketRequired,
      });
    }
    if (value.config.backups.browsing.maxPreviewObjects > value.config.backups.browsing.maxObjects) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'backups', 'browsing', 'maxPreviewObjects'],
        message: messages.backupPreviewExceedsObjects,
      });
    }
    if (value.config.protocols.clickhouse.port === value.config.protocols.clickhouse.httpPort) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'protocols', 'clickhouse', 'httpPort'],
        message: messages.clickhousePortsUnique,
      });
    }
    const binds = new Map<string, (string | number)[]>();
    const addBind = (host: string, port: number, path: (string | number)[]) => {
      const bind = `${host.trim().toLowerCase()}:${port}`;
      const existing = binds.get(bind);
      if (existing) {
        context.addIssue({ code: 'custom', path, message: messages.gatewayBindUnique });
        return;
      }
      binds.set(bind, path);
    };
    for (const [protocol] of protocols) {
      const protocolConfig = value.config.protocols[protocol];
      if (!protocolConfig.enabled) continue;
      addBind(protocolConfig.bindHost, protocolConfig.port, ['config', 'protocols', protocol, 'port']);
      if (protocol === 'clickhouse') {
        const clickhouse = value.config.protocols.clickhouse;
        addBind(clickhouse.httpBindHost, clickhouse.httpPort, ['config', 'protocols', 'clickhouse', 'httpPort']);
      }
    }
    const mysqlImages = [value.config.protocols.mysql.image, ...value.config.protocols.mysql.allowedImages];
    if (mysqlImages.some(isMySqlNineImage)) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'protocols', 'mysql', 'image'],
        message: messages.mysqlNineUnsupported,
      });
    }
    const scheduler = value.config.artifacts.scheduler;
    for (const [field, fieldValue] of [
      ['maxQueuedJobsPerInstance', scheduler.maxQueuedJobsPerInstance],
      ['manualMaxActiveJobs', scheduler.manualMaxActiveJobs],
      ['dynamicMaxActiveJobs', scheduler.dynamicMaxActiveJobs],
    ] as const) {
      if (fieldValue > scheduler.maxQueuedJobs) {
        context.addIssue({
          code: 'custom',
          path: ['config', 'artifacts', 'scheduler', field],
          message: messages.schedulerLimitExceedsQueue,
        });
      }
    }
    const remoteImport = value.config.security.remoteImport;
    if (remoteImport.allowedPrivateHosts.some((host) => !isRemoteImportHost(host))) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'security', 'remoteImport', 'allowedPrivateHosts'],
        message: messages.remotePrivateHostInvalid,
      });
    }
    if (remoteImport.operationTimeoutSeconds < remoteImport.connectTimeoutSeconds) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'security', 'remoteImport', 'operationTimeoutSeconds'],
        message: messages.remoteOperationTimeoutTooShort,
      });
    }
    if (value.config.artifacts.importUploadMaxTotalBytes < value.config.artifacts.importUploadMaxBytes) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'artifacts', 'importUploadMaxTotalBytes'],
        message: messages.uploadTotalSmallerThanFile,
      });
    }
    if (value.config.artifacts.importUploadIdleTimeoutSeconds > value.config.artifacts.importUploadTimeoutSeconds) {
      context.addIssue({
        code: 'custom',
        path: ['config', 'artifacts', 'importUploadIdleTimeoutSeconds'],
        message: messages.uploadIdleTimeoutTooLong,
      });
    }
  });
}

export function isLoopbackHost(host: string) {
  const normalized = host
    .trim()
    .toLowerCase()
    .replace(/^\[(.*)]$/, '$1');
  return normalized === 'localhost' || normalized.startsWith('127.') || normalized === '::1';
}

function isHttpOrigin(value: string) {
  try {
    const origin = new URL(value);
    return (
      ['http:', 'https:'].includes(origin.protocol) &&
      !origin.username &&
      !origin.password &&
      (origin.pathname === '' || origin.pathname === '/') &&
      !origin.search &&
      !origin.hash &&
      Boolean(origin.port || (origin.protocol === 'https:' ? 443 : 80))
    );
  } catch {
    return false;
  }
}

function isIpv4Address(value: string) {
  const parts = value.split('.');
  return parts.length === 4 && parts.every((part) => /^(?:0|[1-9]\d{0,2})$/.test(part) && Number(part) <= 255);
}

function isDnsHostname(value: string) {
  if (
    !value ||
    value.length > 253 ||
    [...value].some((character) => character.charCodeAt(0) > 127) ||
    value.endsWith('.')
  ) {
    return false;
  }
  const labels = value.split('.');
  return labels.every(
    (label) =>
      label.length > 0 &&
      label.length <= 63 &&
      !label.startsWith('-') &&
      !label.endsWith('-') &&
      /^[a-z0-9-]+$/i.test(label),
  );
}

function isValidApiHostname(rawHostname: string, parsedHostname: string) {
  const raw = rawHostname.toLowerCase();
  if (raw.includes(':')) return parsedHostname.includes(':');
  if (/^[\d.]+$/.test(raw)) return isIpv4Address(raw) && parsedHostname === raw;
  return isDnsHostname(raw) && isDnsHostname(parsedHostname);
}

function isMySqlNineImage(image: string) {
  const withoutDigest = image.split('@', 1)[0];
  const tail = withoutDigest.split('/').at(-1) || '';
  const tag = tail.includes(':') ? tail.slice(tail.lastIndexOf(':') + 1) : '';
  return /^9(?:[.-]|$)/.test(tag);
}

function isRemoteImportHost(value: string) {
  const host = value.trim();
  if (!host) return false;
  const ipv4Parts = host.split('.');
  if (ipv4Parts.length === 4 && ipv4Parts.every((part) => /^(?:0|[1-9]\d{0,2})$/.test(part) && Number(part) <= 255)) {
    return true;
  }
  const ipv6 = host.startsWith('[') && host.endsWith(']') ? host.slice(1, -1) : host;
  if (ipv6.includes(':')) {
    try {
      return new URL(`http://[${ipv6}]`).hostname.length > 2;
    } catch {
      return false;
    }
  }
  const normalized = host.endsWith('.') ? host.slice(0, -1) : host;
  if (!normalized || normalized.length > 253 || [...normalized].some((character) => character.charCodeAt(0) > 0x7f)) {
    return false;
  }
  const labels = normalized.split('.');
  if (
    labels.some(
      (label) =>
        !label || label.length > 63 || label.startsWith('-') || label.endsWith('-') || !/^[a-z0-9-]+$/i.test(label),
    )
  ) {
    return false;
  }
  return !labels.every((label) => /^\d+$/.test(label) || /^0x[\da-f]+$/i.test(label));
}

const pathValue = (root: Record<string, unknown>, path: string[], fallback: unknown): unknown => {
  let current: unknown = root;
  for (const part of path) {
    if (!current || typeof current !== 'object' || Array.isArray(current)) return fallback;
    current = (current as Record<string, unknown>)[part];
  }
  return current ?? fallback;
};

const stringValue = (root: Record<string, unknown>, path: string[], fallback = '') => {
  const value = pathValue(root, path, fallback);
  return typeof value === 'string' ? value : fallback;
};
const numberValue = (root: Record<string, unknown>, path: string[], fallback: number) => {
  const value = pathValue(root, path, fallback);
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback;
};
const nullableOverrideValue = (root: Record<string, unknown>, path: string[], fallback: number) => {
  let current: unknown = root;
  for (const part of path) {
    if (!current || typeof current !== 'object' || Array.isArray(current)) return fallback;
    current = (current as Record<string, unknown>)[part];
  }
  if (current === null) return 0;
  return typeof current === 'number' && Number.isFinite(current) ? current : fallback;
};
const booleanValue = (root: Record<string, unknown>, path: string[], fallback: boolean) => {
  const value = pathValue(root, path, fallback);
  return typeof value === 'boolean' ? value : fallback;
};
const stringsValue = (root: Record<string, unknown>, path: string[], fallback: string[]) => {
  const value = pathValue(root, path, fallback);
  return Array.isArray(value) ? value.filter((entry): entry is string => typeof entry === 'string') : fallback;
};

function parseBind(bind: string, fallbackHost: string, fallbackPort: number) {
  const separator = bind.lastIndexOf(':');
  if (separator < 1) return { host: fallbackHost, port: fallbackPort };
  const port = Number(bind.slice(separator + 1));
  return {
    host: bind.slice(0, separator) || fallbackHost,
    port: Number.isInteger(port) && port > 0 && port <= 65_535 ? port : fallbackPort,
  };
}

export function initialNodeFormValues(node?: NodeRecord): NodeFormValues {
  const configuration = node?.configuration ?? {};
  const configuredApiPort = numberValue(configuration, ['api', 'port'], 8090);
  const apiUrl = node?.api_url ? normalizeStoredDaemonApiUrl(node.api_url, configuredApiPort) : '';
  const parsedApiUrl = parseDaemonApiUrl(apiUrl);
  const configuredLogsPath = stringValue(configuration, ['paths', 'logs'], '/var/lib/dbev/logs');
  const protocolValues = Object.fromEntries(
    protocols.map(([protocol, , defaultPort, defaultImage]) => {
      const bind = parseBind(
        stringValue(configuration, [protocol, 'bind'], `0.0.0.0:${defaultPort}`),
        '0.0.0.0',
        defaultPort,
      );
      const base = {
        enabled: booleanValue(configuration, [protocol, 'enabled'], true),
        bindHost: bind.host,
        port: bind.port,
        tls: booleanValue(configuration, [protocol, 'tls'], false),
        image: stringValue(configuration, ['images', protocol], defaultImage),
        allowedImages: stringsValue(
          configuration,
          ['images', 'allowed', protocol],
          protocol === 'mongodb' ? [defaultImage, 'mongo:7.0.37'] : [defaultImage],
        ),
      };
      return [
        protocol,
        protocol === 'clickhouse'
          ? {
              ...base,
              ...(() => {
                const http = parseBind(
                  stringValue(configuration, ['clickhouse', 'http_bind'], '0.0.0.0:20026'),
                  '0.0.0.0',
                  20026,
                );
                return { httpBindHost: http.host, httpPort: http.port };
              })(),
            }
          : base,
      ];
    }),
  ) as NodeFormValues['config']['protocols'];

  return {
    name: node?.name ?? '',
    deploymentPolicy: node?.deployment_policy ?? 'dedicated_only',
    apiUrl,
    publicHost: normalizePublicDatabaseHost(node?.public_host ?? ''),
    defaultCpuCores: node?.default_cpu_cores ?? 0.5,
    defaultMemoryMib: node?.default_memory_mib ?? 512,
    defaultDiskMib: node?.default_disk_mib ?? 1024,
    defaultPoolCpuCores: node?.default_pool_limits?.cpu_cores ?? 1,
    defaultPoolMemoryMib: node?.default_pool_limits?.memory_mib ?? 1024,
    defaultPoolDiskMib: node?.default_pool_limits?.disk_mib ?? 16384,
    defaultPoolMaxDatabases: node?.default_pool_limits?.max_tenants ?? 8,
    enabled: node?.enabled ?? true,
    config: {
      debug: booleanValue(configuration, ['debug'], false),
      protocols: protocolValues,
      databaseTls: {
        cert: stringValue(configuration, ['tls', 'cert']),
        key: stringValue(configuration, ['tls', 'key']),
      },
      api: {
        bindPortOverride: parsedApiUrl && configuredApiPort !== parsedApiUrl.port ? configuredApiPort : 0,
        trustedOrigins: stringsValue(configuration, ['api', 'trusted_origins'], []),
        sslCert: stringValue(configuration, ['api', 'ssl', 'cert']),
        sslKey: stringValue(configuration, ['api', 'ssl', 'key']),
        requireClientCert: booleanValue(configuration, ['api', 'ssl', 'require_client_cert'], false),
        clientCa: stringValue(configuration, ['api', 'ssl', 'client_ca']),
      },
      allocation: {
        preventCpuOverallocation: booleanValue(configuration, ['allocation', 'prevent_cpu_overallocation'], true),
        preventMemoryOverallocation: booleanValue(configuration, ['allocation', 'prevent_memory_overallocation'], true),
        preventDiskOverallocation: booleanValue(configuration, ['allocation', 'prevent_disk_overallocation'], true),
        maxMemoryMib: numberValue(configuration, ['allocation', 'max_memory_mib'], 0),
        maxDiskMib: numberValue(configuration, ['allocation', 'max_disk_mib'], 0),
        reservedMemoryMib: numberValue(configuration, ['allocation', 'reserved_memory_mib'], 512),
        reservedDiskMib: numberValue(configuration, ['allocation', 'reserved_disk_mib'], 2048),
      },
      backups: {
        enabled: booleanValue(configuration, ['backups', 'enabled'], false),
        intervalMinutes: numberValue(configuration, ['backups', 'interval_minutes'], 1440),
        runOnStartup: booleanValue(configuration, ['backups', 'run_on_startup'], false),
        retentionKeepLatestPerInstance: numberValue(
          configuration,
          ['backups', 'retention_keep_latest_per_instance'],
          7,
        ),
        retentionMaxAgeDays: numberValue(configuration, ['backups', 'retention_max_age_days'], 30),
        storageDriver: stringValue(configuration, ['backups', 'storage', 'driver'], 'local') as
          | 'local'
          | 's3'
          | 'kopia',
        s3: {
          bucket: stringValue(configuration, ['backups', 'storage', 's3', 'bucket']),
          region: stringValue(configuration, ['backups', 'storage', 's3', 'region'], 'us-east-1'),
          endpoint: stringValue(configuration, ['backups', 'storage', 's3', 'endpoint']),
          prefix: stringValue(configuration, ['backups', 'storage', 's3', 'prefix'], 'dbev'),
          pathStyle: booleanValue(configuration, ['backups', 'storage', 's3', 'path_style'], false),
          allowHttp: booleanValue(configuration, ['backups', 'storage', 's3', 'allow_http'], false),
          requestTimeoutSeconds: numberValue(
            configuration,
            ['backups', 'storage', 's3', 'request_timeout_seconds'],
            900,
          ),
          maxRetries: numberValue(configuration, ['backups', 'storage', 's3', 'max_retries'], 3),
        },
        kopia: {
          executable: stringValue(configuration, ['backups', 'storage', 'kopia', 'executable'], '/usr/local/bin/kopia'),
          configFile: stringValue(configuration, ['backups', 'storage', 'kopia', 'config_file']),
          operationTimeoutSeconds: numberValue(
            configuration,
            ['backups', 'storage', 'kopia', 'operation_timeout_seconds'],
            3600,
          ),
        },
        browsing: {
          enabled: booleanValue(configuration, ['backups', 'browsing', 'enabled'], true),
          maxObjects: numberValue(configuration, ['backups', 'browsing', 'max_objects'], 256),
          maxPreviewObjects: numberValue(configuration, ['backups', 'browsing', 'max_preview_objects'], 32),
          previewRowsPerObject: numberValue(configuration, ['backups', 'browsing', 'preview_rows_per_object'], 10),
          maxRowBytes: numberValue(configuration, ['backups', 'browsing', 'max_row_bytes'], 4096),
          maxCatalogBytes: numberValue(configuration, ['backups', 'browsing', 'max_catalog_bytes'], 1_048_576),
        },
      },
      artifacts: {
        streamExportsOnly: booleanValue(configuration, ['artifacts', 'stream_exports_only'], false),
        maxArtifactsPerInstance: numberValue(configuration, ['artifacts', 'max_artifacts_per_instance'], 20),
        retentionKeepLatest: numberValue(configuration, ['artifacts', 'retention_keep_latest'], 20),
        retentionMaxAgeDays: numberValue(configuration, ['artifacts', 'retention_max_age_days'], 30),
        importUploadMaxBytes: numberValue(configuration, ['artifacts', 'import_upload_max_bytes'], 8_589_934_592),
        importUploadMaxTotalBytes: numberValue(
          configuration,
          ['artifacts', 'import_upload_max_total_bytes'],
          34_359_738_368,
        ),
        importUploadMaxPerInstance: numberValue(configuration, ['artifacts', 'import_upload_max_per_instance'], 4),
        importUploadMaxConcurrent: numberValue(configuration, ['artifacts', 'import_upload_max_concurrent'], 2),
        importUploadTtlHours: numberValue(configuration, ['artifacts', 'import_upload_ttl_hours'], 24),
        importUploadTimeoutSeconds: numberValue(configuration, ['artifacts', 'import_upload_timeout_seconds'], 3_600),
        importUploadIdleTimeoutSeconds: numberValue(
          configuration,
          ['artifacts', 'import_upload_idle_timeout_seconds'],
          30,
        ),
        scheduler: {
          dynamicLimiterEnabled: booleanValue(
            configuration,
            ['artifacts', 'import_export_scheduler', 'dynamic_limiter_enabled'],
            true,
          ),
          maxQueuedJobs: numberValue(configuration, ['artifacts', 'import_export_scheduler', 'max_queued_jobs'], 1024),
          maxQueuedJobsPerInstance: numberValue(
            configuration,
            ['artifacts', 'import_export_scheduler', 'max_queued_jobs_per_instance'],
            32,
          ),
          manualMaxActiveJobs: numberValue(
            configuration,
            ['artifacts', 'import_export_scheduler', 'manual_max_active_jobs'],
            16,
          ),
          dynamicMaxActiveJobs: numberValue(
            configuration,
            ['artifacts', 'import_export_scheduler', 'dynamic_max_active_jobs'],
            256,
          ),
          dynamicMemoryBudgetMib: numberValue(
            configuration,
            ['artifacts', 'import_export_scheduler', 'dynamic_memory_budget_mib'],
            0,
          ),
          dynamicIoBudgetMib: numberValue(
            configuration,
            ['artifacts', 'import_export_scheduler', 'dynamic_io_budget_mib'],
            0,
          ),
          dynamicCpuUnits: numberValue(configuration, ['artifacts', 'import_export_scheduler', 'dynamic_cpu_units'], 0),
          starvationTimeoutSeconds: numberValue(
            configuration,
            ['artifacts', 'import_export_scheduler', 'starvation_timeout_seconds'],
            30,
          ),
          maxBypass: numberValue(configuration, ['artifacts', 'import_export_scheduler', 'max_bypass'], 8),
        },
      },
      daemon: {
        engine: stringValue(configuration, ['daemon', 'engine'], 'docker') as 'docker' | 'podman',
        socketPath: stringValue(configuration, ['daemon', 'socket_path']),
        containerReadOnlyRootfs: booleanValue(configuration, ['daemon', 'container_read_only_rootfs'], false),
        containerUsernsMode: stringValue(configuration, ['daemon', 'container_userns_mode']),
        containerSeccompProfile: stringValue(configuration, ['daemon', 'container_seccomp_profile']),
        containerApparmorProfile: stringValue(configuration, ['daemon', 'container_apparmor_profile']),
        containerSecurityOpts: stringsValue(configuration, ['daemon', 'container_security_opts'], []),
      },
      security: {
        apiBodyLimitBytes: numberValue(configuration, ['security', 'api_body_limit_bytes'], 1_048_576),
        apiRateLimitPerMinute: numberValue(configuration, ['security', 'api_rate_limit_per_minute'], 600),
        dbConnectionLimitPerMinute: numberValue(configuration, ['security', 'db_connection_limit_per_minute'], 240),
        pidsLimit: numberValue(configuration, ['security', 'pids_limit'], 512),
        pidsLimits: {
          postgres: nullableOverrideValue(configuration, ['security', 'pids_limits', 'postgres'], 0),
          mysql: nullableOverrideValue(configuration, ['security', 'pids_limits', 'mysql'], 0),
          mariadb: nullableOverrideValue(configuration, ['security', 'pids_limits', 'mariadb'], 0),
          redis: nullableOverrideValue(configuration, ['security', 'pids_limits', 'redis'], 0),
          valkey: nullableOverrideValue(configuration, ['security', 'pids_limits', 'valkey'], 0),
          mongodb: nullableOverrideValue(configuration, ['security', 'pids_limits', 'mongodb'], 0),
          clickhouse: nullableOverrideValue(configuration, ['security', 'pids_limits', 'clickhouse'], 4_096),
          qdrant: nullableOverrideValue(configuration, ['security', 'pids_limits', 'qdrant'], 0),
        },
        remoteImport: {
          enabled: booleanValue(configuration, ['security', 'remote_import', 'enabled'], true),
          allowPlaintext: booleanValue(configuration, ['security', 'remote_import', 'allow_plaintext'], false),
          allowedPrivateHosts: stringsValue(configuration, ['security', 'remote_import', 'allowed_private_hosts'], []),
          maxConcurrentJobs: numberValue(configuration, ['security', 'remote_import', 'max_concurrent_jobs'], 4),
          connectTimeoutSeconds: numberValue(
            configuration,
            ['security', 'remote_import', 'connect_timeout_seconds'],
            15,
          ),
          operationTimeoutSeconds: numberValue(
            configuration,
            ['security', 'remote_import', 'operation_timeout_seconds'],
            900,
          ),
          maxStagedBytes: numberValue(configuration, ['security', 'remote_import', 'max_staged_bytes'], 8_589_934_592),
        },
      },
      disk: {
        mode: (() => {
          const mode = stringValue(configuration, ['disk', 'mode'], 'auto');
          return (mode === 'none' ? 'soft_scanner' : mode) as NodeFormValues['config']['disk']['mode'];
        })(),
        fuseQuotaBinary: stringValue(configuration, ['disk', 'fuse_quota_binary'], 'embedded'),
        fuseQuotaBinarySha256: stringValue(configuration, ['disk', 'fuse_quota_binary_sha256']),
        fuseQuotaRescanIntervalSeconds: numberValue(configuration, ['disk', 'fuse_quota_rescan_interval_seconds'], 150),
        projectIdBase: numberValue(configuration, ['disk', 'project_id_base'], 200_000),
        softScanner: {
          scanIntervalSeconds: numberValue(configuration, ['disk', 'soft_scanner', 'scan_interval_seconds'], 15),
          useInotify: booleanValue(configuration, ['disk', 'soft_scanner', 'use_inotify'], true),
          fullScanIntervalSeconds: numberValue(
            configuration,
            ['disk', 'soft_scanner', 'full_scan_interval_seconds'],
            90,
          ),
          inotifyDebounceMilliseconds: numberValue(
            configuration,
            ['disk', 'soft_scanner', 'inotify_debounce_milliseconds'],
            500,
          ),
          maxDirtyPathsPerInstance: numberValue(
            configuration,
            ['disk', 'soft_scanner', 'max_dirty_paths_per_instance'],
            512,
          ),
          maxConcurrentScans: numberValue(configuration, ['disk', 'soft_scanner', 'max_concurrent_scans'], 2),
          maxEntriesPerScan: numberValue(configuration, ['disk', 'soft_scanner', 'max_entries_per_scan'], 1_000_000),
          scanTimeoutSeconds: numberValue(configuration, ['disk', 'soft_scanner', 'scan_timeout_seconds'], 30),
          maxConsecutiveScanFailures: numberValue(
            configuration,
            ['disk', 'soft_scanner', 'max_consecutive_scan_failures'],
            3,
          ),
          safetyReserveMib: numberValue(configuration, ['disk', 'soft_scanner', 'safety_reserve_mib'], 64),
          recoveryPercent: numberValue(configuration, ['disk', 'soft_scanner', 'recovery_percent'], 85),
          shutdownGraceSeconds: numberValue(configuration, ['disk', 'soft_scanner', 'shutdown_grace_seconds'], 30),
        },
      },
      paths: {
        data: stringValue(configuration, ['paths', 'data'], '/var/lib/dbev'),
        metadata: stringValue(configuration, ['paths', 'metadata'], '/var/lib/dbev/metadata'),
        volumes: stringValue(configuration, ['paths', 'volumes'], '/var/lib/dbev/volumes'),
        backups: stringValue(configuration, ['paths', 'backups'], '/var/lib/dbev/backups'),
        sockets: stringValue(configuration, ['paths', 'sockets'], '/run/dbev/sockets'),
        locks: stringValue(configuration, ['paths', 'locks'], '/run/dbev/locks'),
        logs: configuredLogsPath === '/var/log/dbev' ? '/var/lib/dbev/logs' : configuredLogsPath,
        artifacts: stringValue(configuration, ['paths', 'artifacts'], '/var/lib/dbev/artifacts'),
        exports: stringValue(configuration, ['paths', 'exports'], '/var/lib/dbev/artifacts/exports'),
        imports: stringValue(configuration, ['paths', 'imports'], '/var/lib/dbev/artifacts/imports'),
        fuse: stringValue(configuration, ['paths', 'fuse'], '/var/lib/dbev/fuse'),
        tmp: stringValue(configuration, ['paths', 'tmp'], '/var/lib/dbev/tmp'),
      },
    },
    secrets: {
      s3AccessKeyId: '',
      s3SecretAccessKey: '',
      s3SessionToken: '',
      kopiaRepositoryPassword: '',
      clearS3Credentials: false,
      clearKopiaRepositoryPassword: false,
    },
  };
}

function mergeConfiguration(
  base: Record<string, unknown>,
  replacement: Record<string, unknown>,
): Record<string, unknown> {
  const merged: Record<string, unknown> = { ...base };
  for (const [key, value] of Object.entries(replacement)) {
    const current = merged[key];
    if (
      current &&
      value &&
      typeof current === 'object' &&
      typeof value === 'object' &&
      !Array.isArray(current) &&
      !Array.isArray(value)
    ) {
      merged[key] = mergeConfiguration(current as Record<string, unknown>, value as Record<string, unknown>);
    } else {
      merged[key] = value;
    }
  }
  return merged;
}

export function toNodeInput(
  values: NodeFormValues,
  existingConfiguration: Record<string, unknown> = {},
  options: { includeArtifactPolicy?: boolean } = {},
): NodeInput {
  const config = values.config;
  const apiEndpoint = parseDaemonApiUrl(values.apiUrl);
  if (!apiEndpoint) throw new Error('invalid Daemon API URL');
  const apiTlsEnabled = apiEndpoint.scheme === 'https';
  const apiBindPort = config.api.bindPortOverride || apiEndpoint.port;
  const includeArtifactPolicy = options.includeArtifactPolicy !== false;
  const configurationBase = includeArtifactPolicy
    ? existingConfiguration
    : withoutArtifactPolicy(existingConfiguration);
  const protocolConfiguration = Object.fromEntries(
    protocols.map(([protocol]) => {
      const value = config.protocols[protocol];
      return [
        protocol,
        {
          enabled: value.enabled,
          bind: `${value.bindHost}:${value.port}`,
          ...(protocol === 'clickhouse'
            ? {
                http_bind: `${config.protocols.clickhouse.httpBindHost}:${config.protocols.clickhouse.httpPort}`,
              }
            : {}),
          tls: value.tls,
        },
      ];
    }),
  );
  const images = Object.fromEntries(protocols.map(([protocol]) => [protocol, config.protocols[protocol].image]));
  const allowed = Object.fromEntries(
    protocols.map(([protocol]) => [
      protocol,
      Array.from(new Set([config.protocols[protocol].image, ...config.protocols[protocol].allowedImages])),
    ]),
  );

  const configuration = mergeConfiguration(configurationBase, {
    debug: config.debug,
    tls: { cert: config.databaseTls.cert, key: config.databaseTls.key },
    ...protocolConfiguration,
    api: {
      host: '0.0.0.0',
      port: apiBindPort,
      trusted_origins: config.api.trustedOrigins,
      ssl: {
        enabled: apiTlsEnabled,
        cert: config.api.sslCert,
        key: config.api.sslKey,
        require_client_cert: apiTlsEnabled && config.api.requireClientCert,
        client_ca: config.api.clientCa,
      },
    },
    security: {
      api_body_limit_bytes: config.security.apiBodyLimitBytes,
      api_rate_limit_per_minute: config.security.apiRateLimitPerMinute,
      db_connection_limit_per_minute: config.security.dbConnectionLimitPerMinute,
      self_upgrade_enabled: false,
      pids_limit: config.security.pidsLimit,
      pids_limits: Object.fromEntries(
        protocols.map(([protocol]) => [protocol, config.security.pidsLimits[protocol] || null]),
      ),
      remote_import: {
        enabled: config.security.remoteImport.enabled,
        allow_plaintext: config.security.remoteImport.allowPlaintext,
        allowed_private_hosts: config.security.remoteImport.allowedPrivateHosts,
        max_concurrent_jobs: config.security.remoteImport.maxConcurrentJobs,
        connect_timeout_seconds: config.security.remoteImport.connectTimeoutSeconds,
        operation_timeout_seconds: config.security.remoteImport.operationTimeoutSeconds,
        max_staged_bytes: config.security.remoteImport.maxStagedBytes,
      },
    },
    artifacts: {
      ...(includeArtifactPolicy
        ? {
            stream_exports_only: config.artifacts.streamExportsOnly,
            max_artifacts_per_instance: config.artifacts.maxArtifactsPerInstance,
          }
        : {}),
      retention_keep_latest: config.artifacts.retentionKeepLatest,
      retention_max_age_days: config.artifacts.retentionMaxAgeDays,
      import_upload_max_bytes: config.artifacts.importUploadMaxBytes,
      import_upload_max_total_bytes: config.artifacts.importUploadMaxTotalBytes,
      import_upload_max_per_instance: config.artifacts.importUploadMaxPerInstance,
      import_upload_max_concurrent: config.artifacts.importUploadMaxConcurrent,
      import_upload_ttl_hours: config.artifacts.importUploadTtlHours,
      import_upload_timeout_seconds: config.artifacts.importUploadTimeoutSeconds,
      import_upload_idle_timeout_seconds: config.artifacts.importUploadIdleTimeoutSeconds,
      import_export_scheduler: {
        dynamic_limiter_enabled: config.artifacts.scheduler.dynamicLimiterEnabled,
        max_queued_jobs: config.artifacts.scheduler.maxQueuedJobs,
        max_queued_jobs_per_instance: config.artifacts.scheduler.maxQueuedJobsPerInstance,
        manual_max_active_jobs: config.artifacts.scheduler.manualMaxActiveJobs,
        dynamic_max_active_jobs: config.artifacts.scheduler.dynamicMaxActiveJobs,
        dynamic_memory_budget_mib: config.artifacts.scheduler.dynamicMemoryBudgetMib,
        dynamic_io_budget_mib: config.artifacts.scheduler.dynamicIoBudgetMib,
        dynamic_cpu_units: config.artifacts.scheduler.dynamicCpuUnits,
        starvation_timeout_seconds: config.artifacts.scheduler.starvationTimeoutSeconds,
        max_bypass: config.artifacts.scheduler.maxBypass,
      },
    },
    backups: {
      enabled: config.backups.enabled,
      interval_minutes: config.backups.intervalMinutes,
      run_on_startup: config.backups.runOnStartup,
      retention_keep_latest_per_instance: config.backups.retentionKeepLatestPerInstance,
      retention_max_age_days: config.backups.retentionMaxAgeDays,
      storage: {
        driver: config.backups.storageDriver,
        s3: {
          bucket: config.backups.s3.bucket,
          region: config.backups.s3.region,
          endpoint: config.backups.s3.endpoint,
          prefix: config.backups.s3.prefix,
          access_key_id: '',
          secret_access_key: '',
          session_token: '',
          path_style: config.backups.s3.pathStyle,
          allow_http: config.backups.s3.allowHttp,
          request_timeout_seconds: config.backups.s3.requestTimeoutSeconds,
          max_retries: config.backups.s3.maxRetries,
        },
        kopia: {
          executable: config.backups.kopia.executable,
          config_file: config.backups.kopia.configFile,
          repository_password: '',
          operation_timeout_seconds: config.backups.kopia.operationTimeoutSeconds,
        },
      },
      browsing: {
        enabled: config.backups.browsing.enabled,
        max_objects: config.backups.browsing.maxObjects,
        max_preview_objects: config.backups.browsing.maxPreviewObjects,
        preview_rows_per_object: config.backups.browsing.previewRowsPerObject,
        max_row_bytes: config.backups.browsing.maxRowBytes,
        max_catalog_bytes: config.backups.browsing.maxCatalogBytes,
      },
    },
    allocation: {
      prevent_cpu_overallocation: config.allocation.preventCpuOverallocation,
      prevent_memory_overallocation: config.allocation.preventMemoryOverallocation,
      prevent_disk_overallocation: config.allocation.preventDiskOverallocation,
      max_memory_mib: config.allocation.maxMemoryMib || null,
      max_disk_mib: config.allocation.maxDiskMib || null,
      reserved_memory_mib: config.allocation.reservedMemoryMib,
      reserved_disk_mib: config.allocation.reservedDiskMib,
    },
    disk: {
      mode: config.disk.mode,
      fuse_quota_binary: config.disk.fuseQuotaBinary,
      fuse_quota_binary_sha256: config.disk.fuseQuotaBinarySha256,
      fuse_quota_rescan_interval_seconds: config.disk.fuseQuotaRescanIntervalSeconds,
      project_id_base: config.disk.projectIdBase,
      soft_scanner: {
        scan_interval_seconds: config.disk.softScanner.scanIntervalSeconds,
        use_inotify: config.disk.softScanner.useInotify,
        full_scan_interval_seconds: config.disk.softScanner.fullScanIntervalSeconds,
        inotify_debounce_milliseconds: config.disk.softScanner.inotifyDebounceMilliseconds,
        max_dirty_paths_per_instance: config.disk.softScanner.maxDirtyPathsPerInstance,
        max_concurrent_scans: config.disk.softScanner.maxConcurrentScans,
        max_entries_per_scan: config.disk.softScanner.maxEntriesPerScan,
        scan_timeout_seconds: config.disk.softScanner.scanTimeoutSeconds,
        max_consecutive_scan_failures: config.disk.softScanner.maxConsecutiveScanFailures,
        safety_reserve_mib: config.disk.softScanner.safetyReserveMib,
        recovery_percent: config.disk.softScanner.recoveryPercent,
        shutdown_grace_seconds: config.disk.softScanner.shutdownGraceSeconds,
      },
    },
    daemon: {
      engine: config.daemon.engine,
      socket_path: config.daemon.socketPath,
      container_read_only_rootfs: config.daemon.containerReadOnlyRootfs,
      container_userns_mode: config.daemon.containerUsernsMode,
      container_seccomp_profile: config.daemon.containerSeccompProfile,
      container_apparmor_profile: config.daemon.containerApparmorProfile,
      container_security_opts: config.daemon.containerSecurityOpts,
    },
    images: { ...images, allowed },
    paths: config.paths,
  });
  const apiConfiguration = configuration.api;
  if (apiConfiguration && typeof apiConfiguration === 'object' && !Array.isArray(apiConfiguration)) {
    for (const obsolete of ['fqdn', 'trusted_hosts', 'allowed_hosts', 'url']) {
      delete (apiConfiguration as Record<string, unknown>)[obsolete];
    }
  }
  const secrets = values.secrets;
  const hasSecretPatch =
    secrets.s3AccessKeyId ||
    secrets.s3SecretAccessKey ||
    secrets.s3SessionToken ||
    secrets.kopiaRepositoryPassword ||
    secrets.clearS3Credentials ||
    secrets.clearKopiaRepositoryPassword;

  return {
    name: values.name,
    enabled: values.enabled,
    deployment_policy: values.deploymentPolicy,
    api_url: apiEndpoint.normalizedUrl,
    public_host: normalizePublicDatabaseHost(values.publicHost),
    default_cpu_cores: values.defaultCpuCores,
    default_memory_mib: values.defaultMemoryMib,
    default_disk_mib: values.defaultDiskMib,
    default_pool_limits: {
      cpu_cores: values.defaultPoolCpuCores,
      memory_mib: values.defaultPoolMemoryMib,
      disk_mib: values.defaultPoolDiskMib,
      max_tenants: values.defaultPoolMaxDatabases,
    },
    configuration,
    ...(hasSecretPatch
      ? {
          configuration_secrets: {
            s3_access_key_id: secrets.s3AccessKeyId || undefined,
            s3_secret_access_key: secrets.s3SecretAccessKey || undefined,
            s3_session_token: secrets.s3SessionToken || undefined,
            kopia_repository_password: secrets.kopiaRepositoryPassword || undefined,
            clear_s3_credentials: secrets.clearS3Credentials,
            clear_kopia_repository_password: secrets.clearKopiaRepositoryPassword,
          },
        }
      : {}),
  };
}

function withoutArtifactPolicy(configuration: Record<string, unknown>): Record<string, unknown> {
  const artifacts = configuration.artifacts;
  if (!artifacts || typeof artifacts !== 'object' || Array.isArray(artifacts)) return configuration;
  const {
    stream_exports_only: _streamExportsOnly,
    max_artifacts_per_instance: _maxArtifactsPerInstance,
    ...compatibleArtifacts
  } = artifacts as Record<string, unknown>;
  return { ...configuration, artifacts: compatibleArtifacts };
}
