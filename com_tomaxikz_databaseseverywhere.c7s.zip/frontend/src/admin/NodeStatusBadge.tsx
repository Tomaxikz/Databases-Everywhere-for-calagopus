import Badge from '@/elements/data-display/Badge.tsx';
import type { NodeRecord } from '../api/types.ts';
import translations from '../translations.ts';
import { type NodeStatus, nodeStatus } from './nodeRuntimeState.ts';

const COLORS: Record<NodeStatus, string> = {
  disabled: 'gray',
  failed: 'red',
  unchecked: 'gray',
  readOnly: 'yellow',
  healthy: 'green',
};

export default function NodeStatusBadge({ node }: { node: NodeRecord }) {
  const { t } = translations.useTranslations();
  const status = nodeStatus(node);
  return <Badge color={COLORS[status]}>{t(`manage.status.${status}`, {})}</Badge>;
}
