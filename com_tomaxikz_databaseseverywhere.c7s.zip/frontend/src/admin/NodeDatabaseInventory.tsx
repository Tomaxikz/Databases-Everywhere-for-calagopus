import { faChevronDown, faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Group, Stack, Text } from '@mantine/core';
import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import Badge from '@/elements/data-display/Badge.tsx';
import Table, { TableData, TableRow } from '@/elements/data-display/Table.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import { bytesToString } from '@/lib/format/size.ts';
import {
  getNodeSharedPool,
  listNodeInstances,
  listNodeSharedPoolInstances,
  listNodeSharedPools,
  mintNodeMonitoringWebSocketToken,
} from '../api/client.ts';
import { normalizeDatabaseMonitoringInstances } from '../api/normalizers.ts';
import { dbevQueryKeys } from '../api/queryKeys.ts';
import type {
  DatabaseMonitoringInstance,
  DatabaseProtocol,
  DbevAdminInstance,
  DbevSharedPool,
  NodeRecord,
} from '../api/types.ts';
import { StatusBadge } from '../components/common.tsx';
import PoolSummary from '../components/PoolSummary.tsx';
import ProtocolIcon from '../components/ProtocolIcon.tsx';
import { MonitoringSnapshotAssembler } from '../server/monitoringSnapshotAssembler.ts';
import { ReconnectController } from '../server/websocketReconnect.ts';
import translations from '../translations.ts';
import PoolResizeControl from './PoolResizeControl.tsx';

type UnknownRecord = Record<string, unknown>;

function record(value: unknown): UnknownRecord | null {
  return value !== null && typeof value === 'object' && !Array.isArray(value) ? (value as UnknownRecord) : null;
}

function at(value: unknown, ...paths: string[]): unknown {
  for (const path of paths) {
    let current: unknown = value;
    let found = true;
    for (const part of path.split('.')) {
      const currentRecord = record(current);
      if (!currentRecord || !Object.hasOwn(currentRecord, part)) {
        found = false;
        break;
      }
      current = currentRecord[part];
    }
    if (found) return current;
  }
  return undefined;
}

function textValue(value: unknown, ...paths: string[]): string | null {
  const candidate = at(value, ...paths);
  return typeof candidate === 'string' && candidate.trim() ? candidate : null;
}

function numberValue(value: unknown, ...paths: string[]): number | null {
  const candidate = at(value, ...paths);
  return typeof candidate === 'number' && Number.isFinite(candidate) ? candidate : null;
}

function byteValue(value: unknown, ...paths: string[]): string {
  const candidate = numberValue(value, ...paths);
  return candidate === null ? 'Unavailable' : bytesToString(candidate);
}

function percent(value: unknown, ...paths: string[]): string {
  const candidate = numberValue(value, ...paths);
  return candidate === null ? 'Unavailable' : `${Number(candidate.toFixed(2))}%`;
}

function count(value: unknown, ...paths: string[]): string {
  const candidate = numberValue(value, ...paths);
  return candidate === null ? '—' : String(candidate);
}

function databaseIdentity(instance: DbevAdminInstance): string {
  return (
    textValue(instance, 'database.name', 'database_name', 'name') ??
    textValue(instance, 'instance_id') ??
    'Unknown database'
  );
}

function instanceName(instance: DbevAdminInstance): string | null {
  return textValue(instance, 'display_name', 'name', 'label');
}

function operationText(instance: DbevAdminInstance): string {
  const action = textValue(
    instance,
    'operation.action',
    'operation.stage',
    'operation.status',
    'current_operation',
    'current_action',
  );
  return action ?? '—';
}

function migrationText(instance: DbevAdminInstance): string {
  const status = textValue(instance, 'deployment_migration.status', 'migration.status');
  const stage = textValue(instance, 'deployment_migration.stage', 'migration.stage');
  if (status && stage && status !== stage) return `${status} · ${stage}`;
  return status ?? stage ?? '—';
}

function InstanceIdentity({ instance }: { instance: DbevAdminInstance }) {
  const name = instanceName(instance);
  return (
    <Stack gap={0}>
      {name && <Text size='sm'>{name}</Text>}
      <Text size={name ? 'xs' : 'sm'} c={name ? 'dimmed' : undefined} ff='monospace'>
        {instance.instance_id}
      </Text>
    </Stack>
  );
}

function useNodeMonitoring(node: string, instanceIds: string[]) {
  const [instances, setInstances] = useState<Map<string, DatabaseMonitoringInstance>>(new Map());
  const [stale, setStale] = useState(true);
  const selectionKey = [...new Set(instanceIds)].sort().join(',');
  const selection = useMemo(() => (selectionKey ? selectionKey.split(',') : []), [selectionKey]);

  useEffect(() => {
    setInstances(new Map());
    setStale(true);
  }, [node]);

  useEffect(() => {
    setStale(true);
    if (!node || selection.length === 0) return;

    let disposed = false;
    let socket: WebSocket | null = null;
    const controller = new ReconnectController(
      (run, delay) => window.setTimeout(run, delay),
      (timer) => window.clearTimeout(timer),
    );
    let watchdog: number | undefined;
    const armWatchdog = () => {
      window.clearTimeout(watchdog);
      watchdog = window.setTimeout(() => socket?.close(), 60_000);
    };
    let attempts = 0;
    const assembler = new MonitoringSnapshotAssembler();

    const connect = async () => {
      if (disposed) return;
      try {
        const token = await mintNodeMonitoringWebSocketToken(node, selection);
        if (disposed) return;
        assembler.reset();
        socket = new WebSocket(token.url, ['dbe.jwt', token.token]);
        socket.onopen = armWatchdog;
        socket.onmessage = (event) => {
          if (disposed || typeof event.data !== 'string') return;
          try {
            const raw = record(JSON.parse(event.data));
            if (!raw || raw.type !== 'stats') return;
            if (!Array.isArray(raw.instances)) {
              socket?.close();
              return;
            }
            const result = assembler.push({
              ...raw,
              ...(Object.hasOwn(raw, 'instances')
                ? { instances: normalizeDatabaseMonitoringInstances(raw.instances) }
                : {}),
            });
            if (result.kind === 'reconnect') {
              socket?.close(4000, 'monitoring sequence gap');
              return;
            }
            if (result.kind !== 'complete') return;
            setInstances(new Map(result.snapshot.instances.map((instance) => [instance.instance_id, instance])));
            armWatchdog();
            setStale(false);
            attempts = 0;
          } catch {
            // A malformed or incomplete message never replaces the last good snapshot.
          }
        };
        socket.onclose = () => {
          if (disposed) return;
          window.clearTimeout(watchdog);
          assembler.reset();
          setStale(true);
          attempts += 1;
          controller.schedule(attempts, () => void connect());
        };
        socket.onerror = () => setStale(true);
      } catch {
        if (disposed) return;
        setStale(true);
        attempts += 1;
        controller.schedule(attempts, () => void connect());
      }
    };

    void connect();
    return () => {
      disposed = true;
      controller.cancel();
      window.clearTimeout(watchdog);
      socket?.close();
    };
  }, [node, selectionKey]);

  return { instances, stale };
}

function pagination<T>(items: T[]) {
  return { total: items.length, perPage: Math.max(items.length, 1), page: 1, data: items };
}

type NodeMonitoringState = ReturnType<typeof useNodeMonitoring>;

function DedicatedInventory({ instances, live }: { instances: DbevAdminInstance[]; live: NodeMonitoringState }) {
  const { t } = translations.useTranslations();
  const dedicated = instances.filter((instance) => (instance.deployment_mode ?? 'dedicated') === 'dedicated');

  return (
    <TitleCard
      title={t('admin.inventory.dedicatedTitle', {})}
      rightSection={
        <Badge className='ml-auto' color={live.stale ? 'yellow' : 'green'}>
          {live.stale ? t('admin.inventory.stale', {}) : t('admin.inventory.live', {})}
        </Badge>
      }
    >
      <Text size='xs' c='dimmed' mb='md'>
        {t('admin.inventory.dedicatedDescription', {})}
      </Text>
      <Table
        columns={[
          'Instance',
          'Protocol',
          'Status',
          'Database / user',
          'Image / version',
          'CPU',
          'Memory',
          'Disk',
          'Network',
          'Operation',
        ]}
        pagination={pagination(dedicated)}
        allowSelect={false}
      >
        {dedicated.map((instance) => {
          const snapshot = live.instances.get(instance.instance_id);
          const resources = record(snapshot ? snapshot.resources : instance.resources);
          const activity = snapshot?.activity ?? instance.activity;
          const database = databaseIdentity(instance);
          const username = textValue(instance, 'database.username', 'username');
          const image = textValue(instance, 'image.current', 'image.configured', 'image') ?? '—';
          const version = textValue(instance, 'database_version.current', 'version');
          const operation = operationText(instance);
          return (
            <TableRow key={instance.instance_id}>
              <TableData>
                <InstanceIdentity instance={instance} />
              </TableData>
              <TableData>
                <Group gap='xs' wrap='nowrap'>
                  <ProtocolIcon protocol={String(instance.protocol ?? 'postgres') as DatabaseProtocol} size={20} />
                  <Text>{String(instance.protocol ?? 'unknown')}</Text>
                </Group>
              </TableData>
              <TableData>
                <StatusBadge status={snapshot?.status ?? instance.status ?? 'unknown'} />
              </TableData>
              <TableData>{username ? `${database} / ${username}` : database}</TableData>
              <TableData>{version ? `${image} / ${version}` : image}</TableData>
              <TableData>
                {resources
                  ? `${percent(resources, 'cpu.usage_percent')} / ${count(resources, 'cpu.configured_cores')} cores`
                  : 'Unavailable'}
              </TableData>
              <TableData>
                {resources
                  ? `${byteValue(resources, 'memory.usage_bytes')} / ${byteValue(resources, 'memory.limit_bytes')}`
                  : 'Unavailable'}
              </TableData>
              <TableData>
                {resources
                  ? `${byteValue(resources, 'disk.used_bytes')} / ${byteValue(resources, 'disk.limit_bytes')}`
                  : 'Unavailable'}
              </TableData>
              <TableData>
                {activity
                  ? `RX ${byteValue(activity, 'rx_bytes')} · TX ${byteValue(activity, 'tx_bytes')}`
                  : 'Unavailable'}
              </TableData>
              <TableData>{operation}</TableData>
            </TableRow>
          );
        })}
      </Table>
    </TitleCard>
  );
}

function SharedPoolTenants({ node, runtimeId, live }: { node: string; runtimeId: string; live: NodeMonitoringState }) {
  const { t } = translations.useTranslations();
  const query = useQuery({
    queryKey: dbevQueryKeys.adminNodeSharedPoolInstances(node, runtimeId),
    queryFn: () => listNodeSharedPoolInstances(node, runtimeId),
    refetchInterval: 30_000,
  });
  if (query.error) return <Alert color='red'>{httpErrorToHuman(query.error)}</Alert>;
  const tenants = query.data ?? [];
  return (
    <Table
      columns={[
        'Instance',
        'Database / user',
        'Status',
        'Tenant disk',
        'Enforcement',
        'Network',
        'Connections',
        'Operations',
        'Activity telemetry',
        'Actions',
        'Migration',
      ]}
      loading={query.isPending}
      pagination={pagination(tenants)}
      allowSelect={false}
    >
      {tenants.map((tenant) => {
        const snapshot = live.instances.get(tenant.instance_id);
        const resources = record(snapshot ? snapshot.resources : tenant.resources);
        const activity = snapshot?.activity ?? tenant.activity;
        const database = databaseIdentity(tenant);
        const username = textValue(tenant, 'database.username', 'username');
        const accepted = count(activity, 'accepted', 'forwarded');
        const rejected = count(activity, 'rejected');
        const availability = textValue(activity, 'availability') ?? 'unavailable';
        const source = textValue(activity, 'source') ?? 'unavailable';
        return (
          <TableRow key={tenant.instance_id}>
            <TableData>
              <InstanceIdentity instance={tenant} />
            </TableData>
            <TableData>{username ? `${database} / ${username}` : database}</TableData>
            <TableData>
              <StatusBadge status={snapshot?.status ?? tenant.status ?? 'unknown'} />
            </TableData>
            <TableData>
              {resources
                ? `${byteValue(resources, 'disk.used_bytes')} / ${byteValue(resources, 'disk.limit_bytes')}`
                : 'Unavailable'}
            </TableData>
            <TableData>
              {textValue(resources, 'disk.enforcement_strength', 'disk.enforcement_method') ?? 'Unavailable'}
            </TableData>
            <TableData>
              {activity
                ? `RX ${byteValue(activity, 'rx_bytes')} · TX ${byteValue(activity, 'tx_bytes')}`
                : 'Unavailable'}
            </TableData>
            <TableData>{count(activity, 'connections')}</TableData>
            <TableData>{t('admin.inventory.forwardedRejected', { accepted, rejected })}</TableData>
            <TableData>{availability === source ? source : `${availability} · ${source}`}</TableData>
            <TableData>{operationText(tenant)}</TableData>
            <TableData>{migrationText(tenant)}</TableData>
          </TableRow>
        );
      })}
    </Table>
  );
}

function SharedPoolsInventory({
  node,
  pools,
  live,
}: {
  node: NodeRecord;
  pools: DbevSharedPool[];
  live: NodeMonitoringState;
}) {
  const { t } = translations.useTranslations();
  const [expanded, setExpanded] = useState<string | null>(null);
  const detail = useQuery({
    queryKey: dbevQueryKeys.adminNodeSharedPool(node.uuid, expanded ?? ''),
    queryFn: () => getNodeSharedPool(node.uuid, expanded ?? ''),
    enabled: Boolean(expanded),
    refetchInterval: 5_000,
  });
  return (
    <TitleCard
      title={t('admin.inventory.sharedTitle', {})}
      rightSection={
        <Badge className='ml-auto' color={live.stale ? 'yellow' : 'green'}>
          {live.stale ? t('admin.inventory.stale', {}) : t('admin.inventory.live', {})}
        </Badge>
      }
    >
      <Text size='xs' c='dimmed' mb='md'>
        {t('admin.inventory.sharedDescription', {})}
      </Text>
      <Stack gap='sm'>
        {pools.length === 0 && <Text c='dimmed'>{t('admin.inventory.noSharedPools', {})}</Text>}
        {pools.map((pool) => {
          const open = expanded === pool.runtime_id;
          const current = open && detail.data?.runtime_id === pool.runtime_id ? detail.data : pool;
          const image = textValue(current, 'image') ?? '—';
          const version = textValue(current, 'database_version');
          return (
            <TitleCard
              key={pool.runtime_id}
              title={pool.runtime_id}
              rightSection={
                <Group className='ml-auto'>
                  <ProtocolIcon protocol={String(pool.protocol ?? 'postgres') as DatabaseProtocol} size={20} />
                  <StatusBadge status={pool.status ?? 'unknown'} />
                  <Button
                    size='compact-xs'
                    variant='default'
                    onClick={() => setExpanded(open ? null : pool.runtime_id)}
                    leftSection={<FontAwesomeIcon icon={open ? faChevronDown : faChevronRight} />}
                  >
                    {open ? t('admin.inventory.collapse', {}) : t('admin.inventory.expand', {})}
                  </Button>
                </Group>
              }
            >
              <Text size='xs' c='dimmed' mb='sm'>
                {version ? `${image} · ${version}` : image}
              </Text>
              <PoolSummary pool={current} />
              <Text size='xs' c='dimmed' mt='sm'>
                {textValue(current, 'owner.server_id') ?? t('common.unavailable', {})}
              </Text>
              {open && (
                <Stack mt='md'>
                  {detail.error && <Alert color='red'>{httpErrorToHuman(detail.error)}</Alert>}
                  <PoolResizeControl
                    node={node.uuid}
                    pool={current}
                    onSaved={() => {
                      void detail.refetch();
                    }}
                  />
                  <SharedPoolTenants node={node.uuid} runtimeId={pool.runtime_id} live={live} />
                </Stack>
              )}
            </TitleCard>
          );
        })}
      </Stack>
    </TitleCard>
  );
}

export default function NodeDatabaseInventory({ node }: { node: NodeRecord }) {
  const instances = useQuery({
    queryKey: dbevQueryKeys.adminNodeInstances(node.uuid),
    queryFn: () => listNodeInstances(node.uuid),
    refetchInterval: 15_000,
  });
  const pools = useQuery({
    queryKey: dbevQueryKeys.adminNodeSharedPools(node.uuid),
    queryFn: () => listNodeSharedPools(node.uuid),
    refetchInterval: 5_000,
  });
  const inventory = instances.data ?? [];
  const live = useNodeMonitoring(
    node.uuid,
    inventory.map((instance) => instance.instance_id),
  );
  return (
    <Stack>
      {(instances.error || pools.error) && (
        <Alert color='red'>{httpErrorToHuman(instances.error ?? pools.error)}</Alert>
      )}
      <DedicatedInventory instances={inventory} live={live} />
      <SharedPoolsInventory node={node} pools={pools.data ?? []} live={live} />
    </Stack>
  );
}
