import {
  faCircleCheck,
  faCircleMinus,
  faCircleXmark,
  faPlug,
  faTriangleExclamation,
  faXmark,
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useQueryClient } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import ActionIcon from '@/elements/buttons/ActionIcon.tsx';
import Button from '@/elements/buttons/Button.tsx';
import Card from '@/elements/data-display/Card.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Group from '@/elements/layout/Group.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import Text from '@/elements/typography/Text.tsx';
import { checkNodeConnection } from '../api/client.ts';
import { dbevQueryKeys } from '../api/queryKeys.ts';
import type { NodeRecord } from '../api/types.ts';
import translations from '../translations.ts';
import type { CheckStep, CheckStepStatus, ConnectionCheckResult } from './connectionCheck.ts';

export interface ConnectionCheckState {
  result: ConnectionCheckResult | null;
  error: string | null;
  checking: boolean;
  automatic: boolean;
  run: (automatic?: boolean) => Promise<void>;
  close: () => void;
}

export function useConnectionCheck(node: string, checkOnLoad = false): ConnectionCheckState {
  const queryClient = useQueryClient();
  const [result, setResult] = useState<ConnectionCheckResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [automatic, setAutomatic] = useState(false);

  const run = async (automatic = false) => {
    setChecking(true);
    setAutomatic(automatic);
    setError(null);
    try {
      setResult(await checkNodeConnection(node));
    } catch (cause) {
      setResult(null);
      setError(httpErrorToHuman(cause));
    } finally {
      setChecking(false);
      await queryClient.invalidateQueries({ queryKey: dbevQueryKeys.adminNodes() });
    }
  };

  const close = () => {
    setResult(null);
    setError(null);
  };

  useEffect(() => {
    setResult(null);
    setError(null);
    if (checkOnLoad && node) void run(true);
  }, [node, checkOnLoad]);

  return { result, error, checking, automatic, run, close };
}

export function useCheckNodesOnLoad(nodes: NodeRecord[] | undefined, enabled: boolean) {
  const queryClient = useQueryClient();
  const started = useRef(false);

  useEffect(() => {
    if (!enabled || !nodes || started.current) return;
    started.current = true;
    for (const node of nodes) {
      void checkNodeConnection(node.uuid)
        .catch(() => null)
        .then(() => queryClient.invalidateQueries({ queryKey: dbevQueryKeys.adminNodes() }));
    }
  }, [nodes, enabled]);
}

export function CheckConnectionButton({ check }: { check: ConnectionCheckState }) {
  const { t } = translations.useTranslations();
  return (
    <Button loading={check.checking} leftSection={<FontAwesomeIcon icon={faPlug} />} onClick={() => void check.run()}>
      {t('manage.check.run', {})}
    </Button>
  );
}

const STEP_ICONS: Record<CheckStepStatus, { icon: typeof faPlug; color: string }> = {
  passed: { icon: faCircleCheck, color: 'var(--mantine-color-green-6)' },
  warning: { icon: faTriangleExclamation, color: 'var(--mantine-color-yellow-6)' },
  failed: { icon: faCircleXmark, color: 'var(--mantine-color-red-6)' },
  skipped: { icon: faCircleMinus, color: 'var(--mantine-color-dimmed)' },
};

function StepRow({ step }: { step: CheckStep }) {
  const { t } = translations.useTranslations();
  const { icon, color } = STEP_ICONS[step.status];
  return (
    <Group
      gap='sm'
      wrap='nowrap'
      align='flex-start'
      py='xs'
      className='border-t border-(--mantine-color-default-border) first:border-t-0'
    >
      <FontAwesomeIcon icon={icon} color={color} fixedWidth className='mt-1' />
      <Stack gap={2} className='min-w-0'>
        <Text size='sm' fw={600} c={step.status === 'skipped' ? 'dimmed' : undefined}>
          {t(`manage.check.steps.${step.id}`, {})}
        </Text>
        {step.message && (
          <Text size='sm' c={step.status === 'failed' ? 'red' : undefined} className='break-words'>
            {step.message}
          </Text>
        )}
        {step.hint && (
          <Text size='xs' c='dimmed'>
            {step.hint}
          </Text>
        )}
      </Stack>
    </Group>
  );
}

export function ConnectionCheckReport({ check }: { check: ConnectionCheckState }) {
  const { t } = translations.useTranslations();
  const { result, error } = check;
  if (!result && !error) return null;

  const closeButton = (
    <ActionIcon variant='subtle' color='gray' onClick={check.close} aria-label={t('common.close', {})}>
      <FontAwesomeIcon icon={faXmark} />
    </ActionIcon>
  );

  if (!result) {
    return (
      <Alert color='red' title={t('manage.check.couldNotRun', {})} withCloseButton onClose={check.close}>
        {error}
      </Alert>
    );
  }

  const versions = [
    result.version ? `DBEV ${result.version}` : null,
    result.apiVersion ? `API ${result.apiVersion}` : null,
  ].filter(Boolean);
  const problems = result.steps.filter((step) => step.status === 'failed' || step.status === 'warning');

  if (!problems.length) {
    if (check.automatic) return null;
    return (
      <Card px='lg' py='sm'>
        <Group gap='sm' wrap='nowrap'>
          <FontAwesomeIcon icon={faCircleCheck} color={STEP_ICONS.passed.color} fixedWidth />
          <Text size='sm'>{[t('manage.check.passed', {}), ...versions].join(' · ')}</Text>
          <Group ml='auto'>{closeButton}</Group>
        </Group>
      </Card>
    );
  }

  return (
    <TitleCard title={t('manage.check.title', {})} rightSection={<Group ml='auto'>{closeButton}</Group>}>
      <Stack gap={0}>
        {problems.map((step) => (
          <StepRow key={step.id} step={step} />
        ))}
      </Stack>
    </TitleCard>
  );
}

export function NeverCheckedNotice({ node, check }: { node: NodeRecord; check: ConnectionCheckState }) {
  const { t } = translations.useTranslations();
  if (node.last_seen || node.cached_system || check.result || check.error || check.checking) return null;
  return (
    <Alert color='blue' title={t('manage.check.neverTitle', {})}>
      <Stack gap='xs'>
        <Text size='sm'>{t('manage.check.neverDescription', {})}</Text>
        <Group>
          <CheckConnectionButton check={check} />
        </Group>
      </Stack>
    </Alert>
  );
}
