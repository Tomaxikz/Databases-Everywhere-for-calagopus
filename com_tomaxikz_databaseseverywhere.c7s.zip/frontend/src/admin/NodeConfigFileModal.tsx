import { useQuery } from '@tanstack/react-query';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import CopyOnClick from '@/elements/CopyOnClick.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Spinner from '@/elements/feedback/Spinner.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import { Modal, ModalFooter } from '@/elements/modals/Modal.tsx';
import Code from '@/elements/typography/Code.tsx';
import Text from '@/elements/typography/Text.tsx';
import { getNodeConfiguration } from '../api/client.ts';
import { dbevQueryKeys } from '../api/queryKeys.ts';
import translations from '../translations.ts';

export default function NodeConfigFileModal({
  node,
  opened,
  onClose,
}: {
  node: string;
  opened: boolean;
  onClose: () => void;
}) {
  const { t } = translations.useTranslations();
  const configuration = useQuery({
    queryKey: dbevQueryKeys.adminNodeConfiguration(node),
    queryFn: () => getNodeConfiguration(node),
    enabled: opened,
  });

  return (
    <Modal opened={opened} onClose={onClose} title={t('manage.configFile.title', {})} size='xl'>
      <Stack>
        <Text size='sm' c='dimmed'>
          {t('manage.configFile.description', {})}
        </Text>
        {configuration.isPending ? (
          <Spinner.Centered />
        ) : configuration.error ? (
          <Alert color='red'>{httpErrorToHuman(configuration.error)}</Alert>
        ) : (
          <CopyOnClick content={configuration.data || ''} className='block w-full text-left'>
            <Code block className='whitespace-pre-wrap break-all max-h-[60vh] overflow-auto'>
              {configuration.data}
            </Code>
          </CopyOnClick>
        )}
      </Stack>
      <ModalFooter>
        <Button variant='default' onClick={onClose}>
          {t('common.close', {})}
        </Button>
      </ModalFooter>
    </Modal>
  );
}
