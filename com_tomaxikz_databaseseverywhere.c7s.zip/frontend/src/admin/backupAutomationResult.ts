export interface BackupAutomationStatus {
  enabled: boolean | null;
  intervalMinutes: number | null;
  runOnStartup: boolean | null;
  retentionKeepLatestPerInstance: number | null;
  retentionMaxAgeDays: number | null;
  redisExcluded: boolean | null;
  storageDriver: string | null;
  browsingEnabled: boolean | null;
}

export interface CompletedNodeBackup {
  id: string;
  instanceId: string;
  sizeBytes: number | null;
  modifiedAt: string | null;
  sha256: string | null;
}

export interface SkippedNodeBackup {
  instanceId: string;
  protocol: string | null;
  reasonCode: string | null;
  reasonMessage: string;
  errorId: string | null;
}

export interface BackupAutomationRun {
  backups: CompletedNodeBackup[];
  skipped: SkippedNodeBackup[];
}

export function parseBackupAutomationStatus(value: unknown): BackupAutomationStatus | null {
  if (!isRecord(value)) return null;

  const status: BackupAutomationStatus = {
    enabled: booleanOrNull(value.enabled),
    intervalMinutes: numberOrNull(value.interval_minutes),
    runOnStartup: booleanOrNull(value.run_on_startup),
    retentionKeepLatestPerInstance: numberOrNull(value.retention_keep_latest_per_instance),
    retentionMaxAgeDays: numberOrNull(value.retention_max_age_days),
    redisExcluded: booleanOrNull(value.redis_excluded),
    storageDriver: stringOrNull(value.storage_driver),
    browsingEnabled: booleanOrNull(value.browsing_enabled),
  };

  return Object.values(status).some((field) => field !== null) ? status : null;
}

export function parseBackupAutomationRun(value: unknown): BackupAutomationRun | null {
  if (!isRecord(value) || (!Array.isArray(value.backups) && !Array.isArray(value.skipped))) return null;

  return {
    backups: Array.isArray(value.backups) ? value.backups.flatMap(parseCompletedBackup) : [],
    skipped: Array.isArray(value.skipped) ? value.skipped.flatMap(parseSkippedBackup) : [],
  };
}

function parseCompletedBackup(value: unknown): CompletedNodeBackup[] {
  if (!isRecord(value)) return [];
  const id = stringOrNull(value.id);
  const instanceId = stringOrNull(value.instance_id);
  if (!id || !instanceId) return [];

  return [
    {
      id,
      instanceId,
      sizeBytes: numberOrNull(value.size_bytes),
      modifiedAt: stringOrNull(value.modified_at),
      sha256: stringOrNull(value.sha256),
    },
  ];
}

function parseSkippedBackup(value: unknown): SkippedNodeBackup[] {
  if (!isRecord(value)) return [];
  const instanceId = stringOrNull(value.instance_id);
  if (!instanceId) return [];

  const reason = value.reason;
  const diagnostic = isRecord(reason) ? reason : null;
  const reasonMessage =
    stringOrNull(diagnostic?.message) ?? stringOrNull(reason) ?? 'The daemon did not report a reason.';

  return [
    {
      instanceId,
      protocol: stringOrNull(value.protocol),
      reasonCode: stringOrNull(diagnostic?.code),
      reasonMessage,
      errorId: stringOrNull(diagnostic?.error_id),
    },
  ];
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function booleanOrNull(value: unknown): boolean | null {
  return typeof value === 'boolean' ? value : null;
}

function numberOrNull(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function stringOrNull(value: unknown): string | null {
  return typeof value === 'string' && value.trim() ? value : null;
}
