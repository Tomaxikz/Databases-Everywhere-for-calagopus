import { Stepper } from '@mantine/core';
import type { ReactNode } from 'react';
import Card from '@/elements/data-display/Card.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Text from '@/elements/typography/Text.tsx';

export interface NodeSetupStep {
  label: string;
  description: string;
}

interface Props {
  steps: NodeSetupStep[];
  active: number;
  onStepChange: (step: number) => void;
  children: ReactNode;
  footer: ReactNode;
  navigationDisabled?: boolean;
}

export default function NodeSetupWizard({
  steps,
  active,
  onStepChange,
  children,
  footer,
  navigationDisabled = false,
}: Props) {
  const current = steps[active];

  return (
    <div className='mx-auto grid w-full max-w-[100rem] grid-cols-1 gap-6 xl:grid-cols-[18rem_minmax(0,1fr)] xl:items-start'>
      <Card p='lg' className='xl:sticky xl:top-6'>
        <Stepper
          active={active}
          orientation='vertical'
          size='sm'
          onStepClick={navigationDisabled ? undefined : onStepChange}
          classNames={{
            root: 'w-full',
            step: 'w-full',
            stepBody: 'min-w-0',
            stepLabel: 'leading-tight',
            stepDescription: 'mt-1 leading-tight',
          }}
          styles={{ step: { paddingBlock: 4 } }}
        >
          {steps.map((step, index) => (
            <Stepper.Step
              key={step.label}
              label={step.label}
              description={step.description}
              style={{ cursor: navigationDisabled ? 'default' : 'pointer' }}
              aria-current={index === active ? 'step' : undefined}
            />
          ))}
        </Stepper>
      </Card>

      <TitleCard title={current?.label ?? ''} className='min-w-0' wrapperClassName='p-6!'>
        <Text size='sm' c='dimmed' mb='lg'>
          {current?.description}
        </Text>

        <div key={active}>{children}</div>

        <div className='border-t border-(--mantine-color-default-border) mt-6 pt-4'>{footer}</div>
      </TitleCard>
    </div>
  );
}
