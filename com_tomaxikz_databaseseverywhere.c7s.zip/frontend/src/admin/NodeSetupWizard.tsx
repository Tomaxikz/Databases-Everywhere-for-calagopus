import { faXmark } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Stepper } from '@mantine/core';
import type { ReactNode } from 'react';
import Card from '@/elements/data-display/Card.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import Text from '@/elements/typography/Text.tsx';
import Title from '@/elements/typography/Title.tsx';

export interface NodeSetupStep {
  label: string;
  description: string;
}

interface Props {
  steps: NodeSetupStep[];
  active: number;
  onStepChange: (step: number) => void;
  children: ReactNode;
  footer: ReactNode;
  navigationDisabled?: boolean;
  plain?: boolean;
  invalidSteps?: number[];
}

export default function NodeSetupWizard({
  steps,
  active,
  onStepChange,
  children,
  footer,
  navigationDisabled = false,
  plain = false,
  invalidSteps = [],
}: Props) {
  const current = steps[active];

  return (
    <div className='mx-auto grid w-full max-w-[100rem] grid-cols-1 gap-6 xl:grid-cols-[18rem_minmax(0,1fr)] xl:items-start'>
      <Card p='lg' className='xl:sticky xl:top-6'>
        <Stepper
          active={active}
          orientation='vertical'
          size='sm'
          onStepClick={navigationDisabled ? undefined : onStepChange}
          classNames={{
            root: 'w-full',
            step: 'w-full',
            stepBody: 'min-w-0',
            stepLabel: 'leading-tight',
            stepDescription: 'mt-1 leading-tight',
          }}
          styles={{ step: { paddingBlock: 4 } }}
        >
          {steps.map((step, index) => (
            <Stepper.Step
              key={step.label}
              label={step.label}
              description={step.description}
              color={invalidSteps.includes(index) ? 'red' : undefined}
              completedIcon={invalidSteps.includes(index) ? <FontAwesomeIcon icon={faXmark} /> : undefined}
              style={{ cursor: navigationDisabled ? 'default' : 'pointer' }}
              aria-current={index === active ? 'step' : undefined}
            />
          ))}
        </Stepper>
      </Card>

      {plain ? (
        <Stack className='min-w-0'>
          <Stack gap={4}>
            <Title order={3}>{current?.label}</Title>
            <Text size='sm' c='dimmed'>
              {current?.description}
            </Text>
          </Stack>
          {children}
          <Card px='lg' py='md'>
            {footer}
          </Card>
        </Stack>
      ) : (
        <TitleCard title={current?.label ?? ''} className='min-w-0' wrapperClassName='p-6!'>
          <Text size='sm' c='dimmed' mb='lg'>
            {current?.description}
          </Text>

          <div key={active}>{children}</div>

          <div className='border-t border-(--mantine-color-default-border) mt-6 pt-4'>{footer}</div>
        </TitleCard>
      )}
    </div>
  );
}
