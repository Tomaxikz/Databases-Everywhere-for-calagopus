type Json = Record<string, unknown>;

const FILE_ONLY_PATHS = [
  ['remote'],
  ['uuid'],
  ['token_id'],
  ['token'],
  ['jwt_signing_key'],
  ['paths'],
  ['tls', 'cert'],
  ['tls', 'key'],
  ['api', 'ssl', 'cert'],
  ['api', 'ssl', 'key'],
  ['api', 'ssl', 'client_ca'],
  ['daemon', 'socket_path'],
  ['disk', 'fuse_quota_binary'],
  ['disk', 'fuse_quota_binary_sha256'],
  ['backups', 'storage', 's3', 'access_key_id'],
  ['backups', 'storage', 's3', 'secret_access_key'],
  ['backups', 'storage', 's3', 'session_token'],
  ['backups', 'storage', 'kopia', 'executable'],
  ['backups', 'storage', 'kopia', 'config_file'],
  ['backups', 'storage', 'kopia', 'repository_password'],
];

function isObject(value: unknown): value is Json {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function same(left: unknown, right: unknown): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

export function configurationChanges(before: Json, after: Json): Json {
  const changes: Json = {};
  for (const [key, value] of Object.entries(after)) {
    const previous = before[key];
    if (isObject(value) && isObject(previous)) {
      const nested = configurationChanges(previous, value);
      if (Object.keys(nested).length > 0) changes[key] = nested;
    } else if (!same(previous, value)) {
      changes[key] = value;
    }
  }
  return changes;
}

function takePath(patch: Json, path: string[]): unknown {
  let current: unknown = patch;
  for (const key of path.slice(0, -1)) {
    if (!isObject(current)) return undefined;
    current = current[key];
  }
  if (!isObject(current)) return undefined;
  const last = path[path.length - 1];
  if (!(last in current)) return undefined;
  const value = current[last];
  delete current[last];
  return value;
}

function prune(value: Json): Json {
  for (const [key, item] of Object.entries(value)) {
    if (isObject(item)) {
      prune(item);
      if (Object.keys(item).length === 0) delete value[key];
    }
  }
  return value;
}

export function splitLiveChanges(changes: Json): { live: Json; fileOnly: string[] } {
  const live = structuredClone(changes);
  const fileOnly: string[] = [];
  for (const path of FILE_ONLY_PATHS) {
    if (takePath(live, path) !== undefined) fileOnly.push(path.join('.'));
  }
  return { live: prune(live), fileOnly };
}
