import { Group, Text } from '@mantine/core';
import { TableData, TableRow } from '@/elements/data-display/Table.tsx';
import TableLink from '@/elements/data-display/TableLink.tsx';
import Code from '@/elements/typography/Code.tsx';
import type { NodeRecord } from '../api/types.ts';
import { formatTimestamp } from '../components/common.tsx';
import translations from '../translations.ts';
import NodeStatusBadge from './NodeStatusBadge.tsx';
import { nodeRuntimeState } from './nodeRuntimeState.ts';

export default function NodeTableRow({ node }: { node: NodeRecord }) {
  const { t } = translations.useTranslations();
  const error = nodeRuntimeState(node).operationalError;

  return (
    <TableRow>
      <TableData>
        <TableLink to={`/admin/databases-everywhere/${node.uuid}`}>
          <Group gap={4} wrap='nowrap'>
            <Text fw={500}>{node.name}</Text>
          </Group>
        </TableLink>
        <Text size='xs' c='dimmed'>
          {node.api_url}
        </Text>
      </TableData>
      <TableData>
        <Code>{node.uuid}</Code>
      </TableData>
      <TableData>
        <NodeStatusBadge node={node} />
        {error && (
          <Text c='red' size='xs' maw={260} lineClamp={1} mt={4}>
            {error}
          </Text>
        )}
      </TableData>
      <TableData>
        {node.default_cpu_cores} CPU · {node.default_memory_mib} MiB · {node.default_disk_mib} MiB
      </TableData>
      <TableData>{node.last_seen ? formatTimestamp(node.last_seen) : t('admin.never', {})}</TableData>
    </TableRow>
  );
}
