import { Stack, Text } from '@mantine/core';
import { useForm } from '@mantine/form';
import { useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import { AdminCan } from '@/elements/Can.tsx';
import NumberInput from '@/elements/input/NumberInput.tsx';
import { Modal, ModalFooter } from '@/elements/modals/Modal.tsx';
import { useToast } from '@/providers/ToastProvider.tsx';
import { type PoolReport, poolReportSchema, resizePool } from '../api/sharedPools.ts';
import translations from '../translations.ts';

export default function PoolResizeControl({
  node,
  pool,
  onSaved,
}: {
  node: string;
  pool: unknown;
  onSaved: () => void;
}) {
  const parsed = poolReportSchema.safeParse(pool);
  return parsed.success ? (
    <AdminCan action={['databases-everywhere-nodes.operations', 'databases-everywhere-nodes.update']}>
      <Control node={node} pool={parsed.data} onSaved={onSaved} />
    </AdminCan>
  ) : null;
}

function Control({ node, pool, onSaved }: { node: string; pool: PoolReport; onSaved: () => void }) {
  const { t } = translations.useTranslations();
  const { addToast } = useToast();
  const [opened, setOpened] = useState(false);
  const [saving, setSaving] = useState(false);
  const values = () => ({
    cpu: pool.cpu.limit_cores,
    memory: pool.memory.limit_bytes / 1048576,
    disk: pool.disk.limit_bytes / 1048576,
    count: pool.max_tenants,
  });
  const form = useForm({
    initialValues: values(),
    validateInputOnBlur: true,
    validate: {
      cpu: (value) =>
        Number.isFinite(value) && value >= pool.cpu.limit_cores && value <= 1024
          ? null
          : t('common.poolResizeDescription', {}),
      memory: (value) =>
        Number.isInteger(value) && value >= pool.memory.limit_bytes / 1048576 && value <= 1048576
          ? null
          : t('common.poolResizeDescription', {}),
      disk: (value) =>
        Number.isSafeInteger(value) && value >= pool.disk.limit_bytes / 1048576
          ? null
          : t('common.poolResizeDescription', {}),
      count: (value) =>
        Number.isInteger(value) && value >= Math.max(1, pool.tenant_count ?? 0) && value <= 1024
          ? null
          : t('common.poolResizeDescription', {}),
    },
  });
  return (
    <>
      <Button
        variant='default'
        onClick={() => {
          form.setValues(values());
          form.clearErrors();
          setOpened(true);
        }}
      >
        {t('common.poolResize', {})}
      </Button>
      <Modal
        title={t('common.poolResize', {})}
        opened={opened}
        onClose={() => {
          if (!saving) setOpened(false);
        }}
      >
        <form
          onSubmit={form.onSubmit(async (input) => {
            setSaving(true);
            return await (async () => {
              try {
                await resizePool(node, pool.runtime_id, {
                  cpu_cores: input.cpu,
                  memory_mib: input.memory,
                  disk_mib: input.disk,
                  max_tenants: input.count,
                });
                addToast(t('common.poolResized', {}), 'success');
                setOpened(false);
              } catch (error) {
                addToast(httpErrorToHuman(error), 'error');
              }
            })().finally(() => {
              setSaving(false);
              onSaved();
            });
          })}
        >
          <Stack>
            <Text size='sm'>{t('common.poolResizeDescription', {})}</Text>
            <NumberInput
              label={t('forms.poolCpuCores', {})}
              min={pool.cpu.limit_cores}
              max={1024}
              decimalScale={2}
              step={0.25}
              {...form.getInputProps('cpu')}
            />
            <NumberInput
              label={t('forms.poolMemoryMib', {})}
              min={pool.memory.limit_bytes / 1048576}
              max={1048576}
              {...form.getInputProps('memory')}
            />
            <NumberInput
              label={t('forms.poolDiskMib', {})}
              min={pool.disk.limit_bytes / 1048576}
              {...form.getInputProps('disk')}
            />
            <NumberInput
              label={t('forms.poolMaxDatabases', {})}
              min={Math.max(1, pool.tenant_count ?? 0)}
              max={1024}
              {...form.getInputProps('count')}
            />
          </Stack>
          <ModalFooter>
            <Button type='submit' loading={saving}>
              {t('common.save', {})}
            </Button>
          </ModalFooter>
        </form>
      </Modal>
    </>
  );
}
