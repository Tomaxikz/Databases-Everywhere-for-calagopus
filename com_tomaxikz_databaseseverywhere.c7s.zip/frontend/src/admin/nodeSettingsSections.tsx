import {
  faBoxArchive,
  faBoxesStacked,
  faCubes,
  faDatabase,
  faFolderTree,
  faHardDrive,
  faMicrochip,
  faRightLeft,
  faServer,
  faShieldHalved,
  type IconDefinition,
} from '@fortawesome/free-solid-svg-icons';
import type { FieldDef } from '@/elements/form-engine/index.ts';
import translations from '../translations.ts';
import { identityFields, poolDefaultFields, resourceFields } from './nodeBasicFields.tsx';
import { buildNodeConfigurationFields } from './nodeConfigurationFields.ts';
import { type NodeFormValues, protocols } from './nodeForm.ts';

export type NodeSettingsSectionId =
  | 'general'
  | 'resources'
  | 'databases'
  | 'images'
  | 'backups'
  | 'transfers'
  | 'storage'
  | 'containers'
  | 'security'
  | 'paths';

export interface NodeSettingsSection {
  id: NodeSettingsSectionId;
  icon: IconDefinition;
  title: string;
  description: string;
  fields: FieldDef<NodeFormValues>[];
}

type Field = FieldDef<NodeFormValues>;

const IMAGE_FIELD = /^config\.protocols\.\w+\.(image|allowedImages)$/;
const BIND_FIELD = /^config\.protocols\.\w+\.(bindHost|httpBindHost)$/;

function withWhen(field: Field, extra: (values: NodeFormValues) => boolean): Field {
  const when = field.when;
  return { ...field, when: (values: NodeFormValues) => (when ? when(values) : true) && extra(values) } as Field;
}

export function nodeSettingsSections(options: {
  editing: boolean;
  hasStoredSecrets: boolean;
  supportsArtifactPolicy: boolean;
}): NodeSettingsSection[] {
  const { t } = translations.getTranslations();
  const all = buildNodeConfigurationFields(options.editing, options.hasStoredSecrets, options.supportsArtifactPolicy);
  const byName = new Map(all.map((field) => [field.name, field]));
  const field = (name: string) => {
    const found = byName.get(name);
    if (!found) throw new Error(`Unknown node setting ${name}`);
    return found;
  };
  const matching = (test: (name: string) => boolean) =>
    all.filter((item) => item.type !== 'divider' && test(item.name));
  const divider = (name: string, label: string, advanced = false): Field => ({
    type: 'divider',
    name,
    label,
    advanced,
  });

  const browsingLimit = (values: NodeFormValues) => values.config.backups.browsing.enabled;
  const diskMode =
    (...modes: NodeFormValues['config']['disk']['mode'][]) =>
    (values: NodeFormValues) =>
      modes.includes(values.config.disk.mode);

  const protocolBindFields = protocols.flatMap(([protocol, label]) =>
    matching((name) => BIND_FIELD.test(name) && name.startsWith(`config.protocols.${protocol}.`)).map(
      (item) =>
        ({
          ...item,
          label: item.name.endsWith('httpBindHost')
            ? t('admin.nodeConfig.clickhouseHttpHost', {})
            : t('manage.bindAddressFor', { protocol: label }),
          description: undefined,
        }) as Field,
    ),
  );

  const imageFields = protocols.flatMap(([protocol, label]) => [
    {
      type: 'divider',
      name: `images.${protocol}`,
      label,
      when: (values: NodeFormValues) => values.config.protocols[protocol].enabled,
    } as Field,
    ...matching((name) => IMAGE_FIELD.test(name) && name.startsWith(`config.protocols.${protocol}.`)).map(
      (item) => ({ ...item, advanced: false }) as Field,
    ),
  ]);

  const backupFields = all
    .slice(
      all.findIndex((item) => item.name === 'backupSection'),
      all.findIndex((item) => item.name === 'artifactSection'),
    )
    .map((item) => {
      if (item.name === 'backupSection') return { ...item, label: t('manage.automatedBackups', {}) } as Field;
      if (item.name === 'config.backups.kopia.operationTimeoutSeconds')
        return { ...item, label: t('manage.kopiaTimeout', {}) } as Field;
      if (item.name.startsWith('config.backups.browsing.') && item.name !== 'config.backups.browsing.enabled')
        return withWhen(item, browsingLimit);
      return item;
    });
  const browsingIndex = backupFields.findIndex((item) => item.name === 'config.backups.browsing.enabled');
  backupFields.splice(browsingIndex, 0, {
    ...divider('backupBrowsing', t('manage.backupBrowsing', {})),
    when: (values: NodeFormValues) => values.config.backups.enabled,
  } as Field);
  const storageIndex = backupFields.findIndex((item) => item.name === 'config.backups.storageDriver');
  backupFields.splice(storageIndex, 0, {
    ...divider('backupStorage', t('manage.backupStorage', {})),
    when: (values: NodeFormValues) => values.config.backups.enabled,
  } as Field);

  return [
    {
      id: 'general',
      icon: faServer,
      title: t('manage.sections.general.title', {}),
      description: t('manage.sections.general.description', {}),
      fields: identityFields(),
    },
    {
      id: 'resources',
      icon: faMicrochip,
      title: t('manage.sections.resources.title', {}),
      description: t('manage.sections.resources.description', {}),
      fields: [
        ...resourceFields(),
        ...poolDefaultFields(),
        field('allocationSection'),
        ...matching(
          (name) => name.startsWith('config.allocation.max') || name.startsWith('config.allocation.reserved'),
        ),
        field('allocationGuardSection'),
        field('config.allocation.guardWarning'),
        ...matching((name) => name.startsWith('config.allocation.prevent')),
      ],
    },
    {
      id: 'databases',
      icon: faDatabase,
      title: t('manage.sections.databases.title', {}),
      description: t('manage.sections.databases.description', {}),
      fields: [
        field('config.protocols.gatewaySetup'),
        field('config.databaseTls.cert'),
        field('config.databaseTls.key'),
        divider('listenerAddresses', t('manage.listenerAddresses', {}), true),
        ...protocolBindFields,
      ],
    },
    {
      id: 'images',
      icon: faBoxesStacked,
      title: t('manage.sections.images.title', {}),
      description: t('manage.sections.images.description', {}),
      fields: imageFields,
    },
    {
      id: 'backups',
      icon: faBoxArchive,
      title: t('manage.sections.backups.title', {}),
      description: t('manage.sections.backups.description', {}),
      fields: backupFields,
    },
    {
      id: 'transfers',
      icon: faRightLeft,
      title: t('manage.sections.transfers.title', {}),
      description: t('manage.sections.transfers.description', {}),
      fields: [
        field('artifactSection'),
        ...matching(
          (name) =>
            name.startsWith('config.artifacts.') &&
            !name.startsWith('config.artifacts.importUpload') &&
            !name.startsWith('config.artifacts.scheduler.'),
        ),
        field('remoteImportSection'),
        ...matching((name) => name.startsWith('config.security.remoteImport.')),
        field('importUploadSection'),
        ...matching((name) => name.startsWith('config.artifacts.importUpload')),
        field('importExportSchedulerSection'),
        ...matching((name) => name.startsWith('config.artifacts.scheduler.')),
      ],
    },
    {
      id: 'storage',
      icon: faHardDrive,
      title: t('manage.sections.storage.title', {}),
      description: t('manage.sections.storage.description', {}),
      fields: [
        field('config.disk.mode'),
        ...[
          'config.disk.fuseQuotaBinary',
          'config.disk.fuseQuotaBinarySha256',
          'config.disk.fuseQuotaRescanIntervalSeconds',
        ].map((name) => withWhen(field(name), diskMode('auto', 'fuse_quota'))),
        withWhen(field('config.disk.projectIdBase'), diskMode('auto', 'project_quota')),
        withWhen(field('softScannerSection'), diskMode('auto', 'soft_scanner')),
        ...matching((name) => name.startsWith('config.disk.softScanner')).map((item) =>
          withWhen(item, diskMode('auto', 'soft_scanner')),
        ),
      ],
    },
    {
      id: 'containers',
      icon: faCubes,
      title: t('manage.sections.containers.title', {}),
      description: t('manage.sections.containers.description', {}),
      fields: matching((name) => name.startsWith('config.daemon.')),
    },
    {
      id: 'security',
      icon: faShieldHalved,
      title: t('manage.sections.security.title', {}),
      description: t('manage.sections.security.description', {}),
      fields: [
        ...matching((name) => name.startsWith('config.api.')),
        field('securitySection'),
        ...matching(
          (name) =>
            name.startsWith('config.security.') &&
            !name.startsWith('config.security.remoteImport.') &&
            !name.startsWith('config.security.pidsLimits.'),
        ),
        field('protocolPidsSection'),
        ...matching((name) => name.startsWith('config.security.pidsLimits.')),
        divider('logging', t('manage.logging', {}), true),
        field('config.debug'),
      ],
    },
    {
      id: 'paths',
      icon: faFolderTree,
      title: t('manage.sections.paths.title', {}),
      description: t('manage.sections.paths.description', {}),
      fields: matching((name) => name.startsWith('config.paths.')).map(
        (item) => ({ ...item, advanced: false }) as Field,
      ),
    },
  ];
}

export function sectionForPath(sections: NodeSettingsSection[], path: string): NodeSettingsSectionId {
  if (IMAGE_FIELD.test(path)) return 'images';
  if (path.startsWith('secrets.')) return 'backups';
  for (const section of sections) {
    if (
      section.fields.some((item) => item.type !== 'divider' && (item.name === path || path.startsWith(`${item.name}.`)))
    ) {
      return section.id;
    }
  }
  if (path.startsWith('config.protocols') || path.startsWith('config.databaseTls')) return 'databases';
  if (path.startsWith('default')) return 'resources';
  return 'general';
}

export interface SplitFields {
  main: Field[];
  more: Field[];
}

function hasVisibleEntry(fields: Field[], values: NodeFormValues) {
  return fields.some((item) => item.type !== 'divider' && (!item.when || item.when(values)));
}

function pruneDividers(fields: Field[], values: NodeFormValues): Field[] {
  const result: Field[] = [];
  fields.forEach((item, index) => {
    if (item.type !== 'divider' || item.switchName) {
      result.push(item);
      return;
    }
    const next = fields.findIndex((other, otherIndex) => otherIndex > index && other.type === 'divider');
    const group = fields.slice(index + 1, next < 0 ? fields.length : next);
    if (hasVisibleEntry(group, values)) result.push(item);
  });
  return result;
}

export function splitSectionFields(fields: Field[], values: NodeFormValues): SplitFields {
  const main: Field[] = [];
  const more: Field[] = [];
  let heading: Field | null = null;
  let headingCopied = false;
  for (const item of fields) {
    if (item.type === 'divider') {
      heading = item;
      headingCopied = false;
      (item.advanced ? more : main).push({ ...item, advanced: false } as Field);
      if (item.advanced) headingCopied = true;
      continue;
    }
    if (!item.advanced) {
      main.push(item);
      continue;
    }
    if (heading && !heading.advanced && !headingCopied && !heading.switchName) {
      more.push({ ...heading, name: `${heading.name}.more` } as Field);
      headingCopied = true;
    }
    more.push({ ...item, advanced: false } as Field);
  }
  const mainEntries = main.filter((item) => item.type !== 'divider');
  if (mainEntries.length === 0) return { main: pruneDividers(more, values), more: [] };
  return { main: pruneDividers(main, values), more: pruneDividers(more, values) };
}
