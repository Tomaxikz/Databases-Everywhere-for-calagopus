import { Group, SimpleGrid, Stack, Text } from '@mantine/core';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Progress from '@/elements/feedback/Progress.tsx';
import { bytesToString } from '@/lib/format/size.ts';
import { deploymentCapabilities } from '../api/capabilities.ts';
import type { DatabaseProtocol, DbevNodeResourceSummary, DbevSystemResponse } from '../api/types.ts';
import { formatTimestamp } from '../components/common.tsx';
import { protocolLabels } from '../components/protocols.ts';
import translations from '../translations.ts';

interface Props {
  system: DbevSystemResponse | null;
  resources: DbevNodeResourceSummary | null;
}

type RuntimeTranslation = ReturnType<typeof translations.useTranslations>['t'];

const protocols: DatabaseProtocol[] = [
  'postgres',
  'mysql',
  'mariadb',
  'redis',
  'valkey',
  'mongodb',
  'clickhouse',
  'qdrant',
];

export default function NodeRuntimeOverview({ system, resources }: Props) {
  return (
    <SimpleGrid cols={{ base: 1, xl: 2 }}>
      <DaemonStatusCard system={system} />
      <CapacityCard resources={resources} />
    </SimpleGrid>
  );
}

function DaemonStatusCard({ system }: { system: DbevSystemResponse | null }) {
  const { t } = translations.useTranslations();
  const report = system as Partial<DbevSystemResponse> | null;
  const gateways = report?.gateways;
  const placements = deploymentCapabilities(report?.deployment_capabilities);
  const enabledProtocols = protocols.filter((protocol) => (placements[protocol]?.length ?? 0) > 0);
  const predictiveDiskEnforcement = report?.disk_mode === 'soft_scanner' || report?.disk_mode === 'none';
  const diskEnforced = report?.daemon_disk_limits_enforced === true || predictiveDiskEnforcement;

  return (
    <TitleCard title={t('admin.runtimeOverview.daemon', {})}>
      {!report ? (
        <EmptySample t={t} />
      ) : (
        <Stack gap='lg'>
          {gatewayReadinessMessage(gateways) && (
            <Alert color={gateways?.status === 'failed' ? 'red' : 'yellow'}>{gatewayReadinessMessage(gateways)}</Alert>
          )}
          <SimpleGrid cols={{ base: 1, sm: 2 }} spacing='lg'>
            <Metric
              label={t('admin.runtimeOverview.daemonVersion', {})}
              value={report.version ? `v${report.version}` : '—'}
              detail={report.api_version ? `API ${report.api_version}` : undefined}
            />
            <Metric label={t('admin.runtimeOverview.containerRuntime', {})} value={titleCase(report.daemon_engine)} />
            <Metric
              label={t('admin.runtimeOverview.managementApi', {})}
              value={report.api_bind || formatApiBind(report)}
              detail={report.api_ssl_enabled ? undefined : t('admin.runtimeOverview.tlsDisabled', {})}
            />
            <Metric
              label={t('admin.runtimeOverview.gatewayReadiness', {})}
              value={
                gateways
                  ? t('admin.runtimeOverview.listenersReady', {
                      ready: gateways.ready_listeners,
                      expected: gateways.expected_listeners,
                    })
                  : '—'
              }
              detail={gateways?.failure}
            />
            <Metric
              label={t('admin.runtimeOverview.remoteImports', {})}
              value={
                report.remote_import_enabled
                  ? t('admin.runtimeOverview.enabled', {})
                  : t('admin.runtimeOverview.disabled', {})
              }
            />
            <Metric
              label={t('admin.runtimeOverview.diskQuotas', {})}
              value={
                diskEnforced
                  ? predictiveDiskEnforcement
                    ? t('admin.runtimeOverview.predictiveEnforcement', {})
                    : t('admin.runtimeOverview.enforced', {})
                  : t('admin.runtimeOverview.notEnforced', {})
              }
              detail={report.disk_mode ? titleCase(report.disk_mode) : undefined}
            />
          </SimpleGrid>
          <Metric
            label={t('admin.runtimeOverview.databaseGateways', {})}
            value={
              enabledProtocols.length
                ? [
                    ...enabledProtocols.map((protocol) => protocolLabels[protocol]),
                    ...(report.clickhouse_http_enabled ? ['ClickHouse HTTP'] : []),
                  ].join(', ')
                : t('admin.runtimeOverview.noGateways', {})
            }
          />
        </Stack>
      )}
    </TitleCard>
  );
}

export function gatewayReadinessMessage(gateways: DbevSystemResponse['gateways'] | null | undefined): string | null {
  if (gateways?.status === 'starting') {
    return 'The DBEV management API is ready, but database listeners are still starting.';
  }
  if (gateways?.status === 'failed') {
    const failure = gateways.failure?.trim() || 'the daemon did not report a listener failure reason';
    return `DBEV is running, but one or more database gateways failed: ${failure}`;
  }
  return null;
}

function CapacityCard({ resources }: { resources: DbevNodeResourceSummary | null }) {
  const { t } = translations.useTranslations();
  const report = resources as Partial<DbevNodeResourceSummary> | null;
  const summary = isCompleteResourceSummary(report) ? report : null;

  return (
    <TitleCard
      title={t('admin.runtimeOverview.capacity', {})}
      rightSection={
        <Text size='xs' c='dimmed' ml='auto'>
          {report?.sampled_at
            ? t('admin.runtimeOverview.sampledAt', { time: formatTimestamp(report.sampled_at) })
            : t('admin.notSampled', {})}
        </Text>
      }
    >
      {!summary ? (
        <EmptySample t={t} />
      ) : (
        <Stack gap='lg'>
          <CapacityBar
            label={t('admin.runtimeOverview.cpuReservations', {})}
            value={summary.cpu.allocated_cores}
            limit={summary.cpu.total_cores}
            valueLabel={t('admin.runtimeOverview.allocatedOf', {
              allocated: t('admin.runtimeOverview.cores', { count: formatNumber(summary.cpu.allocated_cores) }),
              limit: t('admin.runtimeOverview.cores', { count: formatNumber(summary.cpu.total_cores) }),
            })}
            details={[t('admin.runtimeOverview.hostCpuUse', { percent: formatNumber(summary.cpu.host_usage_percent) })]}
          />
          <CapacityBar
            label={t('admin.runtimeOverview.memoryReservations', {})}
            value={summary.memory.allocated_bytes}
            limit={summary.memory.allocation_limit_bytes}
            valueLabel={t('admin.runtimeOverview.allocatedOf', {
              allocated: formatBytes(summary.memory.allocated_bytes),
              limit: formatBytes(summary.memory.allocation_limit_bytes),
            })}
            details={resourceDetails(summary.memory, t)}
          />
          <CapacityBar
            label={t('admin.runtimeOverview.diskReservations', {})}
            value={summary.disk.allocated_bytes}
            limit={summary.disk.allocation_limit_bytes}
            valueLabel={t('admin.runtimeOverview.allocatedOf', {
              allocated: formatBytes(summary.disk.allocated_bytes),
              limit: formatBytes(summary.disk.allocation_limit_bytes),
            })}
            details={resourceDetails(summary.disk, t)}
          />
          <Group justify='space-between' wrap='nowrap'>
            <Text size='sm' fw={600}>
              {t('admin.runtimeOverview.instances', {})}
            </Text>
            <Text size='sm' c='dimmed' ta='right'>
              {instanceSummary(summary.instances, t)}
            </Text>
          </Group>
        </Stack>
      )}
    </TitleCard>
  );
}

function CapacityBar({
  label,
  value,
  limit,
  valueLabel,
  details,
}: {
  label: string;
  value: number;
  limit: number;
  valueLabel: string;
  details: string[];
}) {
  const percent = percentage(value, limit);
  return (
    <Stack gap={6}>
      <Group justify='space-between' wrap='nowrap'>
        <Text size='sm' fw={600}>
          {label}
        </Text>
        <Text size='sm' ff='monospace' ta='right'>
          {valueLabel}
        </Text>
      </Group>
      <Progress value={percent} color={capacityColor(percent)} hourglass={false} withLabel={false} />
      <Group justify='space-between' gap='xs'>
        {details.map((detail) => (
          <Text key={detail} size='xs' c='dimmed'>
            {detail}
          </Text>
        ))}
      </Group>
    </Stack>
  );
}

function Metric({ label, value, detail }: { label: string; value?: string; detail?: string }) {
  return (
    <div>
      <Text size='xs' c='dimmed'>
        {label}
      </Text>
      {value && <Text fw={600}>{value}</Text>}
      {detail && (
        <Text size='xs' c='dimmed' className='break-all'>
          {detail}
        </Text>
      )}
    </div>
  );
}

/** "3 running · 1 stopped", listing only states with instances in them. */
function instanceSummary(instances: DbevNodeResourceSummary['instances'], t: RuntimeTranslation): string {
  const states = [
    [instances.running, t('admin.runtimeOverview.running', {})],
    [instances.creating, t('admin.runtimeOverview.creating', {})],
    [instances.booting, t('admin.runtimeOverview.booting', {})],
    [instances.stopped, t('admin.runtimeOverview.stopped', {})],
    [instances.failed, t('admin.runtimeOverview.failed', {})],
    [instances.quarantined, t('admin.runtimeOverview.quarantined', {})],
    [instances.deleting, t('admin.runtimeOverview.deleting', {})],
  ] as const;
  const parts = states.filter(([count]) => count > 0).map(([count, label]) => `${count} ${label.toLowerCase()}`);
  return parts.length ? parts.join(' · ') : t('admin.runtimeOverview.totalInstances', { count: 0 });
}

function EmptySample({ t }: { t: RuntimeTranslation }) {
  return (
    <Stack gap={4} py='xl' align='center'>
      <Text fw={600}>{t('admin.runtimeOverview.noSample', {})}</Text>
      <Text size='xs' c='dimmed' ta='center'>
        {t('admin.runtimeOverview.noSampleDescription', {})}
      </Text>
    </Stack>
  );
}

function resourceDetails(resource: DbevNodeResourceSummary['memory'], t: RuntimeTranslation): string[] {
  return [
    t('admin.runtimeOverview.hostUse', {
      used: formatBytes(resource.host_used_bytes),
      total: formatBytes(resource.total_bytes),
    }),
    t('admin.runtimeOverview.available', { size: formatBytes(resource.available_bytes) }),
  ];
}

function isCompleteResourceSummary(value: Partial<DbevNodeResourceSummary> | null): value is DbevNodeResourceSummary {
  return Boolean(value?.cpu && value.memory && value.disk && value.instances);
}

function formatApiBind(system: Partial<DbevSystemResponse>): string {
  if (!system.api_host) return '—';
  return `${system.api_ssl_enabled ? 'https' : 'http'}://${system.api_host}${system.api_port ? `:${system.api_port}` : ''}`;
}

function formatBytes(value: number): string {
  return bytesToString(Number.isFinite(value) ? Math.max(0, value) : 0);
}

function formatNumber(value: number | undefined): string {
  return Number.isFinite(value)
    ? new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(value ?? 0)
    : '0';
}

function percentage(value: number | undefined, limit: number | undefined): number {
  if (!Number.isFinite(value) || !Number.isFinite(limit) || !limit || limit <= 0) return 0;
  return Math.max(0, Math.min(100, ((value ?? 0) / limit) * 100));
}

function capacityColor(percent: number): 'blue' | 'orange' | 'red' {
  if (percent >= 90) return 'red';
  if (percent >= 75) return 'orange';
  return 'blue';
}

function titleCase(value: string | undefined): string {
  if (!value) return '—';
  return value.replaceAll('_', ' ').replace(/\b\w/g, (character) => character.toUpperCase());
}
