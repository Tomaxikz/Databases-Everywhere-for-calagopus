import { faChevronDown, faChevronUp } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { NavLink as MantineNavLink } from '@mantine/core';
import { useQueryClient } from '@tanstack/react-query';
import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import { AdminCan } from '@/elements/Can.tsx';
import Badge from '@/elements/data-display/Badge.tsx';
import Card from '@/elements/data-display/Card.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import { FormEngine, useFormEngine } from '@/elements/form-engine/index.ts';
import Group from '@/elements/layout/Group.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import ConfirmationModal from '@/elements/modals/ConfirmationModal.tsx';
import Text from '@/elements/typography/Text.tsx';
import Title from '@/elements/typography/Title.tsx';
import { useBlocker } from '@/plugins/useBlocker.ts';
import { useAdminCan } from '@/plugins/usePermissions.ts';
import { useToast } from '@/providers/ToastProvider.tsx';
import { useTranslations } from '@/providers/TranslationProvider.tsx';
import { patchRemoteConfiguration, updateNode } from '../api/client.ts';
import { dbevQueryKeys } from '../api/queryKeys.ts';
import type { NodeRecord } from '../api/types.ts';
import translations from '../translations.ts';
import { nodeSupportsArtifactPolicy } from './artifactPolicy.ts';
import { configurationChanges, splitLiveChanges } from './configurationChanges.ts';
import NodeConfigFileModal from './NodeConfigFileModal.tsx';
import NodeFormIssues from './NodeFormIssues.tsx';
import {
  createNodeFormSchema,
  initialNodeFormValues,
  type NodeFormValues,
  nodeFormValidationOptions,
  toNodeInput,
} from './nodeForm.ts';
import { nodeFormIssues } from './nodeFormIssues.ts';
import { nodeFormMessages } from './nodeFormMessages.ts';
import { nodeRuntimeState } from './nodeRuntimeState.ts';
import {
  type NodeSettingsSectionId,
  nodeSettingsSections,
  sectionForPath,
  splitSectionFields,
} from './nodeSettingsSections.tsx';

type ApplyResult =
  | { kind: 'saved'; fileOnly: string[] }
  | { kind: 'applied'; restart: boolean; fileOnly: string[] }
  | { kind: 'offline'; fileOnly: string[] }
  | { kind: 'failed'; error: string; live: Record<string, unknown>; fileOnly: string[] };

const MORE_KEY = 'dbev.settings.more';

function readOpenMore(): string[] {
  try {
    const value = JSON.parse(localStorage.getItem(MORE_KEY) ?? '[]');
    return Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string') : [];
  } catch {
    return [];
  }
}

function writeOpenMore(value: string[]) {
  try {
    localStorage.setItem(MORE_KEY, JSON.stringify(value));
  } catch {
    return;
  }
}

export default function NodeSettingsEditor({ node }: { node: NodeRecord }) {
  const { t } = translations.useTranslations();
  const { t: tBase } = useTranslations();
  const { addToast } = useToast();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const params = useParams();
  const canUpdate = useAdminCan('databases-everywhere-nodes.update');
  const runtimeState = nodeRuntimeState(node);
  const supportsArtifactPolicy = nodeSupportsArtifactPolicy(node);
  const readOnly = !canUpdate || runtimeState.recordMutationBlocked;
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState<ApplyResult | null>(null);
  const [configOpen, setConfigOpen] = useState(false);
  const [openMore, setOpenMore] = useState<string[]>(readOpenMore);

  const sections = useMemo(
    () =>
      nodeSettingsSections({
        editing: true,
        hasStoredSecrets: node.has_configuration_secrets,
        supportsArtifactPolicy,
      }),
    [node.has_configuration_secrets, supportsArtifactPolicy],
  );
  const schema = useMemo(() => createNodeFormSchema(nodeFormMessages()), []);
  const form = useFormEngine<NodeFormValues>('admin.databasesEverywhere.nodes.createOrUpdate', {
    schema,
    initialValues: initialNodeFormValues(node),
    ...nodeFormValidationOptions,
  });
  const dirty = form.isDirty();
  const blocker = useBlocker(dirty, true);

  useEffect(() => {
    if (form.isDirty()) return;
    const values = initialNodeFormValues(node);
    form.setInitialValues(values);
    form.setValues(values);
    form.resetDirty(values);
    if (!schema.safeParse(values).success) form.validate();
  }, [node.updated, node.uuid]);

  const activeId = (sections.find((section) => section.id === params['*'])?.id ?? 'general') as NodeSettingsSectionId;
  const active = sections.find((section) => section.id === activeId) ?? sections[0];
  const values = form.getValues();
  const issues = nodeFormIssues(schema, values, sections);
  const errorSections = new Set([
    ...Object.keys(form.errors).map((path) => sectionForPath(sections, path)),
    ...issues.map((issue) => issue.section),
  ]);
  const dirtySections = new Set(
    sections
      .filter((section) =>
        section.fields.some((field) => field.type !== 'divider' && field.type !== 'custom' && form.isDirty(field.name)),
      )
      .map((section) => section.id),
  );
  if (form.isDirty('config.protocols')) dirtySections.add('databases');

  const split = splitSectionFields(active.fields, values);
  const moreCount = split.more.filter(
    (field) => field.type !== 'divider' && (!field.when || field.when(values)),
  ).length;
  const moreOpen = openMore.includes(active.id) || (errorSections.has(active.id) && split.more.length > 0);
  const toggleMore = () => {
    const next = openMore.includes(active.id) ? openMore.filter((id) => id !== active.id) : [...openMore, active.id];
    setOpenMore(next);
    writeOpenMore(next);
  };
  const goTo = (id: NodeSettingsSectionId) => navigate(`/admin/databases-everywhere/${node.uuid}/configuration/${id}`);

  const pushLive = async (live: Record<string, unknown>, fileOnly: string[]): Promise<ApplyResult> => {
    if (Object.keys(live).length === 0) return { kind: 'saved', fileOnly };
    if (runtimeState.mutationBlocked || !node.cached_system) return { kind: 'offline', fileOnly };
    try {
      const response = await patchRemoteConfiguration(node.uuid, live);
      return { kind: 'applied', restart: response.restart_required, fileOnly };
    } catch (error) {
      return { kind: 'failed', error: httpErrorToHuman(error), live, fileOnly };
    }
  };

  const save = async () => {
    const validation = form.validate();
    const paths = Object.keys(validation.errors);
    if (validation.hasErrors) {
      const first = sections.find((section) => paths.some((path) => sectionForPath(sections, path) === section.id));
      if (first && first.id !== activeId) goTo(first.id);
      addToast(t('manage.fixErrors', {}), 'error');
      return;
    }

    setSaving(true);
    try {
      const values = schema.parse(form.getValues());
      const input = toNodeInput(values, node.configuration, { includeArtifactPolicy: supportsArtifactPolicy });
      await updateNode(node.uuid, input);
      const changes = configurationChanges(node.configuration, input.configuration ?? {});
      const split = splitLiveChanges(changes);
      const fileOnly = input.configuration_secrets ? [...split.fileOnly, 'secrets'] : split.fileOnly;
      const applied = await pushLive(split.live, fileOnly);
      setResult(applied);
      form.resetDirty(form.getValues());
      await queryClient.invalidateQueries({ queryKey: dbevQueryKeys.adminNodes() });
      addToast(t('admin.nodeUpdated', {}), applied.kind === 'failed' ? 'warning' : 'success');
    } catch (error) {
      addToast(httpErrorToHuman(error), 'error');
    } finally {
      setSaving(false);
    }
  };

  const retry = async () => {
    if (result?.kind !== 'failed') return;
    setSaving(true);
    const applied = await pushLive(result.live, result.fileOnly);
    setResult(applied);
    setSaving(false);
    await queryClient.invalidateQueries({ queryKey: dbevQueryKeys.adminNodes() });
  };

  const discard = () => {
    form.reset();
  };

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        if (!readOnly) void save();
      }}
    >
      <ConfirmationModal
        title={tBase('common.modal.unsavedChanges.title', {})}
        opened={blocker.state === 'blocked'}
        onClose={() => blocker.reset()}
        onConfirmed={() => blocker.proceed()}
        confirm={tBase('common.button.leavePage', {})}
      >
        {tBase('common.modal.unsavedChanges.content', {}).md()}
      </ConfirmationModal>
      <NodeConfigFileModal node={node.uuid} opened={configOpen} onClose={() => setConfigOpen(false)} />

      <div className='grid grid-cols-1 gap-4 lg:grid-cols-[15rem_minmax(0,1fr)]'>
        <Card p='sm' className='self-start lg:sticky lg:top-4'>
          <nav aria-label={t('manage.configuration', {})}>
            {sections.map((section) => (
              <MantineNavLink
                key={section.id}
                component='button'
                type='button'
                active={section.id === activeId}
                label={section.title}
                leftSection={<FontAwesomeIcon icon={section.icon} fixedWidth />}
                rightSection={
                  errorSections.has(section.id) ? (
                    <Badge color='red' size='xs'>
                      {t('manage.error', {})}
                    </Badge>
                  ) : dirtySections.has(section.id) ? (
                    <Badge color='yellow' size='xs'>
                      {t('manage.changed', {})}
                    </Badge>
                  ) : null
                }
                onClick={() => goTo(section.id)}
                style={{ borderRadius: 'max(4px, calc(var(--mantine-radius-md) - var(--mantine-spacing-sm)))' }}
              />
            ))}
          </nav>
        </Card>

        <Stack>
          {readOnly && (
            <Alert color='yellow' title={t('manage.readOnlyTitle', {})}>
              {runtimeState.recordMutationBlocked
                ? runtimeState.mutationBlockReason || t('admin.readOnlyCompatibilityDescription', {})
                : t('manage.readOnlyPermission', {})}
            </Alert>
          )}
          <NodeFormIssues
            issues={issues}
            onFix={(issue) => {
              goTo(issue.section);
              form.validate();
            }}
          />
          {result && (
            <ApplyResultAlert
              result={result}
              saving={saving}
              onRetry={retry}
              onShowConfig={() => setConfigOpen(true)}
              onClose={() => setResult(null)}
            />
          )}

          <Card p='lg'>
            <Stack gap={4} mb='lg'>
              <Title order={3}>{active.title}</Title>
              <Text size='sm' c='dimmed'>
                {active.description}
              </Text>
            </Stack>
            <fieldset disabled={readOnly} className='m-0 min-w-0 border-0 p-0'>
              <FormEngine form={form} fields={split.main} />
              {moreCount > 0 && (
                <div className='mt-6 border-t border-(--mantine-color-default-border) pt-4'>
                  <Button
                    type='button'
                    variant='subtle'
                    color='gray'
                    onClick={toggleMore}
                    rightSection={<FontAwesomeIcon icon={moreOpen ? faChevronUp : faChevronDown} />}
                  >
                    {moreOpen ? t('manage.hideMore', {}) : t('manage.showMore', { count: moreCount })}
                  </Button>
                  {moreOpen && <FormEngine form={form} fields={split.more} className='mt-4' />}
                </div>
              )}
            </fieldset>
          </Card>

          {!readOnly && (
            <Card px='lg' py='md' className='sticky bottom-4 z-10'>
              <Group justify='space-between'>
                <Text size='sm' c={dirty ? undefined : 'dimmed'}>
                  {dirty
                    ? t('manage.unsavedIn', {
                        sections:
                          sections
                            .filter((section) => dirtySections.has(section.id))
                            .map((section) => section.title)
                            .join(', ') || active.title,
                      })
                    : t('manage.noChanges', {})}
                </Text>
                <Group gap='sm'>
                  <Button type='button' variant='default' disabled={!dirty || saving} onClick={discard}>
                    {t('manage.discard', {})}
                  </Button>
                  <AdminCan action='databases-everywhere-nodes.update' cantSave>
                    <Button type='submit' loading={saving} disabled={!dirty}>
                      {t('common.save', {})}
                    </Button>
                  </AdminCan>
                </Group>
              </Group>
            </Card>
          )}
        </Stack>
      </div>
    </form>
  );
}

function ApplyResultAlert({
  result,
  saving,
  onRetry,
  onShowConfig,
  onClose,
}: {
  result: ApplyResult;
  saving: boolean;
  onRetry: () => void;
  onShowConfig: () => void;
  onClose: () => void;
}) {
  const { t } = translations.useTranslations();
  const fileOnly = result.fileOnly
    .map((path) => fileOnlyLabel(path))
    .filter((label, index, list) => list.indexOf(label) === index);
  const needsFile = result.kind === 'offline' || fileOnly.length > 0;
  const color =
    result.kind === 'failed' ? 'red' : needsFile || (result.kind === 'applied' && result.restart) ? 'yellow' : 'green';
  const title =
    result.kind === 'applied'
      ? t('manage.apply.appliedTitle', {})
      : result.kind === 'offline'
        ? t('manage.apply.offlineTitle', {})
        : result.kind === 'failed'
          ? t('manage.apply.failedTitle', {})
          : t('manage.apply.savedTitle', {});

  return (
    <Alert color={color} title={title} withCloseButton onClose={onClose}>
      <Stack gap='xs'>
        {result.kind === 'applied' && (
          <Text size='sm'>{result.restart ? t('manage.apply.appliedRestart', {}) : t('manage.apply.applied', {})}</Text>
        )}
        {result.kind === 'offline' && <Text size='sm'>{t('manage.apply.offline', {})}</Text>}
        {result.kind === 'failed' && <Text size='sm'>{t('manage.apply.failed', { error: result.error })}</Text>}
        {result.kind === 'saved' && fileOnly.length === 0 && <Text size='sm'>{t('manage.apply.saved', {})}</Text>}
        {fileOnly.length > 0 && <Text size='sm'>{t('manage.apply.fileOnly', { settings: fileOnly.join(', ') })}</Text>}
        <Group gap='xs'>
          {result.kind === 'failed' && (
            <Button size='compact-sm' loading={saving} onClick={onRetry}>
              {t('manage.apply.retry', {})}
            </Button>
          )}
          {needsFile && (
            <Button size='compact-sm' variant='default' onClick={onShowConfig}>
              {t('manage.configFile.show', {})}
            </Button>
          )}
        </Group>
      </Stack>
    </Alert>
  );
}

function fileOnlyLabel(path: string): string {
  const { t } = translations.getTranslations();
  if (path === 'paths') return t('manage.fileOnly.paths', {});
  if (path.startsWith('tls.')) return t('manage.fileOnly.databaseTls', {});
  if (path.startsWith('api.ssl.')) return t('manage.fileOnly.apiTls', {});
  if (path === 'daemon.socket_path') return t('manage.fileOnly.socket', {});
  if (path.startsWith('disk.')) return t('manage.fileOnly.fuseQuota', {});
  if (path.startsWith('backups.storage.kopia')) return t('manage.fileOnly.kopia', {});
  if (path.startsWith('backups.storage.s3') || path === 'secrets') return t('manage.fileOnly.credentials', {});
  return path;
}
