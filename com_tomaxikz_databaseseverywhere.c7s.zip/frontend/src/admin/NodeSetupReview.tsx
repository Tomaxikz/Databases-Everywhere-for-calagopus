import Badge from '@/elements/Badge.tsx';
import Code from '@/elements/Code.tsx';
import Group from '@/elements/Group.tsx';
import Stack from '@/elements/Stack.tsx';
import Text from '@/elements/Text.tsx';
import TitleCard from '@/elements/TitleCard.tsx';
import ProtocolIcon from '../components/ProtocolIcon.tsx';
import translations from '../translations.ts';
import type { NodeFormValues } from './nodeForm.ts';
import { daemonApiBindPort, parseDaemonApiUrl, protocols } from './nodeForm.ts';

function SummaryValue({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <Text size='xs' c='dimmed'>
        {label}
      </Text>
      <Text size='sm' fw={500} className='break-all'>
        {children}
      </Text>
    </div>
  );
}

export default function NodeSetupReview({
  values,
  showArtifactPolicy = true,
}: {
  values: NodeFormValues;
  showArtifactPolicy?: boolean;
}) {
  const { t } = translations.useTranslations();
  const enabledProtocols = protocols.filter(([protocol]) => values.config.protocols[protocol].enabled);
  const apiEndpoint = parseDaemonApiUrl(values.apiUrl);

  return (
    <Stack gap='md'>
      <TitleCard
        title={t('admin.wizard.reviewConnection', {})}
        rightSection={
          <Badge className='ml-auto' color={values.enabled ? 'green' : 'gray'}>
            {values.enabled ? t('admin.wizard.schedulingEnabled', {}) : t('admin.wizard.schedulingDisabled', {})}
          </Badge>
        }
      >
        <div className='grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4'>
          <SummaryValue label={t('admin.nodeName', {})}>{values.name || '—'}</SummaryValue>
          <SummaryValue label={t('admin.apiUrl', {})}>
            {apiEndpoint?.normalizedUrl || values.apiUrl || '—'}
          </SummaryValue>
          {apiEndpoint?.scheme === 'https' && (
            <SummaryValue label={t('admin.nodeConfig.tlsHostname', {})}>{apiEndpoint.hostname}</SummaryValue>
          )}
          <SummaryValue label={t('admin.nodeConfig.internalApiBindPort', {})}>
            {daemonApiBindPort(values) ?? '—'}
          </SummaryValue>
          <SummaryValue label={t('admin.publicHost', {})}>{values.publicHost || '—'}</SummaryValue>
        </div>
      </TitleCard>

      <TitleCard title={t('admin.wizard.reviewRuntime', {})}>
        <div className='grid grid-cols-2 gap-4 lg:grid-cols-4'>
          <SummaryValue label={t('admin.nodeConfig.containerEngine', {})}>
            {values.config.daemon.engine === 'podman' ? 'Podman' : 'Docker'}
          </SummaryValue>
          <SummaryValue label={t('admin.cpu', {})}>{values.defaultCpuCores}</SummaryValue>
          <SummaryValue label={t('admin.memory', {})}>{values.defaultMemoryMib} MiB</SummaryValue>
          <SummaryValue label={t('admin.disk', {})}>{values.defaultDiskMib} MiB</SummaryValue>
        </div>
      </TitleCard>

      <TitleCard
        title={t('admin.wizard.reviewGateways', {})}
        rightSection={
          <Badge className='ml-auto'>{t('admin.wizard.gatewayCount', { count: enabledProtocols.length })}</Badge>
        }
      >
        <Stack gap='xs'>
          {enabledProtocols.map(([protocol, label]) => {
            const gateway = values.config.protocols[protocol];
            return (
              <Group key={protocol} justify='space-between' wrap='wrap' gap='sm'>
                <Group gap='sm'>
                  <ProtocolIcon protocol={protocol} size={26} />
                  <Text size='sm' fw={600}>
                    {label}
                  </Text>
                  <Badge size='xs' color={gateway.tls ? 'green' : 'gray'}>
                    {gateway.tls ? 'TLS' : t('admin.wizard.plaintext', {})}
                  </Badge>
                </Group>
                <Code>{`${values.publicHost || t('admin.nodeConfig.gatewayExampleHost', {})}:${gateway.port}`}</Code>
              </Group>
            );
          })}
          {enabledProtocols.length === 0 && (
            <Text size='sm' c='dimmed'>
              {t('admin.wizard.noGateways', {})}
            </Text>
          )}
        </Stack>
      </TitleCard>

      <TitleCard title={t('admin.wizard.reviewBackups', {})}>
        <div className='grid grid-cols-1 gap-4 md:grid-cols-3'>
          <SummaryValue label={t('admin.nodeConfig.automatedBackups', {})}>
            {values.config.backups.enabled ? t('admin.wizard.yes', {}) : t('admin.wizard.no', {})}
          </SummaryValue>
          <SummaryValue label={t('admin.nodeConfig.backupStorageDriver', {})}>
            {values.config.backups.storageDriver.toUpperCase()}
          </SummaryValue>
          <SummaryValue label={t('admin.nodeConfig.backupInterval', {})}>
            {values.config.backups.intervalMinutes}
          </SummaryValue>
          {showArtifactPolicy && (
            <>
              <SummaryValue label={t('admin.nodeConfig.streamExportsOnly', {})}>
                {values.config.artifacts.streamExportsOnly ? t('admin.wizard.yes', {}) : t('admin.wizard.no', {})}
              </SummaryValue>
              <SummaryValue label={t('admin.nodeConfig.maxArtifactsPerInstance', {})}>
                {values.config.artifacts.maxArtifactsPerInstance}
              </SummaryValue>
            </>
          )}
        </div>
      </TitleCard>

      <Text size='sm' c='dimmed'>
        {t('admin.wizard.reviewHint', {})}
      </Text>
    </Stack>
  );
}
