import { SimpleGrid } from '@mantine/core';
import type { ReactNode } from 'react';
import Badge from '@/elements/data-display/Badge.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Group from '@/elements/layout/Group.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import Code from '@/elements/typography/Code.tsx';
import Text from '@/elements/typography/Text.tsx';
import { bytesToString, mbToBytes } from '@/lib/format/size.ts';
import ProtocolIcon from '../components/ProtocolIcon.tsx';
import translations from '../translations.ts';
import NodeFormIssues from './NodeFormIssues.tsx';
import type { NodeFormValues } from './nodeForm.ts';
import { daemonApiBindPort, parseDaemonApiUrl, protocols } from './nodeForm.ts';
import { issueFor, type NodeFormIssue } from './nodeFormIssues.ts';

function SummaryValue({ label, issue, children }: { label: string; issue?: NodeFormIssue; children?: ReactNode }) {
  const { t } = translations.useTranslations();
  const empty = children === undefined || children === null || children === '';
  return (
    <div className='min-w-0'>
      <Text size='xs' c={issue ? 'red' : 'dimmed'}>
        {label}
      </Text>
      <Text size='sm' fw={500} c={issue ? 'red' : empty ? 'dimmed' : undefined} className='break-all'>
        {empty ? t('manage.issues.notSet', {}) : children}
      </Text>
      {issue && (
        <Text size='xs' c='red'>
          {issue.message}
        </Text>
      )}
    </div>
  );
}

export default function NodeSetupReview({
  values,
  issues,
  onFix,
}: {
  values: NodeFormValues;
  issues: NodeFormIssue[];
  onFix: (issue: NodeFormIssue) => void;
}) {
  const { t } = translations.useTranslations();
  const enabledProtocols = protocols.filter(([protocol]) => values.config.protocols[protocol].enabled);
  const apiEndpoint = parseDaemonApiUrl(values.apiUrl);
  const deploymentPolicyLabel =
    values.deploymentPolicy === 'dedicated_only'
      ? t('admin.deploymentPolicies.dedicated', {})
      : values.deploymentPolicy === 'shared_only'
        ? t('admin.deploymentPolicies.shared', {})
        : t('admin.deploymentPolicies.hybrid', {});
  const gatewayIssue = issueFor(issues, 'config.protocols');

  return (
    <Stack>
      <NodeFormIssues issues={issues} onFix={onFix} />

      <SimpleGrid cols={{ base: 1, lg: 2 }}>
        <TitleCard
          title={t('admin.wizard.reviewConnection', {})}
          rightSection={
            <Badge ml='auto' color={values.enabled ? 'green' : 'gray'}>
              {values.enabled ? t('admin.wizard.schedulingEnabled', {}) : t('admin.wizard.schedulingDisabled', {})}
            </Badge>
          }
        >
          <SimpleGrid cols={{ base: 1, sm: 2 }}>
            <SummaryValue label={t('admin.nodeName', {})} issue={issueFor(issues, 'name')}>
              {values.name.trim()}
            </SummaryValue>
            <SummaryValue label={t('admin.deploymentPolicy', {})}>{deploymentPolicyLabel}</SummaryValue>
            <SummaryValue label={t('admin.apiUrl', {})} issue={issueFor(issues, 'apiUrl')}>
              {apiEndpoint?.normalizedUrl || values.apiUrl.trim()}
            </SummaryValue>
            <SummaryValue label={t('admin.nodeConfig.internalApiBindPort', {})}>
              {daemonApiBindPort(values) ?? ''}
            </SummaryValue>
            <SummaryValue label={t('admin.publicHost', {})} issue={issueFor(issues, 'publicHost')}>
              {values.publicHost.trim()}
            </SummaryValue>
            {apiEndpoint?.scheme === 'https' && (
              <SummaryValue label={t('admin.nodeConfig.tlsHostname', {})}>{apiEndpoint.hostname}</SummaryValue>
            )}
          </SimpleGrid>
        </TitleCard>

        <TitleCard
          title={t('admin.wizard.reviewGateways', {})}
          rightSection={
            <Badge ml='auto' color={gatewayIssue ? 'red' : undefined}>
              {t('admin.wizard.gatewayCount', { count: enabledProtocols.length })}
            </Badge>
          }
        >
          <Stack gap='xs'>
            {enabledProtocols.map(([protocol, label]) => {
              const gateway = values.config.protocols[protocol];
              return (
                <Group key={protocol} justify='space-between' wrap='wrap' gap='sm'>
                  <Group gap='sm'>
                    <ProtocolIcon protocol={protocol} size={26} />
                    <Text size='sm' fw={600}>
                      {label}
                    </Text>
                    <Badge size='xs' color={gateway.tls ? 'green' : 'gray'}>
                      {gateway.tls ? 'TLS' : t('admin.wizard.plaintext', {})}
                    </Badge>
                  </Group>
                  <Code>{`${values.publicHost.trim() || t('admin.nodeConfig.gatewayExampleHost', {})}:${gateway.port}`}</Code>
                </Group>
              );
            })}
            {enabledProtocols.length === 0 && (
              <Text size='sm' c={gatewayIssue ? 'red' : 'dimmed'}>
                {gatewayIssue?.message ?? t('admin.wizard.noGateways', {})}
              </Text>
            )}
          </Stack>
        </TitleCard>

        <TitleCard title={t('admin.wizard.reviewRuntime', {})}>
          <SimpleGrid cols={{ base: 2, xl: 4 }}>
            <SummaryValue label={t('admin.nodeConfig.containerEngine', {})}>
              {values.config.daemon.engine === 'podman' ? 'Podman' : 'Docker'}
            </SummaryValue>
            <SummaryValue label={t('admin.cpu', {})} issue={issueFor(issues, 'defaultCpuCores')}>
              {values.defaultCpuCores}
            </SummaryValue>
            <SummaryValue label={t('admin.memory', {})} issue={issueFor(issues, 'defaultMemoryMib')}>
              {bytesToString(mbToBytes(values.defaultMemoryMib))}
            </SummaryValue>
            <SummaryValue label={t('admin.disk', {})} issue={issueFor(issues, 'defaultDiskMib')}>
              {bytesToString(mbToBytes(values.defaultDiskMib))}
            </SummaryValue>
          </SimpleGrid>
        </TitleCard>

        <TitleCard title={t('admin.poolDefaults', {})}>
          <SimpleGrid cols={{ base: 2, xl: 4 }}>
            <SummaryValue label={t('forms.poolCpuCores', {})} issue={issueFor(issues, 'defaultPoolCpuCores')}>
              {values.defaultPoolCpuCores}
            </SummaryValue>
            <SummaryValue label={t('forms.poolMemoryMib', {})} issue={issueFor(issues, 'defaultPoolMemoryMib')}>
              {bytesToString(mbToBytes(values.defaultPoolMemoryMib))}
            </SummaryValue>
            <SummaryValue label={t('forms.poolDiskMib', {})} issue={issueFor(issues, 'defaultPoolDiskMib')}>
              {bytesToString(mbToBytes(values.defaultPoolDiskMib))}
            </SummaryValue>
            <SummaryValue label={t('forms.poolMaxDatabases', {})} issue={issueFor(issues, 'defaultPoolMaxDatabases')}>
              {values.defaultPoolMaxDatabases}
            </SummaryValue>
          </SimpleGrid>
        </TitleCard>

        <TitleCard title={t('admin.wizard.reviewBackups', {})}>
          <SimpleGrid cols={{ base: 2, xl: 3 }}>
            <SummaryValue label={t('admin.nodeConfig.automatedBackups', {})}>
              {values.config.backups.enabled ? t('admin.wizard.yes', {}) : t('admin.wizard.no', {})}
            </SummaryValue>
            <SummaryValue label={t('admin.nodeConfig.backupStorageDriver', {})}>
              {values.config.backups.storageDriver.toUpperCase()}
            </SummaryValue>
            <SummaryValue label={t('admin.nodeConfig.backupInterval', {})}>
              {values.config.backups.intervalMinutes}
            </SummaryValue>
          </SimpleGrid>
        </TitleCard>
      </SimpleGrid>
    </Stack>
  );
}
