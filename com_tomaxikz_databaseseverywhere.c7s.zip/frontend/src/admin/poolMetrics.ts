export function poolMetricValue(value: number | null, sample: { state: string; fresh: boolean }): number | null {
  return sample.state === 'fresh' && sample.fresh && value !== null && Number.isFinite(value) ? value : null;
}
