export type CheckStepId = 'reach' | 'authenticate' | 'identity' | 'contract' | 'resources';
export type CheckStepStatus = 'passed' | 'warning' | 'failed' | 'skipped';

export interface CheckStep {
  id: CheckStepId;
  status: CheckStepStatus;
  message: string | null;
  hint: string | null;
}

export interface ConnectionCheckResult {
  ok: boolean;
  latencyMs: number | null;
  steps: CheckStep[];
  version: string | null;
  apiVersion: string | null;
}

const STEP_IDS: CheckStepId[] = ['reach', 'authenticate', 'identity', 'contract', 'resources'];
const STEP_STATUSES: CheckStepStatus[] = ['passed', 'warning', 'failed', 'skipped'];

export function parseConnectionCheck(value: unknown): ConnectionCheckResult | null {
  if (!isRecord(value) || !Array.isArray(value.steps)) return null;
  const steps = value.steps.flatMap((step): CheckStep[] => {
    if (!isRecord(step)) return [];
    const id = STEP_IDS.find((item) => item === step.id);
    const status = STEP_STATUSES.find((item) => item === step.status);
    if (!id || !status) return [];
    return [{ id, status, message: text(step.message), hint: text(step.hint) }];
  });
  if (!steps.length) return null;
  const system = isRecord(value.system) ? value.system : null;
  return {
    ok: value.ok === true,
    latencyMs: typeof value.latency_ms === 'number' ? value.latency_ms : null,
    steps,
    version: text(system?.version),
    apiVersion: text(system?.api_version),
  };
}

function text(value: unknown): string | null {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
