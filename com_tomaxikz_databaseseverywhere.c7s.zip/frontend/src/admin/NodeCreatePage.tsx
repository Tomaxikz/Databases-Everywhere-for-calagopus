import { faExternalLink } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import { AdminCan } from '@/elements/Can.tsx';
import AdminContentContainer from '@/elements/containers/AdminContentContainer.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import { FormEngine, useFormEngine } from '@/elements/form-engine/index.ts';
import Group from '@/elements/layout/Group.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import Anchor from '@/elements/typography/Anchor.tsx';
import { useToast } from '@/providers/ToastProvider.tsx';
import { useTranslations } from '@/providers/TranslationProvider.tsx';
import { createNode } from '../api/client.ts';
import { dbevQueryKeys } from '../api/queryKeys.ts';
import type { NodeCredentials, NodeRecord } from '../api/types.ts';
import translations from '../translations.ts';
import NodeCredentialsModal from './NodeCredentialsModal.tsx';
import NodeSetupReview from './NodeSetupReview.tsx';
import NodeSetupWizard from './NodeSetupWizard.tsx';
import {
  createNodeFormSchema,
  initialNodeFormValues,
  type NodeFormValues,
  nodeFormValidationOptions,
  toNodeInput,
} from './nodeForm.ts';
import { nodeFormMessages } from './nodeFormMessages.ts';
import {
  type NodeSettingsSectionId,
  nodeSettingsSections,
  sectionForPath,
  splitSectionFields,
} from './nodeSettingsSections.tsx';

const STEP_SECTIONS: NodeSettingsSectionId[] = ['general', 'resources', 'databases'];
const REVIEW_STEP = STEP_SECTIONS.length;

export default function NodeCreatePage() {
  const { t } = translations.useTranslations();
  const { t: tBase } = useTranslations();
  const { addToast } = useToast();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [credentials, setCredentials] = useState<NodeCredentials | null>(null);
  const [createdNode, setCreatedNode] = useState<NodeRecord | null>(null);

  const sections = useMemo(
    () => nodeSettingsSections({ editing: false, hasStoredSecrets: false, supportsArtifactPolicy: true }),
    [],
  );
  const schema = useMemo(() => createNodeFormSchema(nodeFormMessages()), []);
  const form = useFormEngine<NodeFormValues>('admin.databasesEverywhere.nodes.createOrUpdate', {
    schema,
    initialValues: initialNodeFormValues(),
    ...nodeFormValidationOptions,
  });

  const steps = [
    ...STEP_SECTIONS.map((id) => {
      const section = sections.find((item) => item.id === id)!;
      return { label: section.title, description: section.description };
    }),
    { label: t('manage.create.reviewLabel', {}), description: t('manage.create.reviewDescription', {}) },
  ];
  const stepFor = (path: string) => {
    const index = STEP_SECTIONS.indexOf(sectionForPath(sections, path));
    return index < 0 ? REVIEW_STEP : index;
  };

  const next = () => {
    const validation = form.validate();
    if (Object.keys(validation.errors).some((path) => stepFor(path) === activeStep)) {
      addToast(t('admin.wizard.stepValidationError', {}), 'error');
      return;
    }
    setActiveStep(Math.min(activeStep + 1, REVIEW_STEP));
  };

  const submit = async () => {
    const validation = form.validate();
    if (validation.hasErrors) {
      setActiveStep(Math.min(...Object.keys(validation.errors).map(stepFor)));
      addToast(t('admin.wizard.validationError', {}), 'error');
      return;
    }
    setLoading(true);
    try {
      const created = await createNode(toNodeInput(schema.parse(form.getValues())));
      await queryClient.invalidateQueries({ queryKey: dbevQueryKeys.adminNodes() });
      setCreatedNode(created.node);
      setCredentials(created.credentials);
      addToast(t('admin.nodeCreated', {}), 'success');
    } catch (error) {
      addToast(httpErrorToHuman(error), 'error');
    } finally {
      setLoading(false);
    }
  };

  const activeSection = sections.find((section) => section.id === STEP_SECTIONS[activeStep]);
  const fields = activeSection ? splitSectionFields(activeSection.fields, form.getValues()).main : [];

  return (
    <AdminContentContainer title={t('manage.create.title', {})} titleOrder={2}>
      <form
        onSubmit={(event) => {
          event.preventDefault();
          if (activeStep < REVIEW_STEP) next();
          else void submit();
        }}
      >
        <NodeSetupWizard
          steps={steps}
          active={activeStep}
          onStepChange={setActiveStep}
          navigationDisabled={loading}
          footer={
            <Group justify='space-between' wrap='wrap'>
              <Group gap='sm'>
                {activeStep > 0 && (
                  <Button
                    type='button'
                    variant='default'
                    disabled={loading}
                    onClick={() => setActiveStep(activeStep - 1)}
                  >
                    {tBase('common.button.back', {})}
                  </Button>
                )}
                <Anchor
                  href='https://github.com/Tomaxikz/DatabasesEverywhere'
                  target='_blank'
                  rel='noopener noreferrer'
                >
                  <Button type='button' variant='subtle' leftSection={<FontAwesomeIcon icon={faExternalLink} />}>
                    {tBase('common.button.viewDocumentation', {})}
                  </Button>
                </Anchor>
              </Group>
              {activeStep < REVIEW_STEP ? (
                <Button type='submit' disabled={loading}>
                  {tBase('common.button.continue', {})}
                </Button>
              ) : (
                <AdminCan action='databases-everywhere-nodes.create' cantSave>
                  <Button type='submit' loading={loading}>
                    {t('manage.create.submit', {})}
                  </Button>
                </AdminCan>
              )}
            </Group>
          }
        >
          {activeStep === 0 && (
            <Alert color='blue' mb='md'>
              {t('manage.create.laterHint', {})}
            </Alert>
          )}
          {activeStep === REVIEW_STEP ? (
            <NodeSetupReview values={form.values} />
          ) : (
            <Stack>
              <FormEngine form={form} fields={fields} />
            </Stack>
          )}
        </NodeSetupWizard>
      </form>
      <NodeCredentialsModal
        credentials={credentials}
        onClose={() => {
          setCredentials(null);
          if (createdNode) navigate(`/admin/databases-everywhere/${createdNode.uuid}`);
        }}
      />
    </AdminContentContainer>
  );
}
