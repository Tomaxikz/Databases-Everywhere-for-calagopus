import { Text } from '@mantine/core';
import type { UseFormReturnType } from '@mantine/form';
import { useQuery } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { z } from 'zod';
import { httpErrorToHuman } from '@/api/axios.ts';
import Alert from '@/elements/feedback/Alert.tsx';
import { insertFieldsAfter } from '@/elements/form-engine/index.ts';
import type { FieldDef } from '@/elements/form-engine/types.ts';
import NumberInput from '@/elements/input/NumberInput.tsx';
import Switch from '@/elements/input/Switch.tsx';
import Divider from '@/elements/layout/Divider.tsx';
import { getPanelNodeHostAvailability } from '../api/client.ts';
import { dbevQueryKeys } from '../api/queryKeys.ts';
import translations from '../translations.ts';
import { legacyDatabaseQuotaTarget, serverPlacementLimitVisibility } from './serverPlacementLimits.ts';

type FormValues = Record<string, unknown>;
type Mode = 'create' | 'update';

function record(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
}

function initialFlag(form: UseFormReturnType<FormValues>, key: string) {
  return record(form.getValues().featureLimits)[key] === true;
}

function ServerDatabaseLimits({ form, mode }: { form: UseFormReturnType<FormValues>; mode: Mode }) {
  const { t } = translations.useTranslations();
  const [nodeUuid, setNodeUuid] = useState(() => {
    const value = form.getValues().nodeUuid;
    return typeof value === 'string' ? value : '';
  });
  const [available, setAvailable] = useState(() => initialFlag(form, 'databasesEverywhereAvailable'));
  const [inUse, setInUse] = useState(() => initialFlag(form, 'databasesEverywhereInUse'));
  const initializedLegacyPlacementLimit = useRef(false);
  const [usePoolDefaults, setUsePoolDefaults] = useState(() => initialFlag(form, 'poolUseNodeDefaults'));
  form.watch('featureLimits.poolUseNodeDefaults', ({ value }) => setUsePoolDefaults(value === true));

  form.watch('nodeUuid', ({ value }) => {
    const next = typeof value === 'string' ? value : '';
    setNodeUuid(next);
    if (mode === 'create') setAvailable(false);
  });
  form.watch('featureLimits.databasesEverywhereAvailable', ({ value }) => setAvailable(value === true));
  form.watch('featureLimits.databasesEverywhereInUse', ({ value }) => setInUse(value === true));

  const validNodeUuid = z.uuid().safeParse(nodeUuid).success;
  const eligibility = useQuery({
    queryKey: dbevQueryKeys.panelNodeAvailability(nodeUuid),
    queryFn: () => getPanelNodeHostAvailability(nodeUuid),
    enabled: validNodeUuid,
  });

  useEffect(() => {
    if (mode !== 'create' || !eligibility.data) return;
    const visibility = serverPlacementLimitVisibility(eligibility.data);
    setAvailable(eligibility.data.available);
    if (initialFlag(form, 'databasesEverywhereAvailable') !== eligibility.data.available) {
      form.setFieldValue('featureLimits.databasesEverywhereAvailable', eligibility.data.available);
    }
    if (!eligibility.data.available) {
      const limits = record(form.getValues().featureLimits);
      for (const key of [
        'databaseCpuCores',
        'databaseMemoryMib',
        'databaseDiskMib',
        'databaseBackups',
        'maxDedicatedDatabases',
        'maxSharedDatabases',
      ]) {
        if (limits[key] !== 0) form.setFieldValue(`featureLimits.${key}`, 0);
      }
    } else if (!initializedLegacyPlacementLimit.current) {
      const limits = record(form.getValues().featureLimits);
      const legacyMaximum = Number(limits.databases);
      const dedicatedMaximum = Number(limits.maxDedicatedDatabases);
      const sharedMaximum = Number(limits.maxSharedDatabases);
      const legacyTarget = legacyDatabaseQuotaTarget(visibility);
      if (!visibility.dedicated && dedicatedMaximum !== 0) {
        form.setFieldValue('featureLimits.maxDedicatedDatabases', 0);
      }
      if (!visibility.shared && sharedMaximum !== 0) {
        form.setFieldValue('featureLimits.maxSharedDatabases', 0);
      }
      if (Number.isInteger(legacyMaximum) && legacyMaximum > 0) {
        if (legacyTarget === 'dedicated' && dedicatedMaximum === 0) {
          form.setFieldValue('featureLimits.maxDedicatedDatabases', legacyMaximum);
        } else if (legacyTarget === 'shared' && sharedMaximum === 0) {
          form.setFieldValue('featureLimits.maxSharedDatabases', legacyMaximum);
        }
      }
      initializedLegacyPlacementLimit.current = true;
    }
  }, [eligibility.data, mode]);

  if (mode === 'create' && validNodeUuid && eligibility.error) {
    return <Alert color='red'>{httpErrorToHuman(eligibility.error)}</Alert>;
  }

  const visible =
    mode === 'create'
      ? eligibility.data?.available === true
      : available ||
        inUse ||
        initialFlag(form, 'databasesEverywhereAvailable') ||
        initialFlag(form, 'databasesEverywhereInUse');
  if (!visible) return null;

  const placementVisibility =
    mode === 'create' || (eligibility.data?.available_deployment_modes?.length ?? 0) > 0
      ? serverPlacementLimitVisibility(eligibility.data)
      : { dedicated: true, shared: true };

  const numberField = (name: string) => ({
    key: form.key(name),
    ...form.getInputProps(name),
  });

  return (
    <div>
      <Divider label={t('forms.section', {})} labelPosition='left' />
      <Text size='xs' c='dimmed' mt='xs'>
        {t('forms.sectionDescription', {})}
      </Text>
      {placementVisibility.shared && (
        <>
          <Divider label={t('forms.poolDefaults', {})} labelPosition='left' mt='md' />
          <Text size='xs' c='dimmed'>
            {t('forms.poolDefaultsDescription', {})}
          </Text>
          <Switch
            mt='md'
            label={t('forms.poolUseNodeDefaults', {})}
            description={t('forms.poolUseNodeDefaultsDescription', {})}
            key={form.key('featureLimits.poolUseNodeDefaults')}
            {...form.getInputProps('featureLimits.poolUseNodeDefaults', { type: 'checkbox' })}
          />
          {!usePoolDefaults && (
            <div className='grid grid-cols-1 md:grid-cols-2 gap-4 mt-4'>
              <NumberInput
                label={t('forms.poolCpuCores', {})}
                min={0.01}
                max={1024}
                decimalScale={2}
                step={0.25}
                {...numberField('featureLimits.poolCpuCores')}
              />
              <NumberInput
                label={t('forms.poolMemoryMib', {})}
                min={1}
                max={1048576}
                step={1}
                {...numberField('featureLimits.poolMemoryMib')}
              />
              <NumberInput
                label={t('forms.poolDiskMib', {})}
                min={1}
                max={9007199254740991}
                step={1}
                {...numberField('featureLimits.poolDiskMib')}
              />
              <NumberInput
                label={t('forms.poolMaxDatabases', {})}
                min={1}
                max={1024}
                step={1}
                {...numberField('featureLimits.poolMaxDatabases')}
              />
            </div>
          )}
        </>
      )}
      <div className='grid grid-cols-1 md:grid-cols-2 gap-4 mt-4'>
        {placementVisibility.dedicated && (
          <NumberInput
            label={t('forms.maxDedicatedDatabases', {})}
            description={t('forms.maxDedicatedDatabasesDescription', {})}
            min={0}
            step={1}
            {...numberField('featureLimits.maxDedicatedDatabases')}
          />
        )}
        {placementVisibility.shared && (
          <NumberInput
            label={t('forms.maxSharedDatabases', {})}
            description={t('forms.maxSharedDatabasesDescription', {})}
            min={0}
            step={1}
            {...numberField('featureLimits.maxSharedDatabases')}
          />
        )}
        {placementVisibility.dedicated && (
          <NumberInput
            label={t('forms.cpu', {})}
            description={t('forms.inheritDescription', {})}
            min={0}
            max={1024}
            decimalScale={2}
            step={0.25}
            {...numberField('featureLimits.databaseCpuCores')}
          />
        )}
        {placementVisibility.dedicated && (
          <NumberInput
            label={t('forms.memory', {})}
            description={t('forms.inheritDescription', {})}
            min={0}
            max={1_048_576}
            step={128}
            {...numberField('featureLimits.databaseMemoryMib')}
          />
        )}
        <NumberInput
          label={t('forms.disk', {})}
          description={t('forms.inheritDescription', {})}
          min={0}
          step={256}
          {...numberField('featureLimits.databaseDiskMib')}
        />
        <NumberInput
          label={t('forms.backups', {})}
          description={t('forms.backupsDescription', {})}
          min={0}
          step={1}
          {...numberField('featureLimits.databaseBackups')}
        />
      </div>
    </div>
  );
}

const slot = (mode: Mode) => ({
  zodShape: {
    featureLimits: z.looseObject({
      databasesEverywhereAvailable: z.boolean(),
      databasesEverywhereInUse: z.boolean(),
      databaseCpuCores: z.number().min(0).max(1024),
      databaseMemoryMib: z.number().int().min(0).max(1_048_576),
      databaseDiskMib: z.number().int().min(0),
      databaseBackups: z.number().int().min(0),
      maxDedicatedDatabases: z.number().int().min(0),
      maxSharedDatabases: z.number().int().min(0),
      poolUseNodeDefaults: z.boolean(),
      poolCpuCores: z.number().min(0.01).max(1024),
      poolMemoryMib: z.number().int().min(1).max(1048576),
      poolDiskMib: z.number().int().min(1).max(9007199254740991),
      poolMaxDatabases: z.number().int().min(1).max(1024),
    }),
  },
  initialValues: {
    featureLimits: {
      databasesEverywhereAvailable: false,
      databasesEverywhereInUse: false,
      databaseCpuCores: 0,
      databaseMemoryMib: 0,
      databaseDiskMib: 0,
      databaseBackups: 0,
      maxDedicatedDatabases: 0,
      maxSharedDatabases: 0,
      poolUseNodeDefaults: mode === 'create',
      poolCpuCores: 1,
      poolMemoryMib: 1024,
      poolDiskMib: 16384,
      poolMaxDatabases: 8,
    },
  },
  transform: (current: FieldDef<FormValues>[]) =>
    insertFieldsAfter(current, 'featureLimits.databases', {
      type: 'custom',
      name: 'featureLimits.databasesEverywhereSection',
      colSpan: 'full',
      render: (form) => <ServerDatabaseLimits form={form} mode={mode} />,
    }),
});

export const createServerLimitsFormSlot = slot('create');
export const updateServerLimitsFormSlot = slot('update');
