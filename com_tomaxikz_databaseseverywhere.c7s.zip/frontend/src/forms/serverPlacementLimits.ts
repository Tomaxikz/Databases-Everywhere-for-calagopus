import type { DeploymentMode, PanelNodeHostAvailability } from '../api/types.ts';

export interface ServerPlacementLimitVisibility {
  dedicated: boolean;
  shared: boolean;
}

export function serverPlacementLimitVisibility(
  availability: PanelNodeHostAvailability | undefined,
): ServerPlacementLimitVisibility {
  const modes = availability?.available_deployment_modes;
  if (!modes) return { dedicated: true, shared: true };
  return {
    dedicated: modes.includes('dedicated'),
    shared: modes.includes('shared'),
  };
}

export function legacyDatabaseQuotaTarget(visibility: ServerPlacementLimitVisibility): DeploymentMode | null {
  if (visibility.dedicated) return 'dedicated';
  if (visibility.shared) return 'shared';
  return null;
}
