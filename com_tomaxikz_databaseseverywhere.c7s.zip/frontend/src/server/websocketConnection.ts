import { isExpectedDaemonRestart, ReconnectController } from './websocketReconnect.ts';

export type SocketConnectionState = 'connecting' | 'connected' | 'reconnecting' | 'unavailable';
export interface SocketMessageAction {
  accepted?: boolean;
  reconnect?: boolean;
  stop?: boolean;
  error?: string;
}
export interface SocketCredentials {
  url: string;
  token: string;
  expires_at_unix: number;
}
export type DbevSocket = Pick<WebSocket, 'onopen' | 'onmessage' | 'onerror' | 'onclose' | 'close'>;
export interface SocketRuntime {
  now: () => number;
  schedule: (callback: () => void, delay: number) => number;
  cancel: (timer: number) => void;
  open: (url: string, protocols: string[]) => DbevSocket;
  random: () => number;
}

export type SocketIssue =
  | 'setupTimeout'
  | 'snapshotTimeout'
  | 'tokenExpired'
  | 'invalidUpdate'
  | 'sequenceGap'
  | 'staleMonitoring'
  | 'unreachable'
  | 'closed';

interface Options {
  message: (issue: SocketIssue) => string;
  mint: (signal: AbortSignal) => Promise<SocketCredentials>;
  monitor: boolean;
  onMessage: (payload: Record<string, unknown>, receivedAt: number) => SocketMessageAction | void;
  onState: (state: SocketConnectionState) => void;
  onError: (error: string | null) => void;
  onAttempt?: () => void;
  onDisconnected?: (receivedAt: number) => void;
  onReconnected?: () => void | Promise<void>;
  classifyError: (cause: unknown) => { retry: boolean; message: string };
}

const browserRuntime: SocketRuntime = {
  now: () => Date.now(),
  schedule: (callback, delay) => window.setTimeout(callback, delay),
  cancel: (timer) => window.clearTimeout(timer),
  open: (url, protocols) => new WebSocket(url, protocols),
  random: () => Math.random(),
};

/** One lifecycle per socket: fresh credentials, bounded setup, expiry, and one retry timer. */
export function connectDbevSocket(options: Options, runtime: SocketRuntime = browserRuntime): () => void {
  let disposed = false;
  let terminal = false;
  let generation = 0;
  let reconnects = 0;
  let hasConnected = false;
  let socket: DbevSocket | null = null;
  let request: AbortController | null = null;
  const timers = new Set<number>();
  const reconnect = new ReconnectController(runtime.schedule, runtime.cancel);

  const later = (callback: () => void, delay: number) => {
    const timer = runtime.schedule(() => {
      timers.delete(timer);
      callback();
    }, delay);
    timers.add(timer);
    return timer;
  };
  const cancelTimer = (timer: number | undefined) => {
    if (timer === undefined) return;
    runtime.cancel(timer);
    timers.delete(timer);
  };
  const closeAttempt = () => {
    generation += 1;
    request?.abort();
    request = null;
    for (const timer of timers) runtime.cancel(timer);
    timers.clear();
    const previous = socket;
    socket = null;
    if (previous) {
      previous.onopen = previous.onmessage = previous.onerror = previous.onclose = null;
      previous.close();
    }
  };
  const retry = (message: string | null) => {
    if (disposed || terminal) return;
    closeAttempt();
    options.onError(message);
    options.onDisconnected?.(runtime.now());
    options.onState('reconnecting');
    const next = reconnects + 1;
    if (reconnect.schedule(next, () => void connect(), runtime.random)) reconnects = next;
  };

  const connect = async () => {
    if (disposed || terminal) return;
    const attempt = ++generation;
    const current = () => !disposed && !terminal && generation === attempt;
    request = new AbortController();
    options.onState(reconnects ? 'reconnecting' : 'connecting');
    options.onAttempt?.();
    // Includes token minting and the WebSocket handshake, not just an already-open socket.
    let deadline: number | undefined = later(() => retry(options.message('setupTimeout')), 15_000);
    let accepted = false;
    try {
      const credentials = await options.mint(request.signal);
      if (!current()) return;
      request = null;
      const remaining = credentials.expires_at_unix * 1000 - runtime.now();
      if (!credentials.token || !Number.isFinite(remaining) || remaining <= 0) {
        retry(options.message('tokenExpired'));
        return;
      }
      // Never put the JWT in a URL. Instance and pool scopes are selected by the caller's backend endpoint.
      const active = runtime.open(credentials.url, ['dbe.jwt', credentials.token]);
      socket = active;
      later(() => retry(null), Math.max(1, remaining - Math.min(5_000, remaining / 2)));
      active.onopen = () => {
        if (!current()) return;
        cancelTimer(deadline);
        deadline = later(() => retry(options.message('snapshotTimeout')), 60_000);
      };
      active.onmessage = (event) => {
        if (!current() || typeof event.data !== 'string') return;
        let payload: unknown;
        try {
          payload = JSON.parse(event.data);
        } catch {
          return;
        }
        if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return;
        let action: SocketMessageAction | void;
        try {
          action = options.onMessage(payload as Record<string, unknown>, runtime.now());
        } catch {
          retry(options.message('invalidUpdate'));
          return;
        }
        if (!current()) return;
        if (action?.stop) {
          terminal = true;
          closeAttempt();
          reconnect.cancel();
          options.onError(action.error ?? null);
          options.onState('unavailable');
          return;
        }
        if (action?.reconnect) {
          retry(action.error ?? options.message('sequenceGap'));
          return;
        }
        // Partial batches, duplicates and unrelated events are not fresh snapshots.
        if (action?.accepted !== true) return;
        cancelTimer(deadline);
        deadline = options.monitor ? later(() => retry(options.message('staleMonitoring')), 60_000) : undefined;
        options.onError(null);
        options.onState('connected');
        if (!accepted) {
          accepted = true;
          later(() => {
            if (current()) reconnects = 0;
          }, 10_000);
          if (hasConnected)
            void Promise.resolve()
              .then(() => {
                if (current()) return options.onReconnected?.();
              })
              .catch(() => undefined);
          hasConnected = true;
        }
      };
      active.onerror = () => {
        if (current()) retry(options.message('unreachable'));
      };
      active.onclose = (event) => {
        if (current()) retry(isExpectedDaemonRestart(event.code, event.reason) ? null : options.message('closed'));
      };
    } catch (cause) {
      if (!current()) return;
      const error = options.classifyError(cause);
      if (error.retry) retry(error.message);
      else {
        terminal = true;
        closeAttempt();
        options.onError(error.message);
        options.onState('unavailable');
      }
    }
  };
  void connect();
  return () => {
    disposed = true;
    reconnect.cancel();
    closeAttempt();
  };
}
