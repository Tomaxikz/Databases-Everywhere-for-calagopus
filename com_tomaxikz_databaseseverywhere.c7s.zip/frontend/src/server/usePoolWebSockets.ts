import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import { poolReportSchema } from '../api/poolSchemas.ts';
import { mintPoolWebSocketToken } from '../api/sharedPools.ts';
import type { DatabaseInstallProgress, DbevSharedPool } from '../api/types.ts';
import translations from '../translations.ts';
import { type DatabaseLogChunk, type DatabaseLogMessage, LogStreamBuffer } from './logStreamBuffer.ts';
import { PoolMonitoringAssembler, type PoolMonitoringMessage } from './poolMonitoringAssembler.ts';
import { appendPoolSample, type PoolMonitoringSample } from './poolMonitoringSamples.ts';
import { socketSetupCanRetry } from './socketStatus.ts';
import { connectDbevSocket, type SocketConnectionState, type SocketIssue } from './websocketConnection.ts';

export type PoolConnectionState = SocketConnectionState;

function errorText(value: unknown): string | null {
  if (typeof value === 'string') return value.trim() || null;
  if (!value || typeof value !== 'object') return null;
  const record = value as Record<string, unknown>;
  const message = errorText(record.message ?? record.error ?? record.detail);
  return message ? [message, record.code, record.error_id].filter((v) => typeof v === 'string').join(' · ') : null;
}

function usePoolSocket({
  server,
  runtimeId,
  channel,
  enabled,
  onMessage,
  onDisconnect,
  onAttempt,
  reconnectKey,
}: {
  server: string;
  runtimeId: string;
  channel: 'monitor' | 'logs';
  enabled: boolean;
  onMessage: (message: Record<string, unknown>) => {
    accepted?: boolean;
    reconnect?: boolean;
    stop?: boolean;
    error?: string;
  };
  onDisconnect?: (receivedAt: number) => void;
  onAttempt?: () => void;
  reconnectKey: number;
}) {
  const { t } = translations.useTranslations();
  const describeIssue = useRef((issue: SocketIssue) => t(`websocket.${issue}`, {}));
  const [state, setState] = useState<PoolConnectionState>(enabled ? 'connecting' : 'unavailable');
  const [error, setError] = useState<string | null>(null);
  const callback = useRef(onMessage);
  const disconnect = useRef(onDisconnect);
  const starting = useRef(onAttempt);

  // Keep live sockets stable while publishing only committed callbacks.
  useLayoutEffect(() => {
    describeIssue.current = (issue) => t(`websocket.${issue}`, {});
    callback.current = onMessage;
    disconnect.current = onDisconnect;
    starting.current = onAttempt;
  }, [onMessage, onDisconnect, onAttempt, t]);

  useEffect(() => {
    if (!enabled || !server || !runtimeId) {
      setState('unavailable');
      setError(null);
      return;
    }
    return connectDbevSocket({
      message: (issue) => describeIssue.current(issue),
      mint: (signal) => mintPoolWebSocketToken(server, runtimeId, channel, signal),
      monitor: channel === 'monitor',
      onMessage: (payload) => callback.current(payload),
      onState: setState,
      onError: setError,
      onAttempt: () => starting.current?.(),
      onDisconnected: (receivedAt) => disconnect.current?.(receivedAt),
      classifyError: (cause) => ({
        message: httpErrorToHuman(cause),
        retry: socketSetupCanRetry(cause),
      }),
    });
  }, [channel, enabled, reconnectKey, runtimeId, server]);

  return { state, error };
}

export function usePoolLiveOverview({
  server,
  runtimeId,
  monitoringEnabled,
  logsEnabled,
}: {
  server: string;
  runtimeId: string;
  monitoringEnabled: boolean;
  logsEnabled: boolean;
}) {
  const [pool, setPool] = useState<DbevSharedPool | null>(null);
  const [samples, setSamples] = useState<PoolMonitoringSample[]>([]);
  const [progress, setProgress] = useState<DatabaseInstallProgress | null>(null);
  const [logs, setLogs] = useState<DatabaseLogChunk[]>([]);
  const [monitorKey, setMonitorKey] = useState(0);
  const [logKey, setLogKey] = useState(0);
  const reconnectMonitoring = useCallback(() => {
    setPool(null);
    setProgress(null);
    setSamples((current) => appendPoolSample(current, { kind: 'gap', receivedAt: Date.now(), pool: null }));
    setMonitorKey((key) => key + 1);
  }, []);
  const reconnectLogs = useCallback(() => setLogKey((key) => key + 1), []);
  const assembler = useRef(new PoolMonitoringAssembler(runtimeId));
  const logBuffer = useRef(new LogStreamBuffer());

  useEffect(() => {
    assembler.current = new PoolMonitoringAssembler(runtimeId);
    logBuffer.current.reset();
    setPool(null);
    setSamples([]);
    setProgress(null);
    setLogs([]);
  }, [runtimeId, server]);

  const monitoring = usePoolSocket({
    server,
    runtimeId,
    channel: 'monitor',
    reconnectKey: monitorKey,
    enabled: monitoringEnabled,
    onAttempt: () => {
      assembler.current.reset();
      setPool(null);
      setProgress(null);
    },
    onDisconnect: (receivedAt) => {
      assembler.current.reset();
      setPool(null);
      setProgress(null);
      setSamples((current) => appendPoolSample(current, { kind: 'gap', receivedAt, pool: null }));
    },
    onMessage: (raw) => {
      if (raw.type !== 'pool_stats') return { accepted: false };
      const parsedPool = poolReportSchema.safeParse(raw.pool);
      if (!parsedPool.success)
        return { accepted: false, reconnect: true, error: 'The pool stream sent an invalid pool snapshot.' };
      const result = assembler.current.push({ ...raw, pool: parsedPool.data } as PoolMonitoringMessage);
      if (result.kind === 'ignored') return { accepted: false };
      if (result.kind === 'reconnect') return { accepted: false, reconnect: true, error: result.reason };
      setPool(result.snapshot.pool);
      setProgress(result.snapshot.install_progress[0] ?? null);
      setSamples((current) =>
        appendPoolSample(current, { kind: 'stats', receivedAt: Date.now(), pool: result.snapshot.pool }),
      );
      return { accepted: true };
    },
  });

  const logStream = usePoolSocket({
    server,
    runtimeId,
    channel: 'logs',
    reconnectKey: logKey,
    enabled: logsEnabled,
    onAttempt: () => {
      logBuffer.current.reset();
      setLogs([]);
    },
    onMessage: (raw) => {
      const message = raw as DatabaseLogMessage;
      if (message.type !== 'logs' || message.runtime_id !== runtimeId) return { accepted: false };
      const result = logBuffer.current.apply(message);
      if (result.kind === 'ignored') return { accepted: false };
      if (result.kind === 'reconnect') return { accepted: false, reconnect: true, error: result.reason };
      setLogs(logBuffer.current.snapshot());
      if (result.kind === 'ended') return { stop: true, error: errorText(result.error) ?? undefined };
      return { accepted: true };
    },
  });

  return { pool, samples, progress, logs, monitoring, logStream, reconnectMonitoring, reconnectLogs };
}
