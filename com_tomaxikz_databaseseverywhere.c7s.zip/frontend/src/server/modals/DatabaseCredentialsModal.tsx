import Button from '@/elements/buttons/Button.tsx';
import { Modal, ModalFooter } from '@/elements/modals/Modal.tsx';
import type { DatabaseRecord } from '../../api/types.ts';
import translations from '../../translations.ts';
import { DatabaseConnectionFields } from '../components/DatabaseConnectionDetails.tsx';

export default function DatabaseCredentialsModal({
  database,
  opened,
  onClose,
}: {
  database: DatabaseRecord;
  opened: boolean;
  onClose: () => void;
}) {
  const { t } = translations.useTranslations();
  return (
    <Modal opened={opened} onClose={onClose} title={t('server.credentials', {})}>
      <DatabaseConnectionFields database={database} />
      <ModalFooter>
        <Button variant='default' onClick={onClose}>
          {t('common.close', {})}
        </Button>
      </ModalFooter>
    </Modal>
  );
}
