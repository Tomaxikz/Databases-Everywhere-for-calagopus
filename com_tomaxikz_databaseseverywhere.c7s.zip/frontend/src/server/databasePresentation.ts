import type { DatabaseMonitoringInstance, DatabaseRecord } from '../api/types.ts';

export function matchesDatabaseSearch(database: DatabaseRecord, search: string) {
  const needle = search.trim().toLowerCase();
  return (
    !needle ||
    [
      database.uuid,
      database.display_name,
      database.protocol_label,
      database.public_host,
      database.database_name,
      database.username,
    ].some((value) => value.toLowerCase().includes(needle))
  );
}

const finite = (value: unknown): number | null =>
  typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : null;
const text = (value: string | null | undefined) => (value?.trim() ? value : null);

export function databaseConnectionValues(database: DatabaseRecord, canReadSecrets: boolean) {
  return {
    database: text(database.database_name),
    username: text(database.username),
    host: text(database.public_host),
    port: database.public_port > 0 ? String(database.public_port) : null,
    password: canReadSecrets ? text(database.password) : null,
    uri: canReadSecrets ? text(database.connection_uri) : null,
  };
}

export function databaseSummaryValues(database: DatabaseRecord, instance: DatabaseMonitoringInstance | null) {
  // Instance telemetry is currently unavailable to shared children. Never display
  // a parent's values (even if accidentally supplied) as this database's usage.
  const own =
    database.deployment_mode === 'dedicated' &&
    instance?.instance_id === database.uuid &&
    instance.deployment_mode !== 'shared' &&
    !['shared_pool', 'shared_tenant'].includes(instance.resource_scope ?? '')
      ? instance
      : null;
  return {
    cpuPercent: finite(own?.resources?.cpu.usage_percent),
    memoryBytes: finite(own?.resources?.memory.usage_bytes),
    diskBytes: finite(own?.resources?.disk.used_bytes),
    connections: finite(own?.activity?.connections),
    accepted: finite(own?.activity?.accepted ?? own?.activity?.forwarded),
    rejected: finite(own?.activity?.rejected),
    rxBytes: finite(own?.activity?.rx_bytes),
    txBytes: finite(own?.activity?.tx_bytes),
    activitySource: own?.activity?.source ?? null,
    activitySampledAt: finite(own?.activity?.sampled_at_unix),
  };
}
