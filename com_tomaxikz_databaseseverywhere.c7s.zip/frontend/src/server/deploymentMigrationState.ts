function nestedRecord(value: unknown, key: string): Record<string, unknown> | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const nested = (value as Record<string, unknown>)[key];
  return nested && typeof nested === 'object' && !Array.isArray(nested) ? (nested as Record<string, unknown>) : null;
}

export function deploymentMigrationStatus(value: unknown): string | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const record = value as Record<string, unknown>;
  const result = nestedRecord(record, 'result');
  const status =
    record.status ??
    nestedRecord(record, 'migration')?.status ??
    result?.status ??
    nestedRecord(result, 'migration')?.status ??
    nestedRecord(record, 'operation')?.status;
  return typeof status === 'string' ? status : null;
}

export function deploymentMigrationStage(value: unknown): string | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const record = value as Record<string, unknown>;
  const result = nestedRecord(record, 'result');
  const stage =
    record.stage ??
    nestedRecord(record, 'migration')?.stage ??
    result?.stage ??
    nestedRecord(result, 'migration')?.stage ??
    nestedRecord(record, 'operation')?.stage;
  return typeof stage === 'string' ? stage : null;
}

export function deploymentMigrationRequiresReconciliation(value: unknown): boolean {
  const stage = deploymentMigrationStage(value);
  return stage === 'submission_outcome_unknown' || stage === 'status_location_unavailable';
}
