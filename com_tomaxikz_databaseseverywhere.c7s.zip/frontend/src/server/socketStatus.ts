import { isAxiosError } from 'axios';
import type { SocketConnectionState } from './websocketConnection.ts';

export function socketSetupCanRetry(cause: unknown): boolean {
  if (!isAxiosError(cause)) return false;
  const status = cause.response?.status;
  return status === undefined || status === 408 || status === 429 || status >= 500;
}

export function socketAlertState(state: SocketConnectionState, error: string | null) {
  if (!error || state === 'connected') return null;
  return {
    title: state,
    color: state === 'unavailable' ? 'red' : 'yellow',
    automaticRetry: state !== 'unavailable',
  } as const;
}
