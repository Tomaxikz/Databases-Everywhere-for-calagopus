export interface DatabaseActionPolicy {
  start: boolean;
  stop: boolean;
  restart: boolean;
  kill: boolean;
  resetCredential: boolean;
  updateImage: boolean;
  useConnection: boolean;
  reconcile: boolean;
  inspect: boolean;
  delete: boolean;
}

export function databaseActionPolicy(
  status: string,
  options: { scannerRestartBlocked?: boolean; deploymentMode?: 'dedicated' | 'shared'; migrationActive?: boolean } = {},
): DatabaseActionPolicy {
  const running = status === 'running';
  const stopped = status === 'stopped';
  const quarantined = status === 'quarantined';
  const transitional = ['creating', 'booting', 'deleting'].includes(status);

  const policy: DatabaseActionPolicy = {
    start: stopped,
    stop: running,
    restart: running,
    kill: running || status === 'booting',
    resetCredential: running,
    updateImage: running,
    useConnection: running,
    reconcile: !transitional,
    inspect: true,
    delete: status !== 'deleting',
    ...(quarantined
      ? {
          start: false,
          stop: false,
          restart: false,
          kill: false,
          resetCredential: false,
          updateImage: false,
          useConnection: false,
          reconcile: true,
        }
      : {}),
  };

  if (options.scannerRestartBlocked) {
    policy.start = false;
    policy.restart = false;
  }

  if (options.deploymentMode === 'shared') {
    policy.start = status === 'stopped' || status === 'disabled';
    policy.stop = status === 'running' || status === 'enabled';
    policy.restart = false;
    policy.kill = false;
    policy.updateImage = false;
  }

  if (options.migrationActive) {
    policy.start = false;
    policy.stop = false;
    policy.restart = false;
    policy.kill = false;
    policy.resetCredential = false;
    policy.updateImage = false;
    policy.useConnection = false;
    policy.reconcile = false;
    policy.delete = false;
  }

  return policy;
}
