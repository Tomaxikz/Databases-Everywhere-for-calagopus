import type { DatabaseInstallProgress, DatabaseMonitoringInstance } from '../api/types.ts';

export interface MonitoringBatch {
  type?: string;
  sequence?: number;
  sampled_at_unix?: number;
  batch_index?: number;
  batch_count?: number;
  instances?: DatabaseMonitoringInstance[];
  progress_reset?: boolean;
  install_progress_removed?: string[];
  install_progress?: DatabaseInstallProgress[];
}

export interface CompleteMonitoringSnapshot {
  type: 'stats';
  sequence: number;
  sampled_at_unix: number | undefined;
  instances: DatabaseMonitoringInstance[];
  install_progress: DatabaseInstallProgress[];
}

export type MonitoringAssemblyResult =
  | { kind: 'pending' | 'ignored' }
  | { kind: 'reconnect'; reason: string }
  | { kind: 'complete'; snapshot: CompleteMonitoringSnapshot };

interface PendingSequence {
  sequence: number;
  count: number;
  sampledAt: number | undefined;
  batches: Map<number, MonitoringBatch>;
}

function integer(value: unknown): number | null {
  return typeof value === 'number' && Number.isSafeInteger(value) ? value : null;
}

function sampleTime(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}

/** Assembles every DBEV batch and maintains the delta-based progress cache. */
export class MonitoringSnapshotAssembler {
  private completedSequence: number | null = null;
  private pending: PendingSequence | null = null;
  private readonly progress = new Map<string, DatabaseInstallProgress>();

  reset() {
    this.completedSequence = null;
    this.pending = null;
    this.progress.clear();
  }

  push(message: MonitoringBatch): MonitoringAssemblyResult {
    if (message.type !== 'stats') return { kind: 'ignored' };
    if (
      !Array.isArray(message.instances) ||
      (message.install_progress !== undefined &&
        (!Array.isArray(message.install_progress) ||
          message.install_progress.some((item) => !item || typeof item.instance_id !== 'string'))) ||
      (message.install_progress_removed !== undefined &&
        (!Array.isArray(message.install_progress_removed) ||
          message.install_progress_removed.some((id) => typeof id !== 'string')))
    ) {
      return { kind: 'reconnect', reason: 'The monitoring stream sent an invalid delta.' };
    }
    const sequence = integer(message.sequence);
    const batchIndex = integer(message.batch_index);
    const batchCount = integer(message.batch_count);
    if (
      sequence === null ||
      sequence < 1 ||
      batchIndex === null ||
      batchCount === null ||
      batchCount < 1 ||
      batchCount > 4096 ||
      batchIndex < 0 ||
      batchIndex >= batchCount
    ) {
      return { kind: 'reconnect', reason: 'The monitoring stream sent invalid batch metadata.' };
    }
    if (this.completedSequence !== null && sequence <= this.completedSequence) return { kind: 'ignored' };
    if (this.completedSequence !== null && sequence !== this.completedSequence + 1) {
      return { kind: 'reconnect', reason: 'The monitoring stream skipped a sequence.' };
    }

    const sampledAt = sampleTime(message.sampled_at_unix);
    if (!this.pending) {
      this.pending = { sequence, count: batchCount, sampledAt, batches: new Map() };
    } else if (sequence !== this.pending.sequence) {
      return { kind: 'reconnect', reason: 'The monitoring stream advanced before completing a sequence.' };
    } else if (this.pending.count !== batchCount || this.pending.sampledAt !== sampledAt) {
      return { kind: 'reconnect', reason: 'The monitoring stream changed batch metadata mid-sequence.' };
    }

    if (this.pending.batches.has(batchIndex)) return { kind: 'ignored' };
    this.pending.batches.set(batchIndex, message);
    if (this.pending.batches.size !== this.pending.count) return { kind: 'pending' };

    const ordered: MonitoringBatch[] = [];
    for (let index = 0; index < this.pending.count; index += 1) {
      const batch = this.pending.batches.get(index);
      if (!batch) return { kind: 'reconnect', reason: 'The monitoring stream omitted a batch.' };
      ordered.push(batch);
    }

    if (this.completedSequence === null && !ordered.some((batch) => batch.progress_reset === true)) {
      return { kind: 'reconnect', reason: 'The first complete monitoring sequence must reset progress.' };
    }
    const instances = new Map<string, DatabaseMonitoringInstance>();
    for (const item of ordered.flatMap((batch) => batch.instances ?? [])) instances.set(item.instance_id, item);

    if (ordered.some((batch) => batch.progress_reset === true)) this.progress.clear();
    for (const id of ordered.flatMap((batch) => batch.install_progress_removed ?? [])) this.progress.delete(id);
    for (const item of ordered.flatMap((batch) => batch.install_progress ?? [])) {
      this.progress.set(item.instance_id, item);
    }

    const snapshot: CompleteMonitoringSnapshot = {
      type: 'stats',
      sequence,
      sampled_at_unix: this.pending.sampledAt,
      instances: [...instances.values()],
      install_progress: [...this.progress.values()],
    };
    this.completedSequence = sequence;
    this.pending = null;
    return { kind: 'complete', snapshot };
  }
}
