export type LogLineLevel = 'error' | 'warning' | 'muted' | 'normal';

const ERROR = /\b(PANIC|FATAL|ERROR|CRITICAL|EMERG|ALERT)\b|<(Error|Fatal|Critical)>|"s":"[EF]"/;
const WARNING = /\b(WARNING|WARN)\b|\[Warning\]|<Warning>|"s":"W"/;
const MUTED = /\b(DETAIL|HINT|STATEMENT|CONTEXT|DEBUG\d?|TRACE)\b|<(Debug|Trace)>|"s":"D\d?"/;

/** Picks a color for one log line from the severity word the engine wrote, not from the output stream. */
export function logLineLevel(line: string): LogLineLevel {
  if (ERROR.test(line)) return 'error';
  if (WARNING.test(line)) return 'warning';
  if (MUTED.test(line)) return 'muted';
  return 'normal';
}

export const LOG_LINE_COLORS: Record<LogLineLevel, string | undefined> = {
  error: 'var(--mantine-color-red-4)',
  warning: 'var(--mantine-color-yellow-4)',
  muted: 'var(--mantine-color-dimmed)',
  normal: undefined,
};
