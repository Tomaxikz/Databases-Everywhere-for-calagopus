import { faArrowsRotate } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Group, Stack, Text, Tooltip } from '@mantine/core';
import { useQueryClient } from '@tanstack/react-query';
import { type ReactNode, useCallback, useState } from 'react';
import { createPortal } from 'react-dom';
import { httpErrorToHuman } from '@/api/axios.ts';
import ActionIcon from '@/elements/buttons/ActionIcon.tsx';
import Button from '@/elements/buttons/Button.tsx';
import { ServerCan } from '@/elements/Can.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import { useServerCan } from '@/plugins/usePermissions.ts';
import { useToast } from '@/providers/ToastProvider.tsx';
import { normalizeDatabaseActivity } from '../api/activityHistory.ts';
import { getDatabaseStatus, powerDatabase } from '../api/client.ts';
import { type DbevMutationFailure, dbevMutationFailure } from '../api/mutationErrors.ts';
import type { DatabaseInstallProgress, DatabaseList, DatabasePowerAction, DatabaseRecord } from '../api/types.ts';
import translations from '../translations.ts';
import DatabaseActivityPanel from './components/DatabaseActivityPanel.tsx';
import DatabaseLiveLogs from './components/DatabaseLiveLogs.tsx';
import DatabaseLiveStats from './components/DatabaseLiveStats.tsx';
import DatabaseSummaryStats from './components/DatabaseSummaryStats.tsx';
import DeploymentMigrationPanel from './components/DeploymentMigrationPanel.tsx';
import DiskRestartBlockedAlert from './components/DiskRestartBlockedAlert.tsx';
import LiveConnectionAlert from './components/LiveConnectionAlert.tsx';
import MutationFailureAlert from './components/MutationFailureAlert.tsx';
import { databaseActionPolicy } from './databaseActionPolicy.ts';
import { databasesEverywhereQueryKey } from './databaseQuery.ts';
import { useDatabaseLiveOverview } from './useDatabaseWebSockets.ts';

interface Props {
  server: string;
  database: DatabaseRecord;
  onChanged: () => void;
  onDeleted: () => void;
  overviewActive: boolean;
  headerActions: HTMLElement | null;
  children: (overviewContent: ReactNode, advancedContent: ReactNode, activityContent: ReactNode) => ReactNode;
}

export default function DatabaseOverview({
  server,
  database,
  onChanged,
  overviewActive,
  headerActions,
  children,
}: Props) {
  const { t } = translations.useTranslations();
  const { addToast } = useToast();
  const queryClient = useQueryClient();
  const canReadLogs = useServerCan('databases-everywhere.logs');
  const [action, setAction] = useState<string | null>(null);
  const [failure, setFailure] = useState<DbevMutationFailure | null>(null);
  const [checkingState, setCheckingState] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const synchronizeStatus = useCallback(
    (status: string) => {
      queryClient.setQueryData<DatabaseList>(databasesEverywhereQueryKey(server), (current) => {
        if (!current) return current;
        const index = current.databases.findIndex((item) => item.uuid === database.uuid);
        if (index < 0 || current.databases[index].status === status) return current;
        const databases = [...current.databases];
        databases[index] = { ...databases[index], status };
        return { ...current, databases };
      });

      if (['running', 'stopped', 'failed', 'quarantined'].includes(status) && status !== database.status) {
        void getDatabaseStatus(server, database.uuid).catch(() => undefined);
      }
    },
    [database.status, database.uuid, queryClient, server],
  );
  const live = useDatabaseLiveOverview({
    server,
    database: database.uuid,
    logsEnabled: overviewActive && canReadLogs && database.deployment_mode === 'dedicated',
    monitoringEnabled: database.deployment_mode === 'dedicated',
    onStatusChange: synchronizeStatus,
  });

  const run = async (name: string, operation: () => Promise<unknown>, success = t('server.operationQueued', {})) => {
    if (!database.mutations_allowed) return;
    setAction(name);
    setFailure(null);
    return await (async () => {
      try {
        await operation();
        addToast(success, 'success');
        onChanged();
      } catch (error) {
        const nextFailure = dbevMutationFailure(error, httpErrorToHuman(error));
        setFailure(nextFailure);
        if (nextFailure.requiresReconciliation) onChanged();
        if (!nextFailure.retryable) addToast(nextFailure.message, 'error');
      }
    })().finally(() => {
      setAction(null);
    });
  };

  const runPower = (power: DatabasePowerAction) =>
    run(power, async () => {
      const result = await powerDatabase(server, database.uuid, power);
      if (power === 'start' || power === 'restart') live.reconnectLogs();
      return result;
    });
  const refresh = async () => {
    if (database.deployment_mode === 'dedicated') {
      live.reconnectMonitoring();
      if (overviewActive && canReadLogs) live.reconnectLogs();
    }
    setRefreshing(true);
    return getDatabaseStatus(server, database.uuid)
      .then((current) => {
        if (current.status) synchronizeStatus(current.status);
        onChanged();
      })
      .catch((error) => addToast(httpErrorToHuman(error), 'error'))
      .finally(() => setRefreshing(false));
  };
  const status = live.instance?.status || database.status;
  const disk = live.instance?.resources?.disk;
  const scannerRestartBlocked =
    disk?.scanner_restart_blocked ?? database.metadata.disk_scanner_restart_blocked === true;
  const policy = databaseActionPolicy(status, {
    scannerRestartBlocked,
    deploymentMode: database.deployment_mode,
    migrationActive: database.migration_active,
  });
  const persistedProgress = database.metadata.creation_progress ?? database.metadata.progress;
  const storedProgress =
    persistedProgress && typeof persistedProgress === 'object' ? (persistedProgress as DatabaseInstallProgress) : null;
  const activeProgress = live.monitoring.state === 'unavailable' ? storedProgress : live.progress;
  const showStart = policy.start;
  const showStop = policy.stop;
  const showRestart = policy.restart;
  const showKill = database.deployment_mode === 'dedicated' && policy.kill;
  const showPowerControls = showStart || showStop || showRestart || showKill;
  const progressDone =
    !!activeProgress &&
    activeProgress.status !== 'failed' &&
    typeof activeProgress.percent === 'number' &&
    activeProgress.percent >= 100;

  const headerControls = (
    <>
      <Tooltip
        label={
          database.deployment_mode === 'shared' ? t('server.refreshStatus', {}) : t('server.refreshMonitoring', {})
        }
      >
        <ActionIcon
          variant='default'
          size='input-sm'
          loading={refreshing}
          onClick={() => void refresh()}
          aria-label={
            database.deployment_mode === 'shared' ? t('server.refreshStatus', {}) : t('server.refreshMonitoring', {})
          }
        >
          <FontAwesomeIcon icon={faArrowsRotate} />
        </ActionIcon>
      </Tooltip>
      {showPowerControls && (
        <ServerCan action='databases-everywhere.power'>
          <Group gap='xs'>
            {showStart && (
              <Button
                color='green'
                loading={action === 'start'}
                disabled={!database.mutations_allowed || action !== null}
                onClick={() => runPower('start')}
              >
                {database.deployment_mode === 'shared' ? 'Enable database access' : t('server.start', {})}
              </Button>
            )}
            {showRestart && (
              <Button
                color='gray'
                loading={action === 'restart'}
                disabled={!database.mutations_allowed || action !== null}
                onClick={() => runPower('restart')}
              >
                {t('server.restart', {})}
              </Button>
            )}
            {showStop && (
              <Button
                color='red'
                loading={action === 'stop'}
                disabled={!database.mutations_allowed || action !== null}
                onClick={() => runPower('stop')}
              >
                {database.deployment_mode === 'shared' ? 'Disable database access' : t('server.stop', {})}
              </Button>
            )}
            {showKill && (
              <Button
                color='red'
                variant='light'
                loading={action === 'kill'}
                disabled={!database.mutations_allowed || action !== null}
                onClick={() => runPower('kill')}
              >
                {t('server.kill', {})}
              </Button>
            )}
          </Group>
        </ServerCan>
      )}
    </>
  );

  return (
    <Stack gap='md'>
      {headerActions && createPortal(headerControls, headerActions)}
      <MutationFailureAlert
        failure={failure}
        checking={checkingState}
        onCheck={() => {
          setCheckingState(true);
          void getDatabaseStatus(server, database.uuid)
            .then((current) => {
              if (current.status) synchronizeStatus(current.status);
              setFailure(null);
              onChanged();
              addToast(t('server.databaseStateRefreshed', {}), 'success');
            })
            .catch((error) => setFailure(dbevMutationFailure(error, httpErrorToHuman(error))))
            .finally(() => setCheckingState(false));
        }}
      />
      {database.last_error && (
        <Alert color='red' title='Last synchronization error'>
          {database.last_error}
        </Alert>
      )}
      <LiveConnectionAlert {...live.monitoring} />
      {live.monitoring.state === 'reconnecting' && !live.monitoring.error && (
        <Alert color='blue'>{t('server.agentReconnecting', {})}</Alert>
      )}
      {status === 'quarantined' && (
        <Alert color='red' title={t('server.quarantinedTitle', {})}>
          {t('server.quarantinedDescription', {})}
        </Alert>
      )}
      {status === 'failed' && (
        <Alert color='red' title={t('server.failedTitle', {})}>
          {database.last_error || t('server.failedDescription', {})}
        </Alert>
      )}
      <DiskRestartBlockedAlert disk={disk} />
      {database.migration_active && (
        <Alert color='blue' title={t('server.placementMigration', {})}>
          {database.mutation_block_reason || t('server.migrationMutationsBlocked', {})}
        </Alert>
      )}
      {activeProgress && !progressDone && (
        <Alert
          color={activeProgress.status === 'failed' ? 'red' : 'blue'}
          title={activeProgress.action || 'Database operation'}
        >
          {activeProgress.diagnostic?.message ||
            activeProgress.message ||
            activeProgress.stage ||
            activeProgress.status}
          {typeof activeProgress.percent === 'number' ? ` · ${activeProgress.percent.toFixed(0)}%` : ''}
        </Alert>
      )}

      {children(
        database.deployment_mode === 'dedicated' ? (
          <Stack gap='md'>
            {canReadLogs ? (
              <div className='grid gap-4 xl:grid-cols-4'>
                <div className='relative flex h-[60vh] min-w-0 flex-col xl:col-span-3 xl:h-auto'>
                  <div className='flex min-h-0 flex-1 flex-col xl:absolute xl:inset-0'>
                    <DatabaseLiveLogs chunks={live.logs} error={live.logStream.error} fill />
                  </div>
                </div>
                <DatabaseSummaryStats database={database} instance={live.instance} stacked />
              </div>
            ) : (
              <DatabaseSummaryStats database={database} instance={live.instance} />
            )}
            <DatabaseLiveStats
              instance={live.instance}
              samples={live.samples}
              limits={database.limits}
              deploymentMode={database.deployment_mode}
            />
          </Stack>
        ) : (
          <Stack gap='md'>
            <Text size='xs' c='dimmed'>
              {t('server.sharedPowerSemantics', {})}
            </Text>
            <DatabaseSummaryStats database={database} instance={live.instance} />
            <Text size='xs' c='dimmed'>
              {t('server.childMetricsUnavailable', {})}
            </Text>
            <Alert color='blue'>{t('server.poolTelemetryDescription', {})}</Alert>
          </Stack>
        ),
        <DeploymentMigrationPanel server={server} database={database} onChanged={onChanged} />,
        <DatabaseActivityPanel
          server={server}
          database={database.uuid}
          liveActivity={normalizeDatabaseActivity(live.instance?.activity ?? null)}
          running={status === 'running'}
        />,
      )}
    </Stack>
  );
}
