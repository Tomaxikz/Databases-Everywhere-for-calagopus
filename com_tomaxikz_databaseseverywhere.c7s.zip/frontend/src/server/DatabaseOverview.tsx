import { faArrowsRotate, faBolt, faSkull, faStop } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Group, Stack, Text } from '@mantine/core';
import { useQueryClient } from '@tanstack/react-query';
import { type ReactNode, useCallback, useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import { ServerCan } from '@/elements/Can.tsx';
import Badge from '@/elements/data-display/Badge.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import { useServerCan } from '@/plugins/usePermissions.ts';
import { useToast } from '@/providers/ToastProvider.tsx';
import { getDatabaseStatus, powerDatabase } from '../api/client.ts';
import { type DbevMutationFailure, dbevMutationFailure } from '../api/mutationErrors.ts';
import type { DatabaseInstallProgress, DatabaseList, DatabasePowerAction, DatabaseRecord } from '../api/types.ts';
import { StatusBadge } from '../components/common.tsx';
import translations from '../translations.ts';
import DatabaseActivityPanel from './components/DatabaseActivityPanel.tsx';
import DatabaseLiveLogs from './components/DatabaseLiveLogs.tsx';
import DatabaseLiveStats from './components/DatabaseLiveStats.tsx';
import DatabaseSummaryStats from './components/DatabaseSummaryStats.tsx';
import DeploymentMigrationPanel from './components/DeploymentMigrationPanel.tsx';
import DiskRestartBlockedAlert from './components/DiskRestartBlockedAlert.tsx';
import LiveConnectionAlert from './components/LiveConnectionAlert.tsx';
import MutationFailureAlert from './components/MutationFailureAlert.tsx';
import { databaseActionPolicy } from './databaseActionPolicy.ts';
import { databasesEverywhereQueryKey } from './databaseQuery.ts';
import { useDatabaseLiveOverview } from './useDatabaseWebSockets.ts';

interface Props {
  server: string;
  database: DatabaseRecord;
  onChanged: () => void;
  onDeleted: () => void;
  overviewActive: boolean;
  children: (overviewContent: ReactNode, advancedContent: ReactNode) => ReactNode;
}

export default function DatabaseOverview({ server, database, onChanged, overviewActive, children }: Props) {
  const { t } = translations.useTranslations();
  const { addToast } = useToast();
  const queryClient = useQueryClient();
  const canReadLogs = useServerCan('databases-everywhere.logs');
  const [action, setAction] = useState<string | null>(null);
  const [failure, setFailure] = useState<DbevMutationFailure | null>(null);
  const [checkingState, setCheckingState] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const synchronizeStatus = useCallback(
    (status: string) => {
      queryClient.setQueryData<DatabaseList>(databasesEverywhereQueryKey(server), (current) => {
        if (!current) return current;
        const index = current.databases.findIndex((item) => item.uuid === database.uuid);
        if (index < 0 || current.databases[index].status === status) return current;
        const databases = [...current.databases];
        databases[index] = { ...databases[index], status };
        return { ...current, databases };
      });

      if (['running', 'stopped', 'failed', 'quarantined'].includes(status) && status !== database.status) {
        void getDatabaseStatus(server, database.uuid).catch(() => undefined);
      }
    },
    [database.status, database.uuid, queryClient, server],
  );
  const live = useDatabaseLiveOverview({
    server,
    database: database.uuid,
    logsEnabled: overviewActive && canReadLogs && database.deployment_mode === 'dedicated',
    monitoringEnabled: database.deployment_mode === 'dedicated',
    onStatusChange: synchronizeStatus,
  });

  const run = async (name: string, operation: () => Promise<unknown>, success = t('server.operationQueued', {})) => {
    if (!database.mutations_allowed) return;
    setAction(name);
    setFailure(null);
    return await (async () => {
      try {
        await operation();
        addToast(success, 'success');
        onChanged();
      } catch (error) {
        const nextFailure = dbevMutationFailure(error, httpErrorToHuman(error));
        setFailure(nextFailure);
        if (nextFailure.requiresReconciliation) onChanged();
        if (!nextFailure.retryable) addToast(nextFailure.message, 'error');
      }
    })().finally(() => {
      setAction(null);
    });
  };

  const runPower = (power: DatabasePowerAction) =>
    run(power, async () => {
      const result = await powerDatabase(server, database.uuid, power);
      if (power === 'start' || power === 'restart') live.reconnectLogs();
      return result;
    });
  const refresh = async () => {
    if (database.deployment_mode === 'dedicated') {
      live.reconnectMonitoring();
      if (overviewActive && canReadLogs) live.reconnectLogs();
    }
    setRefreshing(true);
    return getDatabaseStatus(server, database.uuid)
      .then((current) => {
        if (current.status) synchronizeStatus(current.status);
        onChanged();
      })
      .catch((error) => addToast(httpErrorToHuman(error), 'error'))
      .finally(() => setRefreshing(false));
  };
  const status = live.instance?.status || database.status;
  const disk = live.instance?.resources?.disk;
  const scannerRestartBlocked =
    disk?.scanner_restart_blocked ?? database.metadata.disk_scanner_restart_blocked === true;
  const policy = databaseActionPolicy(status, {
    scannerRestartBlocked,
    deploymentMode: database.deployment_mode,
    migrationActive: database.migration_active,
  });
  const persistedProgress = database.metadata.creation_progress ?? database.metadata.progress;
  const storedProgress =
    persistedProgress && typeof persistedProgress === 'object' ? (persistedProgress as DatabaseInstallProgress) : null;
  const activeProgress = live.monitoring.state === 'unavailable' ? storedProgress : live.progress;
  const showStart = policy.start;
  const showStop = policy.stop;
  const showRestart = policy.restart;
  const showKill = database.deployment_mode === 'dedicated' && policy.kill;
  const showPowerControls = showStart || showStop || showRestart || showKill;
  const lastSample = live.samples.findLast((sample) => sample.kind === 'stats' && sample.instance);

  return (
    <Stack gap='lg'>
      <MutationFailureAlert
        failure={failure}
        checking={checkingState}
        onCheck={() => {
          setCheckingState(true);
          void getDatabaseStatus(server, database.uuid)
            .then((current) => {
              if (current.status) synchronizeStatus(current.status);
              setFailure(null);
              onChanged();
              addToast(t('server.databaseStateRefreshed', {}), 'success');
            })
            .catch((error) => setFailure(dbevMutationFailure(error, httpErrorToHuman(error))))
            .finally(() => setCheckingState(false));
        }}
      />
      {database.last_error && (
        <Alert color='red' title='Last synchronization error'>
          {database.last_error}
        </Alert>
      )}
      <LiveConnectionAlert {...live.monitoring} />
      {live.monitoring.state === 'reconnecting' && !live.monitoring.error && (
        <Alert color='blue'>{t('server.agentReconnecting', {})}</Alert>
      )}
      {status === 'quarantined' && (
        <Alert color='red' title={t('server.quarantinedTitle', {})}>
          {t('server.quarantinedDescription', {})}
        </Alert>
      )}
      {status === 'failed' && (
        <Alert color='red' title={t('server.failedTitle', {})}>
          {database.last_error || t('server.failedDescription', {})}
        </Alert>
      )}
      <DiskRestartBlockedAlert disk={disk} />
      {database.migration_active && (
        <Alert color='blue' title={t('server.placementMigration', {})}>
          {database.mutation_block_reason || t('server.migrationMutationsBlocked', {})}
        </Alert>
      )}
      {activeProgress && (
        <Alert
          color={activeProgress.status === 'failed' ? 'red' : 'blue'}
          title={activeProgress.action || 'Database operation'}
        >
          {activeProgress.diagnostic?.message ||
            activeProgress.message ||
            activeProgress.stage ||
            activeProgress.status}
          {typeof activeProgress.percent === 'number' ? ` · ${activeProgress.percent.toFixed(0)}%` : ''}
        </Alert>
      )}

      <Group justify='space-between'>
        <Stack gap={4}>
          <Group gap='sm'>
            <StatusBadge status={status} />
            <Badge color={database.deployment_mode === 'shared' ? 'cyan' : 'violet'}>
              {database.deployment_mode === 'shared' ? t('server.shared', {}) : t('server.dedicated', {})}
            </Badge>
            {database.deployment_mode === 'dedicated' && (
              <Badge color={live.monitoring.state === 'connected' ? 'green' : 'yellow'}>
                {t('server.monitoringState', { state: live.monitoring.state })}
              </Badge>
            )}
            {database.limits_sync_pending && <Badge color='blue'>{t('server.pendingLimits', {})}</Badge>}
          </Group>
          <Text size='xs' c='dimmed'>
            {database.deployment_mode === 'shared'
              ? t('server.sharedMaximumResources', { disk: database.limits.disk_mib })
              : t('server.maximumResources', {
                  cpu: database.limits.cpu_cores,
                  memory: database.limits.memory_mib,
                  disk: database.limits.disk_mib,
                })}
          </Text>
          {database.deployment_mode === 'shared' && (
            <Text size='xs' c='dimmed'>
              {t('server.sharedPowerSemantics', {})}
            </Text>
          )}
        </Stack>
        <Group gap='xs'>
          <Button
            variant='default'
            loading={refreshing}
            onClick={() => void refresh()}
            leftSection={<FontAwesomeIcon icon={faArrowsRotate} />}
          >
            {database.deployment_mode === 'shared' ? t('server.refreshStatus', {}) : t('server.refreshMonitoring', {})}
          </Button>
          {showPowerControls && (
            <ServerCan action='databases-everywhere.power'>
              <Group gap='xs'>
                {showStart && (
                  <Button
                    size='xs'
                    loading={action === 'start'}
                    disabled={!database.mutations_allowed || action !== null}
                    onClick={() => runPower('start')}
                    leftSection={<FontAwesomeIcon icon={faBolt} />}
                  >
                    {database.deployment_mode === 'shared' ? 'Enable database access' : t('server.start', {})}
                  </Button>
                )}
                {showStop && (
                  <Button
                    size='xs'
                    variant='default'
                    loading={action === 'stop'}
                    disabled={!database.mutations_allowed || action !== null}
                    onClick={() => runPower('stop')}
                    leftSection={<FontAwesomeIcon icon={faStop} />}
                  >
                    {database.deployment_mode === 'shared' ? 'Disable database access' : t('server.stop', {})}
                  </Button>
                )}
                {showRestart && (
                  <Button
                    size='xs'
                    variant='default'
                    loading={action === 'restart'}
                    disabled={!database.mutations_allowed || action !== null}
                    onClick={() => runPower('restart')}
                    leftSection={<FontAwesomeIcon icon={faArrowsRotate} />}
                  >
                    {t('server.restart', {})}
                  </Button>
                )}
                {showKill && (
                  <Button
                    size='xs'
                    color='red'
                    variant='light'
                    loading={action === 'kill'}
                    disabled={!database.mutations_allowed || action !== null}
                    onClick={() => runPower('kill')}
                    leftSection={<FontAwesomeIcon icon={faSkull} />}
                  >
                    {t('server.kill', {})}
                  </Button>
                )}
              </Group>
            </ServerCan>
          )}
        </Group>
      </Group>

      <DatabaseSummaryStats database={database} instance={live.instance} />
      <Text size='xs' c='dimmed'>
        {database.deployment_mode === 'shared'
          ? t('server.childMetricsUnavailable', {})
          : t('server.monitoringLastReceived', {
              state: live.monitoring.state,
              time: lastSample ? new Date(lastSample.receivedAt).toLocaleTimeString() : t('common.unavailable', {}),
            })}
      </Text>
      {children(
        <Stack gap='md'>
          {database.deployment_mode === 'dedicated' ? (
            <>
              <DatabaseLiveStats
                instance={live.instance}
                samples={live.samples}
                limits={database.limits}
                deploymentMode={database.deployment_mode}
              />
              <DatabaseActivityPanel
                server={server}
                database={database.uuid}
                liveActivity={live.instance?.activity ?? null}
                running={status === 'running'}
              />
            </>
          ) : (
            <Alert color='blue'>{t('server.poolTelemetryDescription', {})}</Alert>
          )}

          {canReadLogs && database.deployment_mode === 'dedicated' && (
            <DatabaseLiveLogs chunks={live.logs} state={live.logStream.state} error={live.logStream.error} />
          )}
        </Stack>,
        <DeploymentMigrationPanel server={server} database={database} onChanged={onChanged} />,
      )}
    </Stack>
  );
}
