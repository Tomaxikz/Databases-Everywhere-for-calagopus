import {
  faArrowsRotate,
  faBoxArchive,
  faChartLine,
  faDatabase,
  faGear,
  faPlay,
  faSkull,
  faStop,
  faTerminal,
  faTrash,
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Group, SimpleGrid, Stack, Text } from '@mantine/core';
import { useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import Badge from '@/elements/data-display/Badge.tsx';
import Card from '@/elements/data-display/Card.tsx';
import Table from '@/elements/data-display/Table.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Spinner from '@/elements/feedback/Spinner.tsx';
import NumberInput from '@/elements/input/NumberInput.tsx';
import TextInput from '@/elements/input/TextInput.tsx';
import Tabs from '@/elements/layout/Tabs.tsx';
import { Modal, ModalFooter } from '@/elements/modals/Modal.tsx';
import { bytesToString } from '@/lib/format/size.ts';
import { useServerCan } from '@/plugins/usePermissions.ts';
import { useToast } from '@/providers/ToastProvider.tsx';
import { useServerStore } from '@/stores/server.ts';
import { deleteEmptyPool, getPoolBackups, powerPool, resizeServerPool, updatePoolImage } from '../api/sharedPools.ts';
import type { PoolLimits, ServerPoolView } from '../api/types.ts';
import { StatusBadge } from '../components/common.tsx';
import PoolSummary from '../components/PoolSummary.tsx';
import ProtocolIcon from '../components/ProtocolIcon.tsx';
import { protocolLabels } from '../components/protocols.ts';
import translations from '../translations.ts';
import DatabaseLiveLogs from './components/DatabaseLiveLogs.tsx';
import PoolLiveStats from './components/PoolLiveStats.tsx';
import DatabaseTableRow from './DatabaseTableRow.tsx';
import { visiblePoolProgress } from './poolPresentation.ts';
import { usePoolLiveOverview } from './usePoolWebSockets.ts';

type PowerAction = 'start' | 'stop' | 'restart' | 'kill';

function PoolSettings({ server, view, onSaved }: { server: string; view: ServerPoolView; onSaved: () => void }) {
  const { addToast } = useToast();
  const { t } = translations.useTranslations();
  const [limits, setLimits] = useState<PoolLimits>(view.pool.limits);
  const [image, setImage] = useState('');
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState<'limits' | 'image' | null>(null);
  useEffect(() => {
    setLimits(view.pool.limits);
  }, [
    view.pool.limits.cpu_cores,
    view.pool.limits.disk_mib,
    view.pool.limits.max_tenants,
    view.pool.limits.memory_mib,
  ]);
  const saveLimits = async () => {
    setSaving('limits');
    return await (async () => {
      try {
        await resizeServerPool(server, view.pool.runtime_id, limits);
        addToast(t('poolWorkspace.capacityUpdated', {}), 'success');
        onSaved();
      } catch (error) {
        addToast(httpErrorToHuman(error), 'error');
      }
    })().finally(() => {
      setSaving(null);
    });
  };
  const saveImage = async () => {
    setSaving('image');
    return await (async () => {
      try {
        await updatePoolImage(server, view.pool.runtime_id, image, reason);
        addToast(t('poolWorkspace.imageQueued', {}), 'success');
        setImage('');
        setReason('');
        onSaved();
      } catch (error) {
        addToast(httpErrorToHuman(error), 'error');
      }
    })().finally(() => {
      setSaving(null);
    });
  };
  return (
    <Card p='lg'>
      <Stack>
        <Text size='sm' c='dimmed'>
          {t('poolWorkspace.capacityDescription', {})}
        </Text>
        <SimpleGrid cols={2}>
          <NumberInput
            label={t('poolWorkspace.cpuCores', {})}
            value={limits.cpu_cores}
            min={0.01}
            onChange={(value) => setLimits({ ...limits, cpu_cores: Number(value) })}
          />
          <NumberInput
            label={t('poolWorkspace.memoryMib', {})}
            value={limits.memory_mib}
            min={1}
            onChange={(value) => setLimits({ ...limits, memory_mib: Number(value) })}
          />
          <NumberInput
            label={t('poolWorkspace.diskMib', {})}
            value={limits.disk_mib}
            min={1}
            onChange={(value) => setLimits({ ...limits, disk_mib: Number(value) })}
          />
          <NumberInput
            label={t('poolWorkspace.maxDatabases', {})}
            value={limits.max_tenants}
            min={Math.max(1, view.children.length)}
            onChange={(value) => setLimits({ ...limits, max_tenants: Number(value) })}
          />
        </SimpleGrid>
        <Button loading={saving === 'limits'} disabled={saving !== null} onClick={() => void saveLimits()}>
          {t('poolWorkspace.saveLimits', {})}
        </Button>
        <div className='border-t border-(--mantine-color-default-border) pt-4'>
          <Stack>
            <Text fw={600}>{t('poolWorkspace.image', {})}</Text>
            <Text size='xs' c='dimmed'>
              {t('poolWorkspace.imageDescription', {})}
            </Text>
            <TextInput
              label={t('poolWorkspace.allowedImage', {})}
              value={image}
              onChange={(event) => setImage(event.currentTarget.value)}
            />
            <TextInput
              label={t('poolWorkspace.auditReason', {})}
              value={reason}
              onChange={(event) => setReason(event.currentTarget.value)}
            />
            <Button
              variant='default'
              loading={saving === 'image'}
              disabled={
                saving !== null ||
                !image.trim() ||
                !reason.trim() ||
                !view.runtime ||
                !!view.runtime.pending_image ||
                view.status === 'quarantined'
              }
              onClick={() => void saveImage()}
            >
              {t('poolWorkspace.updateImage', {})}
            </Button>
          </Stack>
        </div>
      </Stack>
    </Card>
  );
}

function DeletePoolModal({
  server,
  view,
  opened,
  onClose,
  onDeleted,
}: {
  server: string;
  view: ServerPoolView;
  opened: boolean;
  onClose: () => void;
  onDeleted: () => void;
}) {
  const { addToast } = useToast();
  const { t } = translations.useTranslations();
  const [reason, setReason] = useState('');
  const [deleting, setDeleting] = useState(false);
  const empty = view.children.length === 0 && view.instances.length === 0 && view.runtime?.tenant_count === 0;
  return (
    <Modal title={t('poolWorkspace.deleteEmpty', {})} opened={opened} onClose={onClose}>
      <Stack>
        <Alert color={empty ? 'yellow' : 'red'}>
          {empty ? t('poolWorkspace.deleteWarning', {}) : t('poolWorkspace.deleteBlocked', {})}
        </Alert>
        <TextInput
          label={t('poolWorkspace.auditReason', {})}
          value={reason}
          onChange={(event) => setReason(event.currentTarget.value)}
        />
      </Stack>
      <ModalFooter>
        <Button variant='default' onClick={onClose}>
          {t('common.cancel', {})}
        </Button>
        <Button
          color='red'
          leftSection={<FontAwesomeIcon icon={faTrash} />}
          loading={deleting}
          disabled={!empty || !reason.trim()}
          onClick={() => {
            setDeleting(true);
            void deleteEmptyPool(server, view.pool.runtime_id, reason)
              .then(() => {
                addToast(t('poolWorkspace.deleted', {}), 'success');
                onDeleted();
                onClose();
              })
              .catch((error) => addToast(httpErrorToHuman(error), 'error'))
              .finally(() => setDeleting(false));
          }}
        >
          {t('poolWorkspace.deleteEmpty', {})}
        </Button>
      </ModalFooter>
    </Modal>
  );
}

export default function PoolWorkspace({
  server,
  view,
  onChanged,
  onDeleted,
}: {
  server: string;
  view: ServerPoolView;
  onChanged: () => void;
  onDeleted: () => void;
}) {
  const { t } = translations.useTranslations();
  const { addToast } = useToast();
  const navigate = useNavigate();
  const serverShort = useServerStore((state) => state.server.uuidShort);
  const canReadChildren = useServerCan('databases-everywhere.read');
  const canMonitor = useServerCan('databases-everywhere.pools-monitor');
  const canLogs = useServerCan('databases-everywhere.pools-logs');
  const canPower = useServerCan('databases-everywhere.pools-power');
  const canUpdate = useServerCan('databases-everywhere.pools-update');
  const canDelete = useServerCan('databases-everywhere.pools-delete');
  const canBackups = useServerCan('databases-everywhere.pools-backups');
  const [tab, setTab] = useState<string | null>('overview');
  const [running, setRunning] = useState<PowerAction | null>(null);
  const [deleting, setDeleting] = useState(false);
  const live = usePoolLiveOverview({
    server,
    runtimeId: view.pool.runtime_id,
    monitoringEnabled: canMonitor,
    logsEnabled: tab === 'logs' && canLogs,
  });
  const runtime = live.monitoring.state === 'connected' ? (live.pool ?? view.runtime) : view.runtime;
  const progress = visiblePoolProgress(live.pool ? live.progress : view.progress);
  const backups = useQuery({
    queryKey: ['dbev', server, 'pools', view.pool.runtime_id, 'backups'],
    queryFn: () => getPoolBackups(server, view.pool.runtime_id),
    enabled: tab === 'backups' && canBackups,
    retry: false,
  });
  const invoke = (action: PowerAction) => {
    setRunning(action);
    void powerPool(server, view.pool.runtime_id, action)
      .then(() => {
        addToast(t('poolWorkspace.powerQueued', { action }), 'success');
        onChanged();
      })
      .catch((error) => addToast(httpErrorToHuman(error), 'error'))
      .finally(() => setRunning(null));
  };
  const status = runtime?.status ?? view.status;
  const blocked =
    !runtime ||
    !!runtime.pending_image ||
    ['creating', 'booting', 'failed', 'quarantined', 'deleting'].includes(status);
  const isRunning = status === 'running';
  const powerActions = [
    { action: 'start' as const, icon: faPlay, disabled: isRunning, color: 'green' },
    { action: 'stop' as const, icon: faStop, disabled: !isRunning, color: 'red' },
    { action: 'restart' as const, icon: faArrowsRotate, disabled: !isRunning, color: undefined },
  ];
  const sampledAt = runtime
    ? Math.max(...[runtime.cpu, runtime.memory, runtime.disk].map((metric) => metric.sample.sampled_at_unix ?? 0))
    : 0;
  return (
    <Stack gap='lg'>
      <Group justify='space-between' align='center' gap='md'>
        <Group gap='md' wrap='nowrap'>
          <div className='flex size-12 shrink-0 items-center justify-center rounded-md border border-(--mantine-color-default-border) bg-(--mantine-color-default)'>
            <ProtocolIcon protocol={view.pool.protocol} size={30} />
          </div>
          <Stack gap='xs'>
            <Text component='h2' size='xl' fw={700}>
              {t('poolWorkspace.name', { engine: protocolLabels[view.pool.protocol] })}
            </Text>
            <Group gap='xs'>
              <Badge color='cyan' variant='light'>
                {t('poolWorkspace.sharedPool', {})}
              </Badge>
              <StatusBadge status={status} />
              <Text size='sm' c='dimmed'>
                {t('poolWorkspace.databaseCount', {
                  used: Math.max(view.children.length, runtime?.tenant_count ?? 0),
                  max: runtime?.max_tenants ?? view.pool.limits.max_tenants,
                })}
              </Text>
              {runtime?.database_version && (
                <Text size='sm' c='dimmed'>
                  {runtime.database_version}
                </Text>
              )}
            </Group>
          </Stack>
        </Group>
        {canPower && (
          <Group gap='xs'>
            {powerActions.map(({ action, icon, disabled, color }) => (
              <Button
                key={action}
                variant={color ? 'light' : 'default'}
                color={color}
                miw={90}
                leftSection={<FontAwesomeIcon icon={icon} />}
                disabled={disabled || blocked || running !== null}
                loading={running === action}
                onClick={() => invoke(action)}
              >
                {t(`server.${action}`, {})}
              </Button>
            ))}
          </Group>
        )}
      </Group>
      {progress && (
        <Alert color={progress.status === 'failed' ? 'red' : 'blue'}>
          {progress.diagnostic?.message || progress.message || progress.stage || progress.status}
        </Alert>
      )}
      {(status === 'quarantined' || runtime?.pending_image) && (
        <Alert color='yellow'>{t('poolWorkspace.operatorAttention', {})}</Alert>
      )}
      <Tabs value={tab} onChange={setTab} keepMounted={false}>
        <Tabs.List className='flex-nowrap overflow-x-auto'>
          <Tabs.Tab value='overview' leftSection={<FontAwesomeIcon icon={faChartLine} />}>
            {t('server.overview', {})}
          </Tabs.Tab>
          {canReadChildren && (
            <Tabs.Tab value='databases' leftSection={<FontAwesomeIcon icon={faDatabase} />}>
              {t('server.title', {})}
            </Tabs.Tab>
          )}
          {canLogs && (
            <Tabs.Tab value='logs' leftSection={<FontAwesomeIcon icon={faTerminal} />}>
              {t('poolWorkspace.logs', {})}
            </Tabs.Tab>
          )}
          {canBackups && (
            <Tabs.Tab value='backups' leftSection={<FontAwesomeIcon icon={faBoxArchive} />}>
              {t('server.backups', {})}
            </Tabs.Tab>
          )}
          {(canUpdate || canDelete || canPower) && (
            <Tabs.Tab value='settings' leftSection={<FontAwesomeIcon icon={faGear} />}>
              {t('poolWorkspace.settings', {})}
            </Tabs.Tab>
          )}
        </Tabs.List>
        <Tabs.Panel value='overview' pt='lg'>
          <Stack gap='lg'>
            <Group justify='space-between'>
              <Text fw={600}>{t('poolWorkspace.resources', {})}</Text>
              <Text size='sm' c='dimmed'>
                {t('poolWorkspace.resourcesShared', {})}
              </Text>
            </Group>
            <PoolSummary pool={runtime} limits={view.pool.limits} />
            <Text size='xs' c='dimmed'>
              {t('poolWorkspace.monitoring', {
                state: canMonitor ? live.monitoring.state : t('poolWorkspace.snapshotOnly', {}),
                time: sampledAt > 0 ? new Date(sampledAt * 1000).toLocaleTimeString() : t('common.unavailable', {}),
              })}
            </Text>
            {live.monitoring.error && <Alert color='yellow'>{live.monitoring.error}</Alert>}
            {canMonitor && <PoolLiveStats pool={live.pool} samples={live.samples} limits={view.pool.limits} />}
          </Stack>
        </Tabs.Panel>
        {canReadChildren && (
          <Tabs.Panel value='databases' pt='lg'>
            <Stack gap='md'>
              <Text size='sm' c='dimmed'>
                {t('poolWorkspace.childDescription', {})}
              </Text>
              {view.children.length ? (
                <Table
                  allowSelect={false}
                  columns={[
                    t('server.columns.name', {}),
                    t('server.columns.type', {}),
                    t('server.columns.address', {}),
                    t('poolWorkspace.username', {}),
                    t('poolWorkspace.diskAllowance', {}),
                    t('poolWorkspace.access', {}),
                    '',
                  ]}
                  pagination={{
                    total: view.children.length,
                    perPage: Math.max(1, view.children.length),
                    page: 1,
                    data: view.children,
                  }}
                >
                  {view.children.map((database) => (
                    <DatabaseTableRow key={database.uuid} database={database} layout='classic' />
                  ))}
                </Table>
              ) : (
                <Card p='xl'>
                  <Text c='dimmed'>{t('poolWorkspace.empty', {})}</Text>
                </Card>
              )}
            </Stack>
          </Tabs.Panel>
        )}
        {canLogs && (
          <Tabs.Panel value='logs' pt='lg'>
            <Stack gap='md'>
              <Text size='sm' c='dimmed'>
                {t('poolWorkspace.logsDescription', {})}
              </Text>
              <DatabaseLiveLogs chunks={live.logs} state={live.logStream.state} error={live.logStream.error} />
            </Stack>
          </Tabs.Panel>
        )}
        {canBackups && (
          <Tabs.Panel value='backups' pt='lg'>
            <Stack gap='md'>
              <Group justify='space-between'>
                <Text size='sm' c='dimmed'>
                  {t('poolWorkspace.backupsDescription', {})}
                </Text>
                <Button variant='default' loading={backups.isFetching} onClick={() => void backups.refetch()}>
                  {t('common.refresh', {})}
                </Button>
              </Group>
              {backups.isLoading && <Spinner.Centered />}
              {backups.error && <Alert color='red'>{httpErrorToHuman(backups.error)}</Alert>}
              {!backups.error &&
                Object.entries(backups.data ?? {}).map(([instance, records]) => {
                  const child = view.children.find((database) => database.uuid === instance);
                  return (
                    <Card key={instance} p='lg'>
                      <Stack gap='md'>
                        <Group justify='space-between'>
                          <Text fw={600}>{child?.display_name ?? instance}</Text>
                          {child && canReadChildren && (
                            <Button
                              variant='default'
                              size='xs'
                              onClick={() => navigate(`/server/${serverShort}/databases/dbev/${child.uuid}`)}
                            >
                              {t('poolWorkspace.openDatabase', {})}
                            </Button>
                          )}
                        </Group>
                        {records.map((record) => (
                          <Group
                            key={record.id}
                            justify='space-between'
                            className='border-t border-(--mantine-color-default-border) pt-3'
                          >
                            <Text size='sm' ff='monospace' className='break-all'>
                              {record.id}
                            </Text>
                            <Text size='sm' c='dimmed'>
                              {typeof record.size_bytes === 'number'
                                ? bytesToString(record.size_bytes)
                                : t('common.unavailable', {})}
                            </Text>
                          </Group>
                        ))}
                      </Stack>
                    </Card>
                  );
                })}
              {!backups.isLoading && !backups.error && !Object.keys(backups.data ?? {}).length && (
                <Card p='xl'>
                  <Text c='dimmed'>{t('poolWorkspace.noBackups', {})}</Text>
                </Card>
              )}
            </Stack>
          </Tabs.Panel>
        )}
        {(canUpdate || canDelete || canPower) && (
          <Tabs.Panel value='settings' pt='lg'>
            <Stack gap='lg'>
              <Card p='lg'>
                <Stack gap='xs'>
                  <Text fw={600}>{t('poolWorkspace.identity', {})}</Text>
                  <Text size='sm' ff='monospace' className='break-all'>
                    {view.pool.runtime_id}
                  </Text>
                  {runtime?.image && (
                    <Text size='sm' c='dimmed' className='break-all'>
                      {runtime.image}
                    </Text>
                  )}
                </Stack>
              </Card>
              {canUpdate && <PoolSettings server={server} view={view} onSaved={onChanged} />}
              {(canDelete || canPower) && (
                <Card p='lg'>
                  <Stack gap='md'>
                    <Text fw={600}>{t('poolWorkspace.dangerZone', {})}</Text>
                    <Text size='sm' c='dimmed'>
                      {t('poolWorkspace.dangerDescription', {})}
                    </Text>
                    <Group>
                      {canPower && (
                        <Button
                          color='red'
                          variant='light'
                          leftSection={<FontAwesomeIcon icon={faSkull} />}
                          disabled={!isRunning || blocked || running !== null}
                          loading={running === 'kill'}
                          onClick={() => invoke('kill')}
                        >
                          {t('server.kill', {})}
                        </Button>
                      )}
                      {canDelete && (
                        <Button
                          color='red'
                          variant='light'
                          leftSection={<FontAwesomeIcon icon={faTrash} />}
                          onClick={() => setDeleting(true)}
                        >
                          {t('poolWorkspace.deleteEmpty', {})}
                        </Button>
                      )}
                    </Group>
                  </Stack>
                </Card>
              )}
            </Stack>
          </Tabs.Panel>
        )}
      </Tabs>
      {canDelete && (
        <DeletePoolModal
          server={server}
          view={view}
          opened={deleting}
          onClose={() => setDeleting(false)}
          onDeleted={onDeleted}
        />
      )}
    </Stack>
  );
}
