import { faPlus, faRotate, faSearch } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import type { MouseEvent } from 'react';
import ActionIcon from '@/elements/buttons/ActionIcon.tsx';
import { ServerCan } from '@/elements/Can.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Spinner from '@/elements/feedback/Spinner.tsx';
import TextInput from '@/elements/input/TextInput.tsx';
import Divider from '@/elements/layout/Divider.tsx';
import Group from '@/elements/layout/Group.tsx';
import Paper from '@/elements/layout/Paper.tsx';
import ScrollArea from '@/elements/layout/ScrollArea.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import NavLink from '@/elements/navigation/NavLink.tsx';
import { type ContextMenuItem, useContextMenu } from '@/elements/overlays/ContextMenu.tsx';
import Tooltip from '@/elements/overlays/Tooltip.tsx';
import Text from '@/elements/typography/Text.tsx';
import type { DataObject } from '../../api/types.ts';
import translations from '../../translations.ts';

export function dataObjectKey(object: DataObject): string {
  return `${object.namespace ?? ''}\u0000${object.name}`;
}

interface Props {
  objects: DataObject[];
  total: number;
  loading: boolean;
  refreshing: boolean;
  error: string | null;
  selectedKey: string | null;
  search: string;
  mode: 'table' | 'collection' | 'key';
  supportsCreation: boolean;
  readOnly?: boolean;
  onSearch: (value: string) => void;
  onSelect: (object: DataObject) => void;
  onCreate: () => void;
  onRefresh: () => void;
  menuItems?: (object: DataObject) => ContextMenuItem[];
}

export default function ObjectSidebar({
  objects,
  total,
  loading,
  refreshing,
  error,
  selectedKey,
  search,
  mode,
  supportsCreation,
  readOnly = false,
  onSearch,
  onSelect,
  onCreate,
  onRefresh,
  menuItems,
}: Props) {
  const { t } = translations.useTranslations();
  const { showMenu } = useContextMenu();
  const title =
    mode === 'collection'
      ? t('server.dataEditor.collections', {})
      : mode === 'key'
        ? t('server.dataEditor.keys', {})
        : t('server.dataEditor.tables', {});
  const searchPlaceholder =
    mode === 'collection'
      ? t('server.dataEditor.searchCollections', {})
      : mode === 'key'
        ? t('server.dataEditor.searchKeys', {})
        : t('server.dataEditor.searchTables', {});
  const emptyText =
    mode === 'collection'
      ? t('server.dataEditor.noCollectionsYet', {})
      : mode === 'key'
        ? t('server.dataEditor.noKeysYet', {})
        : t('server.dataEditor.noTablesYet', {});
  const createLabel =
    mode === 'collection' ? t('server.dataEditor.newCollection', {}) : t('server.dataEditor.newTable', {});

  return (
    <Paper withBorder radius='md' className='flex flex-col overflow-hidden'>
      <div className='flex items-center justify-between bg-(--mantine-color-default) px-3 py-2'>
        <Text size='xs' fw={600} c='dimmed' tt='uppercase' style={{ letterSpacing: '0.05em' }}>
          {title}
        </Text>
        <Group gap={4} wrap='nowrap'>
          <Tooltip label={t('common.refresh', {})}>
            <ActionIcon
              variant='subtle'
              color='gray'
              size='sm'
              loading={refreshing}
              onClick={onRefresh}
              aria-label={t('common.refresh', {})}
            >
              <FontAwesomeIcon icon={faRotate} />
            </ActionIcon>
          </Tooltip>
          {supportsCreation && !readOnly && (
            <ServerCan action='databases-everywhere.data-write'>
              <Tooltip label={createLabel}>
                <ActionIcon variant='subtle' color='gray' size='sm' onClick={onCreate} aria-label={createLabel}>
                  <FontAwesomeIcon icon={faPlus} />
                </ActionIcon>
              </Tooltip>
            </ServerCan>
          )}
        </Group>
      </div>
      <Divider />
      <div className='p-2'>
        <TextInput
          value={search}
          onChange={(event) => onSearch(event.currentTarget.value)}
          placeholder={searchPlaceholder}
          leftSection={<FontAwesomeIcon icon={faSearch} />}
        />
      </div>
      <Divider />
      <ScrollArea className='flex-1' mah='max(20rem, calc(100dvh - 26rem))' type='auto'>
        {error ? (
          <Alert color='red' m='xs'>
            {error}
          </Alert>
        ) : loading ? (
          <Spinner.Centered />
        ) : (
          <Stack gap={0} p='xs'>
            {objects.length === 0 && (
              <Text size='sm' c='dimmed' p='xs'>
                {total === 0 ? emptyText : t('server.dataEditor.noSearchMatches', {})}
              </Text>
            )}
            {objects.map((object) => {
              const key = dataObjectKey(object);
              return (
                <div
                  key={key}
                  onContextMenu={(event: MouseEvent<HTMLDivElement>) => {
                    const items = menuItems?.(object) ?? [];
                    const usable = items.some(
                      (item) => item.type === 'action' && !item.hidden && item.canAccess !== false,
                    );
                    if (!usable) return;
                    event.preventDefault();
                    onSelect(object);
                    showMenu(event.clientX, event.clientY, items);
                  }}
                >
                  <NavLink
                    label={object.namespace ? `${object.namespace}.${object.name}` : object.name}
                    active={key === selectedKey}
                    onClick={() => onSelect(object)}
                    rightSection={
                      object.kind && ![mode, 'table', 'base table'].includes(object.kind.toLowerCase()) ? (
                        <Text size='xs' c='dimmed'>
                          {object.kind}
                        </Text>
                      ) : undefined
                    }
                    style={{
                      borderRadius: 'max(4px, calc(var(--mantine-radius-md) - var(--mantine-spacing-xs)))',
                    }}
                    styles={{
                      label: {
                        fontSize: 'var(--mantine-font-size-sm)',
                        fontFamily: 'var(--mantine-font-family-monospace)',
                      },
                    }}
                  />
                </div>
              );
            })}
          </Stack>
        )}
      </ScrollArea>
    </Paper>
  );
}
