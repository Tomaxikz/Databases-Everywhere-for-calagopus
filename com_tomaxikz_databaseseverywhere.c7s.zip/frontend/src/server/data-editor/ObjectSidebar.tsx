import { faChevronRight, faPlus, faRotate, faSearch, faTable } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Group, Stack, Text } from '@mantine/core';
import ActionIcon from '@/elements/buttons/ActionIcon.tsx';
import Button from '@/elements/buttons/Button.tsx';
import UnstyledButton from '@/elements/buttons/UnstyledButton.tsx';
import { ServerCan } from '@/elements/Can.tsx';
import Badge from '@/elements/data-display/Badge.tsx';
import { NoItems } from '@/elements/data-display/Table.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Spinner from '@/elements/feedback/Spinner.tsx';
import TextInput from '@/elements/input/TextInput.tsx';
import ScrollArea from '@/elements/layout/ScrollArea.tsx';
import type { DataObject } from '../../api/types.ts';
import translations from '../../translations.ts';

export function dataObjectKey(object: DataObject): string {
  return `${object.namespace ?? ''}\u0000${object.name}`;
}

interface Props {
  objects: DataObject[];
  filteredTotal: number;
  loading: boolean;
  refreshing: boolean;
  error: string | null;
  selectedKey: string | null;
  search: string;
  mode: 'table' | 'collection' | 'key';
  supportsCreation: boolean;
  readOnly?: boolean;
  onSearch: (value: string) => void;
  onSelect: (object: DataObject) => void;
  onCreate: () => void;
  onRefresh: () => void;
}

export default function ObjectSidebar({
  objects,
  filteredTotal,
  loading,
  refreshing,
  error,
  selectedKey,
  search,
  mode,
  supportsCreation,
  readOnly = false,
  onSearch,
  onSelect,
  onCreate,
  onRefresh,
}: Props) {
  const { t } = translations.useTranslations();
  const title =
    mode === 'collection'
      ? t('server.dataEditor.collections', {})
      : mode === 'key'
        ? t('server.dataEditor.keys', {})
        : t('server.dataEditor.tables', {});
  const searchPlaceholder =
    mode === 'collection'
      ? t('server.dataEditor.searchCollections', {})
      : mode === 'key'
        ? t('server.dataEditor.searchKeys', {})
        : t('server.dataEditor.searchTables', {});

  return (
    <TitleCard
      title={title}
      className='flex h-[440px] flex-col overflow-hidden lg:h-[clamp(560px,calc(100dvh-220px),900px)]'
      wrapperClassName='p-0! h-auto! flex min-h-0 flex-1 flex-col'
      rightSection={
        <Group gap={6} wrap='nowrap' className='ml-auto'>
          <Badge color='gray'>{filteredTotal}</Badge>
          <ActionIcon
            variant='default'
            size='input-sm'
            loading={refreshing}
            onClick={onRefresh}
            aria-label={t('common.refresh', {})}
          >
            <FontAwesomeIcon icon={faRotate} />
          </ActionIcon>
          {supportsCreation && !readOnly && (
            <ServerCan action='databases-everywhere.data-write'>
              <Button size='sm' onClick={onCreate} leftSection={<FontAwesomeIcon icon={faPlus} />}>
                {mode === 'collection' ? t('server.dataEditor.newCollection', {}) : t('server.dataEditor.newTable', {})}
              </Button>
            </ServerCan>
          )}
        </Group>
      }
    >
      <Stack gap='sm' className='border-b border-(--mantine-color-default-border) px-4 py-3'>
        <TextInput
          value={search}
          onChange={(event) => onSearch(event.currentTarget.value)}
          placeholder={searchPlaceholder}
          leftSection={<FontAwesomeIcon icon={faSearch} />}
          w='100%'
        />
      </Stack>

      <ScrollArea className='min-h-0 flex-1' type='auto' offsetScrollbars>
        {error ? (
          <Alert color='red' m='sm'>
            {error}
          </Alert>
        ) : loading ? (
          <Spinner.Centered />
        ) : objects.length === 0 ? (
          <NoItems />
        ) : (
          <Stack gap={0}>
            {objects.map((object) => {
              const key = dataObjectKey(object);
              const selected = key === selectedKey;
              return (
                <UnstyledButton
                  key={key}
                  w='100%'
                  px='md'
                  py='sm'
                  aria-pressed={selected}
                  bg={selected ? 'var(--mantine-primary-color-light)' : undefined}
                  className='border-b border-(--mantine-color-default-border) transition-colors hover:bg-(--mantine-color-default-hover)'
                  style={{
                    borderLeft: selected ? '3px solid var(--mantine-primary-color-filled)' : '3px solid transparent',
                  }}
                  onClick={() => onSelect(object)}
                >
                  <Group gap='sm' wrap='nowrap'>
                    <FontAwesomeIcon
                      icon={faTable}
                      className={selected ? 'text-(--mantine-primary-color-filled)' : 'text-(--mantine-color-dimmed)'}
                    />
                    <div className='min-w-0 flex-1'>
                      <Text fw={600} size='sm' truncate>
                        {object.name}
                      </Text>
                      <Text size='xs' c='dimmed' truncate>
                        {object.namespace || t('server.dataEditor.noValue', {})} · {object.kind}
                      </Text>
                    </div>
                    <FontAwesomeIcon
                      icon={faChevronRight}
                      className={selected ? 'text-(--mantine-primary-color-filled)' : 'text-(--mantine-color-dimmed)'}
                    />
                  </Group>
                </UnstyledButton>
              );
            })}
          </Stack>
        )}
      </ScrollArea>
    </TitleCard>
  );
}
