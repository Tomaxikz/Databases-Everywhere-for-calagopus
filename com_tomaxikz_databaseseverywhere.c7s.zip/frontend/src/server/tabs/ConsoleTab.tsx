import { faBroom, faClockRotateLeft } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Loader, Text } from '@mantine/core';
import { type KeyboardEvent, useEffect, useMemo, useRef, useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import ActionIcon from '@/elements/buttons/ActionIcon.tsx';
import Card from '@/elements/data-display/Card.tsx';
import Autocomplete from '@/elements/input/Autocomplete.tsx';
import Menu from '@/elements/overlays/Menu.tsx';
import Tooltip from '@/elements/overlays/Tooltip.tsx';
import { executeCommand } from '../../api/client.ts';
import type { DatabaseRecord } from '../../api/types.ts';
import { protocolConsoleExamples } from '../../components/protocols.ts';
import translations from '../../translations.ts';
import DatabaseTerminal, { type ConsoleEntry } from '../console/DatabaseTerminal.tsx';
import { terminalPrompt } from '../console/terminalOutput.ts';

interface HistoryEntry {
  command: string;
  executedAt: number;
}

const HISTORY_LIMIT = 50;
const SESSION_LIMIT = 100;

export default function ConsoleTab({ server, database }: { server: string; database: DatabaseRecord }) {
  const { t } = translations.useTranslations();
  const storageKey = `dbev-console-history:${database.uuid}`;
  const prompt = terminalPrompt(database.protocol, database.display_name);
  const inputRef = useRef<HTMLInputElement>(null);
  const entryId = useRef(0);
  const historyDraft = useRef('');
  const [command, setCommand] = useState('');
  const [entries, setEntries] = useState<ConsoleEntry[]>([]);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setCommand('');
    setEntries([]);
    setHistoryIndex(null);
    historyDraft.current = '';
    try {
      const parsed: unknown = JSON.parse(localStorage.getItem(storageKey) || '[]');
      setHistory(Array.isArray(parsed) ? parsed.filter(isHistoryEntry).slice(0, HISTORY_LIMIT) : []);
    } catch {
      setHistory([]);
    }
  }, [storageKey]);

  const remember = (nextCommand: string) => {
    setHistory((current) => {
      const next = [
        { command: nextCommand, executedAt: Date.now() },
        ...current.filter((entry) => entry.command !== nextCommand),
      ].slice(0, HISTORY_LIMIT);
      try {
        localStorage.setItem(storageKey, JSON.stringify(next));
      } catch {
        // The in-memory terminal history remains usable when browser storage
        // is disabled or full.
      }
      return next;
    });
  };

  const execute = async () => {
    const submitted = command.trim();
    if (!submitted || loading) return;

    const id = ++entryId.current;
    const runningEntry: ConsoleEntry = {
      id,
      command: submitted,
      executedAt: Date.now(),
      state: 'running',
    };
    setEntries((current) => [...current.slice(-(SESSION_LIMIT - 1)), runningEntry]);
    setCommand('');
    setHistoryIndex(null);
    historyDraft.current = '';
    setLoading(true);
    remember(submitted);

    return await (async () => {
      try {
        const output = await executeCommand(server, database.uuid, submitted);
        setEntries((current) =>
          current.map((entry) => (entry.id === id ? { ...entry, state: 'success', output } : entry)),
        );
      } catch (cause) {
        const error = httpErrorToHuman(cause);
        setEntries((current) =>
          current.map((entry) => (entry.id === id ? { ...entry, state: 'error', error } : entry)),
        );
      }
    })().finally(() => {
      setLoading(false);
      requestAnimationFrame(() => inputRef.current?.focus());
    });
  };

  const focusAtEnd = (value: string) => {
    requestAnimationFrame(() => {
      const input = inputRef.current;
      if (!input) return;
      input.focus();
      input.setSelectionRange(value.length, value.length);
    });
  };

  const chooseHistory = (index: number) => {
    const selected = history[index];
    if (!selected) return;
    if (historyIndex === null) historyDraft.current = command;
    setHistoryIndex(index);
    setCommand(selected.command);
    focusAtEnd(selected.command);
  };

  const stepHistory = (direction: 'older' | 'newer') => {
    if (!history.length) return;
    if (direction === 'older') {
      const nextIndex = historyIndex === null ? 0 : Math.min(historyIndex + 1, history.length - 1);
      chooseHistory(nextIndex);
      return;
    }
    if (historyIndex === null) return;
    if (historyIndex === 0) {
      const draft = historyDraft.current;
      setHistoryIndex(null);
      setCommand(draft);
      focusAtEnd(draft);
      return;
    }
    chooseHistory(historyIndex - 1);
  };

  const updateCommand = (value: string) => {
    setCommand(value);
    setHistoryIndex(null);
    historyDraft.current = value;
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    const input = event.currentTarget;
    const value = input.value;
    const selectionStart = input.selectionStart ?? value.length;
    const selectionEnd = input.selectionEnd ?? value.length;
    const modifier = event.ctrlKey || event.metaKey;

    if (modifier && event.key.toLowerCase() === 'l') {
      event.preventDefault();
      if (!loading) setEntries([]);
      return;
    }

    if (event.key === 'Enter' && !event.nativeEvent.isComposing) {
      event.preventDefault();
      void execute();
      return;
    }

    if (event.key === 'ArrowUp' && !value.slice(0, selectionStart).includes('\n')) {
      event.preventDefault();
      stepHistory('older');
      return;
    }

    if (event.key === 'ArrowDown' && !value.slice(selectionEnd).includes('\n')) {
      event.preventDefault();
      stepHistory('newer');
    }
  };

  const presets = useMemo(() => consolePresets(database), [database]);
  const suggestions = useMemo(
    () => Array.from(new Set([...presets.map((preset) => preset.command), ...history.map((entry) => entry.command)])),
    [history, presets],
  );

  return (
    <Card
      className='relative mt-4 flex flex-col p-2! font-mono text-sm'
      style={{ height: 'clamp(420px, calc(100dvh - 300px), 820px)' }}
    >
      <div className='mb-2 flex flex-row items-center justify-between gap-2 text-xs'>
        <div className='flex min-w-0 flex-row items-center'>
          <span
            className={`mr-2 size-3 shrink-0 rounded-full ${
              database.status === 'running' ? 'bg-(--mantine-color-green-filled)' : 'bg-(--mantine-color-red-filled)'
            }`}
          />
          <span className='truncate'>
            {t('server.consoleTerminal.status', {
              protocol: database.protocol_label,
              database: database.database_name,
            })}
          </span>
        </div>
        <div className='flex flex-row items-center gap-2'>
          <Menu position='bottom-end' width={380} shadow='md' withinPortal>
            <Menu.Target>
              <Tooltip label={t('server.consoleTerminal.history', {})}>
                <ActionIcon className='group' size='xs' radius={0} variant='transparent'>
                  <FontAwesomeIcon
                    icon={faClockRotateLeft}
                    className='text-(--mantine-color-dimmed) group-hover:text-(--mantine-color-text)'
                  />
                </ActionIcon>
              </Tooltip>
            </Menu.Target>
            <Menu.Dropdown>
              <Menu.Label>{t('server.consoleTerminal.examples', {})}</Menu.Label>
              {presets.map((preset) => (
                <Menu.Item
                  key={preset.label}
                  onClick={() => {
                    updateCommand(preset.command);
                    focusAtEnd(preset.command);
                  }}
                >
                  <Text size='xs'>{preset.label}</Text>
                </Menu.Item>
              ))}
              <Menu.Divider />
              <Menu.Label>{t('server.consoleTerminal.history', {})}</Menu.Label>
              {history.length ? (
                history.map((entry, index) => (
                  <Menu.Item key={`${entry.executedAt}:${entry.command}`} onClick={() => chooseHistory(index)}>
                    <Text size='xs' ff='monospace' truncate>
                      {entry.command.replace(/\s+/g, ' ')}
                    </Text>
                    <Text size='xs' c='dimmed'>
                      {new Date(entry.executedAt).toLocaleString()}
                    </Text>
                  </Menu.Item>
                ))
              ) : (
                <Text size='xs' c='dimmed' px='sm' py={6}>
                  {t('server.consoleTerminal.noHistory', {})}
                </Text>
              )}
            </Menu.Dropdown>
          </Menu>
          <Tooltip label={t('server.consoleTerminal.clear', {})}>
            <ActionIcon
              className='group'
              size='xs'
              radius={0}
              variant='transparent'
              disabled={loading || entries.length === 0}
              onClick={() => setEntries([])}
            >
              <FontAwesomeIcon
                icon={faBroom}
                className='text-(--mantine-color-dimmed) group-hover:text-(--mantine-color-text)'
              />
            </ActionIcon>
          </Tooltip>
        </div>
      </div>

      <DatabaseTerminal
        entries={entries}
        prompt={prompt}
        protocol={database.protocol}
        protocolLabel={database.protocol_label}
        databaseName={database.display_name}
        onClick={() => inputRef.current?.focus()}
      />

      <div className='mt-4 flex w-full flex-row'>
        <Autocomplete
          ref={inputRef}
          value={command}
          onChange={updateCommand}
          onKeyDown={handleKeyDown}
          readOnly={loading}
          data={suggestions}
          limit={8}
          maxDropdownHeight={260}
          onOptionSubmit={(value) => {
            updateCommand(value);
            focusAtEnd(value);
          }}
          aria-label={t('server.consoleTerminal.commandInput', {})}
          placeholder={t('server.consoleTerminal.placeholder', {
            example: protocolConsoleExamples[database.protocol],
          })}
          autoCorrect='off'
          autoCapitalize='none'
          spellCheck={false}
          className='w-full'
          classNames={{ input: 'font-mono!' }}
          leftSection={
            <span className='truncate pl-2 font-mono font-semibold text-(--mantine-primary-color-filled)'>
              {prompt}
            </span>
          }
          leftSectionWidth={`calc(${prompt.length}ch + 1.25rem)`}
          leftSectionProps={{ className: 'justify-start!' }}
          rightSection={loading ? <Loader size='xs' /> : undefined}
        />
      </div>
    </Card>
  );
}

function isHistoryEntry(value: unknown): value is HistoryEntry {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const entry = value as Record<string, unknown>;
  return typeof entry.command === 'string' && typeof entry.executedAt === 'number';
}

function consolePresets(database: DatabaseRecord): { label: string; command: string }[] {
  const name = database.database_name.replace(/'/g, "''");
  switch (database.protocol) {
    case 'postgres':
      return [
        {
          label: 'Tables',
          command:
            "SELECT table_schema, table_name FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog', 'information_schema') ORDER BY 1, 2;",
        },
        { label: 'Activity', command: 'SELECT pid, usename, state, query FROM pg_stat_activity LIMIT 100;' },
        { label: 'Database size', command: `SELECT pg_size_pretty(pg_database_size('${name}')) AS size;` },
      ];
    case 'mysql':
    case 'mariadb':
      return [
        { label: 'Tables', command: 'SHOW TABLES;' },
        { label: 'Processes', command: 'SHOW PROCESSLIST;' },
        {
          label: 'Database size',
          command: `SELECT SUM(data_length + index_length) AS bytes FROM information_schema.tables WHERE table_schema = '${name}';`,
        },
      ];
    case 'clickhouse':
      return [
        { label: 'Tables', command: 'SHOW TABLES;' },
        { label: 'Processes', command: 'SELECT * FROM system.processes LIMIT 100;' },
        {
          label: 'Parts',
          command:
            'SELECT database, table, sum(bytes_on_disk) AS bytes FROM system.parts WHERE active GROUP BY database, table ORDER BY bytes DESC LIMIT 100;',
        },
      ];
    default:
      return [{ label: 'Example', command: protocolConsoleExamples[database.protocol] }];
  }
}
