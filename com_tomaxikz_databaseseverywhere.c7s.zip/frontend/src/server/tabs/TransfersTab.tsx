import { faFileArrowDown, faFileArrowUp } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Group, Stack, Text } from '@mantine/core';
import { useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import { ServerCan } from '@/elements/Can.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import SegmentedControl from '@/elements/layout/SegmentedControl.tsx';
import { Modal, ModalFooter } from '@/elements/modals/Modal.tsx';
import { useToast } from '@/providers/ToastProvider.tsx';
import { deleteStagedUpload } from '../../api/client.ts';
import type { DatabaseRecord, TemporaryUploadRecord } from '../../api/types.ts';
import TransferComposer, { type ImportPreset } from '../transfers/TransferComposer.tsx';
import TransferFiles from '../transfers/TransferFiles.tsx';
import TransferHistory from '../transfers/TransferHistory.tsx';
import { cancellationDeletesUpload } from '../transfers/uploadContracts.ts';

type TransferSection = 'history' | 'files';
type TransferDialog = 'export' | 'import' | null;

export default function TransfersTab({ server, database }: { server: string; database: DatabaseRecord }) {
  const { addToast } = useToast();
  const [section, setSection] = useState<TransferSection>('history');
  const [dialog, setDialog] = useState<TransferDialog>(null);
  const [importPreset, setImportPreset] = useState<ImportPreset | null>(null);
  const [readyUpload, setReadyUpload] = useState<TemporaryUploadRecord | null>(null);
  const [confirmClose, setConfirmClose] = useState(false);
  const [discardingUpload, setDiscardingUpload] = useState(false);
  const readOnly = !database.mutations_allowed;

  const closeDialog = () => {
    setDialog(null);
    setImportPreset(null);
    setConfirmClose(false);
  };

  const requestClose = () => {
    if (dialog === 'import' && readyUpload) {
      setConfirmClose(true);
      return;
    }
    closeDialog();
  };

  const discardUpload = async () => {
    if (!readyUpload || !cancellationDeletesUpload(readyUpload.state, false)) return;
    setDiscardingUpload(true);
    try {
      await deleteStagedUpload(server, database.uuid, readyUpload.upload_id);
      setReadyUpload(null);
      closeDialog();
      addToast('Upload discarded.', 'success');
    } catch (cause) {
      addToast(httpErrorToHuman(cause), 'error');
    } finally {
      setDiscardingUpload(false);
    }
  };

  return (
    <Stack mt='md' gap='sm'>
      {readOnly && (
        <Alert color='yellow'>
          {database.mutation_block_reason ||
            'Imports and exports are turned off while this database host is in read-only mode.'}
        </Alert>
      )}

      {!readOnly && (
        <Group justify='space-between' gap='sm'>
          <SegmentedControl
            value={section}
            onChange={(value) => setSection(value as TransferSection)}
            data={[
              { value: 'history', label: 'History' },
              { value: 'files', label: 'Files' },
            ]}
          />
          <Group gap='xs'>
            <ServerCan action='databases-everywhere.import'>
              <Button
                variant='default'
                leftSection={<FontAwesomeIcon icon={faFileArrowUp} />}
                onClick={() => setDialog('import')}
              >
                Import
              </Button>
            </ServerCan>
            <ServerCan action='databases-everywhere.export'>
              <Button leftSection={<FontAwesomeIcon icon={faFileArrowDown} />} onClick={() => setDialog('export')}>
                Export
              </Button>
            </ServerCan>
          </Group>
        </Group>
      )}

      {readOnly || section === 'history' ? (
        <TransferHistory server={server} database={database} readOnly={readOnly} />
      ) : (
        <TransferFiles
          server={server}
          database={database}
          onImport={(id, kind) => {
            setImportPreset(kind === 'upload' ? null : { revision: Date.now(), id, kind });
            setDialog('import');
          }}
        />
      )}

      <Modal opened={dialog === 'export'} onClose={requestClose} title='Export database' size='lg'>
        <TransferComposer
          mode='export'
          server={server}
          database={database}
          onQueued={() => {
            closeDialog();
            setSection('history');
          }}
        />
      </Modal>

      <Modal
        opened={dialog === 'import'}
        onClose={requestClose}
        title={`Import into ${database.display_name}`}
        size='lg'
      >
        <TransferComposer
          mode='import'
          server={server}
          database={database}
          preset={importPreset}
          onReadyUploadChange={setReadyUpload}
          onQueued={() => {
            setReadyUpload(null);
            closeDialog();
            setSection('history');
          }}
        />
      </Modal>

      <Modal opened={confirmClose} onClose={() => setConfirmClose(false)} title='Keep the uploaded file?'>
        <Text>
          <strong>{readyUpload?.original_filename}</strong> is uploaded but not imported yet. Keep it to finish the
          import later, or discard it.
        </Text>
        <ModalFooter>
          <Button color='red' loading={discardingUpload} onClick={() => void discardUpload()}>
            Discard
          </Button>
          <Button variant='default' disabled={discardingUpload} onClick={closeDialog}>
            Keep
          </Button>
        </ModalFooter>
      </Modal>
    </Stack>
  );
}
