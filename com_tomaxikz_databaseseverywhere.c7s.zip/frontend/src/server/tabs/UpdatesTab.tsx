import {
  faArrowsRotate,
  faChevronDown,
  faChevronUp,
  faCircleCheck,
  faCircleUp,
  faCodeBranch,
  faCube,
  faRotate,
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Checkbox, Collapse, Group, SimpleGrid, Stack, Text } from '@mantine/core';
import { useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import Card from '@/elements/data-display/Card.tsx';
import StatCard from '@/elements/data-display/StatCard.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Progress from '@/elements/feedback/Progress.tsx';
import PasswordInput from '@/elements/input/PasswordInput.tsx';
import Select from '@/elements/input/Select.tsx';
import Code from '@/elements/typography/Code.tsx';
import { useToast } from '@/providers/ToastProvider.tsx';
import { databaseCapabilities } from '../../api/capabilities.ts';
import { getDatabaseRuntime, getDatabaseStatus, reconcileDatabase, updateDatabaseImage } from '../../api/client.ts';
import { type DbevMutationFailure, dbevMutationFailure } from '../../api/mutationErrors.ts';
import { dbevQueryKeys } from '../../api/queryKeys.ts';
import type { DatabaseInstallProgress, DatabaseRecord } from '../../api/types.ts';
import translations from '../../translations.ts';
import MutationFailureAlert from '../components/MutationFailureAlert.tsx';
import { databaseActionPolicy } from '../databaseActionPolicy.ts';
import { useDatabaseLiveOverview } from '../useDatabaseWebSockets.ts';

interface Props {
  server: string;
  database: DatabaseRecord;
  onChanged: () => void;
}

function progressMessage(progress: DatabaseInstallProgress): string {
  return progress.diagnostic?.message || progress.message || progress.stage || progress.status || 'Waiting for DBE';
}

function readableStage(stage?: string): string {
  if (!stage) return 'Pending';
  return stage.replaceAll('_', ' ').replace(/^./, (character) => character.toUpperCase());
}

export default function UpdatesTab({ server, database, onChanged }: Props) {
  const { t } = translations.useTranslations();
  const { addToast } = useToast();
  const [action, setAction] = useState<'image' | 'reconcile' | null>(null);
  const [image, setImage] = useState(database.image || '');
  const [majorUpgrade, setMajorUpgrade] = useState(false);
  const [legacyPassword, setLegacyPassword] = useState('');
  const [legacyOpen, setLegacyOpen] = useState(false);
  const [failure, setFailure] = useState<DbevMutationFailure | null>(null);
  const [checkingState, setCheckingState] = useState(false);
  const live = useDatabaseLiveOverview({ server, database: database.uuid, logsEnabled: false });
  const runtimeQuery = useQuery({
    queryKey: dbevQueryKeys.databaseRuntime(server, database.uuid),
    queryFn: () => getDatabaseRuntime(server, database.uuid),
    staleTime: 30_000,
    refetchOnWindowFocus: false,
  });

  const runtime = runtimeQuery.data;
  const currentImage = runtime?.image?.current || database.image || t('server.unknown', {});
  const configuredImage = runtime?.image?.configured || database.image || t('server.unknown', {});
  const databaseVersion = runtime?.database_version?.current || t('server.unknown', {});
  const updateAvailable = runtime?.image?.update_available === true;
  const progress = live.progress;
  const imageProgress = progress && ['image_update', 'major_upgrade'].includes(progress.action || '') ? progress : null;
  const progressRunning = imageProgress?.status === 'running';
  const progressFailed = imageProgress?.status === 'failed';
  const progressValue = progressRunning
    ? typeof imageProgress?.percent === 'number'
      ? imageProgress.percent
      : Number.NaN
    : imageProgress?.status === 'completed'
      ? 100
      : 0;
  const supportsMajorUpgrade = !['redis', 'valkey', 'qdrant'].includes(database.protocol);
  const status = live.instance?.status || database.status;
  const policy = databaseActionPolicy(status);
  const capabilities = databaseCapabilities(database.metadata);
  const allowedImages = Array.from(
    new Set([database.default_image, ...(database.allowed_images ?? [])].filter(Boolean)),
  ) as string[];
  const imageAllowed = allowedImages.includes(image);
  const imageChoices = [
    ...allowedImages.map((value) => ({ value, label: value })),
    ...(!image || imageAllowed
      ? []
      : [{ value: image, label: t('server.imageNoLongerAllowed', { image }), disabled: true }]),
  ];
  const mutationBlocked = !database.mutations_allowed;

  useEffect(() => {
    if (runtime?.image?.configured) setImage(runtime.image.configured);
  }, [runtime?.image?.configured]);

  const run = async (name: 'image' | 'reconcile', operation: () => Promise<unknown>, success: string) => {
    if (mutationBlocked) return;
    setAction(name);
    setFailure(null);
    return await (async () => {
      try {
        await operation();
        addToast(success, 'success');
        await runtimeQuery.refetch();
        onChanged();
      } catch (error) {
        const nextFailure = dbevMutationFailure(error, httpErrorToHuman(error));
        setFailure(nextFailure);
        if (nextFailure.requiresReconciliation) {
          await Promise.allSettled([
            getDatabaseStatus(server, database.uuid),
            runtimeQuery.refetch(),
            Promise.resolve(onChanged()),
          ]);
        }
        if (!nextFailure.retryable) addToast(nextFailure.message, 'error');
      }
    })().finally(() => {
      if (name === 'image') setLegacyPassword('');
      setAction(null);
    });
  };

  const checkStateBeforeRetry = async () => {
    setCheckingState(true);
    return await (async () => {
      try {
        await getDatabaseStatus(server, database.uuid);
        await runtimeQuery.refetch();
        await onChanged();
        setFailure(null);
        addToast(t('server.databaseStateRefreshed', {}), 'success');
      } catch (error) {
        setFailure(dbevMutationFailure(error, httpErrorToHuman(error)));
      }
    })().finally(() => {
      setCheckingState(false);
    });
  };

  return (
    <Stack mt='md'>
      {runtimeQuery.error && <Alert color='red'>{httpErrorToHuman(runtimeQuery.error)}</Alert>}
      {live.monitoring.error && (
        <Alert color='yellow' title={t('server.liveUpdateReconnecting', {})}>
          {live.monitoring.error}
        </Alert>
      )}
      {live.monitoring.state === 'reconnecting' && !live.monitoring.error && (
        <Alert color='blue'>{t('server.agentReconnecting', {})}</Alert>
      )}
      {status === 'stopped' && <Alert color='yellow'>{t('server.imageUpdateRequiresRunning', {})}</Alert>}
      {status === 'quarantined' && (
        <Alert color='red' title={t('server.quarantinedTitle', {})}>
          {t('server.quarantinedDescription', {})}
        </Alert>
      )}
      <MutationFailureAlert failure={failure} checking={checkingState} onCheck={() => void checkStateBeforeRetry()} />

      <div className='grid gap-4 sm:grid-cols-3'>
        <StatCard
          icon={faCube}
          label={t('server.currentImage', {})}
          value={currentImage}
          details={configuredImage !== currentImage ? t('server.configuredDetail', { image: configuredImage }) : null}
        />
        <StatCard icon={faCodeBranch} label={t('server.databaseVersion', {})} value={databaseVersion} />
        <StatCard
          icon={updateAvailable ? faCircleUp : faCircleCheck}
          label={t('server.imageStatus', {})}
          value={updateAvailable ? t('server.updateAvailable', {}) : t('server.upToDate', {})}
        />
      </div>

      {imageProgress && (
        <Card px='lg' py='md'>
          <Stack gap='sm'>
            <Group justify='space-between' wrap='nowrap'>
              <Text fw={600}>{readableStage(imageProgress.stage)}</Text>
              <Text size='sm' c={progressFailed ? 'red' : 'dimmed'}>
                {imageProgress.status || t('server.unknown', {})}
              </Text>
            </Group>
            <Progress
              value={progressValue}
              indeterminate={progressRunning && !Number.isFinite(progressValue)}
              color={progressFailed ? 'red' : imageProgress.status === 'completed' ? 'green' : 'blue'}
            />
            <Text size='sm'>{progressMessage(imageProgress)}</Text>
            {(imageProgress.image || imageProgress.layer) && (
              <Text size='xs' c='dimmed'>
                {imageProgress.image && (
                  <>
                    {t('server.targetImage', {})}: <Code>{imageProgress.image}</Code>
                  </>
                )}
                {imageProgress.image && imageProgress.layer && ' · '}
                {imageProgress.layer && (
                  <>
                    {t('server.imageLayer', {})}: <Code>{imageProgress.layer}</Code>
                  </>
                )}
              </Text>
            )}
          </Stack>
        </Card>
      )}

      <Card px='lg' py='md'>
        <Stack gap='md'>
          <Text fw={600}>{t('server.imageUpdate', {})}</Text>
          <SimpleGrid cols={{ base: 1, md: 2 }} spacing='lg' className='items-end'>
            <Select
              value={image}
              onChange={(value) => value && setImage(value)}
              label={t('server.image', {})}
              description={t('server.imageDescription', {})}
              data={imageChoices}
              searchable
            />
            <div className='flex min-h-9 items-center'>
              <Checkbox
                checked={majorUpgrade}
                disabled={!supportsMajorUpgrade || action !== null || progressRunning}
                onChange={(event) => setMajorUpgrade(event.currentTarget.checked)}
                label={t('server.majorUpgrade', {})}
                description={
                  supportsMajorUpgrade
                    ? t('server.majorUpgradeDescription', {})
                    : t('server.majorUpgradeUnsupported', {})
                }
              />
            </div>
          </SimpleGrid>

          <div>
            <Button
              variant='subtle'
              color='gray'
              size='compact-sm'
              px={0}
              onClick={() => setLegacyOpen((open) => !open)}
              rightSection={<FontAwesomeIcon icon={legacyOpen ? faChevronUp : faChevronDown} />}
            >
              {t('server.legacyAgentCompatibility', {})}
            </Button>
            <Collapse expanded={legacyOpen}>
              <PasswordInput
                mt='sm'
                maw={420}
                value={legacyPassword}
                onChange={(event) => setLegacyPassword(event.currentTarget.value)}
                label={t('server.legacyImagePassword', {})}
                description={
                  capabilities.storedTenantCredentials
                    ? t('server.legacyImagePasswordModernDescription', {})
                    : t('server.legacyImagePasswordOldDescription', {})
                }
                disabled={action !== null || progressRunning || !policy.updateImage}
                maxLength={4096}
                autoComplete='current-password'
              />
            </Collapse>
          </div>

          <Group justify='flex-end' gap='sm'>
            <Button
              variant='default'
              loading={action === 'reconcile'}
              disabled={mutationBlocked || action !== null || progressRunning || !policy.reconcile}
              onClick={() =>
                run('reconcile', () => reconcileDatabase(server, database.uuid), t('server.reconciled', {}))
              }
              leftSection={<FontAwesomeIcon icon={faRotate} />}
            >
              {t('server.reconcile', {})}
            </Button>
            <Button
              loading={action === 'image'}
              disabled={
                mutationBlocked ||
                action !== null ||
                progressRunning ||
                !image.trim() ||
                !imageAllowed ||
                !policy.updateImage
              }
              onClick={() =>
                run(
                  'image',
                  () =>
                    updateDatabaseImage(server, database.uuid, image.trim(), majorUpgrade, legacyPassword || undefined),
                  t('server.imageUpdated', {}),
                )
              }
              leftSection={<FontAwesomeIcon icon={faArrowsRotate} />}
            >
              {t('server.updateDatabase', {})}
            </Button>
          </Group>
        </Stack>
      </Card>
    </Stack>
  );
}
