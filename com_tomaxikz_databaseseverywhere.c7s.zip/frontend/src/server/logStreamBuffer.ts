export type DatabaseLogStream = 'stdout' | 'stderr';

export interface DatabaseLogChunk {
  stream: DatabaseLogStream;
  data: string;
}

export interface DatabaseLogMessage {
  type?: string;
  instance_id?: string;
  runtime_id?: string;
  event?: string;
  sequence?: number;
  stream?: string;
  data?: unknown;
  error?: unknown;
}

export type LogStreamApplyResult =
  | { kind: 'ignored' }
  | { kind: 'reconnect'; reason: string }
  | { kind: 'updated' }
  | { kind: 'ended'; error?: unknown };

const DEFAULT_MAX_CHARACTERS = 256 * 1024;

/** Applies DBEV's incremental log protocol without line-based rewriting. */
export class LogStreamBuffer {
  private chunks: DatabaseLogChunk[] = [];
  private characters = 0;
  private lastSequence = -1;
  private ended = false;

  constructor(private readonly maxCharacters = DEFAULT_MAX_CHARACTERS) {}

  reset() {
    this.chunks = [];
    this.characters = 0;
    this.lastSequence = -1;
    this.ended = false;
  }

  snapshot(): DatabaseLogChunk[] {
    return this.chunks.map((chunk) => ({ ...chunk }));
  }

  apply(message: DatabaseLogMessage): LogStreamApplyResult {
    if (this.ended) return { kind: 'ignored' };
    if (message.type !== 'logs' || !Number.isSafeInteger(message.sequence)) return { kind: 'ignored' };
    const sequence = message.sequence as number;

    if (message.event === 'reset') {
      if (sequence !== 0 || this.lastSequence >= 0) return { kind: 'ignored' };
      this.reset();
      this.lastSequence = 0;
      return { kind: 'updated' };
    }
    if (sequence <= this.lastSequence) return { kind: 'ignored' };
    if (this.lastSequence < 0 || sequence !== this.lastSequence + 1) {
      return { kind: 'reconnect', reason: 'The log stream skipped a sequence.' };
    }

    if (message.event === 'append') {
      if ((message.stream !== 'stdout' && message.stream !== 'stderr') || typeof message.data !== 'string') {
        return { kind: 'ignored' };
      }
      this.lastSequence = sequence;
      if (message.data.length > 0) {
        this.chunks.push({ stream: message.stream, data: message.data });
        this.characters += message.data.length;
        this.trim();
      }
      return { kind: 'updated' };
    }

    if (message.event === 'end') {
      this.lastSequence = sequence;
      this.ended = true;
      return { kind: 'ended', ...(message.error === undefined ? {} : { error: message.error }) };
    }
    return { kind: 'ignored' };
  }

  private trim() {
    while (this.characters > this.maxCharacters && this.chunks.length > 0) {
      const overflow = this.characters - this.maxCharacters;
      const first = this.chunks[0];
      if (first.data.length <= overflow) {
        this.characters -= first.data.length;
        this.chunks.shift();
      } else {
        this.chunks[0] = { ...first, data: first.data.slice(overflow) };
        this.characters -= overflow;
      }
    }
  }
}
