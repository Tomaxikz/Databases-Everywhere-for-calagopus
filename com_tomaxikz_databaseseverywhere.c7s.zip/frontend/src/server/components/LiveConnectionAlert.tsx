import { Text } from '@mantine/core';
import Alert from '@/elements/feedback/Alert.tsx';
import translations from '../../translations.ts';
import { socketAlertState } from '../socketStatus.ts';
import type { SocketConnectionState } from '../websocketConnection.ts';

export default function LiveConnectionAlert({ state, error }: { state: SocketConnectionState; error: string | null }) {
  const { t } = translations.useTranslations();
  const alert = socketAlertState(state, error);
  if (!alert) return null;
  return (
    <Alert color={alert.color} title={t(`websocket.alert.${alert.title}`, {})}>
      {error}
      {!alert.automaticRetry && (
        <Text size='sm' mt='xs'>
          {t('websocket.retryStopped', {})}
        </Text>
      )}
    </Alert>
  );
}
