import { faCopy, faKey } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Group, SimpleGrid, Stack, Text } from '@mantine/core';
import ActionIcon from '@/elements/buttons/ActionIcon.tsx';
import Button from '@/elements/buttons/Button.tsx';
import Card from '@/elements/data-display/Card.tsx';
import PasswordInput from '@/elements/input/PasswordInput.tsx';
import TextInput from '@/elements/input/TextInput.tsx';
import { handleRawCopyToClipboard } from '@/lib/clipboard/copy.ts';
import { useServerCan } from '@/plugins/usePermissions.ts';
import { useToast } from '@/providers/ToastProvider.tsx';
import type { DatabaseRecord } from '../../api/types.ts';
import translations from '../../translations.ts';
import { databaseConnectionValues } from '../databasePresentation.ts';

function ConnectionField({
  label,
  value,
  secret = false,
  unavailable,
}: {
  label: string;
  value: string | null;
  secret?: boolean;
  unavailable: string;
}) {
  const { t } = translations.useTranslations();
  const { addToast } = useToast();
  const copy = value !== null && (
    <ActionIcon
      variant='subtle'
      size='sm'
      aria-label={`${t('common.copy', {})} ${label}`}
      onClick={() => handleRawCopyToClipboard(value, addToast)}
    >
      <FontAwesomeIcon icon={faCopy} />
    </ActionIcon>
  );
  return (
    <Stack gap={6} className='min-w-0'>
      <Group justify='space-between' wrap='nowrap'>
        <Text size='xs' fw={600} c='dimmed'>
          {label}
        </Text>
        {copy}
      </Group>
      {secret && value !== null ? (
        <PasswordInput aria-label={label} value={value} readOnly autoComplete='off' />
      ) : (
        <TextInput aria-label={label} value={value ?? unavailable} readOnly />
      )}
    </Stack>
  );
}

export function DatabaseConnectionFields({ database }: { database: DatabaseRecord }) {
  const { t } = translations.useTranslations();
  const canCredentials = useServerCan('databases-everywhere.credentials');
  const values = databaseConnectionValues(database, canCredentials);
  const qdrant = database.protocol === 'qdrant';
  const host = values.host?.includes(':') && !values.host.startsWith('[') ? `[${values.host}]` : values.host;
  const unavailable = t('common.unavailable', {});
  const secretUnavailable = canCredentials
    ? t('server.credentialUnavailable', {})
    : t('server.credentialsRequired', {});
  return (
    <Stack gap='lg'>
      <SimpleGrid cols={{ base: 1, sm: 2 }} spacing='lg'>
        {!qdrant && (
          <>
            <ConnectionField label={t('server.databaseName', {})} value={values.database} unavailable={unavailable} />
            <ConnectionField label={t('server.username', {})} value={values.username} unavailable={unavailable} />
            <ConnectionField label={t('server.connectionHost', {})} value={values.host} unavailable={unavailable} />
            <ConnectionField label={t('server.connectionPort', {})} value={values.port} unavailable={unavailable} />
          </>
        )}
        {qdrant && (
          <div className='sm:col-span-2'>
            <ConnectionField
              label={t('server.grpcEndpoint', {})}
              value={host && values.port ? `${host}:${values.port}` : null}
              unavailable={unavailable}
            />
          </div>
        )}
        <ConnectionField
          label={database.protocol === 'qdrant' ? t('server.apiKey', {}) : t('server.password', {})}
          value={values.password}
          secret
          unavailable={secretUnavailable}
        />
        <ConnectionField
          label={t('server.tls', {})}
          value={database.tls ? t('server.enabled', {}) : t('server.disabled', {})}
          unavailable={unavailable}
        />
      </SimpleGrid>
      <ConnectionField
        label={t('server.connectionUri', {})}
        value={values.uri}
        secret
        unavailable={secretUnavailable}
      />
    </Stack>
  );
}

export default function DatabaseConnectionDetails({
  database,
  onRotate,
}: {
  database: DatabaseRecord;
  onRotate?: () => void;
}) {
  const { t } = translations.useTranslations();
  return (
    <Card p='lg'>
      <Stack gap='lg'>
        <div>
          <Text fw={600} size='md'>
            {t('server.connectionDetails', {})}
          </Text>
          <Text size='sm' c='dimmed' mt={4}>
            {t('server.credentialsDescription', {})}
          </Text>
        </div>
        <DatabaseConnectionFields database={database} />
        {onRotate && (
          <Group>
            <Button
              variant='default'
              leftSection={<FontAwesomeIcon icon={faKey} />}
              onClick={onRotate}
              disabled={!database.mutations_allowed}
            >
              {database.protocol === 'qdrant' ? t('server.resetApiKey', {}) : t('server.resetPassword', {})}
            </Button>
          </Group>
        )}
      </Stack>
    </Card>
  );
}
