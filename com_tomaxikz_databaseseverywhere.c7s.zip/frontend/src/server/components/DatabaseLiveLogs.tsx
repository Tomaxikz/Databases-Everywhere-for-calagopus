import { ScrollArea, Text } from '@mantine/core';
import { useLayoutEffect, useMemo, useRef } from 'react';
import Card from '@/elements/data-display/Card.tsx';
import Code from '@/elements/typography/Code.tsx';
import translations from '../../translations.ts';
import { LOG_LINE_COLORS, logLineLevel } from '../logLineLevel.ts';
import type { DatabaseLogChunk } from '../logStreamBuffer.ts';

export default function DatabaseLiveLogs({
  chunks,
  error,
  fill = false,
}: {
  chunks: DatabaseLogChunk[];
  error: string | null;
  fill?: boolean;
}) {
  const { t } = translations.useTranslations();
  const viewport = useRef<HTMLDivElement>(null);
  const followOutput = useRef(true);
  const lines = useMemo(
    () =>
      chunks.length
        ? chunks
            .map((chunk) => chunk.data)
            .join('')
            .replace(/\n$/, '')
            .split('\n')
        : [],
    [chunks],
  );

  useLayoutEffect(() => {
    const element = viewport.current;
    if (element && followOutput.current) element.scrollTop = element.scrollHeight;
  }, [lines, error]);

  const updateFollowOutput = () => {
    const element = viewport.current;
    if (!element) return;
    followOutput.current = element.scrollHeight - element.scrollTop - element.clientHeight < 32;
  };

  return (
    <Card p={0} className={fill ? 'flex h-full flex-col overflow-hidden' : 'overflow-hidden'}>
      {error && (
        <Text size='xs' c='red' className='border-b border-(--mantine-color-default-border)' px='md' py='xs'>
          {error}
        </Text>
      )}
      <ScrollArea
        h={fill ? undefined : 360}
        className={fill ? 'min-h-0 flex-1' : undefined}
        type='auto'
        viewportRef={viewport}
        onScrollPositionChange={updateFollowOutput}
      >
        <Code
          block
          p='md'
          className={`${fill ? 'min-h-full' : 'min-h-[22rem]'} whitespace-pre-wrap break-all rounded-none border-0 text-xs`}
        >
          {lines.length
            ? lines.map((line, index) => (
                <div key={index} style={{ color: LOG_LINE_COLORS[logLineLevel(line)] }}>
                  {line || ' '}
                </div>
              ))
            : error || t('server.waitingForLogs', {})}
        </Code>
      </ScrollArea>
    </Card>
  );
}
