import { ScrollArea, Text } from '@mantine/core';
import { useLayoutEffect, useRef } from 'react';
import Badge from '@/elements/data-display/Badge.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Code from '@/elements/typography/Code.tsx';
import translations from '../../translations.ts';
import type { DatabaseLogChunk } from '../logStreamBuffer.ts';
import type { LiveConnectionState } from '../useDatabaseWebSockets.ts';

export default function DatabaseLiveLogs({
  chunks,
  state,
  error,
}: {
  chunks: DatabaseLogChunk[];
  state: LiveConnectionState;
  error: string | null;
}) {
  const { t } = translations.useTranslations();
  const viewport = useRef<HTMLDivElement>(null);
  const followOutput = useRef(true);

  useLayoutEffect(() => {
    const element = viewport.current;
    if (element && followOutput.current) element.scrollTop = element.scrollHeight;
  }, [chunks, error]);

  const updateFollowOutput = () => {
    const element = viewport.current;
    if (!element) return;
    followOutput.current = element.scrollHeight - element.scrollTop - element.clientHeight < 32;
  };

  const displayState = error && state === 'connected' ? 'reconnecting' : state;

  return (
    <TitleCard
      title={t('server.databaseLogs', {})}
      wrapperClassName='p-0!'
      rightSection={
        <Badge
          className='ml-auto'
          color={displayState === 'connected' ? 'green' : displayState === 'unavailable' ? 'red' : 'yellow'}
        >
          {displayState}
        </Badge>
      }
    >
      <Text size='xs' c='dimmed' className='border-b border-(--mantine-color-default-border) px-4 py-2'>
        {t('server.databaseLogsDescription', {})}
      </Text>
      {error && (
        <Text size='xs' c='red' className='border-b border-(--mantine-color-default-border) px-4 py-2'>
          {error}
        </Text>
      )}
      <ScrollArea h={360} type='auto' viewportRef={viewport} onScrollPositionChange={updateFollowOutput}>
        <Code block className='min-h-[22rem] whitespace-pre-wrap break-all rounded-none border-0 p-4 text-xs'>
          {chunks.length
            ? chunks.map((chunk, index) => (
                <span
                  key={index}
                  style={{ color: chunk.stream === 'stderr' ? 'var(--mantine-color-red-3)' : undefined }}
                >
                  {chunk.data}
                </span>
              ))
            : error || t('server.waitingForLogs', {})}
        </Code>
      </ScrollArea>
    </TitleCard>
  );
}
