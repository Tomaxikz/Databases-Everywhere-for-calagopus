import { useEffect, useMemo, useState } from 'react';
import {
  CHART_DELAY,
  CHART_TICK,
  CHART_WINDOW,
  type ChartLegendProps,
  type ChartScale,
  type StreamChartProps,
  type StreamChartSeries,
} from '@/lib/chart.ts';
import { nextChartCeiling, niceCeil } from './snapshotChartScale.ts';

interface Options<T extends { t: number }> {
  points: T[];
  labels: string[];
  values: (point: T) => (number | null)[];
  format: (value: number) => string;
  scale?: ChartScale;
  min?: number;
}

const TICK_COUNT = 3;
const COLORS = 4;
const DASHES = [undefined, '6 4', '2 3', '10 4 2 4'];

export default function useSnapshotChart<T extends { t: number }>({
  points,
  labels,
  values: selectValues,
  format,
  scale = 'decimal',
  min = 0,
}: Options<T>) {
  const [end, setEnd] = useState(() => Date.now() - CHART_DELAY);
  const [ceiling, setCeiling] = useState(0);

  useEffect(() => {
    const interval = window.setInterval(() => setEnd(Date.now() - CHART_DELAY), CHART_TICK);
    return () => window.clearInterval(interval);
  }, []);

  useEffect(() => {
    if (points.length !== 0) return;
    setEnd(Date.now() - CHART_DELAY);
  }, [points.length]);

  const { data, wanted, latestValues } = useMemo(() => {
    const start = end - CHART_WINDOW;
    const visible = points.filter((point) => point.t >= start - 2 * CHART_TICK);
    let peak = 0;

    for (const point of visible) {
      for (const value of selectValues(point)) {
        if (value !== null && value > peak) peak = value;
      }
    }

    return {
      data: visible.map((point) => {
        const row: Record<string, number | null> = { t: point.t };
        selectValues(point).forEach((value, index) => {
          row[`v${index}`] = value;
        });
        return row;
      }),
      wanted: niceCeil(Math.max(min, peak * 1.25), scale),
      latestValues: points.length ? selectValues(points[points.length - 1]) : [],
    };
  }, [end, min, points, scale, selectValues]);

  const yMax = nextChartCeiling(points.length ? ceiling : 0, wanted);
  const ticks = Array.from({ length: TICK_COUNT }, (_, index) => (yMax * index) / (TICK_COUNT - 1));

  // Remember the committed scale without mutating refs while rendering the chart.
  useEffect(() => {
    setCeiling(points.length ? yMax : 0);
  }, [points.length, yMax]);

  const series = useMemo<StreamChartSeries[]>(
    () =>
      labels.map((label, index) => {
        const value = latestValues[index] ?? null;
        return {
          key: `v${index}`,
          label,
          color: `var(--chart-series-${(index % COLORS) + 1})`,
          value,
          formatted: value === null ? null : format(value),
          dash: labels.length > 1 ? DASHES[index % DASHES.length] : undefined,
        };
      }),
    [format, labels, latestValues],
  );

  return {
    props: {
      data,
      domain: [end - CHART_WINDOW, end] as [number, number],
      ticks,
      yMax,
      series,
      format,
    } satisfies StreamChartProps,
    legend: { series } satisfies ChartLegendProps,
    value: series.length === 1 ? series[0].formatted : null,
  };
}
