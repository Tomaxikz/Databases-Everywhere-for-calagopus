import type { ChartScale } from '@/lib/chart.ts';

export function niceCeil(value: number, scale: ChartScale): number {
  if (!Number.isFinite(value) || value <= 0) return scale === 'binary' ? 1024 : 1;
  if (scale === 'binary') return 2 ** Math.ceil(Math.log2(value));

  const magnitude = 10 ** Math.floor(Math.log10(value));
  return ([1, 2, 4, 5, 10].find((step) => magnitude * step >= value) ?? 10) * magnitude;
}

export function nextChartCeiling(previous: number, wanted: number): number {
  return wanted > previous || wanted <= previous / 2 ? wanted : previous || wanted;
}
