import { faHardDrive, faMemory, faMicrochip, faNetworkWired, faPlug } from '@fortawesome/free-solid-svg-icons';
import StatCard from '@/elements/data-display/StatCard.tsx';
import { bytesToString, mbToBytes } from '@/lib/format/size.ts';
import type { DatabaseMonitoringInstance, DatabaseRecord } from '../../api/types.ts';
import translations from '../../translations.ts';
import { databaseSummaryValues } from '../databasePresentation.ts';

export default function DatabaseSummaryStats({
  database,
  instance,
  stacked = false,
}: {
  database: DatabaseRecord;
  instance: DatabaseMonitoringInstance | null;
  stacked?: boolean;
}) {
  const { t } = translations.useTranslations();
  const values = databaseSummaryValues(database, instance);
  const shared = database.deployment_mode === 'shared';
  const unavailable = t('common.unavailable', {});
  const bytes = (value: number | null) => (value === null ? unavailable : bytesToString(value));
  const count = (value: number | null) => (value === null ? '—' : value.toLocaleString());
  const memoryLimit = mbToBytes(database.limits.memory_mib);
  const diskLimit = mbToBytes(database.limits.disk_mib);

  return (
    <div
      className={`grid content-start gap-4 sm:grid-cols-2 ${stacked ? 'xl:grid-cols-1' : shared ? 'xl:grid-cols-3' : 'xl:grid-cols-5'}`}
    >
      {!shared && (
        <StatCard
          icon={faMicrochip}
          label={t('server.summaryCpu', {})}
          value={values.cpuPercent === null ? unavailable : `${values.cpuPercent.toFixed(2)}%`}
          limit={`${Math.round(database.limits.cpu_cores * 100)}%`}
          details={t('server.cpuAllowance', { cores: database.limits.cpu_cores })}
          progress={values.cpuPercent}
          total={database.limits.cpu_cores * 100}
        />
      )}
      {!shared && (
        <StatCard
          icon={faMemory}
          label={t('server.summaryMemory', {})}
          value={bytes(values.memoryBytes)}
          limit={bytesToString(memoryLimit)}
          progress={values.memoryBytes}
          total={memoryLimit}
        />
      )}
      <StatCard
        icon={faHardDrive}
        label={t('server.summaryDisk', {})}
        value={bytes(values.diskBytes)}
        limit={bytesToString(diskLimit)}
        progress={values.diskBytes}
        total={diskLimit}
      />
      <StatCard
        icon={faPlug}
        label={t('server.summaryConnections', {})}
        value={values.connections === null ? unavailable : count(values.connections)}
        details={values.activitySource}
      />
      <StatCard
        icon={faNetworkWired}
        label={t('server.summaryGateway', {})}
        value={t('server.gatewayCounts', { accepted: count(values.accepted), rejected: count(values.rejected) })}
        details={
          values.rxBytes === null && values.txBytes === null
            ? null
            : `RX ${bytes(values.rxBytes)} · TX ${bytes(values.txBytes)}`
        }
      />
    </div>
  );
}
