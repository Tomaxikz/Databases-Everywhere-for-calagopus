import { SimpleGrid, Stack, Text } from '@mantine/core';
import Card from '@/elements/data-display/Card.tsx';
import { bytesToString, mbToBytes } from '@/lib/format/size.ts';
import type { DatabaseMonitoringInstance, DatabaseRecord } from '../../api/types.ts';
import translations from '../../translations.ts';
import { databaseSummaryValues } from '../databasePresentation.ts';

export default function DatabaseSummaryStats({
  database,
  instance,
}: {
  database: DatabaseRecord;
  instance: DatabaseMonitoringInstance | null;
}) {
  const { t } = translations.useTranslations();
  const values = databaseSummaryValues(database, instance);
  const shared = database.deployment_mode === 'shared';
  const unavailable = t('common.unavailable', {});
  const bytes = (value: number | null) => (value === null ? '—' : bytesToString(value));
  const count = (value: number | null) => (value === null ? '—' : value.toLocaleString());
  const cards = [
    ...(shared
      ? []
      : [
          {
            label: t('server.summaryCpu', {}),
            value: values.cpuPercent === null ? unavailable : `${values.cpuPercent.toFixed(2)}%`,
            description: t('server.cpuAllowance', { cores: database.limits.cpu_cores }),
          },
          {
            label: t('server.summaryMemory', {}),
            value: `${bytes(values.memoryBytes)} / ${bytesToString(mbToBytes(database.limits.memory_mib))}`,
            description: t('server.dedicated', {}),
          },
        ]),
    {
      label: t('server.summaryDisk', {}),
      value: `${bytes(values.diskBytes)} / ${bytesToString(mbToBytes(database.limits.disk_mib))}`,
      description: t('server.databaseDiskAllowance', {}),
    },
    {
      label: t('server.summaryConnections', {}),
      value: values.connections === null ? unavailable : count(values.connections),
      description: values.activitySource ?? t('server.noSample', {}),
    },
    {
      label: t('server.summaryGateway', {}),
      value: t('server.gatewayCounts', {
        accepted: count(values.accepted),
        rejected: count(values.rejected),
      }),
      description: `RX ${bytes(values.rxBytes)} · TX ${bytes(values.txBytes)}`,
    },
  ];
  return (
    <SimpleGrid cols={{ base: 1, sm: 2, lg: shared ? 3 : 5 }} spacing='md'>
      {cards.map((card) => (
        <Card key={card.label} p='lg'>
          <Stack gap='xs' className='min-w-0'>
            <Text size='sm' c='dimmed'>
              {card.label}
            </Text>
            <Text fw={600} size='lg' className='tabular-nums'>
              {card.value}
            </Text>
            <Text size='xs' c='dimmed'>
              {card.description}
            </Text>
          </Stack>
        </Card>
      ))}
    </SimpleGrid>
  );
}
