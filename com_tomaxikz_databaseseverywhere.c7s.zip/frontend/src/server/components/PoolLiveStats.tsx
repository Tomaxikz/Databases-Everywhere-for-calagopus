import { faHardDrive, faMemory, faMicrochip, faPowerOff } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useMemo } from 'react';
import ChartBlock from '@/elements/charts/ChartBlock.tsx';
import { formatBytes, formatPercent } from '@/lib/chart.ts';
import { mbToBytes } from '@/lib/format/size.ts';
import type { DbevSharedPool, PoolLimits } from '../../api/types.ts';
import { type PoolChartPoint, type PoolMonitoringSample, poolChartPoints } from '../poolMonitoringSamples.ts';
import StableStreamChart from './StableStreamChart.tsx';
import useSnapshotChart from './useSnapshotChart.ts';

const cpuValues = (point: PoolChartPoint) => [point.cpuPercent];
const memoryValues = (point: PoolChartPoint) => [point.memoryBytes];
const diskValues = (point: PoolChartPoint) => [point.diskBytes];

export default function PoolLiveStats({
  pool,
  samples,
  limits,
}: {
  pool: DbevSharedPool | null;
  samples: PoolMonitoringSample[];
  limits: PoolLimits;
}) {
  const points = useMemo(() => poolChartPoints(samples), [samples]);
  const cpu = useSnapshotChart({
    points,
    labels: ['Pool CPU'],
    values: cpuValues,
    format: formatPercent,
    min: Math.max(100, limits.cpu_cores * 100),
  });
  const memory = useSnapshotChart({
    points,
    labels: ['Pool memory'],
    values: memoryValues,
    format: formatBytes,
    scale: 'binary',
    min: mbToBytes(limits.memory_mib),
  });
  const disk = useSnapshotChart({
    points,
    labels: ['Pool disk'],
    values: diskValues,
    format: formatBytes,
    scale: 'binary',
    min: mbToBytes(limits.disk_mib),
  });
  const last = samples.at(-1);
  const overlay =
    samples.length === 0
      ? 'Waiting for whole-pool metrics'
      : last?.kind === 'gap'
        ? 'Pool metrics are reconnecting'
        : !pool
          ? 'Pool metrics are unavailable'
          : undefined;
  const icon = <FontAwesomeIcon icon={faPowerOff} className='text-2xl' />;
  return (
    <div className='grid min-w-0 grid-cols-1 gap-4 lg:grid-cols-3'>
      <ChartBlock
        icon={<FontAwesomeIcon icon={faMicrochip} />}
        title='Whole-engine CPU'
        value={cpu.value}
        overlayIcon={icon}
        overlayLabel={overlay}
      >
        <StableStreamChart {...cpu.props} />
      </ChartBlock>
      <ChartBlock
        icon={<FontAwesomeIcon icon={faMemory} />}
        title='Whole-engine memory'
        value={memory.value}
        overlayIcon={icon}
        overlayLabel={overlay}
      >
        <StableStreamChart {...memory.props} />
      </ChartBlock>
      <ChartBlock
        icon={<FontAwesomeIcon icon={faHardDrive} />}
        title='Whole-engine disk'
        value={disk.value}
        overlayIcon={icon}
        overlayLabel={overlay}
      >
        <StableStreamChart {...disk.props} />
      </ChartBlock>
    </div>
  );
}
