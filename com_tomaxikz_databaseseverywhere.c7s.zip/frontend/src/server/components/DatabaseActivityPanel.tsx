import { faChartLine } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { AreaChart, ChartTooltip } from '@mantine/charts';
import { Group, SimpleGrid, Stack, Text } from '@mantine/core';
import { useQuery } from '@tanstack/react-query';
import { useMemo } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import Badge from '@/elements/data-display/Badge.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import { databaseActivityChartPoints } from '../../api/activityHistory.ts';
import { getDatabaseActivityHistory } from '../../api/client.ts';
import { dbevQueryKeys } from '../../api/queryKeys.ts';
import type { DatabaseActivity } from '../../api/types.ts';
import translations from '../../translations.ts';

const series = [
  { name: 'forwarded', label: 'Forwarded', color: 'var(--chart-series-1)' },
  { name: 'rejected', label: 'Blocked', color: 'var(--chart-series-2)' },
];

function finite(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function activityCount(activity: DatabaseActivity | null, ...fields: (keyof DatabaseActivity)[]): string {
  for (const field of fields) {
    const value = finite(activity?.[field]);
    if (value !== null) return value.toLocaleString();
  }
  return 'Unavailable';
}

function activityLabel(activity: DatabaseActivity | null, field: 'source' | 'availability'): string {
  const value = activity?.[field];
  return typeof value === 'string' && value.trim() ? value : 'unavailable';
}

function sourceColor(source: string): string {
  if (source === 'exact') return 'green';
  if (source === 'observed') return 'blue';
  if (source === 'partial') return 'yellow';
  return 'gray';
}

function ActivityMetric({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <Text size='xs' c='dimmed'>
        {label}
      </Text>
      <Text fw={600} className='tabular-nums'>
        {value}
      </Text>
    </div>
  );
}

export default function DatabaseActivityPanel({
  server,
  database,
  liveActivity,
  running,
}: {
  server: string;
  database: string;
  liveActivity: DatabaseActivity | null;
  running: boolean;
}) {
  const { t } = translations.useTranslations();
  const historyQuery = useQuery({
    queryKey: dbevQueryKeys.databaseActivityHistory(server, database),
    queryFn: () => getDatabaseActivityHistory(server, database),
    staleTime: 60_000,
    refetchInterval: running ? 60_000 : false,
    refetchOnWindowFocus: false,
  });
  // A null live sample is unavailable, not permission to display an older REST snapshot.
  const activity = liveActivity;
  const source = activityLabel(activity, 'source');
  const availability = activityLabel(activity, 'availability');
  const points = useMemo(() => databaseActivityChartPoints(historyQuery.data ?? { buckets: [] }), [historyQuery.data]);

  return (
    <TitleCard
      title={t('server.activity.title', {})}
      icon={<FontAwesomeIcon icon={faChartLine} />}
      rightSection={
        <Group className='ml-auto' gap='xs'>
          <Badge color={sourceColor(source)}>{t('server.activity.source', { source })}</Badge>
          {availability !== source && (
            <Badge color={sourceColor(availability)}>{t('server.activity.availability', { availability })}</Badge>
          )}
        </Group>
      }
    >
      <Stack gap='md'>
        <Text size='sm' c='dimmed'>
          {t('server.activity.description', {})}
        </Text>
        {historyQuery.error && !activity && points.length === 0 && (
          <Alert color='yellow'>{httpErrorToHuman(historyQuery.error)}</Alert>
        )}
        <SimpleGrid cols={{ base: 1, sm: 3 }}>
          <ActivityMetric
            label={t('server.activity.forwarded', {})}
            value={activityCount(activity, 'forwarded', 'accepted')}
          />
          <ActivityMetric label={t('server.activity.blocked', {})} value={activityCount(activity, 'rejected')} />
          <ActivityMetric label={t('server.activity.connections', {})} value={activityCount(activity, 'connections')} />
        </SimpleGrid>
        {points.length > 0 ? (
          <div className='min-h-64 min-w-0'>
            <AreaChart
              h={256}
              data={points}
              dataKey='t'
              series={series}
              curveType='linear'
              withGradient
              fillOpacity={0.2}
              strokeWidth={2}
              withDots={false}
              connectNulls={false}
              valueFormatter={(value) => Number(value).toLocaleString()}
              xAxisProps={{
                type: 'number',
                domain: ['dataMin', 'dataMax'],
                tickFormatter: (value) =>
                  new Date(Number(value)).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              }}
              yAxisProps={{ allowDecimals: false, domain: [0, 'auto'] }}
              tooltipProps={{
                isAnimationActive: false,
                content: ({ label, payload }) => {
                  const point = points.find((candidate) => candidate.t === Number(label));
                  const timestamp = Number.isFinite(Number(label))
                    ? new Date(Number(label)).toLocaleString()
                    : String(label);
                  const bucket = point ? ` · ${point.durationSeconds}s ${t('server.activity.bucket', {})}` : '';
                  return (
                    <ChartTooltip
                      label={`${timestamp}${bucket}`}
                      payload={payload}
                      series={series}
                      valueFormatter={(value) => Number(value).toLocaleString()}
                    />
                  );
                },
              }}
            />
          </div>
        ) : (
          <Text c='dimmed' ta='center' py='xl'>
            {historyQuery.isPending ? t('server.activity.loadingHistory', {}) : t('server.activity.noHistory', {})}
          </Text>
        )}
        <Group gap='xs'>
          <Badge color='blue'>{t('server.activity.forwardedLegend', {})}</Badge>
          <Badge color='red'>{t('server.activity.blockedLegend', {})}</Badge>
          {points.some((point) => point.gap) && <Badge color='gray'>{t('server.activity.gaps', {})}</Badge>}
        </Group>
      </Stack>
    </TitleCard>
  );
}
