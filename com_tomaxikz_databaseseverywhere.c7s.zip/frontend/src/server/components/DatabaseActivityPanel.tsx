import { faArrowRight, faBan, faChartLine, faPlug } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { AreaChart, ChartTooltip } from '@mantine/charts';
import { Stack, Text } from '@mantine/core';
import { useQuery } from '@tanstack/react-query';
import { useMemo } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import ChartBlock from '@/elements/charts/ChartBlock.tsx';
import ChartLegend from '@/elements/charts/ChartLegend.tsx';
import StatCard from '@/elements/data-display/StatCard.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import { databaseActivityChartPoints } from '../../api/activityHistory.ts';
import { getDatabaseActivityHistory } from '../../api/client.ts';
import { dbevQueryKeys } from '../../api/queryKeys.ts';
import type { DatabaseActivity } from '../../api/types.ts';
import translations from '../../translations.ts';

function finite(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function activityCount(activity: DatabaseActivity | null, ...fields: (keyof DatabaseActivity)[]): number | null {
  for (const field of fields) {
    const value = finite(activity?.[field]);
    if (value !== null) return value;
  }
  return null;
}

export default function DatabaseActivityPanel({
  server,
  database,
  liveActivity,
  running,
}: {
  server: string;
  database: string;
  liveActivity: DatabaseActivity | null;
  running: boolean;
}) {
  const { t } = translations.useTranslations();
  const historyQuery = useQuery({
    queryKey: dbevQueryKeys.databaseActivityHistory(server, database),
    queryFn: () => getDatabaseActivityHistory(server, database),
    staleTime: 60_000,
    refetchInterval: running ? 60_000 : false,
    refetchOnWindowFocus: false,
  });
  // A null live sample is unavailable, not permission to display an older REST snapshot.
  const activity = liveActivity;
  const points = useMemo(() => databaseActivityChartPoints(historyQuery.data ?? { buckets: [] }), [historyQuery.data]);
  const unavailable = t('common.unavailable', {});
  const count = (value: number | null) => (value === null ? unavailable : value.toLocaleString());
  const total = (key: 'forwarded' | 'rejected') => points.reduce((sum, point) => sum + (point[key] ?? 0), 0);

  const series = [
    { name: 'forwarded', label: t('server.activity.forwarded', {}), color: 'var(--chart-series-1)' },
    { name: 'rejected', label: t('server.activity.blocked', {}), color: 'var(--chart-series-2)' },
  ];
  const legend = series.map((entry) => ({
    key: entry.name,
    label: entry.label,
    color: entry.color,
    value: total(entry.name as 'forwarded' | 'rejected'),
    formatted: total(entry.name as 'forwarded' | 'rejected').toLocaleString(),
  }));

  return (
    <Stack gap='md'>
      {historyQuery.error && !activity && points.length === 0 && (
        <Alert color='yellow'>{httpErrorToHuman(historyQuery.error)}</Alert>
      )}
      <div className='grid gap-4 sm:grid-cols-3'>
        <StatCard
          icon={faArrowRight}
          label={t('server.activity.forwarded', {})}
          value={count(activityCount(activity, 'forwarded', 'accepted'))}
        />
        <StatCard
          icon={faBan}
          label={t('server.activity.blocked', {})}
          value={count(activityCount(activity, 'rejected'))}
        />
        <StatCard
          icon={faPlug}
          label={t('server.activity.connections', {})}
          value={count(activityCount(activity, 'connections'))}
        />
      </div>
      <ChartBlock
        icon={<FontAwesomeIcon icon={faChartLine} />}
        title={t('server.activity.title', {})}
        legend={points.length > 0 ? <ChartLegend series={legend} /> : undefined}
      >
        {points.length > 0 ? (
          <AreaChart
            h={240}
            data={points}
            dataKey='t'
            series={series}
            curveType='linear'
            withGradient
            fillOpacity={0.2}
            strokeWidth={2}
            withDots={false}
            withLegend={false}
            connectNulls={false}
            valueFormatter={(value) => Number(value).toLocaleString()}
            xAxisProps={{
              type: 'number',
              domain: ['dataMin', 'dataMax'],
              tickFormatter: (value) =>
                new Date(Number(value)).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            }}
            yAxisProps={{ allowDecimals: false, domain: [0, 'auto'] }}
            tooltipProps={{
              isAnimationActive: false,
              content: ({ label, payload }) => {
                const point = points.find((candidate) => candidate.t === Number(label));
                const timestamp = Number.isFinite(Number(label))
                  ? new Date(Number(label)).toLocaleString()
                  : String(label);
                const bucket = point ? ` · ${point.durationSeconds}s ${t('server.activity.bucket', {})}` : '';
                return (
                  <ChartTooltip
                    label={`${timestamp}${bucket}`}
                    payload={payload}
                    series={series}
                    valueFormatter={(value) => Number(value).toLocaleString()}
                  />
                );
              },
            }}
          />
        ) : (
          <div className='flex h-full min-h-52 items-center justify-center'>
            <Text size='sm' c='dimmed'>
              {historyQuery.isPending ? t('server.activity.loadingHistory', {}) : t('server.activity.noHistory', {})}
            </Text>
          </div>
        )}
      </ChartBlock>
      <Text size='xs' c='dimmed'>
        {t('server.activity.note', {})}
      </Text>
    </Stack>
  );
}
