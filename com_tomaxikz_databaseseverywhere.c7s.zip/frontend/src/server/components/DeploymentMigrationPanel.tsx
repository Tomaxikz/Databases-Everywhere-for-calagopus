import { Group, Stack, Text } from '@mantine/core';
import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, useRef, useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import TitleCard from '@/elements/data-display/TitleCard.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Select from '@/elements/input/Select.tsx';
import { useServerCan } from '@/plugins/usePermissions.ts';
import { useToast } from '@/providers/ToastProvider.tsx';
import { getDeploymentMigration, startDeploymentMigration } from '../../api/client.ts';
import { type DbevMutationFailure, dbevMutationFailure } from '../../api/mutationErrors.ts';
import { getServerPools } from '../../api/sharedPools.ts';
import type { DatabaseRecord, DeploymentMode } from '../../api/types.ts';
import translations from '../../translations.ts';
import { deploymentMigrationRequiresReconciliation, deploymentMigrationStatus } from '../deploymentMigrationState.ts';
import MutationFailureAlert from './MutationFailureAlert.tsx';

const terminal = new Set(['completed', 'failed', 'cancelled', 'manual_intervention']);

function nestedRecord(value: unknown, key: string): Record<string, unknown> | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const nested = (value as Record<string, unknown>)[key];
  return nested && typeof nested === 'object' && !Array.isArray(nested) ? (nested as Record<string, unknown>) : null;
}

function detail(value: Record<string, unknown>): string | null {
  const result = nestedRecord(value, 'result');
  const records = [
    nestedRecord(value, 'migration'),
    result ? nestedRecord(result, 'migration') : null,
    result,
    nestedRecord(value, 'operation'),
    value,
  ];
  for (const record of records) {
    if (!record) continue;
    for (const candidate of [
      record.message,
      record.stage,
      nestedRecord(record, 'diagnostic')?.message,
      nestedRecord(record, 'failure')?.message,
    ]) {
      if (typeof candidate === 'string' && candidate.trim()) return candidate.trim();
    }
  }
  return null;
}

export default function DeploymentMigrationPanel({
  server,
  database,
  onChanged,
}: {
  server: string;
  database: DatabaseRecord;
  onChanged: () => void;
}) {
  const { t } = translations.useTranslations();
  const { addToast } = useToast();
  const canMigrate = useServerCan('databases-everywhere.migrate');
  const [target, setTarget] = useState<DeploymentMode | null>(database.available_migration_targets[0] ?? null);
  const [poolId, setPoolId] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);
  const [checkingState, setCheckingState] = useState(false);
  const [failure, setFailure] = useState<DbevMutationFailure | null>(null);
  const [localMigration, setLocalMigration] = useState<Record<string, unknown> | null>(database.deployment_migration);
  const notifiedTerminal = useRef<string | null>(null);
  const activeStatus = deploymentMigrationStatus(localMigration);
  const needsReconciliation = deploymentMigrationRequiresReconciliation(localMigration);
  const shouldPoll =
    !needsReconciliation && (database.migration_active || Boolean(activeStatus && !terminal.has(activeStatus)));
  const query = useQuery({
    queryKey: ['dbev', server, database.uuid, 'deployment-migration'],
    queryFn: () => getDeploymentMigration(server, database.uuid),
    enabled: shouldPoll,
    refetchInterval: (current) => {
      const migration = current.state.data?.migration;
      const status = deploymentMigrationStatus(migration);
      return deploymentMigrationRequiresReconciliation(migration) || (status && terminal.has(status)) ? false : 2_000;
    },
    retry: false,
  });
  const pools = useQuery({
    queryKey: ['dbev', server, 'migration-pools', database.node_uuid, database.protocol],
    queryFn: () => getServerPools(server),
    enabled: canMigrate && target === 'shared',
    retry: false,
  });
  const destinationPools = useMemo(
    () =>
      (pools.data ?? [])
        .filter((view) => view.pool.node_uuid === database.node_uuid && view.pool.protocol === database.protocol)
        .map((view) => ({
          value: view.pool.runtime_id,
          label: `${view.pool.protocol.toUpperCase()} · ${view.children.length}/${view.pool.limits.max_tenants} databases`,
        })),
    [database.node_uuid, database.protocol, pools.data],
  );

  useEffect(() => setLocalMigration(database.deployment_migration), [database.deployment_migration]);
  useEffect(() => {
    if (query.data?.migration) setLocalMigration(query.data.migration);
  }, [query.data]);
  useEffect(() => {
    if (query.error) setFailure(dbevMutationFailure(query.error, httpErrorToHuman(query.error)));
  }, [query.error]);
  const status = deploymentMigrationStatus(query.data?.migration ?? localMigration);
  useEffect(() => {
    if (!status || !terminal.has(status) || notifiedTerminal.current === status) return;
    notifiedTerminal.current = status;
    onChanged();
  }, [onChanged, status]);

  const choices = useMemo(
    () =>
      database.available_migration_targets.map((mode) => ({
        value: mode,
        label: mode === 'shared' ? t('server.shared', {}) : t('server.dedicated', {}),
      })),
    [database.available_migration_targets, t],
  );
  if (!canMigrate || (choices.length === 0 && !localMigration)) return null;

  const start = async () => {
    if (!target || database.migration_active) return;
    setStarting(true);
    setFailure(null);
    return await (async () => {
      try {
        const response = await startDeploymentMigration(server, database.uuid, target, poolId ?? undefined);
        setLocalMigration(response.migration);
        notifiedTerminal.current = null;
        addToast(t('server.migrationQueued', {}), 'success');
        onChanged();
      } catch (error) {
        const nextFailure = dbevMutationFailure(error, httpErrorToHuman(error));
        setFailure(nextFailure);
        if (!nextFailure.retryable) addToast(nextFailure.message, 'error');
        onChanged();
      }
    })().finally(() => {
      setStarting(false);
    });
  };

  return (
    <TitleCard title={t('server.placementMigration', {})}>
      <Stack gap='sm'>
        <Text size='sm' c='dimmed'>
          {t('server.placementMigrationDescription', {})}
        </Text>
        <MutationFailureAlert
          failure={failure}
          checking={checkingState}
          onCheck={() => {
            setCheckingState(true);
            void query
              .refetch()
              .then((result) => {
                if (result.error) {
                  setFailure(dbevMutationFailure(result.error, httpErrorToHuman(result.error)));
                  return;
                }
                setFailure(null);
                onChanged();
              })
              .catch((error) => setFailure(dbevMutationFailure(error, httpErrorToHuman(error))))
              .finally(() => setCheckingState(false));
          }}
        />
        {localMigration && status && (
          <Alert color={status === 'failed' || status === 'manual_intervention' ? 'red' : 'blue'}>
            {t('server.migrationStatus', { status })}
            {detail(localMigration) ? ` · ${detail(localMigration)}` : ''}
          </Alert>
        )}
        {choices.length > 0 && (
          <Group align='end'>
            <Select
              className='flex-1'
              label={t('server.migrationTarget', {})}
              data={choices}
              value={target}
              onChange={(value) => setTarget((value as DeploymentMode | null) ?? null)}
              disabled={database.migration_active || starting}
            />
            {target === 'shared' && (
              <Select
                className='flex-1'
                label='Existing destination pool'
                placeholder={pools.isLoading ? 'Loading pools…' : 'Select a pool'}
                data={destinationPools}
                value={poolId}
                onChange={setPoolId}
                disabled={database.migration_active || starting || pools.isLoading}
              />
            )}
            <Button
              loading={starting}
              disabled={!target || database.migration_active || (target === 'shared' && !poolId)}
              onClick={() => void start()}
            >
              {t('server.startMigration', {})}
            </Button>
          </Group>
        )}
      </Stack>
    </TitleCard>
  );
}
