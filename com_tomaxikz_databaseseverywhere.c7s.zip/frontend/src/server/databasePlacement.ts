import { supportsPrivateShared } from '../api/capabilities.ts';
import type {
  DatabaseList,
  DatabaseProtocol,
  DeploymentMode,
  DeploymentNodeStatus,
  ResourceLimits,
} from '../api/types.ts';

export function nodeSupportsShared(node: DeploymentNodeStatus, protocol: DatabaseProtocol): boolean {
  return (
    node.error === null &&
    (node.deployment_policy === 'shared_only' || node.deployment_policy === 'hybrid') &&
    supportsPrivateShared(
      { api_version: node.api_version, deployment_capabilities: node.deployment_capabilities },
      protocol,
    )
  );
}

export function sharedPlacementAvailable(
  configuration: DatabaseList,
  protocol: DatabaseProtocol,
  nodeUuid?: string,
): boolean {
  return (
    configuration.provisioning_enabled &&
    configuration.protocol_deployment_modes[protocol]?.includes('shared') === true &&
    (configuration.deployment_nodes ?? []).some(
      (node) =>
        (!nodeUuid || node.node_uuid === nodeUuid) &&
        (!configuration.shared_node_pins?.[protocol] || configuration.shared_node_pins[protocol] === node.node_uuid) &&
        nodeSupportsShared(node, protocol),
    )
  );
}

export function sharedPlacementBlockReason(configuration: DatabaseList, protocol: DatabaseProtocol): string | null {
  if (sharedPlacementAvailable(configuration, protocol)) return null;
  const pin = configuration.shared_node_pins?.[protocol];
  const nodes = (configuration.deployment_nodes ?? []).filter((node) => !pin || node.node_uuid === pin);
  if (!nodes.length)
    return 'Server-private pool support is not confirmed. Refresh node capabilities before using Shared.';
  return nodes
    .map((node) => {
      const source = `${node.api_url} (API ${node.api_version ?? 'unknown'})`;
      if (node.deployment_policy === 'dedicated_only') return `${source}: Shared is disabled by the administrator.`;
      if (node.error) return `${source}: ${node.error}`;
      if (!nodeSupportsShared(node, protocol))
        return `${source}: server-private pool support is not confirmed for ${protocol}.`;
      return `${source}: Shared placement is not currently available.`;
    })
    .join('\n');
}

export function placementQuotaAvailable(configuration: DatabaseList, mode: DeploymentMode): boolean {
  return mode === 'dedicated'
    ? configuration.dedicated_database_usage < configuration.max_dedicated_databases
    : configuration.shared_database_usage < configuration.max_shared_databases;
}

export function protocolsForDeployment(configuration: DatabaseList, mode: DeploymentMode): DatabaseProtocol[] {
  return configuration.protocols.filter(
    (protocol) =>
      configuration.protocol_deployment_modes[protocol]?.includes(mode) &&
      (mode !== 'shared' || sharedPlacementAvailable(configuration, protocol)),
  );
}

export function creationLimitsForDeployment(
  configuration: DatabaseList,
  mode: DeploymentMode,
  protocol: DatabaseProtocol,
): ResourceLimits {
  return (
    configuration.placement_defaults[`${mode}:${protocol}`] ?? {
      cpu_cores: configuration.database_cpu_cores ?? 1,
      memory_mib: configuration.database_memory_mib ?? 1024,
      disk_mib: configuration.database_disk_mib ?? 1024,
    }
  );
}

export function initialDeploymentMode(configuration: DatabaseList): DeploymentMode {
  const available = configuration.available_deployment_modes;
  if (
    available.includes('dedicated') &&
    placementQuotaAvailable(configuration, 'dedicated') &&
    protocolsForDeployment(configuration, 'dedicated').length
  )
    return 'dedicated';
  if (
    available.includes('shared') &&
    placementQuotaAvailable(configuration, 'shared') &&
    protocolsForDeployment(configuration, 'shared').length
  )
    return 'shared';
  return available[0] ?? 'dedicated';
}
