import { poolMetricValue } from '../admin/poolMetrics.ts';
import type { DbevSharedPool } from '../api/types.ts';

const MAX_SAMPLES = 180;

export interface PoolMonitoringSample {
  kind: 'stats' | 'gap';
  receivedAt: number;
  pool: DbevSharedPool | null;
}

export interface PoolChartPoint {
  t: number;
  cpuPercent: number | null;
  memoryBytes: number | null;
  diskBytes: number | null;
}

export function appendPoolSample(samples: PoolMonitoringSample[], sample: PoolMonitoringSample) {
  const next = [...samples, sample];
  return next.length > MAX_SAMPLES ? next.slice(-MAX_SAMPLES) : next;
}

export function poolChartPoints(samples: PoolMonitoringSample[]): PoolChartPoint[] {
  return samples.map((sample) => {
    const resources = sample.kind === 'stats' ? sample.pool : null;
    return {
      t: sample.receivedAt,
      cpuPercent: resources ? poolMetricValue(resources.cpu.usage_percent, resources.cpu.sample) : null,
      memoryBytes: resources ? poolMetricValue(resources.memory.usage_bytes, resources.memory.sample) : null,
      diskBytes: resources ? poolMetricValue(resources.disk.usage_bytes, resources.disk.sample) : null,
    };
  });
}
