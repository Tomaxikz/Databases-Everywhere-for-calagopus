import type { DatabaseInstallProgress, DatabaseRecord, ServerPoolView } from '../api/types.ts';
import { protocolLabels } from '../components/protocols.ts';
import { matchesDatabaseSearch } from './databasePresentation.ts';

export type DatabaseInventoryRow =
  | { kind: 'database'; database: DatabaseRecord }
  | { kind: 'pool'; view: ServerPoolView };

export const poolPagePath = (server: string, runtime: string) =>
  `/server/${server}/databases/pools/${encodeURIComponent(runtime)}`;

export function visiblePoolProgress(progress: DatabaseInstallProgress | null) {
  // Completed operations remain cached, but the pool status already communicates readiness.
  return progress?.status === 'completed' ? null : progress;
}

export function belongsToPool(database: DatabaseRecord, view: ServerPoolView) {
  return (
    database.deployment_mode === 'shared' &&
    database.runtime_id === view.pool.runtime_id &&
    database.node_uuid === view.pool.node_uuid &&
    database.protocol === view.pool.protocol
  );
}

export function databaseInventoryRows(
  server: string,
  databases: DatabaseRecord[],
  pools: ServerPoolView[] | undefined,
  canReadPools: boolean,
  search: string,
): DatabaseInventoryRow[] {
  // Never substitute a cached pool from another server, or hide a child whose
  // parent was not returned. Child-only users must retain their database rows.
  const visiblePools = canReadPools ? (pools ?? []).filter((view) => view.pool.server_id === server) : [];
  const rows: DatabaseInventoryRow[] = databases
    .filter((database) => !visiblePools.some((view) => belongsToPool(database, view)))
    .filter((database) => matchesDatabaseSearch(database, search))
    .map((database) => ({ kind: 'database', database }));
  const needle = search.trim().toLowerCase();
  for (const view of visiblePools) {
    const matches =
      !needle ||
      [view.pool.runtime_id, protocolLabels[view.pool.protocol], 'shared pool'].some((value) =>
        value.toLowerCase().includes(needle),
      ) ||
      [...databases, ...view.children].some(
        (database) => belongsToPool(database, view) && matchesDatabaseSearch(database, search),
      );
    if (matches) rows.push({ kind: 'pool', view });
  }
  return rows;
}
