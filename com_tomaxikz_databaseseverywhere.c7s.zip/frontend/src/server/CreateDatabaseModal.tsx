import { SimpleGrid, Stack, Text } from '@mantine/core';
import { useQueryClient } from '@tanstack/react-query';
import { type FormEvent, useEffect, useMemo, useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import NumberInput from '@/elements/input/NumberInput.tsx';
import Select from '@/elements/input/Select.tsx';
import TextInput from '@/elements/input/TextInput.tsx';
import { Modal, ModalFooter } from '@/elements/modals/Modal.tsx';
import { useToast } from '@/providers/ToastProvider.tsx';
import { createDatabase, listDatabases } from '../api/client.ts';
import { type DbevMutationFailure, dbevMutationFailure } from '../api/mutationErrors.ts';
import type { DatabaseList, DatabaseProtocol, DatabaseRecord, DeploymentMode } from '../api/types.ts';
import { protocolLabels } from '../components/protocols.ts';
import translations from '../translations.ts';
import MutationFailureAlert from './components/MutationFailureAlert.tsx';
import {
  creationLimitsForDeployment,
  initialDeploymentMode,
  placementQuotaAvailable,
  protocolsForDeployment,
  sharedPlacementAvailable,
  sharedPlacementBlockReason,
} from './databasePlacement.ts';
import { databasesEverywhereQueryKey } from './databaseQuery.ts';

interface Props {
  opened: boolean;
  server: string;
  configuration: DatabaseList;
  onClose: () => void;
  onCreated: (database: DatabaseRecord) => void;
}

export default function CreateDatabaseModal({
  opened,
  server,
  configuration: cachedConfiguration,
  onClose,
  onCreated,
}: Props) {
  const { t } = translations.useTranslations();
  const { addToast } = useToast();
  const queryClient = useQueryClient();
  const [freshConfiguration, setFreshConfiguration] = useState<DatabaseList | null>(null);
  const [refresh, setRefresh] = useState(0);
  const configuration = freshConfiguration ?? cachedConfiguration;
  const [loading, setLoading] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [deploymentMode, setDeploymentMode] = useState<DeploymentMode>('dedicated');
  const [protocol, setProtocol] = useState<DatabaseProtocol>('postgres');
  const [databaseName, setDatabaseName] = useState('');
  const [username, setUsername] = useState('');
  const [image, setImage] = useState('');
  const [cpuCores, setCpuCores] = useState(1);
  const [memoryMib, setMemoryMib] = useState(1024);
  const [diskMib, setDiskMib] = useState(1024);
  const [failure, setFailure] = useState<DbevMutationFailure | null>(null);
  const [checkingState, setCheckingState] = useState(false);

  const deploymentModes = (['dedicated', 'shared'] as DeploymentMode[]).filter(
    (mode) =>
      configuration.available_deployment_modes.includes(mode) ||
      configuration.deployment_nodes?.some(
        (node) => node.deployment_policy === 'hybrid' || node.deployment_policy === `${mode}_only`,
      ),
  );
  const showPlacement = deploymentModes.includes('dedicated') && deploymentModes.includes('shared');
  const protocols = useMemo(
    () => protocolsForDeployment(configuration, deploymentMode),
    [configuration, deploymentMode],
  );
  const sharedBlockReason = sharedPlacementBlockReason(configuration, protocol);

  useEffect(() => {
    setFreshConfiguration(null);
    if (!opened) return;
    let cancelled = false;
    setCheckingState(true);
    void listDatabases(server)
      .then((value) => {
        if (cancelled) return;
        setFreshConfiguration(value);
        queryClient.setQueryData(databasesEverywhereQueryKey(server), value);
        setFailure(null);
      })
      .catch((error) => {
        if (!cancelled) setFailure(dbevMutationFailure(error, httpErrorToHuman(error)));
      })
      .finally(() => {
        if (!cancelled) setCheckingState(false);
      });
    return () => {
      cancelled = true;
    };
  }, [opened, server, refresh, queryClient]);

  const applyDefaults = (nextMode: DeploymentMode, nextProtocol: DatabaseProtocol) => {
    const limits = creationLimitsForDeployment(configuration, nextMode, nextProtocol);
    setCpuCores(limits.cpu_cores);
    setMemoryMib(limits.memory_mib);
    setDiskMib(limits.disk_mib);
  };

  useEffect(() => {
    if (!opened) return;
    const nextMode = initialDeploymentMode(configuration);
    const nextProtocol = protocolsForDeployment(configuration, nextMode)[0] ?? configuration.protocols[0] ?? 'postgres';
    setDisplayName('');
    setDeploymentMode(nextMode);
    setProtocol(nextProtocol);
    setDatabaseName('');
    setUsername('');
    setImage('');
    applyDefaults(nextMode, nextProtocol);
    setFailure(null);
  }, [opened, server]);

  useEffect(() => {
    if (!opened || !freshConfiguration) return;
    if (protocolsForDeployment(freshConfiguration, deploymentMode).includes(protocol)) return;
    const nextMode = initialDeploymentMode(freshConfiguration);
    const nextProtocol = protocolsForDeployment(freshConfiguration, nextMode)[0] ?? protocol;
    setDeploymentMode(nextMode);
    setProtocol(nextProtocol);
    setImage('');
    applyDefaults(nextMode, nextProtocol);
  }, [opened, freshConfiguration, deploymentMode, protocol]);

  const quotaAvailable = placementQuotaAvailable(configuration, deploymentMode);
  const validLimits = cpuCores > 0 && memoryMib > 0 && diskMib > 0;
  const canSubmit = Boolean(
    freshConfiguration &&
      !checkingState &&
      configuration.provisioning_enabled &&
      displayName.trim() &&
      protocols.includes(protocol) &&
      quotaAvailable &&
      validLimits,
  );

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!canSubmit) return;
    setLoading(true);
    setFailure(null);
    return await (async () => {
      try {
        const database = await createDatabase(server, {
          protocol,
          deployment_mode: deploymentMode,
          display_name: displayName.trim(),
          database_name: databaseName.trim() || undefined,
          username: username.trim() || undefined,
          image: image.trim() || undefined,
          limits: { cpu_cores: cpuCores, memory_mib: memoryMib, disk_mib: diskMib },
        });
        addToast(t('server.created', {}), 'success');
        onCreated(database);
        onClose();
      } catch (error) {
        const nextFailure = dbevMutationFailure(error, httpErrorToHuman(error));
        setFailure(nextFailure);
        if (!nextFailure.retryable) addToast(nextFailure.message, 'error');
      }
    })().finally(() => {
      setLoading(false);
    });
  };

  return (
    <Modal opened={opened} onClose={onClose} title={t('server.createTitle', {})} size='lg'>
      <form onSubmit={submit}>
        <Stack>
          <MutationFailureAlert
            failure={failure}
            checking={checkingState}
            onCheck={() => setRefresh((value) => value + 1)}
          />
          {showPlacement && (
            <Select
              label={t('server.deploymentMode', {})}
              description={
                freshConfiguration && sharedBlockReason ? sharedBlockReason : t('server.deploymentModeDescription', {})
              }
              value={deploymentMode}
              data={deploymentModes.map((value) => ({
                value,
                label: value === 'dedicated' ? t('server.dedicated', {}) : t('server.shared', {}),
                disabled:
                  !freshConfiguration ||
                  checkingState ||
                  !placementQuotaAvailable(configuration, value) ||
                  protocolsForDeployment(configuration, value).length === 0 ||
                  (value === 'shared' && !sharedPlacementAvailable(configuration, protocol)),
              }))}
              onChange={(value) => {
                if (!value) return;
                const nextMode = value as DeploymentMode;
                const nextProtocol = protocolsForDeployment(configuration, nextMode)[0] ?? protocol;
                setDeploymentMode(nextMode);
                setProtocol(nextProtocol);
                setImage('');
                applyDefaults(nextMode, nextProtocol);
              }}
            />
          )}
          <Button
            variant='default'
            loading={checkingState}
            disabled={loading}
            onClick={() => setRefresh((value) => value + 1)}
          >
            {t('server.refreshNodeCapabilities', {})}
          </Button>
          {!quotaAvailable && (
            <Alert color='yellow'>{t('server.placementQuotaExhausted', { mode: deploymentMode })}</Alert>
          )}
          <SimpleGrid cols={{ base: 1, sm: 2 }}>
            <TextInput
              label={t('server.displayName', {})}
              value={displayName}
              onChange={(event) => setDisplayName(event.currentTarget.value)}
              required
              maxLength={191}
            />
            <Select
              label={t('server.protocol', {})}
              value={protocol}
              onChange={(value) => {
                if (!value) return;
                const nextProtocol = value as DatabaseProtocol;
                setProtocol(nextProtocol);
                setImage('');
                applyDefaults(deploymentMode, nextProtocol);
              }}
              data={protocols.map((value) => ({ value, label: protocolLabels[value] }))}
            />
            <TextInput
              label={t('server.databaseName', {})}
              value={databaseName}
              onChange={(event) => setDatabaseName(event.currentTarget.value)}
              maxLength={63}
            />
            <TextInput
              label={t('server.username', {})}
              value={username}
              onChange={(event) => setUsername(event.currentTarget.value)}
              maxLength={63}
            />
          </SimpleGrid>
          <SimpleGrid cols={{ base: 1, sm: deploymentMode === 'shared' ? 1 : 3 }}>
            {deploymentMode === 'dedicated' && (
              <NumberInput
                label={t('server.cpuCores', {})}
                min={0.01}
                max={1024}
                decimalScale={2}
                step={0.25}
                value={cpuCores}
                onChange={(value) => setCpuCores(Number(value) || 0)}
                required
              />
            )}
            {deploymentMode === 'dedicated' && (
              <NumberInput
                label={t('server.memoryMib', {})}
                min={1}
                max={1_048_576}
                step={128}
                value={memoryMib}
                onChange={(value) => setMemoryMib(Number(value) || 0)}
                required
              />
            )}
            <NumberInput
              label={t('server.diskMib', {})}
              description={deploymentMode === 'shared' ? t('server.sharedResourceDefaults', {}) : undefined}
              min={1}
              step={256}
              value={diskMib}
              onChange={(value) => setDiskMib(Number(value) || 0)}
              required
            />
          </SimpleGrid>
          {(deploymentMode === 'dedicated' || !configuration.shared_pool_ids?.[protocol]) && (
            <Select
              label={t('server.image', {})}
              description={
                deploymentMode === 'shared'
                  ? 'Optional image for the new persistent engine pool. Existing pool images are changed from pool controls.'
                  : t('server.imageDescription', {})
              }
              placeholder={t('server.nodeDefaultImage', {})}
              data={(configuration.image_options[protocol] ?? []).map((value) => ({ value, label: value }))}
              value={image || null}
              onChange={(value) => setImage(value || '')}
              searchable
              clearable
              allowDeselect
            />
          )}
          <Text size='xs' c='dimmed'>
            {deploymentMode === 'shared'
              ? t('server.sharedPlacementDescription', {})
              : t('server.dedicatedPlacementDescription', {})}
          </Text>
        </Stack>
        <ModalFooter>
          <Button type='submit' loading={loading} disabled={!canSubmit}>
            {t('common.create', {})}
          </Button>
          <Button variant='default' onClick={onClose} disabled={loading}>
            {t('common.cancel', {})}
          </Button>
        </ModalFooter>
      </form>
    </Modal>
  );
}
