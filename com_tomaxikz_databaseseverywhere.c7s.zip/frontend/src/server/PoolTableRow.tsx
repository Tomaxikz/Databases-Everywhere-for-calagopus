import { faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Group, Stack, Text } from '@mantine/core';
import { useNavigate } from 'react-router';
import Badge from '@/elements/data-display/Badge.tsx';
import { TableData, TableRow } from '@/elements/data-display/Table.tsx';
import TableLink from '@/elements/data-display/TableLink.tsx';
import { bytesToString, mbToBytes } from '@/lib/format/size.ts';
import { useServerStore } from '@/stores/server.ts';
import type { ServerPoolView } from '../api/types.ts';
import { StatusBadge } from '../components/common.tsx';
import ProtocolIcon from '../components/ProtocolIcon.tsx';
import { protocolLabels } from '../components/protocols.ts';
import translations from '../translations.ts';
import type { DatabaseTableLayout } from './DatabaseTableRow.tsx';
import { poolPagePath } from './poolPresentation.ts';

export default function PoolTableRow({ view, layout }: { view: ServerPoolView; layout: DatabaseTableLayout }) {
  const { t } = translations.useTranslations();
  const server = useServerStore((state) => state.server);
  const navigate = useNavigate();
  const path = poolPagePath(server.uuidShort, view.pool.runtime_id);
  return (
    <TableRow className='cursor-pointer' onClick={() => navigate(path)}>
      <TableData>
        <TableLink to={path}>
          <Group gap='sm' wrap='nowrap'>
            <ProtocolIcon protocol={view.pool.protocol} size={24} />
            <Stack gap={2}>
              <Text fw={500}>{t('poolWorkspace.name', { engine: protocolLabels[view.pool.protocol] })}</Text>
              <Text size='xs' c='dimmed'>
                {t('poolWorkspace.databaseCount', {
                  used: Math.max(view.children.length, view.runtime?.tenant_count ?? 0),
                  max: view.runtime?.max_tenants ?? view.pool.limits.max_tenants,
                })}
              </Text>
            </Stack>
          </Group>
        </TableLink>
      </TableData>
      <TableData>
        <Group gap='xs' wrap='nowrap'>
          <Text>{protocolLabels[view.pool.protocol]}</Text>
          <Badge size='xs' color='cyan' variant='light'>
            {t('poolWorkspace.sharedPool', {})}
          </Badge>
        </Group>
      </TableData>
      <TableData>—</TableData>
      <TableData>{layout === 'agent' ? bytesToString(mbToBytes(view.pool.limits.memory_mib)) : '—'}</TableData>
      <TableData>{bytesToString(mbToBytes(view.pool.limits.disk_mib))}</TableData>
      <TableData>
        <StatusBadge status={view.runtime?.status ?? view.status} />
      </TableData>
      <TableData>
        <FontAwesomeIcon icon={faChevronRight} aria-hidden className='text-(--mantine-color-dimmed)' />
      </TableData>
    </TableRow>
  );
}
