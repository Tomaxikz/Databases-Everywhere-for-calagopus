import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Stack } from '@mantine/core';
import { useQueryClient } from '@tanstack/react-query';
import { useNavigate, useParams } from 'react-router';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/buttons/Button.tsx';
import ServerContentContainer from '@/elements/containers/ServerContentContainer.tsx';
import Alert from '@/elements/feedback/Alert.tsx';
import Spinner from '@/elements/feedback/Spinner.tsx';
import { usePollingResource } from '@/plugins/resource/usePollingResource.ts';
import { useServerCan } from '@/plugins/usePermissions.ts';
import { useServerStore } from '@/stores/server.ts';
import { getServerPool } from '../api/sharedPools.ts';
import translations from '../translations.ts';
import { databasesEverywhereQueryKey, serverHasDatabasesEverywhere } from './databaseQuery.ts';
import PoolWorkspace from './PoolWorkspace.tsx';

export default function PoolViewPage() {
  const { t } = translations.useTranslations();
  const server = useServerStore((state) => state.server);
  const { pool: runtimeId } = useParams<{ pool: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const canRead = useServerCan('databases-everywhere.pools-read');
  const enabled = canRead && serverHasDatabasesEverywhere(server) && !!runtimeId;
  const queryKey = ['extensions', 'com.tomaxikz.databaseseverywhere', 'pools', server.uuid];
  const query = usePollingResource({
    queryKey: [...queryKey, runtimeId],
    queryFn: () => getServerPool(server.uuid, runtimeId!),
    interval: 5_000,
    enabled,
    silent: true,
  });
  const listPath = `/server/${server.uuidShort}/databases`;
  const onChanged = () => {
    void queryClient.invalidateQueries({ queryKey });
    void queryClient.invalidateQueries({ queryKey: databasesEverywhereQueryKey(server.uuid) });
  };
  // The backend checks ownership. Also avoid rendering mismatched/stale route data.
  const view =
    enabled && query.data?.pool.server_id === server.uuid && query.data.pool.runtime_id === runtimeId
      ? query.data
      : null;
  return (
    <ServerContentContainer title={t('poolWorkspace.sharedPool', {})} hideTitleComponent>
      <Stack gap='lg' pb='lg'>
        <div>
          <Button
            variant='default'
            leftSection={<FontAwesomeIcon icon={faArrowLeft} />}
            onClick={() => navigate(listPath)}
          >
            {t('server.backToDatabases', {})}
          </Button>
        </div>
        {!enabled ? (
          <Alert color='red'>{t('poolWorkspace.unavailable', {})}</Alert>
        ) : query.error ? (
          <Alert color='red'>{httpErrorToHuman(query.error)}</Alert>
        ) : query.data && !view ? (
          <Alert color='red'>{t('poolWorkspace.unavailable', {})}</Alert>
        ) : !view ? (
          <Spinner.Centered />
        ) : null}
        {view && (
          <PoolWorkspace
            key={view.pool.runtime_id}
            server={server.uuid}
            view={view}
            onChanged={onChanged}
            onDeleted={() => {
              onChanged();
              navigate(listPath, { replace: true });
            }}
          />
        )}
      </Stack>
    </ServerContentContainer>
  );
}
