import {
  faArrowsRotate,
  faBoxArchive,
  faChartLine,
  faDatabase,
  faFileExport,
  faGear,
  faLink,
  faServer,
  faTerminal,
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { lazy, useState } from 'react';
import { useNavigate } from 'react-router';
import Button from '@/elements/buttons/Button.tsx';
import Spinner from '@/elements/feedback/Spinner.tsx';
import Tabs from '@/elements/layout/Tabs.tsx';
import { useServerCan } from '@/plugins/usePermissions.ts';
import { useServerStore } from '@/stores/server.ts';
import type { DatabaseRecord } from '../api/types.ts';
import translations from '../translations.ts';
import DatabaseConnectionDetails from './components/DatabaseConnectionDetails.tsx';
import DatabaseOverview from './DatabaseOverview.tsx';
import { databaseActionPolicy } from './databaseActionPolicy.ts';
import { poolPagePath } from './poolPresentation.ts';

const DataTab = lazy(() => import('./tabs/DataTab.tsx'));
const ConsoleTab = lazy(() => import('./tabs/ConsoleTab.tsx'));
const TransfersTab = lazy(() => import('./tabs/TransfersTab.tsx'));
const BackupsTab = lazy(() => import('./tabs/BackupsTab.tsx'));
const UpdatesTab = lazy(() => import('./tabs/UpdatesTab.tsx'));

interface Props {
  server: string;
  database: DatabaseRecord;
  onChanged: () => void;
  onDeleted: () => void;
  onRotatePassword: () => void;
}

export default function DatabaseWorkspace(props: Props) {
  const { t } = translations.useTranslations();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<string | null>('overview');
  const serverShort = useServerStore((state) => state.server.uuidShort);
  const canBrowseData = useServerCan('databases-everywhere.data');
  const canUseConsole = useServerCan('databases-everywhere.console');
  const canUseTransfers = useServerCan('databases-everywhere.transfers');
  const canUseBackups = useServerCan('databases-everywhere.backups');
  const canUpdate = useServerCan('databases-everywhere.update');
  const canCredentials = useServerCan('databases-everywhere.credentials');
  const canReadPools = useServerCan('databases-everywhere.pools-read');
  const policy = databaseActionPolicy(props.database.status, {
    deploymentMode: props.database.deployment_mode,
    migrationActive: props.database.migration_active,
  });
  return (
    <DatabaseOverview {...props} overviewActive={activeTab === 'overview'}>
      {(overviewContent, advancedContent) => (
        <Tabs value={activeTab} onChange={setActiveTab} keepMounted={false}>
          <Tabs.List className='flex-nowrap overflow-x-auto'>
            <Tabs.Tab value='overview' leftSection={<FontAwesomeIcon icon={faChartLine} />}>
              {t('server.overview', {})}
            </Tabs.Tab>
            <Tabs.Tab value='connection' leftSection={<FontAwesomeIcon icon={faLink} />}>
              {t('server.connection', {})}
            </Tabs.Tab>
            {canBrowseData && policy.useConnection && (
              <Tabs.Tab value='data' leftSection={<FontAwesomeIcon icon={faDatabase} />}>
                {t('server.data', {})}
              </Tabs.Tab>
            )}
            {canUseConsole && policy.useConnection && props.database.mutations_allowed && (
              <Tabs.Tab value='console' leftSection={<FontAwesomeIcon icon={faTerminal} />}>
                {t('server.console', {})}
              </Tabs.Tab>
            )}
            {canUseTransfers && policy.useConnection && props.database.mutations_allowed && (
              <Tabs.Tab value='transfers' leftSection={<FontAwesomeIcon icon={faFileExport} />}>
                {t('server.transfers', {})}
              </Tabs.Tab>
            )}
            {canUseBackups && (
              <Tabs.Tab value='backups' leftSection={<FontAwesomeIcon icon={faBoxArchive} />}>
                {t('server.backups', {})}
              </Tabs.Tab>
            )}
            {canUpdate && props.database.deployment_mode === 'dedicated' && (
              <Tabs.Tab value='updates' leftSection={<FontAwesomeIcon icon={faArrowsRotate} />}>
                {t('server.updates', {})}
              </Tabs.Tab>
            )}
            <Tabs.Tab value='advanced' leftSection={<FontAwesomeIcon icon={faGear} />}>
              {t('server.advanced', {})}
            </Tabs.Tab>
            {props.database.deployment_mode === 'shared' && canReadPools && (
              <Button
                variant='subtle'
                ml='auto'
                leftSection={<FontAwesomeIcon icon={faServer} />}
                onClick={() => navigate(poolPagePath(serverShort, props.database.runtime_id))}
              >
                {t('poolWorkspace.viewParent', {})}
              </Button>
            )}
          </Tabs.List>
          <Tabs.Panel value='overview' pt='lg'>
            {overviewContent}
          </Tabs.Panel>
          <Tabs.Panel value='connection' pt='lg'>
            <DatabaseConnectionDetails
              database={props.database}
              onRotate={canUpdate && canCredentials && policy.resetCredential ? props.onRotatePassword : undefined}
            />
          </Tabs.Panel>
          <Tabs.Panel value='advanced' pt='lg'>
            {advancedContent}
          </Tabs.Panel>
          {canBrowseData && policy.useConnection && (
            <Tabs.Panel value='data'>
              <Spinner.Suspense className='min-h-40'>
                <DataTab server={props.server} database={props.database} />
              </Spinner.Suspense>
            </Tabs.Panel>
          )}
          {canUseConsole && policy.useConnection && props.database.mutations_allowed && (
            <Tabs.Panel value='console'>
              <Spinner.Suspense className='min-h-40'>
                <ConsoleTab server={props.server} database={props.database} />
              </Spinner.Suspense>
            </Tabs.Panel>
          )}
          {canUseTransfers && policy.useConnection && props.database.mutations_allowed && (
            <Tabs.Panel value='transfers'>
              <Spinner.Suspense className='min-h-40'>
                <TransfersTab server={props.server} database={props.database} />
              </Spinner.Suspense>
            </Tabs.Panel>
          )}
          {canUseBackups && (
            <Tabs.Panel value='backups'>
              <Spinner.Suspense className='min-h-40'>
                <BackupsTab server={props.server} database={props.database} />
              </Spinner.Suspense>
            </Tabs.Panel>
          )}
          {canUpdate && props.database.deployment_mode === 'dedicated' && (
            <Tabs.Panel value='updates'>
              <Spinner.Suspense className='min-h-40'>
                <UpdatesTab server={props.server} database={props.database} onChanged={props.onChanged} />
              </Spinner.Suspense>
            </Tabs.Panel>
          )}
        </Tabs>
      )}
    </DatabaseOverview>
  );
}
