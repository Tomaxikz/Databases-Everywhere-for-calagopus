interface MonitoredDatabase {
  uuid: string;
  node_uuid: string;
  deployment_mode: string;
  status: string;
}

export function databaseMonitoringGroups<T extends MonitoredDatabase>(databases: T[]) {
  const groups: Array<{ key: string; databases: T[] }> = [];
  const byNode = new Map<string, T[]>();
  for (const database of databases) {
    if (database.deployment_mode !== 'dedicated') continue;
    // An unpublished/failed creation must not prevent grants for healthy siblings.
    if (['creating', 'booting', 'failed', 'deleting'].includes(database.status)) {
      groups.push({ key: database.uuid, databases: [database] });
    } else {
      const records = byNode.get(database.node_uuid) ?? [];
      records.push(database);
      byNode.set(database.node_uuid, records);
    }
  }
  for (const [node, records] of byNode) {
    records.sort((a, b) => a.uuid.localeCompare(b.uuid));
    for (let start = 0; start < records.length; start += 256) {
      groups.push({ key: `${node}:${start / 256}`, databases: records.slice(start, start + 256) });
    }
  }
  return groups;
}
