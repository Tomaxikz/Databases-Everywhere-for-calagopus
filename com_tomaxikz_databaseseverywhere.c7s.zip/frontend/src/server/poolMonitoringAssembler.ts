import type { DatabaseInstallProgress, DbevSharedPool } from '../api/types.ts';

export interface PoolMonitoringMessage {
  type?: string;
  sequence?: number;
  sampled_at_unix?: number;
  pool?: DbevSharedPool;
  progress_reset?: boolean;
  install_progress_removed?: string[];
  install_progress?: DatabaseInstallProgress[];
}

export interface PoolMonitoringSnapshot {
  type: 'pool_stats';
  sequence: number;
  sampled_at_unix: number | undefined;
  pool: DbevSharedPool;
  install_progress: DatabaseInstallProgress[];
}

export type PoolMonitoringResult =
  | { kind: 'ignored' }
  | { kind: 'reconnect'; reason: string }
  | { kind: 'complete'; snapshot: PoolMonitoringSnapshot };

function sequenceNumber(value: unknown): number | null {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 1 ? value : null;
}

/** Applies DBEV 0.17 pool snapshots and the runtime-keyed progress delta cache. */
export class PoolMonitoringAssembler {
  private completedSequence: number | null = null;
  private readonly progress = new Map<string, DatabaseInstallProgress>();

  constructor(private readonly runtimeId: string) {}

  reset() {
    this.completedSequence = null;
    this.progress.clear();
  }

  push(message: PoolMonitoringMessage): PoolMonitoringResult {
    if (message.type !== 'pool_stats') return { kind: 'ignored' };
    const sequence = sequenceNumber(message.sequence);
    if (sequence === null || !message.pool || message.pool.runtime_id !== this.runtimeId) {
      return { kind: 'reconnect', reason: 'The pool monitoring stream sent an invalid snapshot.' };
    }
    if (this.completedSequence !== null && sequence <= this.completedSequence) return { kind: 'ignored' };
    if (this.completedSequence !== null && sequence !== this.completedSequence + 1) {
      return { kind: 'reconnect', reason: 'The pool monitoring stream skipped a sequence.' };
    }

    if (this.completedSequence === null && message.progress_reset !== true) {
      return { kind: 'reconnect', reason: 'The first pool snapshot must reset progress.' };
    }
    if (
      (message.install_progress !== undefined && !Array.isArray(message.install_progress)) ||
      (message.install_progress_removed !== undefined &&
        (!Array.isArray(message.install_progress_removed) ||
          message.install_progress_removed.some((id) => id !== this.runtimeId)))
    ) {
      return { kind: 'reconnect', reason: 'The pool stream sent an invalid progress delta.' };
    }
    const updates = message.install_progress ?? [];
    if (updates.some((item) => !item || item.instance_id !== this.runtimeId)) {
      return { kind: 'reconnect', reason: 'Pool progress was keyed to an unexpected runtime.' };
    }
    if (message.progress_reset === true) this.progress.clear();
    for (const id of message.install_progress_removed ?? []) this.progress.delete(id);
    for (const item of updates) this.progress.set(item.instance_id, item);

    this.completedSequence = sequence;
    return {
      kind: 'complete',
      snapshot: {
        type: 'pool_stats',
        sequence,
        sampled_at_unix:
          typeof message.sampled_at_unix === 'number' && Number.isFinite(message.sampled_at_unix)
            ? message.sampled_at_unix
            : undefined,
        pool: message.pool,
        install_progress: [...this.progress.values()],
      },
    };
  }
}
