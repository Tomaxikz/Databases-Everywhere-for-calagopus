import { useQueryClient } from '@tanstack/react-query';
import { Fragment, useMemo } from 'react';
import { getDatabaseStatus } from '../api/client.ts';
import { scannerRestartBlockedState } from '../api/normalizers.ts';
import type { DatabaseList, DatabaseRecord } from '../api/types.ts';
import { databasesEverywhereQueryKey } from './databaseQuery.ts';
import { useDatabaseMonitoringEvents } from './useDatabaseWebSockets.ts';

interface NodeDatabaseGroup {
  node: string;
  databases: DatabaseRecord[];
}

export default function DatabaseListLiveUpdates({
  server,
  databases,
}: {
  server: string;
  databases: DatabaseRecord[];
}) {
  const groups = useMemo(() => {
    const byNode = new Map<string, DatabaseRecord[]>();
    for (const database of databases.filter((database) => database.deployment_mode === 'dedicated')) {
      const current = byNode.get(database.node_uuid) ?? [];
      current.push(database);
      byNode.set(database.node_uuid, current);
    }
    return [...byNode.entries()].map(([node, records]) => ({ node, databases: records }));
  }, [databases]);

  return (
    <Fragment>
      {groups.map((group) => (
        <NodeDatabaseMonitor server={server} group={group} key={group.node} />
      ))}
    </Fragment>
  );
}

function NodeDatabaseMonitor({ server, group }: { server: string; group: NodeDatabaseGroup }) {
  const queryClient = useQueryClient();
  const instances = group.databases.map((database) => database.uuid);

  const markMonitoringStale = (stale: boolean) => {
    const databaseIds = new Set(instances);
    queryClient.setQueryData<DatabaseList>(databasesEverywhereQueryKey(server), (current) => {
      if (!current) return current;
      let changed = false;
      const databases = current.databases.map((database) => {
        if (!databaseIds.has(database.uuid) || database.metadata.panel_monitoring_stale === stale) return database;
        changed = true;
        return {
          ...database,
          metadata: { ...database.metadata, panel_monitoring_stale: stale },
        };
      });
      return changed ? { ...current, databases } : current;
    });
  };

  useDatabaseMonitoringEvents({
    server,
    database: instances[0],
    instances,
    enabled: instances.length > 0,
    onReconnected: async () => {
      await Promise.allSettled(group.databases.map((database) => getDatabaseStatus(server, database.uuid)));
      await queryClient.invalidateQueries({ queryKey: databasesEverywhereQueryKey(server) });
    },
    onDisconnected: () => markMonitoringStale(true),
    onMessage: (message) => {
      if (message.type !== 'stats') return;
      const snapshots = new Map(message.instances.map((instance) => [instance.instance_id, instance]));
      const statuses = new Map(
        message.instances
          .filter((instance) => instance.status)
          .map((instance) => [instance.instance_id, instance.status as string]),
      );
      const progress = new Map((message.install_progress ?? []).map((item) => [item.instance_id, item]));

      queryClient.setQueryData<DatabaseList>(databasesEverywhereQueryKey(server), (current) => {
        if (!current) return current;
        let changed = false;
        const next = current.databases.map((database) => {
          const snapshot = snapshots.get(database.uuid);
          const status = statuses.get(database.uuid);
          const installation = progress.get(database.uuid);
          const hadInstallation = Object.hasOwn(database.metadata, 'creation_progress');
          const scannerRestartBlocked = snapshot?.resources
            ? scannerRestartBlockedState(
                snapshot.resources.disk,
                typeof database.metadata.disk_scanner_restart_blocked === 'boolean'
                  ? database.metadata.disk_scanner_restart_blocked
                  : undefined,
              )
            : undefined;
          const scannerStateChanged =
            scannerRestartBlocked !== undefined &&
            database.metadata.disk_scanner_restart_blocked !== scannerRestartBlocked;
          const staleStateChanged = Boolean(snapshot) && database.metadata.panel_monitoring_stale !== false;
          if (!status && !installation && !hadInstallation && !scannerStateChanged && !staleStateChanged)
            return database;
          const diagnostic = installation?.diagnostic?.message?.trim() || null;
          if (
            (!status || status === database.status) &&
            !installation &&
            !hadInstallation &&
            diagnostic === database.last_error &&
            !scannerStateChanged &&
            !staleStateChanged
          )
            return database;
          changed = true;
          return {
            ...database,
            status: status ?? database.status,
            last_error: diagnostic ?? (status === 'running' ? null : database.last_error),
            metadata:
              installation || hadInstallation || scannerStateChanged || staleStateChanged
                ? (() => {
                    const { creation_progress: _removedProgress, ...metadata } = database.metadata;
                    return {
                      ...metadata,
                      ...(installation ? { creation_progress: installation } : {}),
                      ...(scannerRestartBlocked !== undefined
                        ? { disk_scanner_restart_blocked: scannerRestartBlocked }
                        : {}),
                      ...(snapshot ? { panel_monitoring_stale: false } : {}),
                    };
                  })()
                : database.metadata,
          };
        });
        return changed ? { ...current, databases: next } : current;
      });
    },
  });

  return null;
}
