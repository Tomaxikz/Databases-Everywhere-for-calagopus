import { isAxiosError } from 'axios';
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import { getDatabaseRuntime, getDatabaseStatus, mintDatabaseWebSocketToken } from '../api/client.ts';
import { normalizeDatabaseMonitoringInstances, scannerRestartBlockedState } from '../api/normalizers.ts';
import type { DatabaseInstallProgress, DatabaseMonitoringInstance, DatabaseWebSocketChannel } from '../api/types.ts';
import translations from '../translations.ts';
import { type DatabaseLogChunk, type DatabaseLogMessage, LogStreamBuffer } from './logStreamBuffer.ts';
import { appendMonitoringSample, type DatabaseMonitoringSample } from './monitoringSamples.ts';
import { type CompleteMonitoringSnapshot, MonitoringSnapshotAssembler } from './monitoringSnapshotAssembler.ts';
import {
  connectDbevSocket,
  type SocketConnectionState,
  type SocketIssue,
  type SocketMessageAction,
} from './websocketConnection.ts';

export type LiveConnectionState = SocketConnectionState;

export type MonitoringMessage = CompleteMonitoringSnapshot;

interface ImportExportMessage {
  type?: string;
  jobs?: unknown[];
  job?: unknown;
}

function diagnosticMessage(value: unknown): string | null {
  if (typeof value === 'string') return value.trim() || null;
  if (!value || typeof value !== 'object') return null;

  const diagnostic = value as Record<string, unknown>;
  const message = diagnostic.message ?? diagnostic.error ?? diagnostic.detail ?? diagnostic.cause;
  const text = diagnosticMessage(message);
  if (!text) return null;

  const code = typeof diagnostic.code === 'string' ? diagnostic.code.trim() : '';
  const errorId = typeof diagnostic.error_id === 'string' ? diagnostic.error_id.trim() : '';
  return `${text}${code ? ` [${code}]` : ''}${errorId ? ` (error id: ${errorId})` : ''}`;
}

function useDatabaseSocket(
  server: string,
  database: string,
  channel: DatabaseWebSocketChannel,
  enabled: boolean,
  onMessage: (payload: Record<string, unknown>, receivedAt: number) => SocketMessageAction | void,
  instances?: string[],
  reconnectKey = 0,
  onReconnected?: () => void | Promise<void>,
  onDisconnected?: (receivedAt: number) => void,
  onAttempt?: () => void,
) {
  const { t } = translations.useTranslations();
  const describeIssue = useRef((issue: SocketIssue) => t(`websocket.${issue}`, {}));
  const [state, setState] = useState<LiveConnectionState>(enabled ? 'connecting' : 'unavailable');
  const [error, setError] = useState<string | null>(null);
  const callback = useRef(onMessage);
  const startingCallback = useRef(onAttempt);
  const reconnectedCallback = useRef(onReconnected);
  const disconnectedCallback = useRef(onDisconnected);
  const instanceScope = instances ? [...new Set(instances)].sort().join(',') : '';

  // Socket events must only observe callbacks from a committed render.
  useLayoutEffect(() => {
    describeIssue.current = (issue) => t(`websocket.${issue}`, {});
    callback.current = onMessage;
    startingCallback.current = onAttempt;
    reconnectedCallback.current = onReconnected;
    disconnectedCallback.current = onDisconnected;
  }, [onMessage, onReconnected, onDisconnected, onAttempt, t]);

  useEffect(() => {
    if (!enabled || !server || !database) {
      setState('unavailable');
      setError(null);
      return;
    }

    return connectDbevSocket({
      message: (issue) => describeIssue.current(issue),
      mint: (signal) =>
        mintDatabaseWebSocketToken(
          server,
          database,
          channel,
          instanceScope ? instanceScope.split(',') : undefined,
          signal,
        ),
      monitor: channel === 'monitor',
      onMessage: (payload, receivedAt) => callback.current(payload, receivedAt),
      onState: setState,
      onError: setError,
      onAttempt: () => startingCallback.current?.(),
      onDisconnected: (receivedAt) => disconnectedCallback.current?.(receivedAt),
      onReconnected: () => reconnectedCallback.current?.(),
      classifyError: (cause) => ({
        message: httpErrorToHuman(cause),
        retry: !(isAxiosError(cause) && [401, 403, 404, 409, 422].includes(cause.response?.status ?? 0)),
      }),
    });
  }, [channel, database, enabled, instanceScope, reconnectKey, server]);

  return { state, error };
}

export function useDatabaseMonitoringEvents({
  server,
  database,
  instances,
  enabled = true,
  onMessage,
  onReconnected,
  onDisconnected,
  reconnectKey = 0,
}: {
  server: string;
  database: string;
  instances?: string[];
  enabled?: boolean;
  onMessage: (message: MonitoringMessage, receivedAt: number) => void;
  onReconnected?: () => void | Promise<void>;
  onDisconnected?: (receivedAt: number) => void;
  reconnectKey?: number;
}) {
  const assembler = useRef(new MonitoringSnapshotAssembler());
  const instanceScope = instances ? [...new Set(instances)].sort().join(',') : '';

  useEffect(() => assembler.current.reset(), [database, instanceScope, server]);

  return useDatabaseSocket(
    server,
    database,
    'monitor',
    enabled,
    (raw, receivedAt) => {
      if (raw.type !== 'stats') return { accepted: false };
      if (!Array.isArray(raw.instances))
        return { accepted: false, reconnect: true, error: 'The monitoring stream sent invalid instances.' };
      const result = assembler.current.push({
        ...raw,
        ...(Object.hasOwn(raw, 'instances') ? { instances: normalizeDatabaseMonitoringInstances(raw.instances) } : {}),
      });
      if (result.kind === 'reconnect') return { accepted: false, reconnect: true, error: result.reason };
      if (result.kind !== 'complete') return { accepted: false };
      onMessage(result.snapshot, receivedAt);
      return { accepted: true };
    },
    instances,
    reconnectKey,
    onReconnected,
    (receivedAt) => {
      assembler.current.reset();
      onDisconnected?.(receivedAt);
    },
    () => assembler.current.reset(),
  );
}

export function useDatabaseLiveOverview({
  server,
  database,
  logsEnabled,
  monitoringEnabled = true,
  onStatusChange,
}: {
  server: string;
  database: string;
  logsEnabled: boolean;
  monitoringEnabled?: boolean;
  onStatusChange?: (status: string) => void;
}) {
  const [instance, setInstance] = useState<DatabaseMonitoringInstance | null>(null);
  const [samples, setSamples] = useState<DatabaseMonitoringSample[]>([]);
  const [progress, setProgress] = useState<DatabaseInstallProgress | null>(null);
  const [logs, setLogs] = useState<DatabaseLogChunk[]>([]);
  const [logReconnectKey, setLogReconnectKey] = useState(0);
  const [monitorReconnectKey, setMonitorReconnectKey] = useState(0);
  const instanceRef = useRef<DatabaseMonitoringInstance | null>(null);
  const previousStatus = useRef<string | null>(null);
  const logBuffer = useRef(new LogStreamBuffer());

  useEffect(() => {
    setInstance(null);
    setSamples([]);
    setProgress(null);
    setLogs([]);
    logBuffer.current.reset();
    instanceRef.current = null;
    previousStatus.current = null;
  }, [database, server]);

  const reconnectMonitoring = useCallback(() => {
    setInstance(null);
    setProgress(null);
    setSamples((current) => appendMonitoringSample(current, { kind: 'gap', receivedAt: Date.now(), instance: null }));
    setMonitorReconnectKey((current) => current + 1);
  }, []);
  const reconnectLogs = useCallback(() => setLogReconnectKey((current) => current + 1), []);
  const refreshAfterReconnect = useCallback(async () => {
    const [status] = await Promise.all([getDatabaseStatus(server, database), getDatabaseRuntime(server, database)]);
    if (status.status) onStatusChange?.(status.status);
  }, [database, onStatusChange, server]);

  const monitoring = useDatabaseMonitoringEvents({
    server,
    database,
    instances: [database],
    enabled: monitoringEnabled,
    reconnectKey: monitorReconnectKey,
    onReconnected: refreshAfterReconnect,
    onDisconnected: (receivedAt) => {
      setInstance(null);
      setProgress(null);
      setSamples((current) => appendMonitoringSample(current, { kind: 'gap', receivedAt, instance: null }));
    },
    onMessage: (message, receivedAt) => {
      let next = message.instances?.find((item) => item.instance_id === database) ?? null;
      if (next) {
        const resources = next.resources;
        if (resources) {
          const disk = resources.disk;
          const blocked = scannerRestartBlockedState(
            disk,
            instanceRef.current?.resources?.disk.scanner_restart_blocked,
          );
          if (blocked !== undefined && blocked !== disk.scanner_restart_blocked) {
            next = {
              ...next,
              resources: {
                ...resources,
                disk: { ...disk, scanner_restart_blocked: blocked },
              },
            };
          }
        }

        const nextStatus = next.status ?? null;
        if (logsEnabled && nextStatus === 'running' && previousStatus.current && previousStatus.current !== 'running') {
          reconnectLogs();
        }
        if (nextStatus && nextStatus !== previousStatus.current) onStatusChange?.(nextStatus);
        previousStatus.current = nextStatus;
      } else previousStatus.current = null;

      instanceRef.current = next;
      setInstance(next);
      setSamples((current) => appendMonitoringSample(current, { kind: 'stats', receivedAt, instance: next }));
      setProgress(message.install_progress.find((item) => item.instance_id === database) ?? null);
    },
  });

  const logStream = useDatabaseSocket(
    server,
    database,
    'logs',
    logsEnabled,
    (raw) => {
      const message = raw as DatabaseLogMessage;
      if (message.type !== 'logs' || message.instance_id !== database) return { accepted: false };
      const result = logBuffer.current.apply(message);
      if (result.kind === 'ignored') return { accepted: false };
      if (result.kind === 'reconnect') return { accepted: false, reconnect: true, error: result.reason };
      setLogs(logBuffer.current.snapshot());
      if (result.kind === 'ended') {
        return { stop: true, error: diagnosticMessage(result.error) ?? undefined };
      }
      return { accepted: true };
    },
    undefined,
    logReconnectKey,
    undefined,
    undefined,
    () => {
      logBuffer.current.reset();
      setLogs([]);
    },
  );

  return { instance, samples, progress, logs, monitoring, logStream, reconnectLogs, reconnectMonitoring };
}

export function useImportExportEvents(server: string, database: string, enabled = true) {
  const [jobs, setJobs] = useState<unknown[] | null>(null);
  const socket = useDatabaseSocket(
    server,
    database,
    'import-export',
    enabled,
    (raw) => {
      const message = raw as ImportExportMessage;
      if (message.type === 'import_export_snapshot' && Array.isArray(message.jobs)) {
        setJobs(message.jobs);
        return { accepted: true };
      } else if (message.type === 'import_export_job' && message.job) {
        setJobs((current) => {
          const next = [...(current ?? [])];
          const incoming = message.job as Record<string, unknown>;
          const id = String(incoming.job_id ?? incoming.id ?? '');
          const index = next.findIndex((item) => {
            if (typeof item !== 'object' || item === null) return false;
            const record = item as Record<string, unknown>;
            return String(record.job_id ?? record.id ?? '') === id;
          });
          if (index >= 0) next[index] = message.job;
          else next.unshift(message.job);
          return next;
        });
        return { accepted: true };
      }
      return { accepted: false };
    },
    undefined,
    0,
    async () => {
      await Promise.all([getDatabaseStatus(server, database), getDatabaseRuntime(server, database)]);
    },
  );

  useEffect(() => setJobs(null), [database]);
  return { jobs, ...socket };
}
