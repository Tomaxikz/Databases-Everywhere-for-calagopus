DROP TRIGGER IF EXISTS "com_tomaxikz_dbev_placement_quota"
    ON "public"."com_tomaxikz_databaseseverywhere_databases";
DROP FUNCTION IF EXISTS "public"."com_tomaxikz_dbev_enforce_placement_quota"();
DROP INDEX IF EXISTS "public"."dbev_databases_server_placement_idx";

ALTER TABLE "com_tomaxikz_databaseseverywhere_databases"
    DROP CONSTRAINT IF EXISTS "dbev_databases_migration_target_mode_check",
    DROP CONSTRAINT IF EXISTS "dbev_databases_deployment_mode_check",
    DROP COLUMN IF EXISTS "deployment_migration",
    DROP COLUMN IF EXISTS "migration_target_mode",
    DROP COLUMN IF EXISTS "quota_reserved",
    DROP COLUMN IF EXISTS "runtime_id",
    DROP COLUMN IF EXISTS "deployment_mode";

ALTER TABLE "servers"
    DROP CONSTRAINT IF EXISTS "servers_dbev_max_shared_databases_check",
    DROP CONSTRAINT IF EXISTS "servers_dbev_max_dedicated_databases_check",
    DROP COLUMN IF EXISTS "dbev_max_shared_databases",
    DROP COLUMN IF EXISTS "dbev_max_dedicated_databases";

ALTER TABLE "com_tomaxikz_databaseseverywhere_nodes"
    DROP CONSTRAINT IF EXISTS "dbev_nodes_deployment_policy_check",
    DROP COLUMN IF EXISTS "deployment_policy";

-- Restore the pre-v0.8 cross-provider allowance guard when this migration is
-- rolled back. Without this, rolling back would silently leave database limits
-- unenforced for classic, official DB Agent, and DBEV databases.
CREATE FUNCTION "public"."com_tomaxikz_dbev_enforce_database_limit"()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
DECLARE
    "maximum_databases" integer;
    "used_databases" bigint;
BEGIN
    IF TG_OP = 'UPDATE' AND NEW."server_uuid" IS NOT DISTINCT FROM OLD."server_uuid" THEN
        RETURN NEW;
    END IF;

    SELECT "database_limit"
    INTO "maximum_databases"
    FROM "public"."servers"
    WHERE "uuid" = NEW."server_uuid"
    FOR UPDATE;

    IF "maximum_databases" IS NULL THEN
        RETURN NEW;
    END IF;

    SELECT
        (SELECT COUNT(*) FROM "public"."server_databases" WHERE "server_uuid" = NEW."server_uuid")
        + (SELECT COUNT(*) FROM "public"."server_database_instances" WHERE "server_uuid" = NEW."server_uuid")
        + (SELECT COUNT(*) FROM "public"."com_tomaxikz_databaseseverywhere_databases" WHERE "server_uuid" = NEW."server_uuid")
    INTO "used_databases";

    IF "used_databases" >= "maximum_databases" THEN
        RAISE EXCEPTION USING
            ERRCODE = '23514',
            MESSAGE = 'maximum number of databases reached';
    END IF;

    RETURN NEW;
END;
$function$;

CREATE TRIGGER "com_tomaxikz_dbev_classic_database_limit"
BEFORE INSERT OR UPDATE OF "server_uuid"
ON "public"."server_databases"
FOR EACH ROW
EXECUTE FUNCTION "public"."com_tomaxikz_dbev_enforce_database_limit"();

CREATE TRIGGER "com_tomaxikz_dbev_official_agent_database_limit"
BEFORE INSERT OR UPDATE OF "server_uuid"
ON "public"."server_database_instances"
FOR EACH ROW
EXECUTE FUNCTION "public"."com_tomaxikz_dbev_enforce_database_limit"();

CREATE TRIGGER "com_tomaxikz_dbev_database_limit"
BEFORE INSERT OR UPDATE OF "server_uuid"
ON "public"."com_tomaxikz_databaseseverywhere_databases"
FOR EACH ROW
EXECUTE FUNCTION "public"."com_tomaxikz_dbev_enforce_database_limit"();
