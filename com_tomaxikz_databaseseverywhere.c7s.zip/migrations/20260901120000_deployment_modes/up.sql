DROP TRIGGER IF EXISTS "com_tomaxikz_dbev_database_limit"
    ON "public"."com_tomaxikz_databaseseverywhere_databases";
DROP TRIGGER IF EXISTS "com_tomaxikz_dbev_official_agent_database_limit"
    ON "public"."server_database_instances";
DROP TRIGGER IF EXISTS "com_tomaxikz_dbev_classic_database_limit"
    ON "public"."server_databases";
DROP FUNCTION IF EXISTS "public"."com_tomaxikz_dbev_enforce_database_limit"();

ALTER TABLE "com_tomaxikz_databaseseverywhere_nodes"
    ADD COLUMN "deployment_policy" varchar(32) NOT NULL DEFAULT 'dedicated_only',
    ADD CONSTRAINT "dbev_nodes_deployment_policy_check"
        CHECK ("deployment_policy" IN ('dedicated_only', 'shared_only', 'hybrid'));

ALTER TABLE "servers"
    ADD COLUMN "dbev_max_dedicated_databases" integer,
    ADD COLUMN "dbev_max_shared_databases" integer NOT NULL DEFAULT 0;

UPDATE "servers"
SET "dbev_max_dedicated_databases" = "database_limit"
WHERE "dbev_max_dedicated_databases" IS NULL;

ALTER TABLE "servers"
    ALTER COLUMN "dbev_max_dedicated_databases" SET DEFAULT 0,
    ALTER COLUMN "dbev_max_dedicated_databases" SET NOT NULL,
    ADD CONSTRAINT "servers_dbev_max_dedicated_databases_check"
        CHECK ("dbev_max_dedicated_databases" >= 0),
    ADD CONSTRAINT "servers_dbev_max_shared_databases_check"
        CHECK ("dbev_max_shared_databases" >= 0);

ALTER TABLE "com_tomaxikz_databaseseverywhere_databases"
    ADD COLUMN "deployment_mode" varchar(16) NOT NULL DEFAULT 'dedicated',
    ADD COLUMN "runtime_id" varchar(191),
    ADD COLUMN "quota_reserved" boolean NOT NULL DEFAULT true,
    ADD COLUMN "migration_target_mode" varchar(16),
    ADD COLUMN "deployment_migration" jsonb,
    ADD CONSTRAINT "dbev_databases_deployment_mode_check"
        CHECK ("deployment_mode" IN ('dedicated', 'shared')),
    ADD CONSTRAINT "dbev_databases_migration_target_mode_check"
        CHECK ("migration_target_mode" IS NULL OR "migration_target_mode" IN ('dedicated', 'shared'));

UPDATE "com_tomaxikz_databaseseverywhere_databases"
SET "runtime_id" = "uuid"::text
WHERE "runtime_id" IS NULL;

ALTER TABLE "com_tomaxikz_databaseseverywhere_databases"
    ALTER COLUMN "runtime_id" SET NOT NULL;

CREATE INDEX "dbev_databases_server_placement_idx"
    ON "com_tomaxikz_databaseseverywhere_databases"
        ("server_uuid", "deployment_mode")
    WHERE "quota_reserved" = true;

CREATE FUNCTION "public"."com_tomaxikz_dbev_enforce_placement_quota"()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
DECLARE
    "requested_mode" text;
    "requested_modes" text[] := ARRAY[]::text[];
    "maximum_databases" integer;
    "used_databases" bigint;
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW."quota_reserved" = true THEN
            "requested_modes" := array_append("requested_modes", NEW."deployment_mode");
        END IF;
        IF NEW."migration_target_mode" IS NOT NULL
           AND NEW."migration_target_mode" <> NEW."deployment_mode" THEN
            "requested_modes" := array_append("requested_modes", NEW."migration_target_mode");
        END IF;
    ELSIF NEW."server_uuid" IS DISTINCT FROM OLD."server_uuid" THEN
        IF NEW."quota_reserved" = true THEN
            "requested_modes" := array_append("requested_modes", NEW."deployment_mode");
        END IF;
        IF NEW."migration_target_mode" IS NOT NULL
           AND NEW."migration_target_mode" <> NEW."deployment_mode" THEN
            "requested_modes" := array_append("requested_modes", NEW."migration_target_mode");
        END IF;
    ELSE
        IF NEW."quota_reserved" = true
           AND (OLD."quota_reserved" = false
                OR NEW."deployment_mode" IS DISTINCT FROM OLD."deployment_mode")
           AND NOT (
               OLD."migration_target_mode" IS NOT NULL
               AND NEW."deployment_mode" = OLD."migration_target_mode"
           ) THEN
            "requested_modes" := array_append("requested_modes", NEW."deployment_mode");
        END IF;
        IF NEW."migration_target_mode" IS NOT NULL
           AND NEW."migration_target_mode" IS DISTINCT FROM OLD."migration_target_mode"
           AND NEW."migration_target_mode" <> NEW."deployment_mode" THEN
            "requested_modes" := array_append("requested_modes", NEW."migration_target_mode");
        END IF;
    END IF;

    FOREACH "requested_mode" IN ARRAY "requested_modes"
    LOOP
        SELECT CASE "requested_mode"
            WHEN 'shared' THEN "dbev_max_shared_databases"
            ELSE "dbev_max_dedicated_databases"
        END
        INTO "maximum_databases"
        FROM "public"."servers"
        WHERE "uuid" = NEW."server_uuid"
        FOR UPDATE;

        SELECT COUNT(*)
        INTO "used_databases"
        FROM "public"."com_tomaxikz_databaseseverywhere_databases"
        WHERE "server_uuid" = NEW."server_uuid"
          AND "uuid" IS DISTINCT FROM NEW."uuid"
          AND (
              ("quota_reserved" = true AND "deployment_mode" = "requested_mode")
              OR "migration_target_mode" = "requested_mode"
          );

        IF "used_databases" >= "maximum_databases" THEN
            RAISE EXCEPTION USING
                ERRCODE = '23514',
                MESSAGE = CASE "requested_mode"
                    WHEN 'shared' THEN 'maximum number of shared databases reached'
                    ELSE 'maximum number of dedicated databases reached'
                END;
        END IF;
    END LOOP;

    RETURN NEW;
END;
$function$;

CREATE TRIGGER "com_tomaxikz_dbev_placement_quota"
BEFORE INSERT OR UPDATE OF "server_uuid", "deployment_mode", "quota_reserved", "migration_target_mode"
ON "public"."com_tomaxikz_databaseseverywhere_databases"
FOR EACH ROW
EXECUTE FUNCTION "public"."com_tomaxikz_dbev_enforce_placement_quota"();
