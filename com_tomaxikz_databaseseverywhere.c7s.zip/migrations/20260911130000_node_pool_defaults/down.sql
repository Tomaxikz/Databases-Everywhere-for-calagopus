-- No live pool limits are changed in either migration direction.
ALTER TABLE servers DROP COLUMN dbev_pool_use_node_defaults;
ALTER TABLE com_tomaxikz_databaseseverywhere_nodes
    DROP COLUMN default_pool_cpu_cores,
    DROP COLUMN default_pool_memory_mib,
    DROP COLUMN default_pool_disk_mib,
    DROP COLUMN default_pool_max_databases;
