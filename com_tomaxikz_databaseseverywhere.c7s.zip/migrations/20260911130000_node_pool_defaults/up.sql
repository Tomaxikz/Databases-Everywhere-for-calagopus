-- Panel-side defaults for NEW engine pools, not daemon configuration or live limits.
ALTER TABLE com_tomaxikz_databaseseverywhere_nodes
    ADD COLUMN default_pool_cpu_cores double precision NOT NULL DEFAULT 1
        CHECK (default_pool_cpu_cores BETWEEN 0.01 AND 1024),
    ADD COLUMN default_pool_memory_mib bigint NOT NULL DEFAULT 1024
        CHECK (default_pool_memory_mib BETWEEN 1 AND 1048576),
    ADD COLUMN default_pool_disk_mib bigint NOT NULL DEFAULT 16384
        CHECK (default_pool_disk_mib BETWEEN 1 AND 9007199254740991),
    ADD COLUMN default_pool_max_databases integer NOT NULL DEFAULT 8
        CHECK (default_pool_max_databases BETWEEN 1 AND 1024);

-- Preserve every existing server's explicit allocation. Only new servers inherit
-- unless an administrator deliberately opts an existing server into node defaults.
ALTER TABLE servers
    ADD COLUMN dbev_pool_use_node_defaults boolean NOT NULL DEFAULT false;
ALTER TABLE servers
    ALTER COLUMN dbev_pool_use_node_defaults SET DEFAULT true;
