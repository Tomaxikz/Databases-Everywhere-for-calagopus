ALTER TABLE "com_tomaxikz_databaseseverywhere_shared_pools"
    ADD COLUMN "runtime_id" varchar(1024),
    ADD COLUMN "status_url" text,
    ADD CONSTRAINT "dbev_pool_runtime_pair_check"
        CHECK (("runtime_id" IS NULL) = ("status_url" IS NULL)),
    ADD CONSTRAINT "dbev_pool_status_url_check"
        CHECK ("status_url" IS NULL OR ("status_url" LIKE '/api/%' AND "status_url" NOT LIKE '//%'));

CREATE UNIQUE INDEX "dbev_pool_node_runtime_idx"
    ON "com_tomaxikz_databaseseverywhere_shared_pools" ("dbev_node_uuid", "runtime_id")
    WHERE "runtime_id" IS NOT NULL;
