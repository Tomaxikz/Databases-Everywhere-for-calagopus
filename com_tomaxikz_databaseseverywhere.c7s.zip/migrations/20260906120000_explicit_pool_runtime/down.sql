DROP INDEX IF EXISTS "dbev_pool_node_runtime_idx";

ALTER TABLE "com_tomaxikz_databaseseverywhere_shared_pools"
    DROP CONSTRAINT IF EXISTS "dbev_pool_status_url_check",
    DROP CONSTRAINT IF EXISTS "dbev_pool_runtime_pair_check",
    DROP COLUMN IF EXISTS "status_url",
    DROP COLUMN IF EXISTS "runtime_id";
