DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM com_tomaxikz_databaseseverywhere_shared_pools) THEN
        RAISE EXCEPTION 'migrate and retire server-private pools before removing their ownership metadata';
    END IF;
END $$;
DROP TABLE com_tomaxikz_databaseseverywhere_shared_pools;
DROP FUNCTION com_tomaxikz_dbev_keep_pool_pin();
ALTER TABLE servers DROP COLUMN dbev_pool_cpu_cores, DROP COLUMN dbev_pool_memory_mib,
    DROP COLUMN dbev_pool_disk_mib, DROP COLUMN dbev_pool_max_databases;
DROP TABLE com_tomaxikz_databaseseverywhere_installation;
