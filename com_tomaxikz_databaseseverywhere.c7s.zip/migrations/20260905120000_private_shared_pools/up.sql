CREATE TABLE "com_tomaxikz_databaseseverywhere_installation" (
    singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
    uuid uuid NOT NULL UNIQUE DEFAULT gen_random_uuid()
);
INSERT INTO "com_tomaxikz_databaseseverywhere_installation" (singleton) VALUES (true);

ALTER TABLE servers
    ADD COLUMN dbev_pool_cpu_cores double precision NOT NULL DEFAULT 1 CHECK (dbev_pool_cpu_cores BETWEEN 0.5 AND 1024),
    ADD COLUMN dbev_pool_memory_mib bigint NOT NULL DEFAULT 1024 CHECK (dbev_pool_memory_mib BETWEEN 768 AND 1048576),
    ADD COLUMN dbev_pool_disk_mib bigint NOT NULL DEFAULT 16384 CHECK (dbev_pool_disk_mib BETWEEN 2049 AND 9007199254740991),
    ADD COLUMN dbev_pool_max_databases integer NOT NULL DEFAULT 8 CHECK (dbev_pool_max_databases BETWEEN 1 AND 1024);

CREATE TABLE "com_tomaxikz_databaseseverywhere_shared_pools" (
    server_uuid uuid NOT NULL REFERENCES servers(uuid) ON DELETE CASCADE,
    protocol varchar(32) NOT NULL CHECK (protocol IN ('postgres', 'mysql', 'mariadb', 'mongodb', 'clickhouse')),
    dbev_node_uuid uuid NOT NULL REFERENCES com_tomaxikz_databaseseverywhere_nodes(uuid) ON DELETE RESTRICT,
    cpu_cores double precision NOT NULL CHECK (cpu_cores BETWEEN 0.5 AND 1024),
    memory_mib bigint NOT NULL CHECK (memory_mib BETWEEN 768 AND 1048576),
    disk_mib bigint NOT NULL CHECK (disk_mib BETWEEN 2049 AND 9007199254740991),
    max_databases integer NOT NULL CHECK (max_databases BETWEEN 1 AND 1024),
    created timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (server_uuid, protocol)
);

CREATE FUNCTION com_tomaxikz_dbev_keep_pool_pin() RETURNS trigger LANGUAGE plpgsql AS $function$
BEGIN
    IF NEW.server_uuid IS DISTINCT FROM OLD.server_uuid
       OR NEW.protocol IS DISTINCT FROM OLD.protocol
       OR NEW.dbev_node_uuid IS DISTINCT FROM OLD.dbev_node_uuid THEN
        RAISE EXCEPTION 'shared pool node pin is immutable; use an authorized migration';
    END IF;
    RETURN NEW;
END;
$function$;
CREATE TRIGGER com_tomaxikz_dbev_keep_pool_pin
BEFORE UPDATE ON com_tomaxikz_databaseseverywhere_shared_pools
FOR EACH ROW EXECUTE FUNCTION com_tomaxikz_dbev_keep_pool_pin();
