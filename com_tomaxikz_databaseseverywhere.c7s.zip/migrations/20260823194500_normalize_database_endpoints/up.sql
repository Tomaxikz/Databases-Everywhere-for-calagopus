UPDATE com_tomaxikz_databaseseverywhere_nodes
SET public_host = CASE
        WHEN public_host ~ '^\[[^]]+\]:[0-9]+$'
            THEN regexp_replace(public_host, '^\[([^]]+)\]:[0-9]+$', '\1')
        WHEN public_host ~ '^\[[^]]+\]$'
            THEN regexp_replace(public_host, '^\[([^]]+)\]$', '\1')
        WHEN public_host ~ '^[^:]+:[0-9]+$'
            THEN regexp_replace(public_host, '^([^:]+):[0-9]+$', '\1')
        ELSE public_host
    END,
    updated = now()
WHERE public_host ~ '^\[[^]]+\](?::[0-9]+)?$'
   OR public_host ~ '^[^:]+:[0-9]+$';

UPDATE com_tomaxikz_databaseseverywhere_databases AS database
SET public_host = node.public_host,
    public_port = COALESCE(
        substring(node.configuration -> database.protocol ->> 'bind' FROM ':([0-9]+)$')::integer,
        CASE database.protocol
            WHEN 'postgres' THEN 20020
            WHEN 'mysql' THEN 3308
            WHEN 'mariadb' THEN 20021
            WHEN 'redis' THEN 20022
            WHEN 'mongodb' THEN 20023
            WHEN 'clickhouse' THEN 20024
            WHEN 'qdrant' THEN 20025
            WHEN 'valkey' THEN 20027
            ELSE database.public_port
        END
    ),
    tls = COALESCE(
        (node.configuration -> database.protocol ->> 'tls')::boolean,
        database.tls
    ),
    updated = now()
FROM com_tomaxikz_databaseseverywhere_nodes AS node
WHERE database.dbev_node_uuid = node.uuid
  AND (
      database.public_host IS DISTINCT FROM node.public_host
      OR database.public_port IS DISTINCT FROM COALESCE(
          substring(node.configuration -> database.protocol ->> 'bind' FROM ':([0-9]+)$')::integer,
          database.public_port
      )
      OR database.tls IS DISTINCT FROM COALESCE(
          (node.configuration -> database.protocol ->> 'tls')::boolean,
          database.tls
      )
  );
