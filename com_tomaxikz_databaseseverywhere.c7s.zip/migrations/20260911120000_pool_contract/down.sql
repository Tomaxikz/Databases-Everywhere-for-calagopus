-- Refuse rollback if an allocation falls below the old floors; never clamp user allocations.
ALTER TABLE servers
    DROP CONSTRAINT servers_dbev_pool_cpu_cores_check,
    ADD CONSTRAINT servers_dbev_pool_cpu_cores_check CHECK (dbev_pool_cpu_cores BETWEEN 0.5 AND 1024);

ALTER TABLE servers
    DROP CONSTRAINT servers_dbev_pool_memory_mib_check,
    ADD CONSTRAINT servers_dbev_pool_memory_mib_check CHECK (dbev_pool_memory_mib BETWEEN 768 AND 1048576);

ALTER TABLE servers
    DROP CONSTRAINT servers_dbev_pool_disk_mib_check,
    ADD CONSTRAINT servers_dbev_pool_disk_mib_check CHECK (dbev_pool_disk_mib BETWEEN 2049 AND 9007199254740991);

ALTER TABLE com_tomaxikz_databaseseverywhere_shared_pools
    DROP CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_cpu_cores_check,
    ADD CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_cpu_cores_check CHECK (cpu_cores BETWEEN 0.5 AND 1024);

ALTER TABLE com_tomaxikz_databaseseverywhere_shared_pools
    DROP CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_memory_mib_check,
    ADD CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_memory_mib_check CHECK (memory_mib BETWEEN 768 AND 1048576);

ALTER TABLE com_tomaxikz_databaseseverywhere_shared_pools
    DROP CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_disk_mib_check,
    ADD CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_disk_mib_check CHECK (disk_mib BETWEEN 2049 AND 9007199254740991);

ALTER TABLE com_tomaxikz_databaseseverywhere_shared_pools DROP COLUMN creation_attempted;
