-- Keep existing allocations unchanged. Engine-specific startup floors are checked by DBEV.
ALTER TABLE servers
    DROP CONSTRAINT servers_dbev_pool_cpu_cores_check,
    ADD CONSTRAINT servers_dbev_pool_cpu_cores_check CHECK (dbev_pool_cpu_cores BETWEEN 0.01 AND 1024);

ALTER TABLE servers
    DROP CONSTRAINT servers_dbev_pool_memory_mib_check,
    ADD CONSTRAINT servers_dbev_pool_memory_mib_check CHECK (dbev_pool_memory_mib BETWEEN 1 AND 1048576);

ALTER TABLE servers
    DROP CONSTRAINT servers_dbev_pool_disk_mib_check,
    ADD CONSTRAINT servers_dbev_pool_disk_mib_check CHECK (dbev_pool_disk_mib BETWEEN 1 AND 9007199254740991);

ALTER TABLE com_tomaxikz_databaseseverywhere_shared_pools
    DROP CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_cpu_cores_check,
    ADD CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_cpu_cores_check CHECK (cpu_cores BETWEEN 0.01 AND 1024);

ALTER TABLE com_tomaxikz_databaseseverywhere_shared_pools
    DROP CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_memory_mib_check,
    ADD CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_memory_mib_check CHECK (memory_mib BETWEEN 1 AND 1048576);

ALTER TABLE com_tomaxikz_databaseseverywhere_shared_pools
    DROP CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_disk_mib_check,
    ADD CONSTRAINT com_tomaxikz_databaseseverywhere_shared_pools_disk_mib_check CHECK (disk_mib BETWEEN 1 AND 9007199254740991);

-- Existing unbound mappings may represent an old or ambiguous remote creation.
-- Only freshly inserted mappings may claim a new POST automatically.
ALTER TABLE com_tomaxikz_databaseseverywhere_shared_pools
    ADD COLUMN creation_attempted boolean NOT NULL DEFAULT true;
ALTER TABLE com_tomaxikz_databaseseverywhere_shared_pools
    ALTER COLUMN creation_attempted SET DEFAULT false;
